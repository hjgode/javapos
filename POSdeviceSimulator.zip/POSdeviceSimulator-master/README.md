POSdeviceSimulator
==================

Simulator of JavaPOS devices