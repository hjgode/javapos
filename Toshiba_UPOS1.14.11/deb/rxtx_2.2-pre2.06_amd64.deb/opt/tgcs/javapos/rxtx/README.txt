Open source RxTx libraries are used to provide JavaPOS support for 
RS232 Devices. The necessary libraries, jar file, and source are 
installed in the RxTx directory described below.

RxTx version: 2.2pre2
Location:     http://rxtx.qbang.org/wiki/index.php/Download

RxTx directory:
	\opt\tgcs\javapos\rxtx\jar
	\opt\tgcs\javapos\rxtx\lib

rpm:
        rxtx-2.2-pre2.i586.rpm    (for 32-bit OS)
        rxtx-2.2-pre2.x86_64.rpm  (for 64-bit OS; includes both 32-bit/64-bit so)

Content
	RXTXcomm.jar
	librxtxSerial.so     (required default name)
        javax.comm.properties
	librxtxSerial_x86.so 
        rxtx_source.tar      (source files)
        README.txt

=======================================================================
Application Environment
   OS:  32-bit 
   JVM: 32-bit  
=======================================================================
Install rxtx-2.2-pre2.i586.rpm

=======================================================================
   OS:  64-bit 
   JVM: 64-bit  
      *OR*
   OS:  64-bit 
   JVM: 32-bit
=======================================================================
Install rxtx-2.2-pre2.x86_64.rpm.  

In this case, no additional installation action is needed.  By default, 
OS specific rxtx libraries are installed and symbolic links are created.

=======================================================================
Programming Notes for RxTx usage:   
=======================================================================
* RXTX uses lock files by default Lock files are used to prevent more 
than one program accessing a port at a time. User that executes RxTx 
libraries(i.e. JavaPOS application) should have write permission to 
/var/lock directory.

Action to take:
-Depending on Linux distribution, you must add specific user 
to -uucp- or -lock- group

You can find details at =>
http://rxtx.qbang.org/wiki/index.php/Trouble_shooting#How_can_I_use_Lock_Files_with_rxtx.3F

 * The rxtx libraries have symbolic links in /lib.  Therefore, ensure that
  /usr/lib path is set in LD_LIBRARY_PATH variable.  

   For example  export LD_LIBARY_PATH=/usr/lib:$LD_LIBRARY_PATH

 * Consult the following page for RxTx Trouble shooting information: 
	http://rxtx.qbang.org/wiki/index.php/Trouble_shooting

 * For 32-bit JVM running on 64-bit OS the following considerations
 should be taken into account:

  -> user executing the JavaPOS application should be member of uucp 
  group.

  -> The following additional libraries may be required to execute 
  JavaPOS drivers:
      yum install giflib-4.1.6-9.el7.i686
      yum install libXaw-1.0.12-5.el7.i686
      yum install libXaw-1.0.12-5.el7.x86_64
      yum install libXtst-1.2.2-2.1.el7.i686
      yum install libXft-2.3.2-2.el7.i686 
