/*
 * Module Name:     aipdcs.c
 *
 * Description:     Toshiba RS-485 Driver for Linux
 *
 *  Copyright (C) 2004-2019 Toshiba Global Commerce Solutions, Inc.
 *  All right reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA; Otherwise,
 *  see <http://www.gnu.org/licenses/>.
 *
 *
 * Should you need to contact me, the author, you can do so either by
 * e-mail - mail your message to <gha@toshibagcs.com>.
 */


/* System Headers */
#include <linux/version.h>
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 11, 0)
#include <linux/sched/signal.h>
#elif LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 19)
#include <linux/config.h>
#elif LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 32)
#include <linux/signal.h>
#include <linux/sched.h>
#endif
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/compiler.h>
#include <linux/pci.h>
#include <linux/init.h>
#include <linux/ioport.h>
#include <linux/delay.h>
#include <linux/timer.h>
#include <linux/interrupt.h>
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 11, 0)
#include <linux/uaccess.h>
#else
#include <asm/uaccess.h>
#endif

#if LINUX_VERSION_CODE > KERNEL_VERSION(2, 5, 0)
#include <linux/moduleparam.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#endif
#include <linux/poll.h>
#include <linux/thread_info.h>
#include <linux/cred.h>
#include <linux/cgroup.h>



/* Local Headers */
#include "aipkernel.h"
#include "aipsp700.h"
#include "aipdebug.h"


#define DCS_DRIVER_VERSION 5

typedef struct {
    ushort_t    id_model;
    ushort_t    id_submodel;
    ushort_t    adapter_id;
    short       known_adapter;
    ushort_t    port_count;         /* # of ports (4694 has 1) */
    ushort_t    irq_level;
    ulong_t     int_flags;
    short       rc;
    short       nvram_rc;

    ulong_t     buffer_addr;
    ulong_t     base_io_addr;       /* ISA -> 220, 260, 2A0  */

    volatile uchar_t *p2k_buffer;
    volatile uchar_t *ssb;
    ushort_t    offset_ssb;

    ulong_t     nvram_size;         /* Size of this block of NVRAM */
    ulong_t     nvram_buffer_addr;  /* Buffer location  */
    uchar_t    *nvram;              /* Pointer to memory mapped storage */
    ulong_t     bottum_junk;        /* Size of RAS Junk at the bottom */
    ulong_t     junk_offset;        /* Offset of RAS Junk in page 0 */
    ulong_t     junk_length;        /* Length of RAS Junk in page 0 */
    ulong_t     nvram_page_size;    /* Size of pages in paged NVRAM */
    ulong_t     nvram_pages;        /* Number of pages in paged NVRAM */
    ulong_t     page_reg_offset;    /* I/O Space Offset of page reg */
                                    /*     (NVRAM_PAGED) */
    ushort_t    nvram_map_type;     /* Memory or I/O mapped? */
    AREA_DATA   nvram_area[NUM_AREAS];  /* How NVRAM is divided... */
    struct pci_dev *pcidcs;

    volatile int timer_expired;
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 27)
    pid_t current_pid;              /* process id to send SIGUSR1 signal */
    pid_t current_cd_pid;           /* process id to send SIGUSR1 signal */
#else
    struct pid *current_pid;
    struct pid *current_cd_pid;
#endif
    ushort_t    interrupt_slot;
    ushort_t    interrupt_cd_slot;
    int         board_size;         /* I/O space length */
    ushort_t    open_count;         /* Keep count so that if DevOpen is */
                                    /* called  more than once, we don't */
                                    /* repeat. */
    ushort_t    buffer_read;
    short       sio_available;
    short       nvram_available;
    uchar_t     config_register;

#define MAX_CDEVS 5
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 18)
    struct class  *dev_class;
    struct cdev    cdev[MAX_CDEVS];
    struct device *dev;
    int            dev_count;
    int            major;
    dev_t          dev_number;
#endif
} dcs_adapter;


#define IBM_VENDOR_ID       0x1014
#define SIO_4800_ID         0x0295
#define NVRAMT_SUB_ID       0x031B
#define SIO_4674_ID         0xEFCA
#define SIO_4695_ADAPTER_ID 0xEECF
#define SIO_4695_PLANAR_ID  0xEFCB

#define IBM_4694N           0x0001
#define IBM_4695_ADAPTER    0x0005
#define IBM_4694W           0x0006


#define SIO_4694N_ID_BYTE1 0xFF
#define SIO_4694W_ID_BYTE1 0x34

/* Local Constants */
#define FALSE 0
#define TRUE  1

static const char DEVDRVR_ID[] = "aipdcs";
#define DEFAULT_MAJOR_DEV 245

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 18)
static int aipdcs_major = DEFAULT_MAJOR_DEV;
#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 0)
MODULE_PARM(aipdcs_major, "i");
#elif LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 18)
module_param_named(major, aipdcs_major, int, S_IRUGO | S_IWUSR);
MODULE_PARM_DESC(major, "aipdcs major device number");
#endif

static bool nptl_enabled = FALSE;
static int aipdcs_version = DCS_DRIVER_VERSION;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 0)

module_param_named(nptl, nptl_enabled, bool, S_IRUGO | S_IWUSR);
module_param_named(version, aipdcs_version, int, S_IRUGO);
#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 4, 23)
typedef void irqreturn_t;
#define IRQ_RETVAL(arg)
#endif

/*  Registers for the SIO board */
#define REG_A   0x220      /* NVRAM window starting address */
#define REG_B   0x221      /* Select active Page of the NVRAM  */
#define REG_C   0x222      /* Set the start address of SRAM (4k space) */
#define REG_D   0x223      /* Select the SIO interrrupt 0=IRQ7  1 = IRQ11 */
#define REG_E   0x224      /* Select VGA mmonitor type (write only) */
#define REG_F   0x225      /* Set Flash Memory (write only) */
#define REG_G   0x226      /* Read Flash Memory type (read only) */
#define REG_H   0x227      /* Set Flash Memeory Write Enable/Disable */

#define ISA_4694_BOARD_SIZE  0x8   /* I/O space is 8 bytes */
#define ISA_4674_BOARD_SIZE  0x20  /* I/O space is 32 bytes */
#define PCI_4800_BOARD_SIZE  0x10  /* I/O space is 16 bytes */

#define ID_OFFSET     0xE000
#define NVREAD        0
#define NVWRITE       1

/* Macros needed by function calculate_crc */
#define DL (*((char *) &DX))
#define DH (*(((char *) &DX) + 1))
#define AL (*((char *) &AX))
#define AH (*(((char *) &AX) + 1))


/* Function Prototypes */
static int __init dcs_init(void);
static void __exit dcs_exit(void);
static int dcs_open(struct inode *inode, struct file *file);
static ssize_t dcs_read(struct file *file, char *buf, size_t count,
                        loff_t *ppos);
static ssize_t dcs_write(struct file *file, const char *buf, size_t count,
                         loff_t *ppos);
static int dcs_release(struct inode *inode, struct file *file);
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 36)
static int dcs_ioctl(struct inode *inode, struct file *file,
                     unsigned int cmd, unsigned long arg);
#else
static long dcs_ioctl(struct file *file, unsigned int cmd, unsigned long arg);
#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 19)
static irqreturn_t dcs_pci_interrupt_handler(int irq, void *dev_id,
                                             struct pt_regs *regs);
static irqreturn_t dcs_isa_interrupt_handler(int irq, void *dev_id,
                                             struct pt_regs *regs);
#else
static irqreturn_t dcs_pci_interrupt_handler(int irq, void *dev_id);
static irqreturn_t dcs_isa_interrupt_handler(int irq, void *dev_id);
#endif
static unsigned int dcs_poll(struct file *file, struct poll_table_struct *wait);

static int get_4800_configuration(dcs_adapter *adapter);
static int  get_4800_pci_config(dcs_adapter *adapter, int bar);
static int  get_4800_pci_eeprom(dcs_adapter *adapter, int bar);
static void set_4800_sio_buffer(dcs_adapter *adapter, int bar);
static void set_4800_nvram(dcs_adapter *adapter, int bar);
static void set_4800_cd_defaults(dcs_adapter *adapter);
static int find_4694(dcs_adapter *adapter);
static int find_4674(dcs_adapter *adapter, int addr);
static void turn_off_ok_message(dcs_adapter *adapter);
static int set_interrupt_handler(dcs_adapter *adapter);
static void reset_adapter(dcs_adapter *adapter);
static int get_driver_version(char *buffer);

#if defined(V4690)
static int dcs_nvram_mmap(struct file *file, struct vm_area_struct *vma);
static int set_interrupt_mode_off(dcs_adapter *adapter, char *buffer);
static int return_buffer_noint(dcs_adapter *Adapter, char *buffer);
#endif

/* SIO-specific functions */
static int disable_async_comm(dcs_adapter *adapter, char *buffer);
static int enable_async_comm(dcs_adapter *adapter, char *buffer);
static int get_dcs_info(dcs_adapter *adapter, char *buffer);
static int get_slot_info(dcs_adapter *adapter, char *buffer);
static int get_interrupt_slot(dcs_adapter *adapter, char *buffer);
static int power_on_reset_8051(dcs_adapter *adapter, char *buffer);
static int request_buffer(dcs_adapter *adapter, char *buffer);
static int return_buffer(dcs_adapter *adapter, char *buffer);
static int wait_for_buffer(dcs_adapter *adapter, char *buffer);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 14, 0)
static void dcs_timer_handler(struct timer_list *unused);
#else
static void dcs_timer_handler(unsigned long unused);
#endif

/* NVRAM-specific functions */
static unsigned short calculate_crc(const char *pData, int Length);
static void paged_io(dcs_adapter *adapter, uint32_t nvr, char *mem,
                     uint32_t len, int fWrite);
static void nvram_io(uint32_t nvr, char *mem, uint32_t len,
                     int fWrite);
static void wcr_paged_io(dcs_adapter *adapter, uint32_t nvr, char *mem,
                         uint32_t len,  int fWrite);
static void read_write_nvram_data(dcs_adapter *adapter, char *datarecptr,
                                  uint32_t datareclen, int rwFlag);
static int write_nvram_table(dcs_adapter *adapter);
static int get_nvram_data(dcs_adapter *adapter, char *buffer);
static int query_valid_data_flag(dcs_adapter *adapter, char *buffer);
static int get_vital_product_data(dcs_adapter *adapter, char *buffer);
static int query_nvram_card_type(dcs_adapter *adapter, char *bffer);
static int set_valid_data_flag(dcs_adapter *adapter, char *buffer);
static int reset_valid_data_flag(dcs_adapter *adapter, char *buffer);
static int set_nvram_area_sizes(dcs_adapter *adapter, char *buffer);
static int nvram_read_data(dcs_adapter *adapter, char *buffer);
static int nvram_write_data(dcs_adapter *adapter, char *buffer);

/* PCI Cash Drawer-specific functions */
static int disable_async_cd_comm(dcs_adapter *adapter, char *buffer);
static int enable_async_cd_comm(dcs_adapter *adapter, char *buffer);
static int get_cd_interrupt_slot(dcs_adapter *adapter, char *buffer);
static int set_cash_drawer_interface(dcs_adapter *adapter, char *buffer);
static int get_cash_drawer_status(dcs_adapter *adapter, char *buffer);
static int open_cash_drawer(dcs_adapter *adapter, char *buffer);



/* static global variables  */
static DECLARE_WAIT_QUEUE_HEAD(aipdcs_queue);
static int aipdcs_interrupted = FALSE;
static dcs_adapter  Adapter;

static struct timer_list dcs_timer;

static int intNotHandled = 0;



static const unsigned short LookupTable[] =
{
    0x0000,0x1189,0x2312,0x329B,0x4624,0x57AD,0x6536,0x74BF,
    0x8C48,0x9DC1,0xAF5A,0xBED3,0xCA6C,0xDBE5,0xE97E,0xF8F7,
    0x1081,0x0108,0x3393,0x221A,0x56A5,0x472C,0x75B7,0x643E,
    0x9CC9,0x8D40,0xBFDB,0xAE52,0xDAED,0xCB64,0xF9FF,0xE876,
    0x2102,0x308B,0x0210,0x1399,0x6726,0x76AF,0x4434,0x55BD,
    0xAD4A,0xBCC3,0x8E58,0x9FD1,0xEB6E,0xFAE7,0xC87C,0xD9F5,
    0x3183,0x200A,0x1291,0x0318,0x77A7,0x662E,0x54B5,0x453C,
    0xBDCB,0xAC42,0x9ED9,0x8F50,0xFBEF,0xEA66,0xD8FD,0xC974,
    0x4204,0x538D,0x6116,0x709F,0x0420,0x15A9,0x2732,0x36BB,
    0xCE4C,0xDFC5,0xED5E,0xFCD7,0x8868,0x99E1,0xAB7A,0xBAF3,
    0x5285,0x430C,0x7197,0x601E,0x14A1,0x0528,0x37B3,0x263A,
    0xDECD,0xCF44,0xFDDF,0xEC56,0x98E9,0x8960,0xBBFB,0xAA72,
    0x6306,0x728F,0x4014,0x519D,0x2522,0x34AB,0x0630,0x17B9,
    0xEF4E,0xFEC7,0xCC5C,0xDDD5,0xA96A,0xB8E3,0x8A78,0x9BF1,
    0x7387,0x620E,0x5095,0x411C,0x35A3,0x242A,0x16B1,0x0738,
    0xFFCF,0xEE46,0xDCDD,0xCD54,0xB9EB,0xA862,0x9AF9,0x8B70,
    0x8408,0x9581,0xA71A,0xB693,0xC22C,0xD3A5,0xE13E,0xF0B7,
    0x0840,0x19C9,0x2B52,0x3ADB,0x4E64,0x5FED,0x6D76,0x7CFF,
    0x9489,0x8500,0xB79B,0xA612,0xD2AD,0xC324,0xF1BF,0xE036,
    0x18C1,0x0948,0x3BD3,0x2A5A,0x5EE5,0x4F6C,0x7DF7,0x6C7E,
    0xA50A,0xB483,0x8618,0x9791,0xE32E,0xF2A7,0xC03C,0xD1B5,
    0x2942,0x38CB,0x0A50,0x1BD9,0x6F66,0x7EEF,0x4C74,0x5DFD,
    0xB58B,0xA402,0x9699,0x8710,0xF3AF,0xE226,0xD0BD,0xC134,
    0x39C3,0x284A,0x1AD1,0x0B58,0x7FE7,0x6E6E,0x5CF5,0x4D7C,
    0xC60C,0xD785,0xE51E,0xF497,0x8028,0x91A1,0xA33A,0xB2B3,
    0x4A44,0x5BCD,0x6956,0x78DF,0x0C60,0x1DE9,0x2F72,0x3EFB,
    0xD68D,0xC704,0xF59F,0xE416,0x90A9,0x8120,0xB3BB,0xA232,
    0x5AC5,0x4B4C,0x79D7,0x685E,0x1CE1,0x0D68,0x3FF3,0x2E7A,
    0xE70E,0xF687,0xC41C,0xD595,0xA12A,0xB0A3,0x8238,0x93B1,
    0x6B46,0x7ACF,0x4854,0x59DD,0x2D62,0x3CEB,0x0E70,0x1FF9,
    0xF78F,0xE606,0xD49D,0xC514,0xB1AB,0xA022,0x92B9,0x8330,
    0x7BC7,0x6A4E,0x58D5,0x495C,0x3DE3,0x2C6A,0x1EF1,0x0F78
};


/* The various file operations we support. */
static struct file_operations dcs_fops = {
    .read           = dcs_read,
    .write          = dcs_write,
    .poll           = dcs_poll,
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 36)
    .ioctl          = dcs_ioctl,
#else
    .unlocked_ioctl = dcs_ioctl,
#endif
#if LINUX_VERSION_CODE > KERNEL_VERSION(3, 9, 0)
    .compat_ioctl   = dcs_ioctl,
#endif
    .open           = dcs_open,
    .release        = dcs_release,
#if defined(V4690)
    .mmap           = dcs_nvram_mmap,
#endif
    .owner          = THIS_MODULE,
};

#if !defined(V4690)
static uchar_t POR_MSG[] = {0x04,0x00,0x11,0x60,0x00,0x7A,0x03,0x00,0x40,
                            0x04,0x00,0x22,0x60,0x00,0x7A,0x03,0x00,0x40};
#endif


static int wait_for_pc_done_status(dcs_adapter *adapter, int count, int delay)
{
    int waitcnt = count;
    int rc = RPDONE;

    while ((readb(adapter->ssb) & SSB_PC_DONE) && (waitcnt > 0)) {
        udelay(delay);
        waitcnt--;
    }

    if (waitcnt == 0) {
        aip_warning("SSB_PC_DONE not cleared!\n");

        rc = RPDONE | PC_DONE_NOT_SET;
    }

    return rc;
}


static int wait_for_interrupted(dcs_adapter *adapter, int timeout, int delay)
{
    int rc = RPDONE;

    adapter->timer_expired = FALSE;

    if (timeout > 0) {
        dcs_timer.expires = jiffies + HZ * timeout/1000;
        add_timer(&dcs_timer);

        while (adapter->timer_expired == FALSE) {
            if (readb(adapter->ssb) & SSB_INTERRUPTED) {
                break;
            }
            udelay(delay);
        }
    }

    if (readb(adapter->ssb) & SSB_INTERRUPTED) {
        if (timeout > 0) {
            del_timer(&dcs_timer);
        }

        adapter->timer_expired = FALSE;
    } else {
        rc = RPDONE | RPERR | RPDEV | BLOCK_TIMEOUT;
    }

    return rc;
}


/* dcs_pci_interrupt_handler: Handler for interrupt event
 * ************************************************************************
 *
 *  Function Name:  dcs_pci_interrupt_handler
 *
 *  Purpose:        Handler for interrupt event
 *
 *  Description:    When a device channel interrupt occurs, clear
 *                  SSB_INTERRUPTED and SSB_INTERRUPT_PC_ENABLE and
 *                  signal the process that registered for SIO interrupts.
 *                  For PCI adapters, when a cash drawer interrupt occurs,
 *                  signal the process that registered for CD interrupts.
 *                  For PCI adapters, when any interrupt occurs, clear the
 *                  interrupt status register.
 *
 *  Input:          irq     - interrupt number
 *                  dev_id  - device identifier (same as last arg of request_irq)
 *                  pt_regs - snapshot of processor context prior to int
 *
 *  Output:         None
 *
 * ************************************************************************
 */

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 19)
static irqreturn_t dcs_pci_interrupt_handler(int irq, void *dev_id,
                                             struct pt_regs *regs)
#else
static irqreturn_t dcs_pci_interrupt_handler(int irq, void *dev_id)
#endif
{
    int rc = FALSE;
    uchar_t ssb;
    uchar_t status_reg_a;

    /* Get Status Register A contents, available in I/O space */
    status_reg_a = inb((Adapter.base_io_addr + SP700_ASIC_INTERRUPT_STATUS_REGISTER));

    aip_verbose("Int_Handler -- 4800 (status_reg = %02x)\n", status_reg_a);

    if (Adapter.sio_available != TRUE)
        goto cd_only;

    /* 4800 SIO Interrupt or an interrupt on any other SIO adapter */
    if (status_reg_a & SP700_SIO_INTERRUPT) {
        /* SSB PC_DONE bit must be cleared before we set
         * access the SSB.
         */
        wait_for_pc_done_status(&Adapter, 1000, 1000);

        ssb = readb(Adapter.ssb);

        if ((SSB_INTERRUPTED | SSB_INTERRUPT_PC_ENABLE) ==
            (ssb & (SSB_INTERRUPTED | SSB_INTERRUPT_PC_ENABLE))) {
            aip_dbg("Int_Handler: SSB_INTERRUPTED\n");

            intNotHandled = 0;

            /* Clear bits 0 and 3 as soon as we know it's us and
             * it's safe to access the SSB.
             */
            ssb &= ~(SSB_BUFFER_ACCESS | SSB_INTERRUPT_PC_ENABLE);
            writeb(ssb, Adapter.ssb);

            Adapter.interrupt_slot = TRUE;

            if (nptl_enabled == FALSE) {
                aipdcs_interrupted = TRUE;
                wake_up_interruptible(&aipdcs_queue);
            }

            /* If a process has registered for SIO interrupts,
             * signal SIGUSR1
             */
            if (Adapter.current_pid != 0) {
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 27)
                kill_proc(Adapter.current_pid, SIGUSR1, 1);
#else
                kill_pid(Adapter.current_pid, SIGUSR1, 1);
#endif
            }

            /* We handled the interrupt */
            rc = TRUE;
        } else {

            // If we have not been able to handle an AIPDCS interrupt
            // more than 5 times, something is wrong - do not leave a
            // hot interrupt floating
            if (intNotHandled++ > 2) {
               intNotHandled = 0;
               aip_warning("Int_Handler: Force handling of AIPDCS interrupt...");
               rc = TRUE;
            }
        }
    }

cd_only:
    /* 4800 Cash Drawer Interrupt */
    if (status_reg_a & SP700_CD_INTERRUPT) {
        Adapter.interrupt_cd_slot = TRUE;

        aip_dbg("Int_Handler -- CD: slot=%d, StatusReg=0x%x\n",
                Adapter.interrupt_cd_slot, inb(Adapter.base_io_addr));

        /* Clear only the cash drawer interrupt bits */
        outb((inb(Adapter.base_io_addr + SP700_ASIC_CD_PORT_2) & 0xFC),
             (Adapter.base_io_addr + SP700_ASIC_CD_PORT_2));


        /* "Signal" the application of cash drawer interrupt
         */
        if (nptl_enabled == TRUE) {
            aipdcs_interrupted = TRUE;
            wake_up_interruptible(&aipdcs_queue);
        }

        if (Adapter.current_cd_pid != 0 && nptl_enabled == FALSE) {
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 27)
            kill_proc(Adapter.current_cd_pid, SIGUSR1, 1);
#else
            kill_pid(Adapter.current_cd_pid, SIGUSR1, 1);
#endif
        }

        /* We handled the interrupt */
        rc = TRUE;
    }

    if (rc == TRUE) {
        outb(0x00, (Adapter.base_io_addr + SP700_ASIC_INTERRUPT_STATUS_REGISTER));
    }

    return IRQ_RETVAL(rc == TRUE ? IRQ_HANDLED : IRQ_NONE);
}


/* dcs_isa_interrupt_handler: Handler for interrupt event
 * ************************************************************************
 *
 *  Function Name:  dcs_isa_interrupt_handler
 *
 *  Purpose:        Handler for interrupt event
 *
 *  Description:    When a device channel interrupt occurs, clear
 *                  SSB_INTERRUPTED and SSB_INTERRUPT_PC_ENABLE and
 *                  signal the process that registered for SIO interrupts.
 *
 *  Input:          irq     - interrupt number
 *                  dev_id  - device identifier (same as last arg of
 *                            request_irq)
 *                  pt_regs - snapshot of processor context prior to int
 *
 *  Output:         None
 *
 * ************************************************************************
 */

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 19)
static irqreturn_t dcs_isa_interrupt_handler(int irq, void *dev_id,
                                             struct pt_regs *regs)
#else
static irqreturn_t dcs_isa_interrupt_handler(int irq, void *dev_id)
#endif
{
    uchar_t ssb;
    int rc = FALSE;

    aip_verbose("Int_Handler -- 4694\n");

    /* SSB PC_DONE bit must be cleared before we set
     * access the SSB.
     */
    wait_for_pc_done_status(&Adapter, 1000, 1000);

    ssb = readb(Adapter.ssb);

    if ((SSB_INTERRUPTED | SSB_INTERRUPT_PC_ENABLE) ==
        (ssb & (SSB_INTERRUPTED | SSB_INTERRUPT_PC_ENABLE))) {
        aip_dbg("Int_Handler: SSB_INTERRUPTED\n");

        /* Clear bits 0 and 3 as soon as we know it's us and
         * it's safe to access the SSB.
         */
        ssb &= ~(SSB_BUFFER_ACCESS | SSB_INTERRUPT_PC_ENABLE);
        writeb(ssb, Adapter.ssb);

        aipdcs_interrupted = TRUE;
        wake_up_interruptible(&aipdcs_queue);

        /* If a process has registered for SIO interrupts,
         * signal SIGUSR1
         */
        if (Adapter.current_pid != 0) {
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 27)
            kill_proc(Adapter.current_pid, SIGUSR1, 1);
#else
            kill_pid(Adapter.current_pid, SIGUSR1, 1);
#endif
        }

        /* We handled the interrupt */
        rc = TRUE;
    }

    return IRQ_RETVAL(rc == TRUE ? IRQ_HANDLED : IRQ_NONE);
}

/* dcs_poll: Handler for polling
 * ************************************************************************
 *
 *  Function Name:  dcs_poll
 *
 *  Purpose:        Handler for polling
 *
 *  Description:
 *
 *  Input:          file - file descriptor
 *                  wait - kernel poll list waiting structure
 *
 *  Output:         mask indicating if device has data for reading
 *
 * ************************************************************************
 */

static unsigned int dcs_poll(struct file *file, struct poll_table_struct *wait)
{
    unsigned int mask = 0;

    poll_wait(file, &aipdcs_queue, wait);

    if (aipdcs_interrupted == TRUE) {
        mask = POLLIN | POLLRDNORM;
    }

    return mask;
}


/* turn_off_ok_message: Turn off the OK message on some 4694 terminals
 * ************************************************************************
 *
 *  Function Name:  turn_off_ok_message
 *
 *  Purpose:        Turn off the OK message on some 4694 terminals
 *
 *  Description:    Assign the interrupt handler to process all interrupts
 *                  from this adapter..
 *
 *  Input:          none
 *
 *  Output:         none
 *
 * ************************************************************************
 */

static void turn_off_ok_message(dcs_adapter *adapter)
{
    /* Turn the Ok message printing off.
     * --> Only if the NVRAM is enabled and it's 4694
     */
    if ((adapter->nvram != NULL) && (adapter->nvram_size != 0) &&
        ((adapter->adapter_id == IBM_4694N) ||
         (adapter->adapter_id == IBM_4694W))) {
        uchar_t tempByte;

        aip_dbg("Turn OK message printing OFF\n");

        tempByte = readb((adapter->nvram + 0x0FF7)) | 0x80;
        writeb(tempByte, (adapter->nvram + 0x0FF7));
    }

    return;
}


/* find_4694: Find and Setup 4694 Terminals
 * ************************************************************************
 *
 *  Function Name:  find_4694
 *
 *  Purpose:        Find and Setup 4694 Terminals
 *
 *  Description:    Determine if we are running on a 4694 terminal.
 *
 *  Input:          none
 *
 *  Output:         none
 *
 * ************************************************************************
 */

static int find_4694(dcs_adapter *adapter)
{
    int rc = -1;
    uchar_t *pmem = NULL;
    unsigned short id_4694_byte1 = 0;
    unsigned short id_4694_byte2 = 0;
    unsigned short reg = 0;
    int cnt = 0;

    /* Look for 4694 adapter */
    if (request_region(REG_A, ISA_4694_BOARD_SIZE, DEVDRVR_ID) == 0) {
        aip_dbg("Memory between %#x and %#x already allocated!\n",
                REG_A, REG_H);
        goto out;
    }

    /* Probe the I/O space to see if there really is a board there */
    cnt = 0;
    for (reg = REG_A; reg <= REG_H; ++reg) {
        if (inb(reg) == 0xff) {
            ++cnt;
        }
    }

    if (cnt == ISA_4694_BOARD_SIZE) {
        aip_dbg("adapter NOT found between %#x and %#x!\n",
                REG_A, REG_H);

        release_region(REG_A, ISA_4694_BOARD_SIZE);

        goto out;
    }

    aip_dbg("adapter found between %#x and %#x!\n", REG_A, REG_H);

    rc = 0;

    /* read two bytes for 4694 ID from BIOS */
    pmem = (uchar_t *)ioremap(0xFE000, 2);
    id_4694_byte1 = readb(pmem);
    id_4694_byte2 = readb(pmem + 1);
    iounmap(pmem);

    aip_dbg("4694 ID=%#x.%#x\n", id_4694_byte1, id_4694_byte2);

    if (id_4694_byte1 == SIO_4694N_ID_BYTE1) {
        adapter->adapter_id = IBM_4694N;
    } else if (id_4694_byte1 == SIO_4694W_ID_BYTE1) {
        adapter->adapter_id = IBM_4694W;
    } else {
        aip_dbg("adapter %#x not recognized\n", id_4694_byte1);

        release_region(REG_A, ISA_4694_BOARD_SIZE);

        goto out;
    }

    adapter->known_adapter = TRUE;
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 19)
    adapter->int_flags     = SA_INTERRUPT;
#elif LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 36)
    adapter->int_flags     = IRQF_DISABLED;
#else
    adapter->int_flags     = 0;
#endif

    if ((inb(REG_D) & 0x1)  == 0) {
        adapter->irq_level = 7;
    } else {
        if (adapter->adapter_id == IBM_4694N) {
            adapter->irq_level = 9;
        } else {
            adapter->irq_level = 11;
        }
    }

    adapter->base_io_addr = REG_A;
    adapter->board_size   = ISA_4694_BOARD_SIZE;
    adapter->port_count   = 1;
    adapter->offset_ssb   = SSB;
    adapter->buffer_addr = (inb(REG_C) & 0x0FL) * 0x1000L +
                           (inb(REG_C) & 0x10L ? 0x0D0000L : 0x0E0000L) + 0x0800L;

    adapter->nvram_buffer_addr = (inb(REG_A) & 0x1F) * 0x1000L + 0x0D0000L;
    adapter->nvram_map_type    = NVRAM_PAGED;
    adapter->nvram_page_size   = 4096;
    adapter->nvram_pages       = 2;
    adapter->page_reg_offset   = 1;
    adapter->bottum_junk       = 16;
    adapter->junk_length       = 160;
    adapter->nvram_size        = (32L * 1024L) - adapter->bottum_junk -
                                 adapter->junk_length;
    adapter->junk_offset       = adapter->nvram_page_size -
                                 adapter->junk_length;

    adapter->nvram_area[DEVICE_DRVRS].Offset = 28672;
    adapter->nvram_area[DEVICE_DRVRS].Size   = 3920;
    adapter->nvram_area[APPLICATION].Offset  = 0;
    adapter->nvram_area[APPLICATION].Size    = 28672;

out:

    return rc;
}


/* find_4674: Find and Setup 4674 and 4695 Terminals
 * ************************************************************************
 *
 *  Function Name:  find_4674
 *
 *  Purpose:        Find and Setup 4674 and 4695 Terminals
 *
 *  Description:    Determine if we are running on a 4674 or 4695 terminal.
 *
 *  Input:          none
 *
 *  Output:         none
 *
 * ************************************************************************
 */

static int find_4674(dcs_adapter *adapter, int addr)
{
    int rc = -1;
    uchar_t ATRegA = 0;
    unsigned short id = 0;

    aip_dbg("Trying address 0x%x\n", addr);

    if (request_region(addr, ISA_4674_BOARD_SIZE, DEVDRVR_ID) == 0) {
        aip_dbg("Memory between %#x and %#x already allocated!\n",
                addr, addr + ISA_4674_BOARD_SIZE -1);

        goto out;
    }

    id = inw(addr + 0x18 );
    if (!((SIO_4695_ADAPTER_ID == id) || (SIO_4695_PLANAR_ID == id) ||
          (SIO_4674_ID == id))) {
        release_region(addr, ISA_4674_BOARD_SIZE);

        goto out;
    }

    aip_dbg("Found 4695: addr=0x%x, id=0x%x\n", addr, id);
    rc = 0;

    adapter->board_size    = ISA_4674_BOARD_SIZE;
    adapter->known_adapter = TRUE;
    adapter->adapter_id    = IBM_4695_ADAPTER;
    adapter->base_io_addr  = addr;
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 19)
    adapter->int_flags     = SA_INTERRUPT;
#elif LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 36)
    adapter->int_flags     = IRQF_DISABLED;
#else
    adapter->int_flags     = 0;
#endif

    /* The 4695 adapter card and 4674 terminal only have one (1) port but
     * the 4695 planar has two (2) ports.
     */
    if (id == SIO_4695_ADAPTER_ID || id == SIO_4674_ID) {
        adapter->port_count = 1;
    } else {
        adapter->port_count = 2;
    }

    /* Set WCR1 to access the 2K shared buffer */
    aip_dbg("Writing I/O Port 0x%lu=0x08, 0x%lu=0x00\n",
            (adapter->base_io_addr + 3), (adapter->base_io_addr + 2));

    outb(0x00, (adapter->base_io_addr + 2));
    outb(0x08, (adapter->base_io_addr + 3));

    ATRegA = inb(adapter->base_io_addr + 0x10);
    if (ATRegA & 0x80) {
        adapter->buffer_addr = 0xC0000 + (((ATRegA >> 1) & 0x0F) * 0x02000);
    } else {
        adapter->buffer_addr = 0xC0000 + (((ATRegA >> 2) & 0x07) * 0x04000);
    }

    /* In Linux, we cannot access WCR0 nor the first 2K page of our memory
     * region.  We will use WCR1 and the second 2K of the memory region
     * for the 2K shared buffer -- we need to add 2K to the buffer
     * address that we just got from the adapter.
     */
    adapter->buffer_addr += 0x0800;

    aip_dbg("2K shared buffer=0x%lx\n", adapter->buffer_addr);


    adapter->offset_ssb = 2047;

    if ((ATRegA & 0x40) != 0) {
        adapter->irq_level = 11;
    } else {
        adapter->irq_level = 7;
    }

    aip_dbg("IRQLevel=%d\n", adapter->irq_level);

    /* NVRAM size differs between 4674 and 4695's */
    if ((id == SIO_4695_ADAPTER_ID) || (id == SIO_4695_PLANAR_ID)) {
        /* 128K */
        adapter->nvram_size                      = 128L * 1024L;
        adapter->nvram_area[DEVICE_DRVRS].Offset = 126976;
        adapter->nvram_area[DEVICE_DRVRS].Size   = 4096 - 32;
        adapter->nvram_area[APPLICATION].Offset  = 0;
        adapter->nvram_area[APPLICATION].Size    = 126976;
    } else if (id == SIO_4674_ID) {
        /* 32K */
        adapter->nvram_size                      = 32L * 1024L;
        adapter->nvram_area[DEVICE_DRVRS].Offset = 28672;
        adapter->nvram_area[DEVICE_DRVRS].Size   = 4096 - 32;
        adapter->nvram_area[APPLICATION].Offset  = 0;
        adapter->nvram_area[APPLICATION].Size    = 28672;
    }

    /* Common NVRAM information */
    adapter->bottum_junk       = 0;
    adapter->nvram_map_type    = NVRAM_WCR_PAGED;
    adapter->nvram_page_size   = 2048;
    adapter->nvram_pages       = 1;
    adapter->nvram_buffer_addr = adapter->buffer_addr + 0x0800;

out:
    return rc;
}


/* get_4800_pci_config: Setup the 4800 SIO Buffer and interrupt levels
 * ************************************************************************
 *
 *  Function Name:  get_4800_pci_config
 *
 *  Purpose:        Setup the 4800 SIO Buffer and interrupt levels
 *
 *  Description:    Assign the interrupt handler to process all interrupts
 *                  from this adapter..
 *
 *  Input:          none
 *
 *  Output:         none
 *
 * ************************************************************************
 */

static int get_4800_pci_config(dcs_adapter *adapter, int bar)
{
    int rc = 0;

    /* Get I/O space address */
    adapter->base_io_addr = pci_resource_start(adapter->pcidcs, bar);
    adapter->board_size   = pci_resource_len(adapter->pcidcs, bar);

    /* Try to claim our I/O space */
    if (request_region(adapter->base_io_addr, adapter->board_size,
                       DEVDRVR_ID) == 0) {
        aip_error("Memory between %#lx and %#lx already allocated!\n",
                  adapter->base_io_addr,
                  adapter->base_io_addr + adapter->board_size -1);
        rc = -1;
    }

    return rc;
}


/* get_4800_pci_eeprom: Setup the 4800 SIO Buffer and interrupt levels
 * ************************************************************************
 *
 *  Function Name:  get_4800_pci_eeprom
 *
 *  Purpose:        Setup the 4800 SIO Buffer and interrupt levels
 *
 *  Description:    Assign the interrupt handler to process all interrupts
 *                  from this adapter..
 *
 *  Input:          none
 *
 *  Output:         none
 *
 * ************************************************************************
 */

static int get_4800_pci_eeprom(dcs_adapter *adapter, int bar)
{
    int rc = 0;
    uint32_t       EEROMConfigAddr = 0;
    uchar_t       *pEEROMConfig    = NULL;
    int            eeprom_length   = 0;


    /* Get EEROM address */
    EEROMConfigAddr = pci_resource_start(adapter->pcidcs, bar);
    eeprom_length   = pci_resource_len(adapter->pcidcs, bar);
    pEEROMConfig    = (uchar_t *) ioremap(EEROMConfigAddr, eeprom_length);

    if (pEEROMConfig != 0) {
        /* Determine size and mapping */
        adapter->config_register = *(pEEROMConfig + SP700_EEPPROM_A2_CONFIG_REG_0);

        aip_dbg("EEROMConfigAddr=0x%x, pEEROMConfig=0x%p\n",
                EEROMConfigAddr, pEEROMConfig);

        /* Free EEROM virtual address space */
        iounmap((void *) pEEROMConfig);
    }

    aip_info("PCI SP700 config_register: 0x%x\n", adapter->config_register);

    if (!(adapter->config_register & SP700_CONFIG0_SIO_ENABLED)) {
        aip_info("aipdcs: sio disabled in config\n");
        adapter->sio_available = FALSE;
    }

    if (!(adapter->config_register & SP700_CONFIG0_NVRAM_ENABLED)) {
        aip_info("aipdcs: nvram disabled in config\n");
        adapter->nvram_available = FALSE;
    }

    return rc;
}


/* set_4800_sio_buffer: Setup the 4800 SIO Buffer and interrupt levels
 * ************************************************************************
 *
 *  Function Name:  set_4800_sio_buffer
 *
 *  Purpose:        Setup the 4800 SIO Buffer and interrupt levels
 *
 *  Description:    Assign the interrupt handler to process all interrupts
 *                  from this adapter..
 *
 *  Input:          none
 *
 *  Output:         none
 *
 * ************************************************************************
 */

static void set_4800_sio_buffer(dcs_adapter *adapter, int bar)
{
    /* Get 2K shared buffer address */
    adapter->buffer_addr = pci_resource_start(adapter->pcidcs, bar);

    if (adapter->buffer_addr == 0) {
        adapter->sio_available = FALSE;
    }

    aip_dbg("adapter->buffer_addr=%lx\n", adapter->buffer_addr);

    return;
}


/* get_4800_configuration: Get the 4800 pci configuration information
 * ************************************************************************
 *
 *  Function Name:  get_4800_pci_config
 *
 *  Purpose:        Get the 4800 pci configuration information.
 *
 *  Description:    Find out what is enabled.
 *
 *  Input:          none
 *
 *  Output:         none
 *
 * ************************************************************************
 */

static int get_4800_configuration(dcs_adapter *adapter)
{
    int rc    = 0;
    int bar   = 0;

    aip_info("PCI Bus=0x%x, Device=0x%x, Function=0x%x\n",
             adapter->pcidcs->bus->number, adapter->pcidcs->device,
             adapter->pcidcs->devfn);

    adapter->base_io_addr    = 0;
    adapter->board_size      = 0;
    adapter->known_adapter   = TRUE;
    adapter->adapter_id      = adapter->pcidcs->device;
    adapter->irq_level       = adapter->pcidcs->irq;
    adapter->port_count      = 1;
    adapter->offset_ssb      = 2047;
    adapter->page_reg_offset = 8;
    adapter->config_register = 0;
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 19)
    adapter->int_flags       = SA_INTERRUPT | SA_SHIRQ;
#elif LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 36)
    adapter->int_flags       = IRQF_DISABLED | IRQF_SHARED;
#else
    adapter->int_flags       = IRQF_SHARED;
#endif

    if (adapter->pcidcs->subsystem_device == NVRAMT_SUB_ID) {
        adapter->adapter_id      = adapter->pcidcs->subsystem_device;
        adapter->sio_available   = FALSE;
        adapter->nvram_available = TRUE;
    }

    aip_info("Irq:  %d\n", adapter->irq_level);
    for (bar = 0; bar <= 4; bar++) {
        int start  = pci_resource_start(adapter->pcidcs, bar);
        int length = pci_resource_len(adapter->pcidcs, bar);
        int flags  = pci_resource_flags(adapter->pcidcs, bar);

        if (flags & IORESOURCE_IO) {
            aip_info("Bar %d: IO  Start=%08x Length=%06d\n",
                     bar, start, length);

            if (bar == SP700_CONFIG_BAR) {
                get_4800_pci_config(adapter, bar);
            }
        } else if (flags & IORESOURCE_MEM) {
            aip_info("Bar %d: MEM Start=%08x Length=%06d\n",
                     bar, start, length);

            if (bar == SP700_EEPROM_BAR) {
                get_4800_pci_eeprom(adapter, bar);
            } else if (((bar == 3) &&
                        (adapter->nvram_available == FALSE)) ||
                       (bar == 4)) {
                if (adapter->sio_available == TRUE) {
                    set_4800_sio_buffer(adapter, bar);
                }
            } else if (bar == 3) {
                set_4800_nvram(adapter, bar);
            }
        }
    }

    return rc;
}


/* set_4800_nvram: Setup the NVRAM for the 4800
 * ************************************************************************
 *
 *  Function Name:  set_4800_nvram
 *
 *  Purpose:        Setup the NVRAM for the 4800
 *
 *  Description:    Set the 4800 sizes and addresses.
 *
 *  Input:          none
 *
 *  Output:         none
 *
 * ************************************************************************
 */

static void set_4800_nvram(dcs_adapter *adapter, int bar)
{
    int config_register = adapter->config_register;

    /* Get NVRAM address */
    adapter->nvram_buffer_addr = pci_resource_start(adapter->pcidcs, bar);

    aip_dbg("Nvram buffer address=0x%lx\n", adapter->nvram_buffer_addr);

    /* If the NVRAM address is not there (equal to 0) */
    if (adapter->nvram_buffer_addr == 0) {
        adapter->nvram_available = FALSE;
        goto out;
    }

    if (config_register & SP700_CONFIG0_NVRAM_ENABLED) {
        uchar_t size_config = (config_register & SP700_CONFIG0_NVRAM_SIZE_MASK) >> 3;

        aip_dbg("NVRAM ENABLED (size=%d)\n", size_config);

        switch (size_config) {
        case SP700_NVRAM_SIZE_128KB:
            adapter->nvram_size = 128 * 1024;
            break;
        case SP700_NVRAM_SIZE_256K:
            adapter->nvram_size = 256 * 1024;
            break;
        case SP700_NVRAM_SIZE_512K:
            adapter->nvram_size = 512 * 1024;
            break;
        case SP700_NVRAM_SIZE_1MB:
            adapter->nvram_size = 1024 * 1024;
            break;
        case SP700_NVRAM_SIZE_0KB:
            /* No NVRAM installed -- this is one way to disable
             * the NVRAM.  In early versions of the configuration
             * code, the various places to indicate "no NVRAM"
             * we not tied together so we'll check all of them
             * to make sure.
             */
            adapter->nvram_size = 0;
            break;
        case SP700_NVRAM_SIZE_32KB:
        default:
            adapter->nvram_size = 32 * 1024;
            break;
        }
    } else {
        aip_dbg("NVRAM DISABLED");

        /* NVRAM is disabled -- this is one way to disable the NVRAM.
         * In early versions of the configuration code, the various
         * places to indicate "no NVRAM" were not tied together so
         * we'll check all of them to make sure...
         */
        adapter->nvram_size = 0;
    }

    if (adapter->nvram_size == 0) {
        goto out;
    }

    if (config_register & SP700_CONFIG0_NVRAM_BELOW_1MB) {
        aip_dbg("NVRAM below 1M\n");

        /* NVRAM below 1M so it's automatically paged  */
        adapter->nvram_map_type  = NVRAM_PAGED;
        adapter->nvram_page_size = 4096;
        adapter->nvram_pages     = 2;
    } else {
        aip_dbg("NVRAM above 1M\n");

        if (config_register & 0x01) {
            aip_dbg("NVRAM paging ENABLED\n");

            /* NVRAM above 1M, Paging ENABLED */
            adapter->nvram_map_type  = NVRAM_PAGED;
            adapter->nvram_page_size = 4096;
            adapter->nvram_pages     = 2;
        } else {
            aip_dbg("NVRAM paging NOT enabled\n");

            /* NVRAM above 1M, Paging NOT enabled */
            adapter->nvram_map_type  = NVRAM_MEMORY_MAP;
            adapter->nvram_page_size = adapter->nvram_size;
            adapter->nvram_pages     = 1;
        }
    }

#if !defined(DIAGNOSTIC_MODE)
    /* Set up the NVRAM areas for the drivers and applications */
    adapter->nvram_area[DEVICE_DRVRS].Offset = adapter->nvram_size - 2048L;
    adapter->nvram_area[DEVICE_DRVRS].Size   = 2048;
    adapter->nvram_area[APPLICATION].Offset  = 0;
    adapter->nvram_area[APPLICATION].Size    = adapter->nvram_size - 2048L;
#else
    /* Set up the NVRAM areas for diagnostics */
    adapter->nvram_area[DEVICE_DRVRS].Offset = adapter->nvram_size;
    adapter->nvram_area[DEVICE_DRVRS].Size   = 0;
    adapter->nvram_area[APPLICATION].Offset  = 0;
    adapter->nvram_area[APPLICATION].Size    = adapter->nvram_size;
#endif

out:
    return;
}


/* set_4800_cd_defaults: Setup the defaults for the 4800 cash drawer
 * ************************************************************************
 *
 *  Function Name:  set_4800_cd_defaults
 *
 *  Purpose:        Setup the defaults for the 4800 cash drawer
 *
 *  Description:    Set the 4800 cash drawer to legacy support.
 *
 *  Input:          none
 *
 *  Output:         none
 *
 * ************************************************************************
 */

static void set_4800_cd_defaults(dcs_adapter *adapter)
{
    uchar_t default_cd = SP700_CD0_DRAWER_ENABLE;

    aip_dbg("Cash Drawer Config orig=0x%x\n", inb(adapter->base_io_addr));

    if (adapter->sio_available == TRUE) {
        /*
        * Set CD to 8051 ("legacy") interface
        * 0x05 indicates:  CD interrupts disabled  not right
        *                  8051 CD interface enabled
        *                  CD pulse 100ms
        *                  CDs can be opened       not right
        */
        default_cd |= SP700_CD0_ENABLE_8051_INTERFACE;
        outb(default_cd, adapter->base_io_addr);
    } else {
        default_cd |= SP700_CD0_INTERRUPT_ENABLE;
        outb(default_cd, adapter->base_io_addr);
    }

    aip_dbg("Cash Drawer Config new=0x%x\n", inb(adapter->base_io_addr));

    return;
}


/* set_interrupt_handler: Set the interrupt handler for this adapter
 * ************************************************************************
 *
 *  Function Name:  set_interrupt_handler
 *
 *  Purpose:        Set the interrupt handler for this adapter
 *
 *  Description:    Assign the interrupt handler to process all interrupts
 *                  from this adapter..
 *
 *  Input:          none
 *
 *  Output:         none
 *
 * ************************************************************************
 */

static int set_interrupt_handler(dcs_adapter *adapter)
{
    int rc = 0;

    if (adapter->adapter_id == SIO_4800_ID) {
        aip_dbg("Requesting PCI shared interrupt\n");

        rc = request_irq(adapter->irq_level,
                         dcs_pci_interrupt_handler,
                         adapter->int_flags, DEVDRVR_ID,
                         (void *) adapter);
    } else {
        aip_dbg("Requesting ISA exclusive interrupt\n");

        rc = request_irq(adapter->irq_level,
                         dcs_isa_interrupt_handler,
                         adapter->int_flags, DEVDRVR_ID,
                         (void *) adapter);
    }

    if (rc != 0) {
        aip_error("Can't request IRQ %d, Adapter=0x%x\n",
                  adapter->irq_level, adapter->adapter_id);

        /* Unmap device channel addresses */
        iounmap((void *)adapter->p2k_buffer);
        iounmap((void *)adapter->ssb);

        /* Indicate IRQ error */
        adapter->rc = (RPDONE | RPERR | IRQ_ERROR);
    }

    return rc;
}


/* reset_adapter: Set the adapter to a known state
 * ************************************************************************
 *
 *  Function Name:  reset_adapter
 *
 *  Purpose:        Reset the adapter to a known state
 *
 *  Description:    POR the Adapter.
 *
 *  Input:          none
 *
 *  Output:         none
 *
 * ************************************************************************
 */

static void reset_adapter(dcs_adapter *adapter)
{
    uchar_t ssb = 0;
    uchar_t bdata = 0;

    /* Set now so we can clear the interrupt we generate here */
    adapter->rc = RPDONE;

    ssb = readb(adapter->ssb);

    /* Power On Reset adapter */
    bdata = ssb | (SSB_PC_DONE | SSB_BUFFER_ACCESS |
                   SSB_INTERRUPT_PC_ENABLE);
    writeb(bdata, adapter->ssb);

    aip_dbg("Request buffer, SSB=0x%x\n", readb(adapter->ssb));

    /* Wait for access to buffer */
    mdelay(2000);
    if ((readb(adapter->ssb) & SSB_INTERRUPTED) == 0) {
        if (adapter->adapter_id == SIO_4800_ID) {
            aip_info("Disabling sio\n");
            adapter->sio_available = FALSE;
        } else {
            aip_warning("Error in accessing SIO\n");

            free_irq(adapter->irq_level, (void *) adapter);

            /* Unmap device channel addresses */
            iounmap((void *) adapter->p2k_buffer);
            iounmap((void *) adapter->ssb);

            adapter->rc = (RPDONE | RPERR | LOST_8051);
        }

        goto out;
    }

    aip_dbg("SSB indicates interrupt (SSB=0x%x)\n", readb(adapter->ssb));

    /* Clear out the buffer and put the Power On Reset (POR) broadcast
     * message in the buffer.
     */
    memset_io(adapter->p2k_buffer, 0x0, 2047);

#if defined(V4690)
    // Old RS-485 devices cannot all handle the broadcast reset.
    // Init only happens during load of AIPDCS for 4690OS and then
    //   4690OS manages the state of the devices.
    aip_warning("AIPDCS: reset_adapter - do not post POR for 4690OS\n");
#else
    memcpy_toio(adapter->p2k_buffer + 0x012F, POR_MSG,
                sizeof(POR_MSG));
    bdata = readb(adapter->p2k_buffer + REQUEST) | 0x30;
    writeb(bdata, adapter->p2k_buffer + REQUEST);

    bdata = readb(adapter->p2k_buffer + FUNCTION) | 0x48;
    writeb(bdata, adapter->p2k_buffer + FUNCTION);

    writeb(adapter->port_count, adapter->p2k_buffer + NO_MSGS);
    writew(0x012F, adapter->p2k_buffer + MSG_LOC);
#endif

    adapter->buffer_read = FALSE;

    bdata = readb(adapter->ssb) & ~SSB_BUFFER_ACCESS;
    writeb(bdata, adapter->ssb);

    ssb = readb(adapter->ssb);

    aip_dbg("Buffer request cleared, SSB=0x%x\n", ssb);

    /* Tell the 8051 that we are through with the buffer. This will cause
     * the 8051 to act on the broadcast.
     */
    bdata = ssb | SSB_PC_DONE;
    writeb(bdata, adapter->ssb);

    aip_dbg("PC DONE set, SSB=0x%x\n", readb(adapter->ssb));
out:

    return;
}


/* dcs_open: Open device driver
 * ************************************************************************
 *
 *  Function Name:  dcs_open
 *
 *  Purpose:        Open this device driver
 *
 *  Description:    Setup NVRAM and enable PC interrupts (device channel).
 *
 *  Input:          inode  -
 *                  file   -
 *
 *  Output:         0  -- success
 *                  -1 -- error
 *
 * ************************************************************************
 */

static int dcs_open(struct inode *iNode, struct file *file)
{
    int rc = 0;
    uchar_t bdata = 0;
    char nvramrec[sizeof(NVRAM_DATA) + 4];
    uint32_t nvreclen = sizeof(NVRAM_DATA) + 4;
    short crc = 0;
    char crcchr[2];
    int index = 0;
    int nvram_in_use = FALSE;
    int crc_ok = 0;
    PNVRAM_DATA nviptr = 0;

    aip_dbg("open_count=%d, Adapter.rc=%x\n", Adapter.open_count,
            Adapter.rc);

    if ((Adapter.known_adapter != TRUE) || (Adapter.rc != RPDONE) ||
        (Adapter.open_count > 0)) {
        goto out;
    }

    nviptr = (PNVRAM_DATA) &nvramrec[2];

    rc = Adapter.rc;

#if !defined(DIAGNOSTIC_MODE)
    /* When using this driver for diagnostics do not update the machines
     * NVRAM because this can destroy customers data saved in NVRAM
     */
    if ((Adapter.nvram_rc == RPDONE) &&
        (Adapter.nvram_size > 0) &&
        (Adapter.nvram_available == TRUE)) {
        aip_dbg("Read NVRAM Data\n");

        /* First, read the last (sizeof(NVRAM_DATA)+4) bytes in
         * this NVRAM.
         */
        read_write_nvram_data(&Adapter, (char *) nvramrec,
                              nvreclen, NVREAD);

        /* Calculate CRC on all but the last 2 bytes. */
        crc = calculate_crc((char *) nvramrec,
                            (sizeof(NVRAM_DATA) + 2));

        crcchr[1] = (char) (crc & 0x00FF);
        crcchr[2] = (char) ((crc >> 8) & 0x00FF);

        /* Check calculated CRC against last 2 bytes read */
        if ((nvramrec[(sizeof(NVRAM_DATA) + 2)] == crcchr[1]) &&
            (nvramrec[(sizeof(NVRAM_DATA) + 3)] == crcchr[2])) {
            crc_ok = 1;
        }

        aip_dbg("Copy from NVRAM to nvram_area\n");

        /* Check to see if any areas are being used */
        for (index = 0; index < NUM_AREAS; index++) {
            if (Adapter.nvram_area[index++].InUseFlag != FALSE) {
                nvram_in_use = TRUE;
                break;
            }
        }

        /* Copy the read information into nvram_area only if at least
         * one area has been used.
         */
        if ((nvram_in_use) && (crc_ok)) {
            aip_dbg("Copy NVRAM Table to nvram_area\n");

            memcpy(Adapter.nvram_area, nviptr->AreaData,
                   (sizeof(AREA_DATA) * NUM_AREAS));
        } else {
            aip_dbg("Copy nvram_area to NVRAM\n");

            /* Write the default NVRAM data table to the top of
             * the NVRAM.
             */
            rc = write_nvram_table(&Adapter);
        }
    }
#endif

    if (Adapter.sio_available == TRUE) {
        /* SSB PC_DONE bit must be cleared before we set access the
         * SSB byte.
         */
        if (wait_for_pc_done_status(&Adapter, 1000, 1000) == RPDONE) {
            /* Setting SSB_INTERRUPT_PC_ENABLE  */
            bdata = readb(Adapter.ssb) | SSB_INTERRUPT_PC_ENABLE;
            writeb(bdata, Adapter.ssb);

            aip_dbg("Wrote SSB=0x%x\n", bdata);
        } else {
            aip_info("aipdcs: Disabling sio\n");
            Adapter.sio_available = FALSE;
        }
    }

out:
    ++Adapter.open_count;

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 5, 0)
    MOD_INC_USE_COUNT;
#endif

    aip_dbg("returning, open_count=%d, rc=0x%x\n", Adapter.open_count, rc);

    return 0;
}


/* dcs_release: Close device driver
 * ************************************************************************
 *
 *  Function Name:  dcs_release
 *
 *  Purpose:        Close this device driver
 *
 *  Description:    Disable PC interrupts (device channel).
 *
 *  Input:          inode  -
 *                  file   -
 *
 *  Output:         0  -- success
 *                  -1 -- error
 *
 * ************************************************************************
 */

static int dcs_release(struct inode *iNode, struct file *file)
{
    aip_dbg("open_count=%d, Adapter.rc=%d\n", Adapter.open_count,
            Adapter.rc);

    --Adapter.open_count;

    if (Adapter.open_count == 0) {
        uchar_t bdata = 0;

        /* make sure there are no shared IRQ's or this will fail */
        if (Adapter.rc == RPDONE) {
            /* SSB PC_DONE bit must be cleared before we set
             * access the SSB.
             */
            if (Adapter.sio_available == TRUE) {
                aip_dbg("SSB=0x%x\n", readb(Adapter.ssb));

                wait_for_pc_done_status(&Adapter, 1000, 1000);

                bdata = readb(Adapter.ssb) & ~SSB_INTERRUPT_PC_ENABLE;
                writeb(bdata, Adapter.ssb);

                aip_dbg("Wrote SSB=0x%x\n", bdata);
            }
        }

        Adapter.current_pid = 0;
        Adapter.current_cd_pid = 0;
    }

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 5, 0)
    MOD_DEC_USE_COUNT;
#endif

    aip_dbg("returning, open_count=%d\n", Adapter.open_count);

    return 0;
}


/* dcs_read: Read from device
 * ************************************************************************
 *
 *  Function Name:  dcs_read
 *
 *  Purpose:        Read from this device
 *
 *  Description:    Not supported by this device.
 *
 *  Input:          file  -
 *                  buf   -
 *                  count -
 *                  ppos  -
 *
 *  Output:         -EINVAL -- invalid
 *
 * ************************************************************************
 */

static ssize_t dcs_read(struct file *file, char *buf, size_t count,
                        loff_t *ppos)
{
    aip_dbg("Read not supported\n");

    return -EINVAL;
}


/* dcs_write: Write to device
 * ************************************************************************
 *
 *  Function Name:  dcs_write
 *
 *  Purpose:        Write to this device
 *
 *  Description:    Not supported by this device.
 *
 *  Input:          file  -
 *                  buf   -
 *                  count -
 *                  ppos  -
 *
 *  Output:         -EINVAL -- invalid
 *
 * ************************************************************************
 */

static ssize_t dcs_write(struct file *file, const char *buf, size_t count,
                         loff_t *ppos)
{
    aip_dbg("Write not supported\n");

    return -EINVAL;
}


/* dcs_ioctl: I/O Control for this device driver
 * ************************************************************************
 *
 *  Function Name:  dcs_ioctl
 *
 *  Purpose:        Handle ioctl calls to this device driver
 *
 *  Description:    Call correct function based on ioctl request.
 *
 *  Input:          inode  -
 *                  file   -
 *                  cmd    - ioctl request
 *                  arg    - pointer to argument structure
 *
 *  Output:         0  -- success
 *                  -1 -- error
 *
 *  Note:           Remember that FIOCLEX, FIONCLEX, FIONBIO, and FIOASYN
 *                  are reserved ioctl cmd numbers
 *
 * ************************************************************************
 */

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 36)
static int dcs_ioctl(struct inode *inode, struct file *file,
                     unsigned int cmd, unsigned long arg)
#else
static long dcs_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
#endif
{
    int rc = 0;
    int size = _IOC_SIZE(cmd);
    char *buffer = (char *) arg;

    aip_verbose("dcs_ioctl() entered, cmd=%d\n", _IOC_NR(cmd));

    /* Extract the type and number bitfields, and don't decode wrong cmds.
     * return EINVAL before verify_area()
     */
    if (_IOC_TYPE(cmd) != IOCTL_MAGIC) {
        aip_dbg("Unsupported Magic value, _IOC_TYPE=%c, _IOC_DIR=%d, _IOC_NR=%d, cmd=0x%x\n",
                _IOC_TYPE(cmd), _IOC_DIR(cmd), _IOC_NR(cmd), cmd);

        rc = -EINVAL;
        goto out;
    } else {
        if (_IOC_DIR(cmd) & _IOC_READ) {
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 14)
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 0, 0)
            rc = access_ok((void *) buffer, size);
#else
            rc = access_ok(VERIFY_WRITE, (void *) buffer, size);
#endif
            if (rc == 0) {
                aip_dbg("verify_write failed, nr=%d, cmd=0x%x\n",
                        _IOC_NR(cmd), cmd);
                rc = -EFAULT;
            } else {
                rc = 0;
            }
#else
            rc = verify_area(VERIFY_WRITE, (void *) buffer, size);
            if (rc != 0) {
                aip_dbg("verify_write failed, rc=%d\n", rc);
            }
#endif
        } else {
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 14)
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 0, 0)
            rc = access_ok((void *) buffer, size);
#else
            rc = access_ok(VERIFY_READ, (void *) buffer, size);
#endif
            if (rc == 0) {
                aip_dbg("verify_read failed, nr=%d, cmd=0x%x\n",
                        _IOC_NR(cmd), cmd);
                rc = -EFAULT;
            } else {
                rc = 0;
            }
#else
            rc = verify_area(VERIFY_READ, (void *) buffer, size);
            if (rc != 0) {
                aip_dbg("verify_read failed, rc=%d\n", rc);
            }
#endif
        }
        if (rc != 0) {
            goto out;
        }
    }

    /* Check credential - only root programs can use some of these IOCLTS */
    if (!capable(CAP_SYS_ADMIN)) {
        switch (_IOC_NR(cmd)) {
            case _IOC_NR(GET_VITAL_PRODUCT_DATA):
            case _IOC_NR(DISABLE_ASYNC_CD_COMM):
            case _IOC_NR(ENABLE_ASYNC_CD_COMM):
            case _IOC_NR(GET_CD_INTERRUPT_SLOT):
            case _IOC_NR(SET_CD_INTERFACE):
            case _IOC_NR(OPEN_CD):
            case _IOC_NR(GET_CD_STATUS):
            case _IOC_NR(GET_DRIVER_VERSION):
            case _IOC_NR(GET_SLOT_INFO):
                // aip_dbg("IOCTL: User Level Access is permitted for this IOCTL command: 0x%x\n", _IOC_NR(cmd));
                break;
            case _IOC_NR(GET_NVRAM_INFO):
            case _IOC_NR(NVRAM_READ_DATA):
            case _IOC_NR(NVRAM_WRITE_DATA):
                if (nptl_enabled == FALSE) {
                    aip_warning("IOCTL: This process is not permitted to access this IOCTL function: 0x%x\n", _IOC_NR(cmd));
                    return -EACCES;
                }
                // aip_dbg("IOCTL: User Level Access is permitted for this IOCTL command: 0x%x\n", _IOC_NR(cmd));
                break;
            default:
                aip_warning("IOCTL: This process is not permitted to access this IOCTL function: 0x%x\n", _IOC_NR(cmd));
                return -EACCES;
        }
    } else {
         // aip_dbg("IOCTL: Root Processes are granted access to this IOCTL function: 0x%x\n", _IOC_NR(cmd));
    }

    switch (_IOC_NR(cmd)) {
    case _IOC_NR(GET_DCS_INFO):
        rc = get_dcs_info(&Adapter, buffer);
        break;
    case _IOC_NR(GET_INTERRUPT_SLOT):
        rc = get_interrupt_slot(&Adapter, buffer);
        break;
    case _IOC_NR(GET_SLOT_INFO):
        rc = get_slot_info(&Adapter, buffer);
        break;
    case _IOC_NR(POR_8051):
        rc = power_on_reset_8051(&Adapter, buffer);
        break;
    case _IOC_NR(REQUEST_BUFFER):
        rc = request_buffer(&Adapter, buffer);
        break;
    case _IOC_NR(RETURN_BUFFER):
        rc = return_buffer(&Adapter, buffer);
        break;
    case _IOC_NR(WAIT_FOR_BUFFER):
        rc = wait_for_buffer(&Adapter, buffer);
        break;
    case _IOC_NR(GET_NVRAM_INFO):
        rc = get_nvram_data(&Adapter, buffer);
        break;
    case _IOC_NR(QUERY_VALID_DATA_FLAG):
        rc = query_valid_data_flag(&Adapter, buffer);
        break;
    case _IOC_NR(GET_VITAL_PRODUCT_DATA):
        rc = get_vital_product_data(&Adapter, buffer);
        break;
    case _IOC_NR(QUERY_NVRAM_CARD_TYPE):
        rc = query_nvram_card_type(&Adapter, buffer);
        break;
    case _IOC_NR(SET_VALID_DATA_FLAG):
        rc = set_valid_data_flag(&Adapter, buffer);
        break;
    case _IOC_NR(RESET_VALID_DATA_FLAG):
        rc = reset_valid_data_flag(&Adapter, buffer);
        break;
    case _IOC_NR(SET_NVRAM_AREA_SIZES):
        rc = set_nvram_area_sizes(&Adapter, buffer);
        break;
    case _IOC_NR(NVRAM_READ_DATA):
        rc = nvram_read_data(&Adapter, buffer);
        break;
    case _IOC_NR(NVRAM_WRITE_DATA):
        rc = nvram_write_data(&Adapter, buffer);
        break;
    case _IOC_NR(DISABLE_ASYNC_COMM):
        rc = disable_async_comm(&Adapter, buffer);
        break;
    case _IOC_NR(ENABLE_ASYNC_COMM):
        rc = enable_async_comm(&Adapter, buffer);
        break;
    case _IOC_NR(DISABLE_ASYNC_CD_COMM):
        rc = disable_async_cd_comm(&Adapter, buffer);
        break;
    case _IOC_NR(ENABLE_ASYNC_CD_COMM):
        rc = enable_async_cd_comm(&Adapter, buffer);
        break;
    case _IOC_NR(GET_CD_INTERRUPT_SLOT):
        rc = get_cd_interrupt_slot(&Adapter, buffer);
        break;
    case _IOC_NR(SET_CD_INTERFACE):
        rc = set_cash_drawer_interface(&Adapter, buffer);
        break;
    case _IOC_NR(OPEN_CD):
        rc = open_cash_drawer(&Adapter, buffer);
        break;
    case _IOC_NR(GET_CD_STATUS):
        rc = get_cash_drawer_status(&Adapter, buffer);
        break;
    case _IOC_NR(GET_DRIVER_VERSION):
        rc = get_driver_version(buffer);
        break;
#if defined(V4690)
    case _IOC_NR(SET_INTERRUPT_MODE):
        rc = set_interrupt_mode_off(&Adapter, buffer);
        break;
    case _IOC_NR(RETURN_BUFFER_NOINT):
        rc = return_buffer_noint(&Adapter, buffer);
        break;
#endif
    default:
        aip_dbg("unrecognized command, cmd=0x%x\n", _IOC_NR(cmd));
        rc = -EINVAL;
        break;
    }

out:
    aip_verbose("returning, rc=%d (0x%x)\n", rc, rc);

    return rc;
}


#if defined(V4690)
/* dcs_nvram_mmap: Memory Map driver area
 * ************************************************************************
 *
 *  Function Name:  dcs_nvram_mmap
 *
 *  Purpose:        Memory map NVRAM area for application access
 *
 *  Description:    .
 *
 *  Input:          file  -
 *                  vma*
 *
 *  Output:         0  -- success
 *                  -1 -- error
 *
 * ************************************************************************
 */

static int dcs_nvram_mmap(struct file *file, struct vm_area_struct *vma)
{
    int rc = 0;
    uint32_t offset;
    uint32_t virt_size;
    uint32_t phys_size;

    /* Check credential - only root programs can use this */
    if (!capable(CAP_SYS_ADMIN)) {
       aip_warning("dcs_nvram_mmap: This process is not permitted to access this function\n");
       return -EACCES;
    } else {
       // aip_dbg("dcs_nvram_mmap: Access has been granted to this NVRAM function\n");
    }

    if (Adapter.nvram_available == TRUE) {
        offset = vma->vm_pgoff << PAGE_SHIFT;

        virt_size = vma->vm_end - vma->vm_start;
        phys_size = Adapter.nvram_size - offset;

        aip_info("nvram_mmap: offset=%x, size=%ld\n", offset, phys_size);

        /* set the reserved bit, so this area is not swapped out  */
        vma->vm_flags |= VM_IO;

        if (virt_size > phys_size) {
            aip_error("physical size is smaller than virtual size\n");

            /* attempt to map more memory than is physically there */
            return -EINVAL;
        }

        /* call remap_page_range( virtual, physical, size, prot) to get
         * a virtual address the user can access
         * We already have a virtual kernel address that we access...
         */
        if (io_remap_pfn_range(vma, vma->vm_start,
                               (Adapter.nvram_buffer_addr + offset) >> PAGE_SHIFT,
                               virt_size, vma->vm_page_prot)) {
            aip_error("Failed the remap_pfn_range\n");
            return -EAGAIN;
        }
    } else {
        rc = -EINVAL;
    }

    return rc;
}
#endif


/* get_driver_version: Get version information of this kernel file
 * ************************************************************************
 *
 *  Function Name:  get_driver_version
 *
 *  Purpose:        Get version information of this kernel file
 *
 *  Description:    This function returns the current version information
 *                  if this kernel file.  Updated when new features are
 *                  added to allow user-mode application to adjust at
 *                  runtime to specific behaviors.
 *
 *  Input:          buffer - pointer to argument structure
 *
 *  Output:         0       - success
 *                  -EFAULT - error
 *
 *    On success, CompletionCode will contain one of the following:
 *
 *                  RPDONE
 *
 * ************************************************************************
 */

static int get_driver_version(char *buffer)
{
    int   rc = -EFAULT;
    GET_DRIVER_VERSION_PARMS parms;

    parms.Version        = aipdcs_version;
    parms.Reserved_1     = 0;
    parms.Reserved_2     = 0;
    parms.CompletionCode = RPDONE;

    rc = 0;
    if (copy_to_user(buffer, &parms, sizeof(parms)) != 0) {
        rc = -EFAULT;
    }

    aip_dbg("returning, rc=0x%x\n", parms.CompletionCode);

    return rc;
}


/* get_dcs_info: Get adapter id and number of ports
 * ************************************************************************
 *
 *  Function Name:  get_dcs_info
 *
 *  Purpose:        Get adapter id and number of ports
 *
 *  Description:    This function gets the adapter id and number of ports
 *                  for the adapter in this given slot and returns it to
 *                  the caller in the IOCTL parameter block.
 *
 *  Input:          buffer - pointer to argument structure
 *
 *  Output:         0       - success
 *                  -EFAULT - error
 *
 *    On success, CompletionCode will contain one of the following:
 *
 *                  RPDONE
 *                  return code from INIT time
 *                  RPDONE | RPERR | RPDEV | UNKNOWN_ADAPTER
 *                  RPDONE | RPERR | RPDEV | INVALID_SLOT_NO
 *                  RPDONE | RPERR | RPDEV | BAD_PARAMETERS
 *
 * ************************************************************************
 */

static int get_dcs_info(dcs_adapter *adapter, char *buffer)
{
    int   rc = -EFAULT;
    uint32_t slot = 0;
    GET_DCS_INFO_PARMS parms;

    aip_dbg("get_dcs_info - sio_available=%d\n", adapter->sio_available);

    /* Copy over the structure from user space */
    if (copy_from_user(&parms, buffer, sizeof(parms)) != 0) {
        goto out;
    }
    slot = parms.Slot;

    /* If the slot number is valid, process it. */
    if (slot == 1) {
        /* If we recognize the adapter as one of ours, continue. */
        if (adapter->known_adapter != TRUE)
            rc = RPDONE | RPERR | RPDEV | UNKNOWN_ADAPTER;
        else {
            /* If we successfully setup the adapter, process
             * this request.
             */
            if (adapter->rc == RPDONE) {
                /*
                 * Store the adapter ID we are working with in
                 * the client register structure.  Also, store
                 * the number of ports for this adapter card.
                 */
                parms.AdapterID = (long) adapter->adapter_id;
                parms.NumPorts  = (long) adapter->port_count;
            }

            if (adapter->sio_available == FALSE)
                rc = RPDONE | RPERR | RPDEV | LOST_8051;
            else
                rc = adapter->rc;
        }
    } else if (slot == 0) {
        /*
         * Store the planar ID we are working with in the client
         * register structure.  Also, store the number of ports
         * for this adapter card.
         */
        parms.AdapterID = (long) adapter->id_model;
        parms.NumPorts  = (long) adapter->port_count;
        rc = RPDONE;
    } else {
        rc = RPDONE | RPERR | RPDEV | INVALID_SLOT_NO;
    }

    parms.CompletionCode = rc;

    rc = 0;
    if (copy_to_user(buffer, &parms, sizeof(parms)) != 0) {
        rc = -EFAULT;
    }

out:

    aip_verbose("returning, rc=0x%x\n", parms.CompletionCode);

    return rc;
}


/* get_slot_info: Get adapter id and number of ports
 * ************************************************************************
 *
 *  Function Name:  get_slot_info
 *
 *  Purpose:        Get adapter id and number of ports
 *
 *  Description:    This function gets the adapter id and number of ports
 *                  for the adapter in this given slot and returns it to
 *                  the caller in the IOCTL parameter block.
 *
 *  Input:          buffer - pointer to argument structure
 *
 *  Output:         0       - success
 *                  -EFAULT - error
 *
 *    On success, CompletionCode will contain one of the following:
 *
 *                  RPDONE
 *                  return code from INIT time
 *                  RPDONE | RPERR | RPDEV | UNKNOWN_ADAPTER
 *                  RPDONE | RPERR | RPDEV | INVALID_SLOT_NO
 *                  RPDONE | RPERR | RPDEV | BAD_PARAMETERS
 *
 * ************************************************************************
 */

static int get_slot_info(dcs_adapter *adapter, char *buffer)
{
    int   rc = -EFAULT;
    GET_SLOT_INFO_PARMS parms;
    int i;
    int cd_count = 0;

    /* Always copy slot 0 info (planar) */
    memset(&parms, 0, sizeof(parms));
    parms.SlotType[0]  = SLOT_TYPE_PLANAR;
    parms.AdapterID[0] = (long) adapter->id_model;

    aip_dbg("SlotType[0]=%#x, AdapterID[0]=%#x\n",
            parms.SlotType[0], parms.AdapterID[0]);

    /* Copy slot 1 through MAX_SLOTS only if it's a known SIO adapter
     * and there are no errors for that adapter.
     */
    for (i = 1; i < MAX_SLOTS; i++) {
        parms.rc[i] =  RPDONE | RPERR | RPDEV | UNKNOWN_ADAPTER;
    }

    if (adapter->known_adapter == TRUE) {
        uchar_t cd_status_reg = inb(Adapter.base_io_addr);

        if (adapter->sio_available == TRUE) {
            parms.SlotType[1]  = SLOT_TYPE_IBM_SIO;
        } else if (adapter->nvram_available == TRUE) {
            parms.SlotType[1]  = SLOT_TYPE_IBM_NVRAM;
        }

        parms.AdapterID[1] = (long) adapter->adapter_id;
        parms.SlotNVRAM[1] = adapter->nvram_size;

        if (adapter->nvram_available == FALSE) {
            parms.SlotNVRAM[1] = 0;
        }

        if (!(cd_status_reg & SP700_CD0_DRAWER_1_CONNECTED)) {
            cd_count++;
        }
        if (!(cd_status_reg & SP700_CD0_DRAWER_2_CONNECTED)) {
            cd_count++;
        }
        parms.SlotDrawers[1] = cd_count;

        parms.rc[1] = (long) adapter->rc;

        aip_dbg("SlotType[1]=%#x, AdapterID=%#x, NvramSize=%#x, CashDrawers=%#x, rc=%x\n",
                parms.SlotType[1], parms.AdapterID[1],
                parms.SlotNVRAM[1], parms.SlotDrawers[1],
                parms.rc[1]);
    }

    parms.CompletionCode = RPDONE;
    rc = 0;
    if (copy_to_user(buffer, &parms, sizeof(parms)) != 0) {
        rc = -EFAULT;
    }

    aip_verbose("returning, rc=0x%x\n", parms.CompletionCode);

    return rc;
}


/* sio_check: Common parameter check
 * ****************************************************************************
 *
 *  Function Name:  sio_check
 *
 *  Purpose:        Common parameter check
 *
 *  Description:    This function checks to make sure the slot number
 *                  is correct, the adapter is one we recognize, and
 *                  the adapter was set up correctly..
 *
 *  Input:          slot number to validate
 *
 *  Output:         RPDONE
 *                  RPDONE | RPERR | RPDEV | UNKNOWN_ADAPTER
 *                  RPDONE | RPERR | RPDEV | INVALID_SLOT_NO
 *
 * ****************************************************************************
 */

static int sio_check(dcs_adapter *adapter, uint32_t slot)
{
    int rc = RPDONE;

    /* If the slot number is valid, process it. */
    if (slot != 1) {
        rc = RPDONE | RPERR | RPDEV | INVALID_SLOT_NO;
    }
    /* If we recognize the adapter as one of ours, continue. */
    else if (adapter->known_adapter == FALSE) {
        rc = RPDONE | RPERR | RPDEV | UNKNOWN_ADAPTER;
    } else if (adapter->sio_available == FALSE) {
        rc = RPDONE | RPERR | RPDEV | LOST_8051;
    }
    /* If we had an error setting up the adapter */
    else {
        rc = adapter->rc;
    }

    return rc;
}


/* nvram_check: Common parameter check
 * ****************************************************************************
 *
 *  Function Name:  nvram_check
 *
 *  Purpose:        Common parameter check
 *
 *  Description:    This function checks to make sure the slot number
 *                  is correct, the adapter is one we recognize, and
 *                  the adapter was set up correctly..
 *
 *  Input:          slot number to validate
 *
 *  Output:         RPDONE
 *                  RPDONE | RPERR | RPDEV | UNKNOWN_ADAPTER
 *                  RPDONE | RPERR | RPDEV | INVALID_SLOT_NO
 *
 * ****************************************************************************
 */

static int nvram_check(dcs_adapter *adapter, uint32_t slot)
{
    int rc = RPDONE;

    /* If the slot number is valid, process it. */
    if (slot != 1) {
        rc = RPDONE | RPERR | RPDEV | INVALID_SLOT_NO;
    }
    /* If we recognize the adapter as one of ours, continue. */
    else if (adapter->known_adapter == FALSE) {
        rc = RPDONE | RPERR | RPDEV | UNKNOWN_ADAPTER;
    }
    /* If we had an error setting up the adapter */
    else {
        rc = adapter->nvram_rc;
    }

    return rc;
}


/* power_on_reset_8051: Cause the 8051 to go through Power On Reset
 * ****************************************************************************
 *
 *  Function Name:  power_on_reset_8051
 *
 *  Purpose:        Cause the 8051 to go through a Power On Reset
 *
 *  Description:    This function sets bit 6 of the System Status Byte (SSB)
 *                  to cause the 8051 to do a Power On Reset (POR).  It then
 *                  blocks for up to 2 sec waiting for the 8051 to interrupt.
 *                  It then checks the status in bit 2 of the SSB.
 *
 *  Input:          buffer - pointer to argument structure
 *
 *  Output:         0       - success
 *                  -EFAULT - error
 *
 *    On success, CompletionCode will contain one of the following:
 *
 *                  RPDONE
 *                  return code from INIT time
 *                  RPDONE | RPERR | RPDEV | INVALID_SLOT_NO
 *                  RPDONE | RPERR | RPDEV | LOST_8051
 *                  RPDONE | RPERR | RPDEV | UNKNOWN_ADAPTER
 *                  RPDONE | RPERR | RPDEV | BAD_PARAMETERS
 *
 * ****************************************************************************
 */

static int power_on_reset_8051(dcs_adapter *adapter, char *buffer)
{
    int rc = -EFAULT;
    POR_8051_PARMS parms;

    /* Extract the slot number from the client structure. */
    if (copy_from_user(&parms, buffer, sizeof(parms)) != 0) {
        goto out;
    }

    /* If we successfully setup the adapter, process this request. */
    if ((rc = sio_check(adapter, parms.Slot)) == RPDONE) {
        uchar_t bdata;

        /* SSB PC_DONE bit must be cleared before we set access
         * the SSB.
         */
        wait_for_pc_done_status(adapter, 1000, 1000);

        /* Turn bit 6 on for one millisecond and then turn the bit off
         * again to start POR.
         */
        bdata = readb(adapter->ssb) | SSB_SOFT_POR;
        writeb(bdata, adapter->ssb);
        udelay(1000);

        bdata = readb(adapter->ssb) & ~SSB_SOFT_POR;
        writeb(bdata, adapter->ssb);

        /* Block the thread for either 3 seconds or until the Power On
         * Reset (POR) is completed and the 8051 interrupts us. The
         * first value is a unique id. Set the timer to go off if we
         * don't get interrupted
         */
        dcs_timer.expires = jiffies + HZ*3;
        adapter->timer_expired = FALSE;

        add_timer(&dcs_timer);
        while (!(readb(adapter->ssb) & SSB_INTERRUPTED)) {
            if (adapter->timer_expired == TRUE) {
                break;
            }
        }

        if (adapter->timer_expired == TRUE) {
            aip_warning("SSB_INTERRUPTED timer expired\n");
        } else {
            del_timer(&dcs_timer);

            if (adapter->current_pid != 0) {
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 27)
                kill_proc(adapter->current_pid, SIGUSR1, 1);
#else
                kill_pid(adapter->current_pid, SIGUSR1, 1);
#endif
            }
        }

        /* Bit 2 of the SSB should be on.  If it isn't then we do not
         * have a functioning 8051.  Set the appropriate return code.
         */
        if (readb(Adapter.ssb) & SSB_INTERRUPTED) {
            rc = RPDONE;
            Adapter.buffer_read = FALSE;
        } else {
            aip_warning("failed to set SSB_INTERRUPTED\n");
            rc = RPDONE | RPERR | RPDEV | LOST_8051;
        }
    }

    parms.CompletionCode = rc;
    rc = 0;
    if (copy_to_user(buffer, &parms, sizeof(parms)) != 0) {
        rc = -EFAULT;
    }

out:
    aip_dbg("returning rc=%#x\n", parms.CompletionCode);

    return rc;
}


/* request_buffer: Request ownership of the 2K buffer
 * ****************************************************************************
 *
 *  Function Name:  request_buffer
 *
 *  Purpose:        Request ownership of the 2K buffer from the 8051
 *
 *  Description:    This function sets bit 0 of the System Status Byte (SSB)
 *                  to tell the 8051 that we want ownership of the 2K buffer.
 *
 *  Input:          buffer - pointer to argument structure
 *
 *  Output:         0       - success
 *                  -EFAULT - error
 *
 *    On success, CompletionCode will contain one of the following:
 *
 *                  RPDONE
 *                  return code from INIT time
 *                  RPDONE | RPERR | RPDEV | UNKNOWN_ADAPTER
 *                  RPDONE | RPERR | RPDEV | INVALID_SLOT_NO
 *                  RPDONE | RPERR | RPDEV | BAD_PARAMETERS
 *
 * ****************************************************************************
 */

static int request_buffer(dcs_adapter *adapter, char *buffer)
{
    int rc = -EFAULT;
    REQ_BUFFER_PARMS parms;

    /* Extract the slot number from the client structure. */
    if (copy_from_user(&parms, buffer, sizeof(parms)) != 0) {
        goto out;
    }

    /* If we successfully setup the adapter, process this request. */
    if ((rc = sio_check(adapter, parms.Slot)) == RPDONE) {
        uchar_t bdata;

        /* SSB PC_DONE bit must be cleared before we set access the SSB.
         */
        wait_for_pc_done_status(adapter, 1000, 1000);

        /* Turn on bit 0 to tell 8051 that we want posession of the
         * 2K shared buffer.
         */
        bdata = readb(adapter->ssb) | SSB_BUFFER_ACCESS;
        writeb(bdata, adapter->ssb);

        rc = RPDONE;
    }

    parms.CompletionCode = rc;
    rc = 0;
    if (copy_to_user(buffer, &parms, sizeof(parms))) {
        rc = -EFAULT;
    }

out:

    aip_dbg("returning rc=%#x\n", parms.CompletionCode);

    return rc;
}


/* return_buffer: Tell the 8051 that we are done with the 2K buffer
 * ************************************************************************
 *
 *  Function Name:  return_buffer
 *
 *  Purpose:        Tell the 8051 that we are done with the 2K buffer.
 *
 *  Description:    This function set bit 1 of the System Status Byte
 *                  (SSB) to tell the 8051 that we are done with the
 *                  2K shared buffer.
 *
 *  Input:          buffer - pointer to argument structure
 *
 *  Output:         0       - success
 *                  -EFAULT - error
 *
 *    On success, CompletionCode will contain one of the following:
 *
 *                  RPDONE
 *                  return code from INIT time
 *                  RPDONE | RPERR | RPDEV | UNKNOWN_ADAPTER
 *                  RPDONE | RPERR | RPDEV | INVALID_SLOT_NO
 *                  RPDONE | RPERR | RPDEV | BAD_PARAMETERS
 *                  RPDONE | RPERR | RPDEV | PC_DONE_NOT_SET
 *
 * ************************************************************************
 */

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wframe-larger-than="
static int return_buffer(dcs_adapter *adapter, char *buffer)
{
    int rc = -EFAULT;
    RET_BUFFER_PARMS parms;

    /* Extract the slot number from the client structure. */
    if (copy_from_user(&parms, buffer, sizeof(parms)) != 0) {
        goto out;
    }

    /* If we successfully setup the adapter, process this request. */
    if ((rc = sio_check(adapter, parms.Slot)) == RPDONE) {
        uchar_t bdata;

        adapter->buffer_read = FALSE;

        /* Place given 2K buffer data into the shared buffer
         * (but not SSB)
         */
        memcpy_toio(adapter->p2k_buffer, parms.Buffer, 2047);

        /* SSB PC_DONE bit must be cleared before we set access the SSB.
         */
        wait_for_pc_done_status(adapter, 1000, 1000);

        /* Turn on bit 1 to tell 8051 that we are finished with
         * the 2K shared buffer.  Wait 1ms and then enable
         * interrupts.  The 1ms wait is to give the 8051 enough
         * time to lower bit 2 so that we don't generate an
         * immediate interrupt by setting
         * SSB_INTERRUPT_PC_ENABLE.  It may become
         * necessary to add code after the Block() to determine
         * whether or not the 8051 has lowered bits 0 and 2.
         */
        bdata = readb(adapter->ssb) | SSB_PC_DONE;
        writeb(bdata, adapter->ssb);

        /* SSB PC_DONE bit must be cleared before we set
         * INTERRUPT_PC_ENABLE.
         */
        dcs_timer.expires = jiffies + HZ*2;  /* wait 2 seconds max  */
        adapter->timer_expired = FALSE;
        add_timer(&dcs_timer);

        while (readb(adapter->ssb) & SSB_PC_DONE) {
            if (adapter->timer_expired == TRUE) {
                break;
            }
            udelay(1000);
        }

        if (adapter->timer_expired == TRUE) {
            aip_warning("SSB_PC_DONE failed to clear\n");

            rc = RPDONE | PC_DONE_NOT_SET;
        } else {
            del_timer(&dcs_timer);
        }

        bdata = readb(adapter->ssb) | SSB_INTERRUPT_PC_ENABLE;
        writeb(bdata, adapter->ssb);
        rc = RPDONE;
    }

    parms.CompletionCode = rc;
    rc = 0;
    if (copy_to_user(buffer, &parms, sizeof(parms)) != 0) {
        rc = -EFAULT;
    }

out:
    aip_dbg("returning rc=%#x\n", parms.CompletionCode);

    return rc;
}
#pragma GCC diagnostic pop


/* return_buffer_noint: Tell the 8051 that we are done with the 2K buffer
 * ************************************************************************
 *
 *  Function Name:  return_buffer
 *
 *  Purpose:        Tell the 8051 that we are done with the 2K buffer
 *                  without turning on SSB_INTERRUPT_PC_ENABLE.
 *
 *  Description:    This function set bit 1 of the System Status Byte
 *                  (SSB) to tell the 8051 that we are done with the
 *                  2K shared buffer.  Do NOT Generate an Interrupt as
 *                  a result of this!!!!
 *
 *  Input:          buffer - pointer to argument structure
 *
 *  Output:         0       - success
 *                  -EFAULT - error
 *
 *    On success, CompletionCode will contain one of the following:
 *
 *                  RPDONE
 *                  return code from INIT time
 *                  RPDONE | RPERR | RPDEV | UNKNOWN_ADAPTER
 *                  RPDONE | RPERR | RPDEV | INVALID_SLOT_NO
 *                  RPDONE | RPERR | RPDEV | BAD_PARAMETERS
 *                  RPDONE | RPERR | RPDEV | PC_DONE_NOT_SET
 *
 * ************************************************************************
 */

#if defined(V4690)
static int return_buffer_noint(dcs_adapter *adapter, char *buffer)
{
    int rc = -EFAULT;
    RET_BUFFER_PARMS parms;

    aip_dbg("enter\n");

    /* Extract the slot number from the client structure. */
    if (copy_from_user(&parms, buffer, sizeof(parms)) != 0) {
        goto out;
    }

    /* If we successfully setup the adapter, process this request. */
    if ((rc = sio_check(adapter, parms.Slot)) == RPDONE) {
        uchar_t bdata;

        /* Place given 2K buffer data into the shared buffer
         * (but not SSB)
         */
        memcpy_toio(adapter->p2k_buffer, parms.Buffer, 2047);

        adapter->buffer_read = FALSE;

        /* SSB PC_DONE bit must be cleared before we set access the SSB.
         */
        rc = wait_for_pc_done_status(adapter, 1000, 1000);

        /* Turn on bit 1 to tell 8051 that we are finished with
         * the 2K shared buffer.  Wait 1ms and then enable
         * interrupts.  The 1ms wait is to give the 8051 enough
         * time to lower bit 2 so that we don't generate an
         * immediate interrupt by setting
         * SSB_INTERRUPT_PC_ENABLE.  It may become
         * necessary to add code after the Block() to determine
         * whether or not the 8051 has lowered bits 0 and 2.
         */
        bdata = readb(adapter->ssb) | SSB_PC_DONE;
        writeb(bdata, adapter->ssb);

        /* SSB PC_DONE bit must be cleared before we set
         * INTERRUPT_PC_ENABLE.
         */
        dcs_timer.expires = jiffies + HZ*2;  /* wait 2 seconds max  */
        adapter->timer_expired = FALSE;
        add_timer(&dcs_timer);

        while (readb(adapter->ssb) & SSB_PC_DONE) {
            if (adapter->timer_expired == TRUE) {
                break;
            }
            udelay(1000);
        }

        if (adapter->timer_expired == TRUE) {
            aip_warning("SSB_PC_DONE failed to clear\n");

            rc = RPDONE | PC_DONE_NOT_SET;
        } else {
            del_timer(&dcs_timer);
            rc = RPDONE;
        }
    }

    parms.CompletionCode = rc;
    rc = 0;
    if (copy_to_user(buffer, &parms, sizeof(parms)) != 0) {
        rc = -EFAULT;
    }

out:
    aip_dbg("End rc=%x\n", parms.CompletionCode);

    return rc;
}
#endif


/* wait_for_buffer: Wait for the 8051 to turn over the 2K buffer
 * ************************************************************************
 *
 *  Function Name:  wait_for_buffer
 *
 *  Purpose:        Block the thread until the 8051 is done with the 2K buffer
 *
 *  Description:    This function checks to see if we have ownership of the
 *                  2K buffer.  If we don't have it yet, block the thread
 *                  for the number of milliseconds specified in the timeout
 *                  field of the IOCTL parameters.
 *
 *  Input:          buffer - pointer to argument structure
 *
 *  Output:         0       - success
 *                  -EFAULT - error
 *
 *    On success, CompletionCode will contain one of the following:
 *
 *                  RPDONE
 *                  return code from INIT time
 *                  RPDONE | RPERR | RPDEV | UNKNOWN_ADAPTER
 *                  RPDONE | RPERR | RPDEV | BLOCK_TIMEOUT
 *                  RPDONE | RPERR | RPDEV | BAD_PARAMETERS
 *                  RPDONE | RPERR | RPDEV | INVALID_SLOT_NO
 *
 * ************************************************************************
 */

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wframe-larger-than="
static int wait_for_buffer(dcs_adapter *adapter, char *buffer)
{
    int rc = - EFAULT;
    WAIT_BUFFER_PARMS parms;

    /* Extract the slot number from the client structure. */
    if (copy_from_user(&parms, buffer, sizeof(parms)) != 0) {
        goto out;
    }

    /* If we successfully setup the adapter, process this request. */
    if ((rc = sio_check(adapter, parms.Slot)) == RPDONE) {
        /* SSB PC_DONE bit must be cleared before we set access the SSB.
         */
        rc = wait_for_pc_done_status(adapter, 1000, 1000);

        /* Check bit 2 of the System Status Byte (SSB) to see if we
         * have the buffer already.
         */
        if (rc == RPDONE) {
            rc = wait_for_interrupted(adapter, parms.Timeout, 1000);
        }

        /* Did we get the buffer? */
        if (rc == RPDONE) {
            /* If we successfully setup the adapter, process this request. */
            if (adapter->buffer_read == FALSE) {
                /* Copy the 2K shared buffer to the callers buffer. */
                memcpy_fromio(parms.Buffer, adapter->p2k_buffer,
                              BUFF_LEN);

                adapter->buffer_read = TRUE;
            } else {
                rc = UNEXPECTED_READ_FAILURE;
            }
        }
    }

    parms.CompletionCode = rc;
    rc = 0;
    if (copy_to_user(buffer, &parms, sizeof(parms)) != 0) {
        rc = -EFAULT;
    }

out:
    aip_dbg("End rc=%#x, SSB=%#x\n", parms.CompletionCode,
            readb(adapter->ssb));

    return rc;
}
#pragma GCC diagnostic pop


/* disable_async_comm: Request to disable notification of device channel interrupts
 * ************************************************************************
 *
 *  Function Name:  disable_async_comm
 *
 *  Purpose:        Disable notification of device channel interrupts
 *
 *  Description:    This function disables asynchronous communication of
 *                  interrupts to user mode by clearing out the process id
 *                  and async_comm flag in the BOARDDATA structure.
 *
 *  Input:          buffer - pointer to argument structure
 *
 *  Output:         0       - success
 *                  -EFAULT - error
 *
 * ************************************************************************
 */

static int disable_async_comm(dcs_adapter *adapter, char *buffer)
{
    int rc = 0;
    COMPLETION_CODE_PARMS parms;

    adapter->current_pid = 0;

    parms.CompletionCode = RPDONE;

    if (copy_to_user(buffer, &parms, sizeof(parms)) != 0) {
        rc = -EFAULT;
    }

    aip_dbg("disable_async_comm exiting, rc=%d\n", rc);

    return rc;
}


/* enable_async_comm: Request to enable notification of device channel interrupts
 * ************************************************************************
 *
 *  Function Name:  enable_async_comm
 *
 *  Purpose:        Enable notification of device channel interrupts to
 *                  the given process id
 *
 *  Description:    This function enables asynchronous communication of
 *                  interrupts to user mode by setting the process id
 *                  and async_comm flag in the BOARDDATA structure.
 *
 *  Input:          buffer - pointer to argument structure
 *
 *  Output:         0       - success
 *                  -EFAULT - error
 *
 * ************************************************************************
 */

static int enable_async_comm(dcs_adapter *adapter, char *buffer)
{
    int rc = 0;
    ENABLE_ASYNC_COMM_PARMS parms;

    aip_dbg("enable_async_comm\n");

#if !defined(V4690)
    if (adapter->current_pid != 0) {
        rc = -EBUSY;
        goto out;
    }
#endif

    if (copy_from_user(&parms, buffer, sizeof parms)) {
        rc = -EFAULT;
        goto out;
    }

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 27)
    adapter->current_pid = (pid_t)parms.ProcessID;
#else
    rcu_read_lock();
    adapter->current_pid = find_vpid((pid_t) parms.ProcessID);
    rcu_read_unlock();
#endif

    parms.CompletionCode = RPDONE;

    if (copy_to_user(buffer, &parms, sizeof(parms)) != 0) {
        rc = -EFAULT;
    }

out:

    aip_dbg("enable_async_comm exiting, rc=%d\n", rc);

    return rc;
}


/* get_interrupt_slot: Request to return to caller number of sloty that interrupted
 * ************************************************************************
 *
 *  Function Name:  get_interrupt_slot
 *
 *  Purpose:        Return to the caller the number of the slot (adapter)
 *                  that caused the interrupt.
 *
 *  Description:    This function passes back to the caller interrupt_slot
 *                  from the BOARDDATA structure.  This byte will indicate
 *                  all slots that have interrupted and not yet been serviced
 *                  (it is a bit mask).
 *
 *  Input:          buffer - pointer to argument structure
 *
 *  Output:         0       - success
 *                  -EFAULT - error
 *
 *  Note:  The current implementation of POSS for Linux does not call this
 *         function since it has never had to support multiple device channel
 *         adapters in the same machine.
 *
 * ************************************************************************
 */

static int get_interrupt_slot(dcs_adapter *adapter, char *buffer)
{
    int rc = 0;
    GET_INTERRUPT_SLOT_PARMS parms;

    parms.Slot = 1;
    parms.CompletionCode = RPDONE;

    if (copy_to_user(buffer, &parms, sizeof(parms))) {
        rc = -EFAULT;
    }

    return rc;
}


/* set_interrupt_mode_off: Turn off Interrupts from the 8051
 * ************************************************************************
 *
 *  Function Name:  set_interrupt_mode_off
 *
 *  Purpose:        Allow the user to turn off SSB_INTERRUPT_PC_ENABLE
 *                  Allow the User to request that interrupts not be
 *                  generated when the 8051.
 *
 *  Description:    This function permits a user of AIPDCS to request that
 *                  interrupts not be generated by the 8051, which happens
 *                  as a result of such functions as return_buffer().
 *
 *  Input:          buffer - pointer to argument structure
 *
 *  Output:         0       - success
 *                  -EFAULT - error
 *
 *  Note:  This is currently used for functions that wish to update the
 *         the 2X20 display, but do not implement the asynchronous
 *         notification of interrupts to inform that this has occurred.
 *         The multitude of unneeded interrupts bogs down the system.
 *
 * ************************************************************************
 */

#if defined(V4690)
static int set_interrupt_mode_off(dcs_adapter *adapter, char *buffer)
{
    int rc = 0;

    if (adapter->sio_available == TRUE) {
        /* set a variable that will tell us not to turn on the
         * the SSB_INTERRUPT_PC_ENABLE bit
         */
        uchar_t bdata = readb(adapter->ssb) & ~SSB_INTERRUPT_PC_ENABLE;
        writeb(bdata, adapter->ssb);

        aip_warning("Request to turn SSB_INTERRUPT_PC_ENABLE OFF!\n");
    }

    return rc;
}
#endif

/* TimerHandler: Alarm handler
 * ************************************************************************
 *
 *  Function Name:  TimerHandler
 *
 *  Purpose:        Alarm handler for situations where an interrupt is
 *                  missed or things went badly.
 *
 *  Description:    This is a timer callback function.  Tiners are used
 *                  in the 2K shared buffer-related functiosn to prevent
 *                  waiting forever (hanging the system) when something
 *                  goes wrong.
 *
 *  Input:          unused - unused
 *
 *  Output:         none
 *
 * ************************************************************************
 */

#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 14, 0)
static void dcs_timer_handler(struct timer_list *unused)
#else
static void dcs_timer_handler(unsigned long unused)
#endif
{
    aip_verbose("Timed out\n");

    Adapter.timer_expired = TRUE;
}


/* :H1.calculate_crc - Calculate a CRC code
 * ************************************************************************
 *
 * Function Name:  calculate_crc
 *
 * Purpose:        Calculate a CRC code
 *
 * Description:    This function calculates a CRC code based on the
 *                 data passed in.
 *
 * Input:          pData  - a pointer to the data buffer to use
 *                 Length - The length of data to use
 *
 * Output:         The CRC code of the data
 *
 * Notes:          This function should be written to be as fast as
 *                 possible - we assume the address passed is valid!
 *
 * ***********************************************************************
 */

static unsigned short calculate_crc(const char *buffer, int length)
{
    unsigned short AX = 0xFFFF;
    unsigned short DX = 0x0000;
    int i;

    for (i = 0; i < length ; i++) {
        DL = buffer[i];
        DX ^= AX;
        DH = 0;
        AL = AH;
        AH = 0;
        DX = LookupTable[DX];
        AX ^= DX;
    }

    return ~AX;
}


/* :H1.paged_io: Paged IO
 * ************************************************************************
 *
 *  Function Name:  paged_io
 *
 *  Purpose:        Read/Write NVRAM data
 *
 *  Description:    This function reads and writes NVRAM data where
 *                  paged I/O is used -- currently 4694 and 4695.
 *                  (Two 4K pages, page 0 always in lower window.)
 *
 *  Input:          slot   - Slot number associated with this adapter
 *                  nvr    - NVRAM start (offset)
 *                  mem    - Pointer to NVRAM data
 *                  len    - Length of NVRAM data
 *                  fWrite - Read/Write flag
 *
 *  Output:         None
 *
 * ************************************************************************
 */

static void paged_io(dcs_adapter *adapter, uint32_t nvr, char *mem,
                     uint32_t len, int write_flag)
{
    uint32_t i;
    uint32_t p;
    uint32_t old_page = 0xFFL;

    aip_dbg("nvr=%x, mem=0x%p, len=%x, fWrite=%d\n",
            nvr, mem, len, write_flag);

    for (i = 0; i < len; ++i) {
        p = nvr + i;
        if (p >= adapter->junk_offset) {
            p += adapter->junk_length;
        }

        /* If not on page 0, we will need to access in the second page
         * window.
         */
        if (p >= adapter->nvram_page_size) {  /* Past Page 0 */
            unsigned int index;

            /* If on a new page or the first time through, set the
             * page
             */
            if (old_page != (unsigned int) ((p >> 12) & 0x00FF)) {
                old_page = (unsigned int) ((p >> 12) & 0x00FF);

                aip_dbg("old_page: 0x%x\n", old_page);

                outb((uchar_t) old_page,(adapter->base_io_addr +
                                         adapter->page_reg_offset));
            }

            index = adapter->nvram_page_size + (p & 0x0FFF);
            if (write_flag) {
                adapter->nvram[index] = mem[i];
            } else {
                mem[i] = adapter->nvram[index];
            }
        } else { /* (Page 0) */
            if (write_flag) {
                adapter->nvram[p & 0x0FFF] = mem[i];
            } else {
                mem[i] = adapter->nvram[p & 0x0FFF];
            }
        }
    }

    return;
}


/* :H1.nvram_io: I/O Mapped
 * ************************************************************************
 *
 *  Function Name:  nvram_io
 *
 *  Purpose:        Read/Write NVRAM data
 *
 *  Description:    This function reads and writes NVRAM data where
 *                  the NVRAM is I/O mapped.
 *
 *  Input:          nvr    - NVRAM start (offset)
 *                  mem    - Pointer to NVRAM data
 *                  len    - Length of NVRAM data
 *                  fWrite - Read/Write flag
 *
 *  Output:         None
 *
 * ************************************************************************
 */

static void nvram_io(uint32_t nvr, char *mem, uint32_t len,
                     int write_flag)
{
    uint32_t i;
    unsigned int  hi = (unsigned int) (nvr / 256);
    unsigned int  lo = (unsigned int) (nvr % 256);

    aip_dbg("nvr=%x, mem=0x%p, len=%x, fWrite=%d\n",
            nvr, mem, len, write_flag);

    for (i = 0; i < len; ++i) {
        outb(hi, (uchar_t) 0x75);
        outb(lo, (uchar_t) 0x74);

        if (write_flag) {
            outb(mem[i], (uchar_t) 0x76);
        } else {
            mem[i] = (char) inb((uchar_t) 0x76);
        }

        if (++lo == 0x100) {
            ++hi;
            lo = 0;
        }
    }

    return;
}


/* :H1.wcr_paged_io: Paged I/O Using Window Control Registers (WCRs)
 * ************************************************************************
 *
 *  Function Name:  wcr_paged_io
 *
 *  Purpose:        Read/Write NVRAM data
 *
 *  Description:    This function reads and writes NVRAM data where Window
 *                  Control Register-paged I/O is used -- currently Palm,
 *                  Melrose, 4695, 4674.  There are four or eight 2K pages
 *                  accessed through four or eight window control registers
 *                  (WCRs). This function uses just one 2K page, "moving" it
 *                  as necessary using WCR2.  (WCR1 accesses the 2K shared
 *                  buffer and WCR0 is EEROM which we cannot access through
 *                  Linux.)
 *
 *
 *  Input:          slot   - Slot number associated with this adapter
 *                  nvr    - NVRAM start (offset)
 *                  mem    - Pointer to NVRAM data
 *                  len    - Length of NVRAM data
 *                  fWrite - Read/Write flag
 *
 *  Output:         None
 *
 * ************************************************************************
 */

static void wcr_paged_io(dcs_adapter *adapter, uint32_t nvr, char *mem,
                         uint32_t len, int write_flag)
{
    uint32_t i;
    uint32_t p;
    unsigned int  old_page = 0xFFFF;

    aip_dbg("nvr=%x, mem=0x%p, len=%x, fWrite=%d\n",
            nvr, mem, len, write_flag);

    for (i = 0; i < len; ++i) {
        p = nvr + i;

        /* If on a new page or the first time through, set the page.
         */
        if (old_page != (unsigned int) ((p >> 11) & 0x3F)) {
            old_page = (unsigned int) ((p >> 11) & 0x3F);

            /* Since we moved the 2K buffer from WCR0 to WCR1,
             * we need to move the NVRAM to WCR2.
             */
            outb(0x20, (uchar_t) (adapter->base_io_addr + 5));
            outb(old_page, (uchar_t) (adapter->base_io_addr + 4));
        }

        if (write_flag) {
            adapter->nvram[p & 0x07FF] = mem[i];
        } else {
            mem[i] = adapter->nvram[p & 0x07FF];
        }
    }

    return;
}


/* :H1.read_write_nvram_data: Read/Write Info About NVRAM into the NVRAM
 * ************************************************************************
 *
 *  Function Name:  read_write_nvram_data
 *
 *  Purpose:        Read/Write Info About NVRAM
 *
 *  Description:    This function reads and writes information about how
 *                  the NVRAM is divided between the device drivers, system
 *                  services, and applications.  This information is written
 *                  at the top (end) of the device driver area in the NVRAM.
 *
 *  Input:          slot       - Slot number associated with this adapter
 *                  datarecptr - Pointer to NVRAM data record
 *                  datareclen - Length of NVRAM data record
 *                  rwFlag     - Read/Write flag
 *
 *  Output:         None
 *
 * ************************************************************************
 */

static void read_write_nvram_data(dcs_adapter *adapter, char *datarecptr,
                                  uint32_t datareclen, int write_flag)
{
    uint32_t nvrecoffset = (adapter->nvram_area[DEVICE_DRVRS].Offset +
                                 adapter->nvram_area[DEVICE_DRVRS].Size) -
                                datareclen;

    aip_dbg("nvrecoffset=%d, write_flag=%d\n", nvrecoffset, write_flag);

    switch (adapter->nvram_map_type) {
    case NVRAM_MEMORY_MAP:
        aip_dbg("nvram_memory_map\n");

        if (write_flag == NVREAD) {
            memcpy_fromio(datarecptr, adapter->nvram +
                          nvrecoffset, datareclen);
        } else {
            memcpy_toio(adapter->nvram + nvrecoffset,
                        datarecptr, datareclen);
        }

        break;

    case NVRAM_IO_MAP:
        aip_dbg("nvram_io_map\n");

        nvram_io(adapter->nvram_buffer_addr + nvrecoffset, datarecptr,
                 datareclen, write_flag);

        break;

    case NVRAM_PAGED:
        aip_dbg("nvram_paged\n");

        paged_io(adapter, nvrecoffset + adapter->bottum_junk,
                 datarecptr, datareclen, write_flag);

        break;

    case NVRAM_WCR_PAGED:
        aip_dbg("nvram_wcr_paged\n");

        wcr_paged_io(adapter, nvrecoffset + adapter->bottum_junk,
                     datarecptr, datareclen, write_flag);

        break;

    default:
        break;
    }

    return;
}


/* :H1.write_nvram_table: Write Info About NVRAM into the NVRAM
 * ************************************************************************
 *
 *  Function Name:  write_nvram_table
 *
 *  Purpose:        Write Info About NVRAM
 *
 *  Description:    This function builds a NVRAM record containing the
 *                  NVRAM data table and writes it to the top of the NVRAM.
 *                  It then reads the table back and compares it with the
 *                  area data contained in NVSlotArray.
 *
 *  Input:          slot - Slot number associated with this NVRAM
 *
 *  Output:         RPDONE
 *                    or
 *                  RPDONE | RPERR | RPDEV | NVRAM_WRITE_ERROR
 *
 * ************************************************************************
 */

static int write_nvram_table(dcs_adapter *Adapter)
{
    int rc;
    uint32_t nvreclen;          /* Length of NVRAM data record */
    char nvramrec[sizeof(NVRAM_DATA)+4]; /* NVRAM area usage info record */
    NVRAM_DATA  nvinfo;
    PNVRAM_DATA nviptr;
    short crc;

    nvinfo.TotalSize = Adapter->nvram_size;
    memcpy(nvinfo.AreaData, Adapter->nvram_area,
           (sizeof(AREA_DATA) * NUM_AREAS));

    /*   Build the record - first the length, then data, then CRC.  The CRC
     *   is calculated based on the length of the user data.
     *
     *   Note: The following code will work on Intel and RISC machines.
     *  Don't change to a case or this will no longer be portable.
     */
    nvramrec[0] = (char) ((sizeof(NVRAM_DATA) + 4) & 0x00FF);
    nvramrec[1] = (char) (((sizeof(NVRAM_DATA) + 4) >> 8) & 0x00FF);
    memcpy(nvramrec + 2, &nvinfo, sizeof(NVRAM_DATA));

    crc = calculate_crc((char *) nvramrec, (sizeof(NVRAM_DATA) + 2));
    nvramrec[(sizeof(NVRAM_DATA) + 2)] = (char) (crc & 0x00FF);
    nvramrec[(sizeof(NVRAM_DATA) + 3)] = (char) ((crc >> 8) & 0x00FF);

    nvreclen = sizeof(NVRAM_DATA) + 4;

    /* Write the record to the last (sizeof(NVRAM_DATA)+4) bytes of this
     * NVRAM.
     */
    read_write_nvram_data(Adapter, (char *) nvramrec, nvreclen, NVWRITE);

    /* Clear the temporary record so we can fill it again.
     */
    memset(nvramrec, 0x00, nvreclen);

    /* Read the NVRAM data record from the top of NVRAM and make sure it
     * matches what we have in NVSlotArray...
     */
    read_write_nvram_data(Adapter, (char *) nvramrec, nvreclen, NVREAD);
    nviptr = (PNVRAM_DATA) &nvramrec[2];

    if ((Adapter->nvram_size != nviptr->TotalSize) ||
        (memcmp(Adapter->nvram_area, nviptr->AreaData,
                (sizeof(AREA_DATA) * NUM_AREAS)) != 0)) {

        aip_warning("Written table DOES NOT match read table\n");
        aip_warning("NVRAM access disabled\n");

        Adapter->nvram_available = FALSE;
        rc = RPDONE | RPERR | RPDEV | NVRAM_WRITE_ERROR;
    } else {
        aip_dbg("Written table matches read table\n");

        rc = RPDONE;
    }

    aip_dbg("returning rc=0x%x\n", rc);

    return rc;
}


/* :H1.get_nvram_data: Get NVRAM Information
 * ************************************************************************
 *
 *  Function Name:  get_nvram_data
 *
 *  Purpose:        Get information about the NVRAM in a particular slot
 *
 *  Description:    Returns the total size and information about the
 *                  areas for a particular NVRAM.
 *
 *  Input:          pr - Pointer to the request packet
 *
 *  Output:         0       - success
 *                  -EFAULT - error
 *
 *    On success, CompletionCode will contain one of the following:
 *
 *                  RPDONE
 *                  return code from INIT time
 *                  RPDONE | RPERR | RPDEV | INVALID_SLOT_NO
 *                  RPDONE | RPERR | RPDEV | UNKNOWN_ADAPTER
 *                  RPDONE | RPERR | RPDEV | BAD_PARAMETERS
 *
 * ************************************************************************
 */

static int get_nvram_data(dcs_adapter *adapter, char *buffer)
{
    int rc = -EFAULT;
    GET_NVRAM_DATA_PARMS parms;

    if (copy_from_user(&parms, buffer, sizeof(parms)) != 0) {
        goto out;
    }

    /* If we successfully setup the adapter, process this request. */
    if ((rc = nvram_check(adapter, parms.Slot)) == RPDONE) {
        int index;

        parms.NumAreas = (ulong_t)NUM_AREAS;
        parms.BuiltIn  = TRUE;
        parms.NvramInfo.TotalSize  = (ulong_t)adapter->nvram_size;

        for (index = 0; index < NUM_AREAS; index++) {
            aip_dbg("get_nvram_data: AreaData[%d].Size=0x%x, "
                    "Offset=0x%x, InUseFlag=0x%x\n",
                    index,
                    adapter->nvram_area[index].Size,
                    adapter->nvram_area[index].Offset,
                    adapter->nvram_area[index].InUseFlag);

            parms.NvramInfo.AreaData[index].Size =
            (ulong_t)adapter->nvram_area[index].Size;
            parms.NvramInfo.AreaData[index].Offset =
            (ulong_t)adapter->nvram_area[index].Offset;
            parms.NvramInfo.AreaData[index].InUseFlag =
            (ulong_t)adapter->nvram_area[index].InUseFlag;
        }
    }

    parms.CompletionCode = rc;
    rc = 0;
    if (copy_to_user(buffer, &parms, sizeof(parms)) != 0) {
        rc = -EFAULT;
    }

out:
    aip_dbg("returning rc=0x%x\n", parms.CompletionCode);

    return rc;
}


/* :H1.query_valid_data_flag: Get value of InUseFlag
 * ************************************************************************
 *
 *  Function Name:  query_valid_data_flag
 *
 *  Purpose:        Get value of InUseFlag
 *
 *  Description:    Returns the value of the InUseFlag for the specified
 *                  NVRAM area.
 *
 *  Input:          pr - Pointer to the request packet
 *
 *  Output:         0       - success
 *                  -EFAULT - error
 *
 *    On success, CompletionCode will contain one of the following:
 *
 *                  RPDONE
 *                  return code from INIT time
 *                  RPDONE | RPERR | RPDEV | INVALID_SLOT_NO
 *                  RPDONE | RPERR | RPDEV | UNKNOWN_ADAPTER
 *                  RPDONE | RPERR | RPDEV | BAD_PARAMETERS
 *
 * ************************************************************************
 */

static int query_valid_data_flag(dcs_adapter *adapter, char *buffer)
{
    int rc = -EFAULT;
    VALID_DATA_FLAG_PARMS parms;

    if (copy_from_user(&parms, buffer, sizeof(parms)) != 0) {
        goto out;
    }

    /* If we successfully setup the adapter, process this request. */
    if ((rc = nvram_check(adapter, parms.Slot)) == RPDONE) {
        if ((parms.AreaId < 0) || (parms.AreaId >= NUM_AREAS)) {
            rc = RPDONE | RPERR | RPDEV | BAD_PARAMETERS;
        } else {
            parms.CompletionCode = RPDONE;
            parms.Slot   = 1;
            parms.AreaId = parms.AreaId;
            parms.ValidDataFlag =
            adapter->nvram_area[parms.AreaId].InUseFlag;
        }
    }

    parms.CompletionCode = rc;
    rc = 0;
    if (copy_to_user(buffer, &parms, sizeof(parms)) != 0) {
        rc = -EFAULT;
    }

out:
    aip_dbg("returning rc=0x%x\n", parms.CompletionCode);

    return rc;
}


/* :H1.get_vital_product_data: Get VPD Information from RAS Area
 * ************************************************************************
 *
 *  Function Name:  get_vital_product_data
 *
 *  Purpose:        Get VPD from RAS Area of NVRAM in a 4694.
 *
 *  Description:    Returns VPD
 *
 *  Input:          pr - Pointer to the request packet
 *
 *  Output:         0       - success
 *                  -EFAULT - error
 *
 *    On success, CompletionCode will contain one of the following:
 *
 *                  RPDONE
 *
 * ************************************************************************
 */

static int get_vital_product_data(dcs_adapter *adapter, char *buffer)
{
    int rc = -EFAULT;
    GET_VPD_PARMS parms;

    if (copy_from_user(&parms, buffer, sizeof(parms)) != 0) {
        goto out;
    }

    if ((rc = nvram_check(adapter, 1)) == RPDONE) {
        /* Initialize to blanks */
        memset(parms.VPD, ' ', VITAL_PRODUCT_DATA_LENGTH);

        /* VPD is only on 4694's for now. */
        if ((adapter->adapter_id == IBM_4694N) ||
            (adapter->adapter_id == IBM_4694W)) {
            uint32_t i = 0;
            uint32_t p = 0;

            for (i = 0; i < VITAL_PRODUCT_DATA_LENGTH; ++i) {
                p = ((0xFD0 + i) & 0x0FFF);
                parms.VPD[i] = adapter->nvram[p];
            }

            if ((parms.VPD[0] != '4') ||
                (parms.VPD[1] != '6') ||
                (parms.VPD[2] != '9')) {
                /* Set to blanks -- no valid info here */
                memset(parms.VPD, ' ',
                       VITAL_PRODUCT_DATA_LENGTH);
            }
        }
    }

    parms.CompletionCode = rc;
    rc = 0;
    if (copy_to_user(buffer, &parms, sizeof(parms)) != 0) {
        rc = -EFAULT;
    }

out:
    aip_dbg("returning rc=0x%x\n", parms.CompletionCode);

    return rc;
}


/* :H1.query_nvram_card_type: Get card type for this NVRAM
 * ************************************************************************
 *
 *  Function Name:  query_nvram_card_type
 *
 *  Purpose:        Get card type for this NVRAM
 *
 *  Description:    Returns the card type for the specified slot.
 *
 *  Input:          pr - Pointer to the request packet
 *
 *  Output:         0       - success
 *                  -EFAULT - error
 *
 *    On success, CompletionCode will contain one of the following:
 *
 *                  RPDONE
 *                  return code from INIT time
 *                  RPDONE | RPERR | RPDEV | INVALID_SLOT_NO
 *                  RPDONE | RPERR | RPDEV | UNKNOWN_ADAPTER
 *                  RPDONE | RPERR | RPDEV | BAD_PARAMETERS
 *
 * ************************************************************************
 */

static int query_nvram_card_type(dcs_adapter *adapter, char *buffer)
{
    int rc = -EFAULT;
    VALID_DATA_FLAG_PARMS parms;

    if (copy_from_user(&parms, buffer, sizeof(parms)) != 0) {
        goto out;
    }

    if ((rc = nvram_check(adapter, parms.Slot)) == RPDONE) {
        parms.CompletionCode = RPDONE;
        parms.ValidDataFlag = (ulong_t) adapter->adapter_id;
    }

    parms.CompletionCode = rc;
    rc = 0;
    if (copy_to_user(buffer, &parms, sizeof(parms)) != 0) {
        rc = -EFAULT;
    }

out:
    aip_dbg("returning rc=0x%x\n", parms.CompletionCode);

    return rc;
}


/* :H1.set_valid_data_flag: Set InUseFlag
 * ************************************************************************
 *
 *  Function Name:  set_valid_data_flag
 *
 *  Purpose:        SetInUseFlag
 *
 *  Description:    Sets the InUseFlag for the specified NVRAM Area to 1.
 *
 *  Input:          pr - Pointer to the request packet
 *
 *  Output:         0       - success
 *                  -EFAULT - error
 *
 *    On success, CompletionCode will contain one of the following:
 *
 *                  RPDONE
 *                  return code from INIT time
 *                  RPDONE | RPERR | RPDEV | INVALID_SLOT_NO
 *                  RPDONE | RPERR | RPDEV | UNKNOWN_ADAPTER
 *                  RPDONE | RPERR | RPDEV | BAD_PARAMETERS
 *
 * ************************************************************************
 */

static int set_valid_data_flag(dcs_adapter *adapter, char *buffer)
{
    int rc = -EFAULT;
    VALID_DATA_FLAG_PARMS parms;

    if (copy_from_user(&parms, buffer, sizeof(parms)) != 0) {
        goto out;
    }

    if ((rc = nvram_check(adapter, parms.Slot)) == RPDONE) {
        if ((parms.AreaId < 0) || (parms.AreaId >= NUM_AREAS)) {
            rc = RPDONE | RPERR | RPDEV | BAD_PARAMETERS;
        } else {
            adapter->nvram_area[parms.AreaId].InUseFlag = TRUE;

            /* Write the NVRAM data record to top of NVRAM */
            rc = write_nvram_table(adapter);
        }
    }

    parms.CompletionCode = rc;
    rc = 0;
    if (copy_to_user(buffer, &parms, sizeof(parms)) != 0) {
        rc = -EFAULT;
    }

out:
    aip_dbg("returning rc=0x%x\n", parms.CompletionCode);

    return rc;
}


/* :H1.reset_valid_data_flag: Reset InUseFlag
 * ************************************************************************
 *
 *  Function Name:  reset_valid_data_flag
 *
 *  Purpose:        Reset InUseFlag
 *
 *  Description:    Sets the InUseFlag for the specified NVRAM Area to 0.
 *
 *  Input:          pr - Pointer to the request packet
 *
 *  Output:         0       - success
 *                  -EFAULT - error
 *
 *    On success, CompletionCode will contain one of the following:
 *
 *                  RPDONE
 *                  return code from INIT time
 *                  RPDONE | RPERR | RPDEV | INVALID_SLOT_NO
 *                  RPDONE | RPERR | RPDEV | UNKNOWN_ADAPTER
 *                  RPDONE | RPERR | RPDEV | BAD_PARAMETERS
 *
 * ************************************************************************
 */

static int reset_valid_data_flag(dcs_adapter *adapter, char *buffer)
{
    int rc = -EFAULT;
    VALID_DATA_FLAG_PARMS parms;

    if (copy_from_user(&parms, buffer, sizeof(parms)) != 0) {
        goto out;
    }

    if ((rc = nvram_check(adapter, parms.Slot)) == RPDONE) {
        if ((parms.AreaId < 0) || (parms.AreaId >= NUM_AREAS)) {
            rc = RPDONE | RPERR | RPDEV | BAD_PARAMETERS;
        } else {
            adapter->nvram_area[parms.AreaId].InUseFlag = FALSE;

            /* Write the NVRAM data record to top of NVRAM */
            rc = write_nvram_table(adapter);
        }
    }

    parms.CompletionCode = rc;
    rc = 0;
    if (copy_to_user(buffer, &parms, sizeof(parms)) != 0) {
        rc = -EFAULT;
    }

out:
    aip_dbg("returning rc=0x%x\n", parms.CompletionCode);

    return rc;
}


/* :H1.set_nvram_area_sizes: Set the size of all NVRAM areas
 * ************************************************************************
 *
 *  Function Name:  set_nvram_area_sizes
 *
 *  Purpose:        Set the size of all NVRAM areas
 *
 *  Description:    Each NVRAM can be divided into several areas (currently 3).
 *                  This function sets the size of all areas EXCEPT the area
 *                  reserved for the POSS for Windows 3.1 device drivers.
 *
 *                  NOTE: a) The application area always starts at offset 0.
 *                        b) The device driver area is always at the very top.
 *                        c) The system services area is always just before
 *                           the device driver area.
 *                        d) If additional (appl) areas are added, they should
 *                           come before the system services area.
 *
 *  Input:          pr - Pointer to the request packet
 *
 *  Output:         0       - success
 *                  -EFAULT - error
 *
 *    On success, CompletionCode will contain one of the following:
 *
 *                  RPDONE
 *                  return code from INIT time
 *                  RPDONE | RPERR | RPDEV | INVALID_SLOT_NO
 *                  RPDONE | RPERR | RPDEV | UNKNOWN_ADAPTER
 *                  RPDONE | RPERR | RPDEV | BAD_PARAMETERS
 *                  RPDONE | RPERR | RPDEV | BAD_BUFFER
 *                  RPDONE | RPERR | RPDEV | OFFSET_OUT_OF_RANGE
 *                  RPDONE | RPERR | RPDEV | SIZE_OUT_OF_RANGE
 *                  RPDONE | RPERR | RPDEV | NVRAM_AREA_IN_USE
 *                  RPDONE | RPERR | RPDEV | NVRAM_WRITE_ERROR
 *
 * ************************************************************************
 */

static int set_nvram_area_sizes(dcs_adapter *adapter, char *buffer)
{
    int rc = -EFAULT;
    GET_NVRAM_DATA_PARMS  parms;
    uint32_t totalsize = 0;/* Total NVRAM available for subdividing */
    uint32_t newsize = 0;  /* Total of new sizes */
    uint32_t next_offset;   /* Next NVRAM offset */
    int index = 1;

    if (copy_from_user(&parms, buffer, sizeof(parms)) != 0) {
        goto out;
    }

    if ((rc = nvram_check(adapter, parms.Slot)) != RPDONE) {
        goto rc_out;
    }

    while (index < NUM_AREAS) {
        if (adapter->nvram_area[index].InUseFlag == FALSE) {
            rc = RPDONE | RPERR | RPDEV | NVRAM_AREA_IN_USE;
            goto rc_out;
        }
        index++;
    }

    totalsize = adapter->nvram_size - adapter->nvram_area[DEVICE_DRVRS].Size;

    for (index = 1; index < NUM_AREAS; index++) {
        newsize += parms.NvramInfo.AreaData[index].Size;
    }

    if (totalsize < newsize) {
        rc = RPDONE | RPERR | RPDEV | SIZE_OUT_OF_RANGE;
    } else {
        /* Set the new sizes and offsets for all but system services
         * area.  Start at offset 0.
         */
        next_offset = 0;
        for (index = (NUM_AREAS - 1); index > 1; index--) {
            adapter->nvram_area[index].Size =
            parms.NvramInfo.AreaData[index].Size;
            adapter->nvram_area[index].Offset = next_offset;
            next_offset += adapter->nvram_area[index].Size;
        }

        /* Set the new size and offset for the system services
         * area -- just before the device driver area.
         */
        adapter->nvram_area[SERVICES].Size =
        parms.NvramInfo.AreaData[SERVICES].Size;
        adapter->nvram_area[SERVICES].Offset =
        adapter->nvram_area[DEVICE_DRVRS].Offset -
        parms.NvramInfo.AreaData[SERVICES].Size;

        /* Write the NVRAM data record to top of NVRAM */
        rc = write_nvram_table(adapter);
    }

rc_out:
    parms.CompletionCode = rc;
    rc = 0;
    if (copy_to_user(buffer, &parms, sizeof(parms)) != 0) {
        rc = -EFAULT;
    }

out:
    aip_dbg("returning rc=0x%x\n", parms.CompletionCode);

    return rc;
}


/* :H1.nvram_read_data: Read data from NVRAM
 * ************************************************************************
 *
 *  Function Name:  nvram_read_data
 *
 *  Purpose:        Read data from NVRAM
 *
 *  Description:    This function checks to make sure that the caller has
 *                  specified a valid NVRAM offset and length.  Then makes
 *                  the necessary calls to the memory or I/O copy routine
 *                  to copy the data out of the NVRAM to the caller's buffer.
 *
 *  Input:          buffer - input buffer
 *
 *  Output:         0       - success
 *                  -EFAULT - error
 *
 *    On success, CompletionCode will contain one of the following:
 *
 *                  RPDONE
 *                  return code from INIT time
 *                  RPDONE | RPERR | RPDEV | INVALID_SLOT_NO
 *                  RPDONE | RPERR | RPDEV | LOST_8051
 *                  RPDONE | RPERR | RPDEV | UNKNOWN_ADAPTER
 *                  RPDONE | RPERR | RPDEV | BAD_PARAMETERS
 *                  RPDONE | RPERR | RPDEV | BAD_BUFFER
 *                  RPDONE | RPERR | RPDEV | OFFSET_OUT_OF_RANGE
 *                  RPDONE | RPERR | RPDEV | SIZE_OUT_OF_RANGE
 *
 * ************************************************************************
 */

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wframe-larger-than="
static int nvram_read_data(dcs_adapter *adapter, char *buffer)
{
    int rc = -EFAULT;
    NVRAM_READ_PARMS parms;

    if (copy_from_user(&parms, buffer, sizeof(parms)) != 0) {
        goto out;
    }

    if ((rc = nvram_check(adapter, parms.Slot)) != RPDONE) {
        /* just return the error code */
    } else if (parms.Offset > adapter->nvram_size) {
        rc = RPDONE | RPERR | RPDEV | OFFSET_OUT_OF_RANGE;
    } else if (parms.Length > sizeof(parms.Buffer)) {
        rc = RPDONE | RPERR | RPDEV | BAD_PARAMETERS;
    } else if ((parms.Offset + parms.Length) > adapter->nvram_size) {
        rc = RPDONE | RPERR | RPDEV | SIZE_OUT_OF_RANGE;
    } else {
        switch (adapter->nvram_map_type) {
        case NVRAM_MEMORY_MAP:
            aip_dbg("nvram_memory_map: offset=%d, length=%d\n",
                    parms.Offset, parms.Length);

            memcpy_fromio(parms.Buffer,
                          adapter->nvram + parms.Offset,
                          (unsigned short) parms.Length);

            break;

        case NVRAM_IO_MAP:
            nvram_io(adapter->nvram_buffer_addr + parms.Offset,
                     parms.Buffer, parms.Length, NVREAD);

            break;

        case NVRAM_PAGED:
            paged_io(adapter, parms.Offset + adapter->bottum_junk,
                     parms.Buffer, parms.Length, NVREAD);

            break;

        case NVRAM_WCR_PAGED:
            wcr_paged_io(adapter, parms.Offset + adapter->bottum_junk,
                         parms.Buffer, parms.Length, NVREAD);

            break;

        default:
            break;
        }
    }

    parms.CompletionCode = rc;
    rc = 0;
    if (copy_to_user(buffer, &parms, sizeof(parms)) != 0) {
        rc = -EFAULT;
    }

out:
    aip_dbg("returning rc=0x%x\n", parms.CompletionCode);

    return rc;
}
#pragma GCC diagnostic pop


/* :H1.nvram_write_data: Write data to NVRAM
 * ************************************************************************
 *
 *  Function Name:  nvram_write_data
 *
 *  Purpose:        Write data to NVRAM
 *
 *  Description:    This function check to be sure that the caller has
 *                  specified valid NVRAM offset and length and then
 *                  makes the necessary calls to the memory or I/O copy
 *                  routine to copy the data out of caller's buffer into
 *                  the NVRAM.
 *
 *  Input:          pr - Pointer to the request packet
 *
 *  Output:         0       - success
 *                  -EFAULT - error
 *
 *    On success, CompletionCode will contain one of the following:
 *
 *                  RPDONE
 *                  return code from INIT time
 *                  RPDONE | RPERR | RPDEV | INVALID_SLOT_NO
 *                  RPDONE | RPERR | RPDEV | UNKNOWN_ADAPTER
 *                  RPDONE | RPERR | RPDEV | BAD_PARAMETERS
 *                  RPDONE | RPERR | RPDEV | BAD_BUFFER
 *                  RPDONE | RPERR | RPDEV | OFFSET_OUT_OF_RANGE
 *                  RPDONE | RPERR | RPDEV | SIZE_OUT_OF_RANGE
 *
 * ************************************************************************
 */

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wframe-larger-than="
static int nvram_write_data(dcs_adapter *adapter, char *buffer)
{
    int rc = -EFAULT;
    NVRAM_WRITE_PARMS parms;

    if (copy_from_user(&parms, buffer, sizeof(NVRAM_WRITE_PARMS)) != 0) {
        goto out;
    }

    /* If we successfully setup the adapter, process this request. */
    if ((rc = nvram_check(adapter, parms.Slot)) != RPDONE) {
        /* just return the error code */
    } else if (parms.Offset > adapter->nvram_size) {
        rc = RPDONE | RPERR | RPDEV | OFFSET_OUT_OF_RANGE;
    } else if (parms.Length > sizeof(parms.Buffer)) {
        rc = RPDONE | RPERR | RPDEV | BAD_PARAMETERS;
    } else if ((parms.Offset + parms.Length) > adapter->nvram_size) {
        rc = RPDONE | RPERR | RPDEV | SIZE_OUT_OF_RANGE;
    } else {
        switch (adapter->nvram_map_type) {
        case NVRAM_MEMORY_MAP:
            aip_dbg("nvram_memory_map: offset=%d, length=%d\n",
                    parms.Offset, parms.Length);

            memcpy_toio(adapter->nvram + parms.Offset,
                        parms.Buffer,
                        (unsigned short) parms.Length);

            break;

        case NVRAM_IO_MAP:
            nvram_io(adapter->nvram_buffer_addr + parms.Offset,
                     parms.Buffer, parms.Length, NVWRITE);

            break;

        case NVRAM_PAGED:
            paged_io(adapter, parms.Offset + adapter->bottum_junk,
                     parms.Buffer, parms.Length, NVWRITE);

            break;

        case NVRAM_WCR_PAGED:
            wcr_paged_io(adapter, parms.Offset + adapter->bottum_junk,
                         parms.Buffer, parms.Length, NVWRITE);

            break;

        default:
            break;
        }
    }

    parms.CompletionCode = rc;
    rc = 0;
    if (copy_to_user(buffer, &parms, sizeof(parms)) != 0) {
        rc = -EFAULT;
    }

out:
    aip_dbg("returning rc=0x%x\n", parms.CompletionCode);

    return rc;
}
#pragma GCC diagnostic pop


/* disable_async_cd_comm: Request to disable notification of cash drawer interrupts
 * ************************************************************************
 *
 *  Function Name:  disable_async_cd_comm
 *
 *  Purpose:        Disable notification of cash drawer interrupts
 *
 *  Description:    This function disables asynchronous communication of
 *                  cash drawer interrupts to user mode by clearing out
 *                  the cash drawer process id and cash drawer async_comm
 *                  flag in the BOARDDATA structure.
 *
 *  Input:          buffer - pointer to argument structure
 *
 *  Output:         0       - success
 *                  -EFAULT - error
 *
 * ************************************************************************
 */

static int disable_async_cd_comm(dcs_adapter *adapter, char *buffer)
{
    int rc = 0;
    COMPLETION_CODE_PARMS parms;

    adapter->current_cd_pid = 0;

    parms.CompletionCode = RPDONE;

    if (copy_to_user(buffer, &parms, sizeof(parms))) {
        rc = -EFAULT;
    }

    aip_dbg("End rc=0x%x\n", parms.CompletionCode);

    return rc;
}


/* enable_async_cd_comm: Request to enable notification of cash drawer interrupts
 * ************************************************************************
 *
 *  Function Name:  enable_async_cd_comm
 *
 *  Purpose:        Enable notification of cash drawer interrupts
 *
 *  Description:    This function enables asynchronous communication of
 *                  cash drawer interrupts to user mode by setting
 *                  the cash drawer process id and cash drawer async_comm
 *                  flag in the BOARDDATA structure.
 *
 *  Input:          buffer - pointer to argument structure
 *
 *  Output:         0       - success
 *                  -EFAULT - error
 *
 * ************************************************************************
 */

static int enable_async_cd_comm(dcs_adapter *adapter, char *buffer)
{
    int rc = -EFAULT;
    ENABLE_ASYNC_COMM_PARMS parms;

    if (adapter->current_cd_pid != 0) {
        rc = -EBUSY;
    } else if (copy_from_user(&parms, buffer, sizeof(parms)) != 0) {
        rc = -EFAULT;
    } else {
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 27)
        adapter->current_cd_pid = (pid_t)parms.ProcessID;
#else
        rcu_read_lock();
        adapter->current_cd_pid = find_vpid((pid_t) parms.ProcessID);
        rcu_read_unlock();
#endif

        parms.CompletionCode = RPDONE;

        rc = 0;
        if (copy_to_user(buffer, &parms, sizeof(parms))) {
            rc = -EFAULT;
        }
    }

    aip_dbg("returning rc=0x%x\n", parms.CompletionCode);

    return rc;
}


/* get_cd_interrupt_slot: Request to return to caller number of slot that interrupted
 * ************************************************************************
 *
 *  Function Name:  get_cd_interrupt_slot
 *
 *  Purpose:        Return to the caller the number of the slot (adapter)
 *                  that caused the cash drawer interrupt.
 *
 *  Description:    This function passes back to the caller interrupt_cd_slot
 *                  from the BOARDDATA structure.  This byte will indicate
 *                  all slots that have experienced cash drawer interrupts
 *                  that have not yet been serviced (it is a bit mask).
 *
 *  Input:          buffer - pointer to argument structure
 *
 *  Output:         0       - success
 *                  -EFAULT - error
 *
 *  Note:  The call is unnecessary if there is no requirement to support
 *         multiple device channel adapters in the same machine.
 *
 * ************************************************************************
 */

static int get_cd_interrupt_slot(dcs_adapter *adapter, char *buffer)
{
    int rc = 0;
    GET_INTERRUPT_SLOT_PARMS parms;

    parms.Slot = adapter->interrupt_cd_slot;
    adapter->interrupt_cd_slot = 0;
    parms.CompletionCode = RPDONE;

    if (copy_to_user(buffer, &parms, sizeof(parms))) {
        rc = -EFAULT;
    }

    aip_verbose("returning rc=0x%x\n", parms.CompletionCode);

    return rc;
}


/* set_cash_drawer_interface: Request to set the cash drawer interface
 * ************************************************************************
 *
 *  Function Name:  set_cash_drawer_interface
 *
 *  Purpose:        Set the cash drawer interface to either legacy (4694)
 *                  or PCI mode.
 *
 *  Description:    This function sets the cash drawer interface based
 *                  on the values in the arguments passed to it. Both
 *                  the interface type (4694 or PCI) and the pulse width
 *                  (100 or 200ms) are set.
 *
 *  Input:          buffer - pointer to argument structure
 *
 *  Output:         0       - success
 *                  -EFAULT - error
 *
 *    On success, CompletionCode will contain one of the following:
 *
 *                  RPDONE
 *                  RPDONE | RPERR | RPDEV | UNKNOWN_ADAPTER
 *                  RPDONE | RPERR | RPDEV | INVALID_SLOT_NO
 *
 * ************************************************************************
 */

static int set_cash_drawer_interface(dcs_adapter *adapter, char *buffer)
{
    int rc = -EFAULT;
    SET_CD_INTERFACE_PARMS parms;

    if (copy_from_user(&parms, buffer, sizeof(parms)) != 0) {
        goto out;
    }
    rc = RPDONE;

    /* If the slot number is valid, process it. */
    if (parms.Slot != 1) {
        rc = RPDONE | RPERR | RPDEV | INVALID_SLOT_NO;
    }

    /* If we recognize the adapter as one of ours, continue. */
    else if (adapter->adapter_id != SIO_4800_ID) {
        rc = RPDONE | RPERR | RPDEV | UNKNOWN_ADAPTER;
    } else {
        /* Read the cash drawer config byte */
        uchar_t cd_config = inb(adapter->base_io_addr);

        aip_dbg("Cash Drawer Config=0x%x\n", cd_config);

        /* Clear out the setup bits first */
        cd_config &= 0xF0;

        /* Set interface type */
        if (adapter->sio_available == FALSE) {
            cd_config |= SP700_CD0_INTERRUPT_ENABLE;
        } else if (parms.CDInterface == 0) {
            cd_config |= SP700_CD0_ENABLE_8051_INTERFACE;
        } else if (parms.CDInterface == 1) {
            cd_config |= SP700_CD0_INTERRUPT_ENABLE;
        }

        /* Set pulse width if necessary */
        if (parms.PulseWidth == 1) {
            cd_config |= SP700_CD0_PULSE_WIDTH_200MS;
        }

        /* Always arm the drawers */
        cd_config |= SP700_CD0_DRAWER_ENABLE;

        outb(cd_config, adapter->base_io_addr);

        aip_dbg("Config=0x%x\n", inb(adapter->base_io_addr));
    }

    parms.CompletionCode = rc;
    rc = 0;
    if (copy_to_user(buffer, &parms, sizeof(parms))) {
        rc = -EFAULT;
    }

out:
    aip_dbg("returning rc=0x%x\n", parms.CompletionCode);

    return rc;
}


/* open_cash_drawer: Request to open a cash drawer (PCI interface only)
 * ************************************************************************
 *
 *  Function Name:  open_cash_drawer
 *
 *  Purpose:        Open the specified cash drawer
 *
 *  Description:    This function opens the cash drawer specified by the
 *                  arguments passed to it. This call has no effect when
 *                  the cash drawer interface type is legacy (4694).
 *
 *  Input:          buffer - pointer to argument structure
 *
 *  Output:         0       - success
 *                  -EFAULT - error
 *
 *    On success, CompletionCode will contain one of the following:
 *
 *                  RPDONE
 *                  RPDONE | RPERR | RPDEV | UNKNOWN_ADAPTER
 *                  RPDONE | RPERR | RPDEV | INVALID_SLOT_NO
 *
 * ************************************************************************
 */

static int open_cash_drawer(dcs_adapter *adapter, char *buffer)
{
    int rc = -EFAULT;
    OPEN_CD_PARMS parms;

    if (copy_from_user(&parms, buffer, sizeof(parms)) != 0) {
        goto out;
    }

    rc = RPDONE;

    /* If the slot number is valid, process it. */
    if (parms.Slot != 1) {
        rc = RPDONE | RPERR | RPDEV | INVALID_SLOT_NO;
    }
    /* If we recognize the adapter as one of ours, continue. */
    else if (adapter->adapter_id != SIO_4800_ID) {
        rc = RPDONE | RPERR | RPDEV | UNKNOWN_ADAPTER;
    } else {
        /* Check cash drawer config byte -- PCI CD enabled? */
        if (!(inb(adapter->base_io_addr) & SP700_CD0_ENABLE_8051_INTERFACE)) {
            /* Default to CD 1 */
            uchar_t open_cd_byte = SP700_CD1_OPEN_DRAWER_1;

            /* Cash drawer 2? */
            if (parms.WhichCD == 2) {
                open_cd_byte = SP700_CD1_OPEN_DRAWER_2;
            }

            /* Our cash drawer h/w generates an interrupt for every
             * state change and the state changes 2-3 times for an
             * open pulse. It is up to the caller to determine
             * which states to report to an application --
             * i.e. all interrupts/status changes will be reported
             * to the caller registered for cash drawer interrupts.
             */
            outb(open_cd_byte, (adapter->base_io_addr + SP700_ASIC_CD_PORT_1));

            aip_dbg("Open Cash Drawer %d\n", parms.WhichCD);
        } else {
            aip_dbg("Cash drawer 8051 interface enabled\n");
            rc = RPDONE | RPERR | RPDEV | BAD_PARAMETERS;
        }
    }

    parms.CompletionCode = rc;
    rc = 0;
    if (copy_to_user(buffer, &parms, sizeof(parms))) {
        rc = -EFAULT;
    }

out:
    aip_dbg("returning rc=0x%x\n", parms.CompletionCode);

    return rc;
}


/* get_cash_drawer_status: Request to get cash drawer status byte (PCI interface only)
 * ************************************************************************
 *
 *  Function Name:  get_cash_drawer_status
 *
 *  Purpose:        Get the cash drawer status byte
 *
 *  Description:    This function returns to the caller the cash drawer
 *                  status byte for the specified adapter.
 *
 *  Input:          buffer - pointer to argument structure
 *
 *  Output:         0       - success
 *                  -EFAULT - error
 *
 *    On success, CompletionCode will contain one of the following:
 *
 *                  RPDONE
 *                  RPDONE | RPERR | RPDEV | UNKNOWN_ADAPTER
 *                  RPDONE | RPERR | RPDEV | INVALID_SLOT_NO
 *
 * ************************************************************************
 */

static int get_cash_drawer_status(dcs_adapter *adapter, char *buffer)
{
    int rc = -EFAULT;
    GET_CD_STATUS_PARMS parms;

    if (copy_from_user(&parms, buffer, sizeof(parms)) != 0) {
        goto out;
    }

    rc = RPDONE;

    /* If the slot number is valid, process it. */
    if (parms.Slot != 1) {
        rc = RPDONE | RPERR | RPDEV | INVALID_SLOT_NO;
    }
    /* If we recognize the adapter as one of ours, continue. */
    else if (adapter->adapter_id != SIO_4800_ID) {
        rc = RPDONE | RPERR | RPDEV | UNKNOWN_ADAPTER;
    } else {
        parms.CDStatus = inb(adapter->base_io_addr);

        aip_verbose("Cash Drawer Status 0x%x\n", parms.CDStatus);
    }

    parms.CompletionCode = rc;
    rc = 0;
    if (copy_to_user(buffer, &parms, sizeof(parms))) {
        rc = -EFAULT;
    }

    aipdcs_interrupted = FALSE;

out:
    aip_verbose("returning rc=0x%x\n", parms.CompletionCode);

    return rc;
}


#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 18)

int aipdcs_device_create(unsigned int major_number, char *modname,
                         struct file_operations *fops)
{
    int err;

    /* Register as a device with kernel. */
    if ((err = register_chrdev(major_number, modname, fops))) {
        aip_error("Failure to load module. error %d\n", -err);
        return err;
    }

    return 0;
}


void aipdcs_device_destroy(unsigned int aipdcs_major, char *modname)
{
    if (unregister_chrdev(aipdcs_major, modname) != 0) {
        aip_error("unregister_chrdev failed\n");
    }

    return;
}

#else

int aipdcs_device_create(char *modname, char *devname[], int dev_count,
                         char *class_name, dcs_adapter *adapter,
                         struct file_operations *fops)
{
    int err = 0;
    int i = 0;
    int major = 0;
    struct device *dev;

    adapter->major = 0;

    /* Request dynamic allocation of a device major number */
    aip_dbg("Allocating major device with %d minors\n", dev_count);
    if ((err = alloc_chrdev_region(&adapter->dev_number, 0, dev_count,
                                   modname)) < 0) {
        aip_error("Cannot register device, error=%d\n", -err);
        return err;
    }

    aip_dbg("dev number is %x for '%s'\n", adapter->dev_number, modname);

    /* Populate sysfs entries */
    adapter->dev_class = class_create(THIS_MODULE, class_name);

    if (IS_ERR(adapter->dev_class)) {
        aip_error("Cannot create class '%s' error %ld\n", class_name,
                  PTR_ERR(adapter->dev_class));
        adapter->dev_class = NULL;
        return -EINVAL;
    }

    adapter->dev_count = dev_count;
    adapter->major = 0;

    major = MAJOR(adapter->dev_number);

    adapter->major = major;

    for (i = 0; i < dev_count && i < MAX_CDEVS; i++) {
        aip_dbg("Initialzing cdev for %d '%s'\n", i, devname[i]);

        /* Connect the file operations with the cdev */
        cdev_init(&adapter->cdev[i], fops);

        aip_dbg("Adding cdev for '%s' major=%d/minor=%d\n", devname[i],
                major, i);

        /* Connect the major/minor number to the cdev */
        err = cdev_add(&adapter->cdev[i], MKDEV(major, i), 1);
        adapter->cdev[i].owner = THIS_MODULE;

        if (err) {
            aip_error("Bad cdev add, error %d\n", -err);

            /* Destroy dev_class */
            class_destroy(adapter->dev_class);
            adapter->dev_class = NULL;

            return err;
        }

        aip_dbg("Adding device for '%s' major=%d/minor=%d\n",
                devname[i], major, i);

        /* Send uevents to udev, so it'll create /dev node */
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 26)
        dev = device_create(adapter->dev_class, NULL, MKDEV(major, i),
                            devname[i]);
#elif LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 28)
        dev = device_create_drvdata(adapter->dev_class, NULL, MKDEV(major, i),
                                    NULL, devname[i]);
#else
        dev = device_create(adapter->dev_class, NULL, MKDEV(major, i), NULL,
                            devname[i]);
#endif
        if (!IS_ERR(dev)) {
            /* save sysfs dev pointer for creating additional attributes */
            adapter->dev = dev;
        }

        aip_dbg("Adding sysfs for '%s' major=%d/minor=%d returned err %ld\n",
                devname[i], major, i, (long)IS_ERR(dev));
    }

    return 0;
}


void aipdcs_device_destroy(dcs_adapter *adapter)
{
    int i = 0;

    aip_dbg("entered major=%d, count=%d\n",
            adapter->major, adapter->dev_count);

    /* Release the major number */
    if (adapter != NULL && adapter->major > 0) {
        if (adapter->dev_class != NULL) {
            for (i = 0; i < adapter->dev_count && i < MAX_CDEVS; i++) {
                aip_dbg("Removing device major=%d/minor=%d returned\n",
                        adapter->major, i);

                /* Destroy device */
                device_destroy(adapter->dev_class, MKDEV(adapter->major, i));

                /* Remove the cdev */
                cdev_del(&adapter->cdev[i]);
            }

            aip_dbg("Unregistering chrdev major=%d, count=%d\n",
                    adapter->major, adapter->dev_count);

            unregister_chrdev_region(adapter->major, adapter->dev_count);

            adapter->dev_count = 0;

            /* Destroy dev_class */
            class_destroy(adapter->dev_class);
            adapter->dev_class = NULL;
        }
        adapter->major = 0;
    }

    aip_dbg("returning\n");

    return;
}

#endif


/* dcs_init: Init device driver
 * ************************************************************************
 *
 *  Function Name:  dcs_init
 *
 *  Purpose:        Initialize this device driver (called at insmod/modprobe
 *                  time)
 *
 *  Description:    Find PCI (4800 and beyond) and/or ISA (4694) adapters
 *                  and get configuration information (2K buffer address,
 *                  NVRAM address, IRQ). Register interrupt handler and
 *                  send initial POR.
 *
 *  Input:          none
 *
 *  Output:         0  -- success
 *                  -1 -- error
 *
 * ************************************************************************
 */

static int __init dcs_init(void)
{
    int addr = 0;
    int err = 0;
    int rc = -1;
    struct pci_dev *pcidcs = NULL;
    uchar_t *pmem = NULL;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 18)
    char *dev_names[20] = { "aipdcs"};
    int  dev_count = 1;
#endif

    /* Initialize our data structure */
    memset(&Adapter, 0, sizeof(dcs_adapter));
    Adapter.known_adapter = FALSE;
    Adapter.sio_available = TRUE;
    Adapter.nvram_available = TRUE;

    /* Initialize buffer access identification */
    Adapter.buffer_read = FALSE;

    /* read two bytes for model/submodel from BIOS */
    pmem = (uchar_t *)ioremap(0xFFFFE, 2);
    if (pmem != NULL) {
        Adapter.id_model    = readb(pmem);
        Adapter.id_submodel = readb(pmem + 1);
        iounmap(pmem);

        aip_info("Model=%#x, Submodel=%#x\n", Adapter.id_model,
                 Adapter.id_submodel);
    }

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 18)
    /* Register as a device with kernel. */
    err = aipdcs_device_create(aipdcs_major, DEVDRVR_ID, &dcs_fops);
#else
    /* Request dynamic allocation of a device major number */
    err = aipdcs_device_create((char *) DEVDRVR_ID, dev_names, dev_count,
                               "aipdcs", &Adapter, &dcs_fops);
#endif

    if (err != 0)
        return err;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 14, 0)
    timer_setup(&dcs_timer, dcs_timer_handler, 0);
#else
    init_timer(&dcs_timer);
    dcs_timer.data     = 0;
    dcs_timer.function = dcs_timer_handler;
#endif

    aip_dbg("Device registered with kernel\n");

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 9)
    pcidcs = pci_find_device(IBM_VENDOR_ID, SIO_4800_ID, pcidcs);
#else
    pcidcs = pci_get_device(IBM_VENDOR_ID, SIO_4800_ID, pcidcs);
#endif
    if (pcidcs != 0) {
        aip_dbg("4800 adapter found...\n");

        if ((err = pci_enable_device(pcidcs)) == 0) {
            Adapter.pcidcs = pcidcs;

            /* Try to claim our I/O space */
            if (get_4800_configuration(&Adapter) == 0) {
                /* Read the cash drawer config byte */
                set_4800_cd_defaults(&Adapter);
                rc = 0;
            }
        } else {
            /* PCI but cannot enable */
            aip_error("Failure to enable PCI device, error=%d\n",
                      -err);
        }
    }

    /* Currently, there is no way to have a PCI channel adapter and an ISA
     * channel adapter in the same IBM machine. Look for an ISA adapter
     * only if we did not find a PCI adapter.
     */
    if (Adapter.known_adapter == FALSE) {
        aip_dbg("Looking for ISA SIO channel adapter\n");

        rc = find_4694(&Adapter);
    }

    if (Adapter.known_adapter == FALSE) {
        /* Look for 4674 adapter */
        for (addr = 0x600; addr < 0x700; addr += 0x40) {
            if ((rc = find_4674(&Adapter, addr)) == 0) {
                break;
            }
        }
    }

    /* Only call ioremap() if buffer is not zero */
    if (Adapter.buffer_addr != 0) {
        /* Map the physical addresses for 2K buffer, SSB, and NVRAM */
        Adapter.p2k_buffer = (uchar_t *)ioremap(Adapter.buffer_addr,
                                                BUFF_LEN);
        Adapter.ssb = (uchar_t *)ioremap((Adapter.buffer_addr +
                                          Adapter.offset_ssb), 1);
        aip_dbg("p2k_buffer=%p ssb=%p (%02x)\n",
                Adapter.p2k_buffer, Adapter.ssb, readb(Adapter.ssb));
    }

    /* Only call ioremap() if nvram_buffer_addr is not zero */
    if (Adapter.nvram_buffer_addr != 0) {
        Adapter.nvram = ioremap(Adapter.nvram_buffer_addr,
                                (Adapter.nvram_page_size *
                                 Adapter.nvram_pages));

        Adapter.nvram_rc = RPDONE;

        /*
         * Turn the Ok message printing off.
         * --> Only if the NVRAM is enabled and it's 4694
         */
        turn_off_ok_message(&Adapter);
    }

    /* A device channel adapter was found above */
    if (Adapter.adapter_id == NVRAMT_SUB_ID) {
        /* skip additional setup */
        Adapter.sio_available = FALSE;
    } else if (Adapter.known_adapter == TRUE) {
        Adapter.rc = RPDONE;
        if (Adapter.buffer_addr != 0) {
            if (set_interrupt_handler(&Adapter) == 0) {
                reset_adapter(&Adapter);

                if (Adapter.adapter_id == SIO_4800_ID &&
                    Adapter.sio_available == FALSE) {
                    set_4800_cd_defaults(&Adapter);
                }
            }
        } else if (Adapter.adapter_id == SIO_4800_ID) {
            if (set_interrupt_handler(&Adapter) == 0) {
                Adapter.sio_available = FALSE;
                set_4800_cd_defaults(&Adapter);
            }
        }
    }

    aip_dbg("irq_level=0x%x\n", Adapter.irq_level);
    aip_dbg("base_io_addr=0x%lx\n", Adapter.base_io_addr);
    aip_dbg("nvram_buffer_addr=0x%lx\n", Adapter.nvram_buffer_addr);
    aip_dbg("buffer_addr=0x%lu, p2KBuffer=0x%p\n",
            Adapter.buffer_addr, Adapter.p2k_buffer);
    aip_dbg("nvram=0x%p\n", Adapter.nvram);
    aip_dbg("nvram_size=0x%lx\n", Adapter.nvram_size);
    aip_dbg("nvram_map_type=0x%u\n", Adapter.nvram_map_type);
    aip_dbg("nvram_page_size=0x%lx\n", Adapter.nvram_page_size);
    aip_dbg("nvram_pages=0x%lx\n", Adapter.nvram_pages);
    aip_dbg("nvram_area[DEVICE_DRVRS].Offset=0x%x\n",
            Adapter.nvram_area[DEVICE_DRVRS].Offset);
    aip_dbg("nvram_area[DEVICE_DRVRS].Size=0x%x\n",
            Adapter.nvram_area[DEVICE_DRVRS].Size);
    aip_dbg("nvram_area[APPLICATION].Offset=0x%x\n",
            Adapter.nvram_area[APPLICATION].Offset);
    aip_dbg("nvram_area[APPLICATION].Size=0x%x\n",
            Adapter.nvram_area[APPLICATION].Size);

    aip_info("ID=0x%x, IRQ=%u, SRAM=0x%lx NVRAM=0x%lx\n",
             (unsigned)Adapter.adapter_id,
             (unsigned)Adapter.irq_level, Adapter.buffer_addr,
             Adapter.nvram_buffer_addr);

    return 0;
}


/* dcs_exit: Exit (unload) device driver
 * ************************************************************************
 *
 *  Function Name:  dcs_exit
 *
 *  Purpose:        Unload this device driver (called at rmmod time)
 *
 *  Description:    Release (unmap) memory, I/O space, and IRQ.
 *
 *  Input:          none
 *
 *  Output:         none
 *
 * ************************************************************************
 */

static void __exit dcs_exit(void)
{
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 5, 0)
    if (MOD_IN_USE) {
        aip_dbg("device busy, remove delayed\n");
        return;
    }
#endif

    if (Adapter.known_adapter == TRUE) {
        if (Adapter.rc == RPDONE) {
            aip_dbg("Unmap buffer/ssb, IRQ=%d\n",
                    Adapter.irq_level);

            iounmap((void *) Adapter.p2k_buffer);
            iounmap((void *) Adapter.ssb);

            free_irq(Adapter.irq_level, (void *)&Adapter);
        }

        aip_dbg("Unmap nvram\n");

        iounmap((void *)Adapter.nvram);

        aip_dbg("Release port (0x%lx) regions\n", Adapter.base_io_addr);

        release_region(Adapter.base_io_addr, Adapter.board_size);
    }

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 18)
    aipdcs_device_destroy(aipdcs_major, DEVDRVR_ID);
#else
    aipdcs_device_destroy(&Adapter);
#endif

    aip_dbg("Module unloaded\n");

    return;
}


module_init(dcs_init);
module_exit(dcs_exit);

MODULE_AUTHOR("Toshiba Global Commerce Solutions, Inc.");
MODULE_DESCRIPTION("Toshiba RS-485 Device Channel Server");
MODULE_LICENSE("GPL");
