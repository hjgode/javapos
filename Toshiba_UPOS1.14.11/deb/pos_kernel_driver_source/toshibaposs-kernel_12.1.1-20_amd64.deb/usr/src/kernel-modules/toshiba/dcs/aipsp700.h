/*
 *  Module Name:     aipsp700.h
 *
 *  Description:     kernel driver include
 *
 *  Copyright (C) 2004-2015 Toshiba Global Commerce Solutions, Inc.
 *  All right reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA; Otherwise,
 *  see <http://www.gnu.org/licenses/>.
 *
 *
 * Should you need to contact me, the author, you can do so either by
 * e-mail - mail your message to <gha@toshibagcs.com>.
 */


#ifndef _H_AIPSP700
#define _H_AIPSP700

/* ************************************************************************
 * A2 BARs
 * ************************************************************************
 */
#define SP700_CONFIG_BAR                     0
#define SP700_EEPROM_BAR                     1
#define SP700_NVRAM_BAR                      3
#define SP700_SIO_BAR                        4


/* ************************************************************************
 * A2 I/O Registers mapped into PCI BAR 0
 * ************************************************************************
 */
#define SP700_ASIC_CD_PORT_0                 0x00
#define SP700_ASIC_CD_PORT_1                 0x01
#define SP700_ASIC_CD_PORT_2                 0x02
#define SP700_ASIC_DUMP_SWITCH               0x03
#define SP700_ASIC_EEPROM_CONTROL            0x04
#define SP700_ASIC_CD_CONTROL                0x05
#define SP700_ASIC_NVRAM_PAGE                0x08
#define SP700_ASIC_GPIO_PORT_0               0x09
#define SP700_ASIC_GPIO_PORT_1               0x0A
#define SP700_ASIC_INTERRUPT_STATUS_REGISTER 0x0B


/* ************************************************************************
 * Cash Drawer Control Port 0 (setup/configuration/status)
 * ************************************************************************
 */
#define SP700_CD0_DRAWER_ENABLE              0x01
#define SP700_CD0_PULSE_WIDTH_200MS          0x02
#define SP700_CD0_ENABLE_8051_INTERFACE      0x04
#define SP700_CD0_INTERRUPT_ENABLE           0x08
#define SP700_CD0_DRAWER_2_CONNECTED         0x10
#define SP700_CD0_DRAWER_2_CLOSED            0x20
#define SP700_CD0_DRAWER_1_CONNECTED         0x40
#define SP700_CD0_DRAWER_1_CLOSED            0x80

#define SP700_D0_DRAWER_INTERRUPTS_ENABLED_MASK (SP700_CD0_DRAWER_ENABLE| \
                                                 SP700_CD0_INTERRUPT_ENABLE)

#define SP700_CD0_DRAWER_STATUS_MASK (SP700_CD0_DRAWER_2_CONNECTED| \
                                      SP700_CD0_DRAWER_2_CLOSED| \
                                      SP700_CD0_DRAWER_1_CONNECTED| \
                                      SP700_CD0_DRAWER_1_CLOSED)


/* ************************************************************************
 * Cash Drawer Control Port 1 (Cash Drawer Open)
 * ************************************************************************
 */
#define SP700_CD1_OPEN_DRAWER_1              0x6D
#define SP700_CD1_OPEN_DRAWER_2              0xEA


/* ************************************************************************
 * Cash Drawer Control Port 2 (Cash Drawer Interrupt Control)
 * ************************************************************************
 */
#define SP700_CD2_DRAWER_1_INTERRUPTED       0x01
#define SP700_CD2_DRAWER_2_INTERRUPTED       0x02
#define SP700_INTERRUPT_MASK                 0x03

/* ************************************************************************
 * Cash Drawer Control Register
 * ************************************************************************
 */
#define SP700_CD3_38_VOLTS_SETTING           0x10  /* 0:24V, 1:38V */
#define SP700_CD3_38_VOLTS_STATUS            0x20  /* 0:24V, 1:38V */
#define SP700_CD3_HW_VOLTAGE_SETTING         0x40  /* 0:ASIC, 1:HW */
#define SP700_CD3_JUMPER_OVERRIDE            0x80  /* 0:No, 1:Yes  */


/* ************************************************************************
 * Dump Switch Interface
 * ************************************************************************
 */
#define SP700_DUMP_SWITCH_SET                0x01
#define SP700_DUMP_SWITCH_CLEAR_MASK         ~SP700_DUMP_SWITCH_SET


/* ************************************************************************
 * NVRAM Page Register
 * ************************************************************************
 */
#define SP700_NVRAM_PAGE_0                   0x00  /* Page 0   */
#define SP700_NVRAM_MAX_PAGE                 0xFF  /* Page 256 */


/* ************************************************************************
 * EEPROMT/FLASH ROM Control Port
 * ************************************************************************
 */
#define SP700_EEPROM_0_READ                  0x01
#define SP700_EEPROM_0_WRITE                 0x02
#define SP700_EEPROM_1_AND_2_READ            0x04
#define SP700_EEPROM_1_AND_2_WRITE           0x08
#define SP700_EEPROM_FLASH_WRITE_ARMED       0xA0
#define SP700_EEPROM_WRITE_MASK              0xEF


/* ************************************************************************
 * Interrupt Status Register
 * ************************************************************************
 */
#define SP700_SIO_INTERRUPT                  0x01
#define SP700_CD_INTERRUPT                   0x02


/* ************************************************************************
 * EEPROM Config Mapping
 * ************************************************************************
 */
#define SP700_EEPPROM_FUNC0_VENDOR_ID        0x00   /* two bytes */
#define SP700_EEPPROM_FUNC0_SUBSYSTEM_ID     0x02   /* two bytes */
#define SP700_EEPPROM_FUNC1_VENDOR_ID        0x04   /* two bytes */
#define SP700_EEPPROM_FUNC1_SUBSYSTEM_ID     0x06   /* two bytes */
#define SP700_EEPPROM_A2_CONFIG_REG_0        0x08   /* NVRAM & SIO RAM */
#define SP700_EEPPROM_A2_CONFIG_REG_1        0x09   /* Exp ROM & CD auto */
#define SP700_EEPPROM_A2_CONFIG_REG_2        0x0A   /* UART Enable/Disable */
#define SP700_EEPPROM_A2_CHECKSUM            0xff   /* 2's complement */


/* ************************************************************************
 * ASIC Configuration Register 0 (NVRAM/SIO Control)
 * ************************************************************************
 */
#define SP700_CONFIG0_SIO_ENABLED            0x02   /* 1:Enable, 0:Disable */
#define SP700_CONFIG0_SIO_BELOW_1MB          0x04
#define SP700_CONFIG0_NVRAM_SIZE_BIT_0       0x08
#define SP700_CONFIG0_NVRAM_SIZE_BIT_1       0x10
#define SP700_CONFIG0_NVRAM_SIZE_BIT_2       0x20
#define SP700_CONFIG0_NVRAM_SIZE_MASK        0x38
#define SP700_CONFIG0_NVRAM_BELOW_1MB        0x40
#define SP700_CONFIG0_NVRAM_ENABLED          0x80

#define SP700_NVRAM_SIZE_32KB                0x00
#define SP700_NVRAM_SIZE_128KB               0x01
#define SP700_NVRAM_SIZE_256K                0x02
#define SP700_NVRAM_SIZE_512K                0x03
#define SP700_NVRAM_SIZE_1MB                 0x04
#define SP700_NVRAM_SIZE_RESERVED_0          0x05
#define SP700_NVRAM_SIZE_RESERVED_1          0x06
#define SP700_NVRAM_SIZE_0KB                 0x07

/* ************************************************************************
 * Cash Drawer timer interval after S3 resume (milliseconds)
 * ************************************************************************
 */
#define SP700_CD_TIMER                       5

#endif
