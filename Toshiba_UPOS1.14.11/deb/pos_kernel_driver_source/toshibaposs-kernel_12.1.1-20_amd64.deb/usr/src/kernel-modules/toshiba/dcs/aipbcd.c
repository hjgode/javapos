/*
 * Module Name:     aipbcd.c
 *
 * Description:     Cash Drawer Driver for Linux
 *
 *  Copyright (C) 2004-2019 Toshiba Global Commerce Solutions, Inc.
 *  All right reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA; Otherwise,
 *  see <http://www.gnu.org/licenses/>.
 *
 *
 * Should you need to contact me, the author, you can do so either by
 * e-mail - mail your message to <gha@toshibagcs.com>.
 */

/* System Headers */
#include <linux/version.h>
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 19)
#include <linux/config.h>
#else
#include <linux/fs.h>
#endif
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/compiler.h>
#include <linux/pci.h>
#include <linux/init.h>
#include <linux/ioport.h>
#include <linux/delay.h>
#if LINUX_VERSION_CODE > KERNEL_VERSION(2, 5, 0)
#include <linux/cdev.h>
#include <linux/moduleparam.h>
#endif
#include <linux/timer.h>
#include <linux/interrupt.h>
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 11, 0)
#include <linux/uaccess.h>
#else
#include <asm/uaccess.h>
#endif


/* Local Headers */
#include "aipkernel.h"
#include "aipdebug.h"

#define MAX_CDEVS 5
typedef struct {
    uint32_t      SlotDrawers;
    uint32_t      CDRegAddr;
    int boardSize;          /* I/O space length  */
    pid_t cd_pid;
    struct pci_dev *pcidev;
    unsigned short OpenCount;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 18)
    struct class  *dev_class;
    struct cdev    cdev[MAX_CDEVS];
    struct device *dev;
    int            dev_count;
    int            major;
    dev_t          dev_number;
#endif
} BOARDDATA;



/* Local Constants */
#define DEVDRVR_ID "aipbcd"

#define DEFAULT_MAJOR_DEV 247


#define IBM_VENDOR_ID       0x1014
#define NM_VENDOR_ID        0x9710
#define NM_DEVICE_ID        0x9835
#define SP500_DEVICE_ID     0x299
#define SP500_MODELID_1     0x34
#define SP500_MODELID_2     0x42
#define SP500_31X_MODELID_3 0x59
#define SP500_32X_MODELID_3 0x57

#define CD2_CONNECTED       0x10
#define CD2_OPEN        0x20
#define CD1_CONNECTED       0x40
#define CD1_OPEN        0x80

#define OPEN_CMD_SIZE 10
unsigned char OpenCDCmd[OPEN_CMD_SIZE] =
{ 0xFF, 0x7F, 0xD5, 0x55, 0xAA, 0x2A, 0xFE, 0x7E, 0xFF, 0x7F};

/* Function Prototypes */
static int __init aipbcd_init(void);
static void __exit aipbcd_exit (void);

static int aipbcd_open(struct inode *inode, struct file *file);
static ssize_t aipbcd_read(struct file *file, char *buf, size_t count,
                           loff_t *ppos);
static ssize_t aipbcd_write(struct file *file, const char *buf, size_t count,
                            loff_t *ppos);
static int aipbcd_release(struct inode *inode, struct file *file);
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 36)
static int aipbcd_ioctl(struct inode *inode, struct file *file,
                        unsigned int cmd, unsigned long arg);
#else
static long aipbcd_ioctl(struct file *file, unsigned int cmd, unsigned long arg);
#endif


/* PCI Cash Drawer-specific functions */
static int disable_async_comm(char *pBuffer);
static int enable_async_comm(char *pBuffer);
static int get_slot_info(char *pBuffer);
static int get_cd_status(char *pBuffer);
static int open_cd_drawer(char *pBuffer);
static int set_cd_interface(char *pBuffer);



/* static global variables */
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 18)
static int aipbcd_major = DEFAULT_MAJOR_DEV;
#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 0)
MODULE_PARM(aipbcd_major, "i");
#elif LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 18)
module_param_named(major, aipbcd_major, int, S_IRUGO | S_IWUSR);
MODULE_PARM_DESC(major, "aipbcd major device number");
#endif


static BOARDDATA BoardData;



/* The various file operations we support. */
struct file_operations aipbcd_fops = {
    .owner          = THIS_MODULE,
    .read           = aipbcd_read,
    .write          = aipbcd_write,
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 36)
    .ioctl          = aipbcd_ioctl,
#else
    .unlocked_ioctl = aipbcd_ioctl,
#endif
#if LINUX_VERSION_CODE > KERNEL_VERSION(3, 11, 0)
    .compat_ioctl   = aipbcd_ioctl,
#endif
    .open           = aipbcd_open,
    .release        = aipbcd_release,
};




/* aipbcd_open: Open device driver
 * ************************************************************************
 *
 *  Function Name:  aipbcd_open
 *
 *  Purpose:        Open this device driver
 *
 *  Description:    Setup NVRAM and enable PC interrupts (device channel).
 *
 *  Input:          inode  -
 *                  file   -
 *
 *  Output:         0  -- success
 *                  -1 -- error
 *
 * ************************************************************************
 */

static int aipbcd_open(struct inode *iNode, struct file *file)
{
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 5, 0)
    MOD_INC_USE_COUNT;
#endif

    ++BoardData.OpenCount;

    aip_dbg("END OpenCount=%d\n", BoardData.OpenCount);

    return 0;
}


/* aipbcd_release: Close device driver
 * ************************************************************************
 *
 *  Function Name:  aipbcd_release
 *
 *  Purpose:        Close this device driver
 *
 *  Description:    Disable PC interrupts (device channel).
 *
 *  Input:          inode  -
 *                  file   -
 *
 *  Output:         0  -- success
 *                  -1 -- error
 *
 * ************************************************************************
 */

static int aipbcd_release(struct inode *iNode, struct file *file)
{
    if (--BoardData.OpenCount == 0) {
        BoardData.cd_pid = 0;
    }

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 5, 0)
    MOD_DEC_USE_COUNT;
#endif

    aip_dbg("END OpenCount=%d\n", BoardData.OpenCount);

    return 0;
}


/* aipbcd_read: Read from device
 * ************************************************************************
 *
 *  Function Name:  aipbcd_read
 *
 *  Purpose:        Read from this device
 *
 *  Description:    Not supported by this device.
 *
 *  Input:          file  -
 *                  buf   -
 *                  count -
 *                  ppos  -
 *
 *  Output:         -EINVAL -- invalid
 *
 * ************************************************************************
 */

static ssize_t aipbcd_read(struct file *file, char *buf, size_t count,
                           loff_t *ppos)
{
    aip_dbg("Error: read unsupported\n");

    return -EINVAL;
}


/* aipbcd_write: Write to device
 * ************************************************************************
 *
 *  Function Name:  aipbcd_write
 *
 *  Purpose:        Write to this device
 *
 *  Description:    Not supported by this device.
 *
 *  Input:          file  -
 *                  buf   -
 *                  count -
 *                  ppos  -
 *
 *  Output:         -EINVAL -- invalid
 *
 * ************************************************************************
 */

static ssize_t aipbcd_write(struct file *file, const char *buf, size_t count,
                            loff_t *ppos)
{
    aip_dbg("Error: write unsupported\n");

    return -EINVAL;
}


/* aipbcd_ioctl: I/O Control for this device driver
 * ************************************************************************
 *
 *  Function Name:  aipbcd_ioctl
 *
 *  Purpose:        Handle ioctl calls to this device driver
 *
 *  Description:    Call correct function based on ioctl request.
 *
 *  Input:          inode  -
 *                  file   -
 *                  cmd    - ioctl request
 *                  arg    - pointer to argument structure
 *
 *  Output:         0  -- success
 *                  -1 -- error
 *
 *  Note:           Remember that FIOCLEX, FIONCLEX, FIONBIO, and FIOASYN
 *                  are reserved ioctl cmd numbers
 *
 * ************************************************************************
 */

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 36)
static int aipbcd_ioctl(struct inode *inode, struct file *file,
                        unsigned int cmd, unsigned long arg)
#else
static long aipbcd_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
#endif
{
    int rc = 0;
    int size = _IOC_SIZE(cmd);   /* the size bitfield in cmd */
    char *buffer = (char *) arg;

    /* Extract the type and number bitfields, and don't decode
     * wrong cmds;  return EINVAL before access_ok()
     */
    if (_IOC_TYPE(cmd) != IOCTL_MAGIC) {
        aip_dbg("INCORRECT IOC_TYPE\n");
        rc = -EINVAL;
        goto out;
    }

    if ((_IOC_NR(cmd) < IOCTL_CD_MINNR) || (_IOC_NR(cmd) > IOCTL_CD_MAXNR)) {
        aip_dbg("INVALID IOC_NR\n");
        rc = -EINVAL;
        goto out;
    }

    if (_IOC_DIR(cmd) & _IOC_READ) {
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 14)
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 0, 0)
        rc = access_ok((void *) buffer, size);
#else
        rc = access_ok(VERIFY_WRITE, (void *) buffer, size);
#endif
        if (rc == 0) {
            aip_dbg("VERIFY_WRITE failed, nr=%d, cmd=0x%x\n",
                    _IOC_NR(cmd), cmd);
            rc = -EFAULT;
        } else {
            rc = 0;
        }
#else
        rc = verify_area(VERIFY_WRITE, (void *) buffer, size);
        if (rc != 0) {
            aip_dbg("VERIFY_WRITE failed, rc=%d\n", rc);
        }
#endif
    } else if (_IOC_DIR(cmd) & _IOC_WRITE) {
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 14)
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 0, 0)
        rc = access_ok((void *) buffer, size);
#else
        rc = access_ok(VERIFY_READ, (void *) buffer, size);
#endif
        if (rc == 0) {
            aip_dbg("VERIFY_READ failed, nr=%d, cmd=0x%x\n",
                    _IOC_NR(cmd), cmd);
            rc = -EFAULT;
        } else {
            rc = 0;
        }
#else
        rc = verify_area(VERIFY_READ, (void *) buffer, size);
        if (rc != 0) {
            aip_dbg("VERIFY_READ failed, rc=%d\n", rc);
        }
#endif
    }

    if (rc != 0) {
        goto out;
    }

    switch (_IOC_NR(cmd)) {
    case _IOC_NR(GET_SLOT_INFO):
        rc = get_slot_info((char *) arg);
        break;
    case _IOC_NR(OPEN_CD):
        rc = open_cd_drawer((char *) arg);
        break;
    case _IOC_NR(GET_CD_STATUS):
        rc = get_cd_status((char *) arg);
        break;
    case _IOC_NR(DISABLE_ASYNC_CD_COMM):
        rc = disable_async_comm((char *) arg);
        break;
    case _IOC_NR(ENABLE_ASYNC_CD_COMM):
        rc = enable_async_comm((char *) arg);
        break;
    case _IOC_NR(SET_CD_INTERFACE):
        rc = set_cd_interface((char *) arg);
        break;
    default:
        rc = -EINVAL;
        break;
    }

out:

    return rc;
}


/* disable_async_comm: Request to disable notification of cash drawer interrupts
 * ************************************************************************
 *
 *  Function Name:  disable_async_comm
 *
 *  Purpose:        Disable notification of cash drawer interrupts
 *
 *  Description:    This function disables asynchronous communication of
 *                  cash drawer interrupts to user mode by clearing out
 *                  the cash drawer process id and cash drawer async_comm
 *                  flag in the BOARDDATA structure.
 *
 *  Input:          pBuffer - pointer to argument structure
 *
 *  Output:         0       - success
 *                  -EFAULT - error
 *
 *    On success, CompletionCode will be RPDONE
 *
 * ************************************************************************
 */

static int disable_async_comm(char *buffer)
{
    COMPLETION_CODE_PARMS parms = {0};
    int rc = 0;

    aip_dbg("cd_pid=0x%x\n", BoardData.cd_pid);

    BoardData.cd_pid = 0;

    parms.CompletionCode = RPDONE;

    if (copy_to_user(buffer, &parms, sizeof(parms)) != 0) {
        rc = -EFAULT;
    }

    return rc;
}


/* enable_async_comm: Request to enable notification of cash drawer interrupts
 * ************************************************************************
 *
 *  Function Name:  enable_async_comm
 *
 *  Purpose:        Enable notification of cash drawer interrupts
 *
 *  Description:    This function enables asynchronous communication of
 *                  cash drawer interrupts to user mode by setting
 *                  the cash drawer process id and cash drawer async_comm
 *                  flag in the BOARDDATA structure.
 *
 *  Input:          pBuffer - pointer to argument structure
 *
 *  Output:         0       - success
 *                  -EFAULT - error
 *
 *    On success, CompletionCode will be RPDONE
 *
 * ************************************************************************
 */

static int enable_async_comm(char *buffer)
{
    ENABLE_ASYNC_COMM_PARMS parms = {0};
    int rc = 0;

    aip_dbg("cd_pid=0x%x\n", BoardData.cd_pid);

    if (BoardData.cd_pid != 0) {
        rc = -EBUSY;
        goto out;
    }

    if (copy_from_user(&parms, buffer, sizeof(parms)) != 0) {
        rc = -EFAULT;
        goto out;
    }

    BoardData.cd_pid = (pid_t) parms.ProcessID;

    parms.CompletionCode = RPDONE;

    aip_dbg("cd_pid=0x%x\n", BoardData.cd_pid);

    if (copy_to_user(buffer, &parms, sizeof(parms))) {
        rc = -EFAULT;
    }
out:

    return rc;
}


/* get_slot_info: Get adapter id and number of cash drawers
 * ************************************************************************
 *
 *  Function Name:  get_slot_info
 *
 *  Purpose:        Get adapter id and number of ports
 *
 *  Description:    This function gets the adapter id and number of ports
 *                  for the adapter in this given slot and returns it to
 *                  the caller in the IOCTL parameter block.
 *
 *  Input:          pBuffer - pointer to argument structure
 *
 *  Output:         0       - success
 *                  -EFAULT - error
 *
 *    On success, CompletionCode will be RPDONE
 *
 * ************************************************************************
 */

static int get_slot_info(char *buffer)
{
    GET_SLOT_INFO_PARMS parms = {0};
    unsigned char cdConfig = 0x00;
    int rc = 0;

    /* Reset SlotDrawers */
    BoardData.SlotDrawers = 0;

    /* Read the cash drawer config byte again since someone could have
     * attached a cash drawer since load time
     */
    cdConfig = inb(BoardData.CDRegAddr + 1);

    aip_dbg("Cash Drawer Config=0x%x\n", cdConfig);

    /* Cash Drawer 1 Attached (0 = attached, 1 = not) */
    if (!(cdConfig & 0x20)) {
        BoardData.SlotDrawers += 1;
        aip_dbg("Cash Drawer 1 Attached\n");
    }

    /* Cash Drawer 2 Attached (0 = attached, 1 = not) */
    if (!(cdConfig & 0x80)) {
        BoardData.SlotDrawers += 1;
        aip_dbg("Cash Drawer 2 Attached\n");
    }

    parms.AdapterID[1]   = SP500_DEVICE_ID;
    parms.SlotDrawers[1] = BoardData.SlotDrawers;

    aip_dbg("AdapterID=%#x DrawerCount=%d\n", parms.AdapterID[1],
            parms.SlotDrawers[1]);

    parms.CompletionCode = RPDONE;
    if (copy_to_user(buffer, &parms, sizeof(parms))) {
        rc = -EFAULT;
    }

    aip_dbg("End rc=%d\n", rc);

    return rc;
}

/* get_cd_status: Request to get cash drawer status byte
 * ************************************************************************
 *
 *  Function Name:  get_cd_status
 *
 *  Purpose:        Get the cash drawer status byte
 *
 *  Description:    This function returns to the caller the cash drawer
 *                  status byte for the specified adapter.
 *
 *  Input:          buffer - pointer to argument structure
 *
 *  Output:         0       - success
 *                  -EFAULT - error
 *
 *    On success, CompletionCode will be RPDONE
 *
 * ************************************************************************
 */

static int get_cd_status(char *buffer)
{
    GET_CD_STATUS_PARMS parms = {0};
    unsigned char cd_status;
    unsigned char translated_status;
    int rc = 0;

    if (copy_from_user(&parms, buffer, sizeof(parms)) != 0) {
        rc = -EFAULT;
        goto out;
    }

    cd_status = inb(BoardData.CDRegAddr + 1);

    aip_dbg("Raw Cash Drawer Status 0x%x\n", cd_status);

    translated_status = cd_status & 0x0F;
    if (cd_status & 0x80)
        translated_status |= CD2_CONNECTED;
    if (cd_status & 0x40)
        translated_status |= CD2_OPEN;
    if (cd_status & 0x20)
        translated_status |= CD1_CONNECTED;
    if (cd_status & 0x10)
        translated_status |= CD1_OPEN;

    parms.CDStatus = (uint32_t)translated_status;

    aip_dbg("Cash Drawer Status 0x%x\n", parms.CDStatus);

    parms.CompletionCode = RPDONE;

    if (copy_to_user(buffer, &parms, sizeof(parms))) {
        rc = -EFAULT;
    }

out:
    return rc;
}


/* open_cd_drawer: Request to open a cash drawer
 * ************************************************************************
 *
 *  Function Name:  open_cd_drawer
 *
 *  Purpose:        Open the specified cash drawer
 *
 *  Description:    This function opens the cash drawer specified by the
 *                  arguments passed to it. This call has no effect when
 *                  the cash drawer interface type is legacy (4694).
 *
 *  Input:          pBuffer - pointer to argument structure
 *
 *  Output:         0       - success
 *                  -EFAULT - error
 *
 *    On success, CompletionCode will be RPDONE
 *
 * ************************************************************************
 */

static int open_cd_drawer(char *buffer)
{
    int index;
    OPEN_CD_PARMS parms = {0};
    int rc = 0;

    if (copy_from_user(&parms, buffer, sizeof(parms)) != 0) {
        rc = -EFAULT;
        goto out;
    }

    for (index = 0; index < OPEN_CMD_SIZE; index++) {
        if ((parms.WhichCD == 1) || ((index != 6) && (index != 7))) {
            aip_dbg("outb(0x%x, 0x%x)\n", OpenCDCmd[index],
                    BoardData.CDRegAddr);

            outb(OpenCDCmd[index], (BoardData.CDRegAddr));
        } else if ((index == 6) && (parms.WhichCD == 2)) {
            aip_dbg("outb(0xFD, 0x%x)\n", BoardData.CDRegAddr);

            outb(0xFD, (BoardData.CDRegAddr));
        } else if ((index == 7) && (parms.WhichCD == 2)) {
            aip_dbg("outb(0x7D, 0x%x)\n", BoardData.CDRegAddr);

            outb(0x7D, BoardData.CDRegAddr);
        }
    }

    aip_dbg("Open Cash Drawer %d\n", parms.WhichCD);

    parms.CompletionCode = RPDONE;

    if (copy_to_user(buffer, &parms, sizeof(parms)) != 0) {
        rc = -EFAULT;
    }

out:
    return rc;
}


/* set_cd_interface: Request to set the cash drawer interface
 * ************************************************************************
 *
 *  Function Name:  set_cd_interface
 *
 *  Purpose:        Set the cash drawer interface to either legacy (4694)
 *                  or PCI mode.
 *
 *  Description:    This function sets the cash drawer interface based
 *                  on the values in the arguments passed to it. Both
 *                  the interface type (4694 or PCI) and the pulse width
 *                  (100 or 200ms) are set.
 *
 *  Input:          pBuffer - pointer to argument structure
 *
 *  Output:         0       - success
 *                  -EFAULT - error
 *
 *    On success, CompletionCode will be RPDONE
 *
 * ************************************************************************
 */

static int set_cd_interface(char *buffer)
{
    SET_CD_INTERFACE_PARMS parms = {0};
    int rc = 0;

    aip_dbg("Interface set\n");

    if (copy_from_user(&parms, buffer, sizeof(parms)) != 0) {
        rc = -EFAULT;
        goto out;
    }

    parms.CompletionCode = RPDONE;

    if (copy_to_user(buffer, &parms, sizeof(parms)) != 0) {
        rc = -EFAULT;
    }

out:
    return rc;
}


#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 18)

int aipbcd_device_create(unsigned int major_number, char *modname,
                         const struct file_operations *fops)
{
    int err;

    /* Register as a device with kernel. */
    if ((err = register_chrdev(major_number, modname, fops))) {
        aip_error("Failure to load module. error %d\n", -err);
        return err;
    }

    return 0;
}


void aipbcd_device_destroy(unsigned int major_number, char *modname)
{
    if (unregister_chrdev(major_number, modname) != 0) {
        aip_error("unregister_chrdev failed\n");
    }

    return;
}

#else

int aipbcd_device_create(char *modname, char *devname[], int dev_count,
                         char *class_name, BOARDDATA *adapter,
                         struct file_operations *fops)
{
    int err = 0;
    int i = 0;
    int major = 0;
    struct device *dev;

    adapter->major = 0;

    /* Request dynamic allocation of a device major number */
    aip_dbg("Allocating major device with %d minors\n", dev_count);
    if ((err = alloc_chrdev_region(&adapter->dev_number, 0, dev_count,
                                   modname)) < 0) {
        aip_error("Cannot register device, error=%d\n", -err);
        return err;
    }

    aip_dbg("dev number is %x for '%s'\n", adapter->dev_number, modname);

    /* Populate sysfs entries */
    adapter->dev_class = class_create(THIS_MODULE, class_name);

    if (IS_ERR(adapter->dev_class)) {
        aip_error("Cannot create class '%s' error %ld\n", class_name,
                  PTR_ERR(adapter->dev_class));
        adapter->dev_class = NULL;
        return -EINVAL;
    }

    adapter->dev_count = dev_count;
    adapter->major = 0;

    major = MAJOR(adapter->dev_number);

    adapter->major = major;

    for (i = 0; i < dev_count && i < MAX_CDEVS; i++) {
        aip_dbg("Initialzing cdev for %d '%s'\n", i, devname[i]);

        /* Connect the file operations with the cdev */
        cdev_init(&adapter->cdev[i], fops);

        aip_dbg("Adding cdev for '%s' major=%d/minor=%d\n", devname[i],
                major, i);

        /* Connect the major/minor number to the cdev */
        err = cdev_add(&adapter->cdev[i], MKDEV(major, i), 1);
        adapter->cdev[i].owner = THIS_MODULE;

        if (err) {
            aip_error("Bad cdev add, error %d\n", -err);

            /* Destroy dev_class */
            class_destroy(adapter->dev_class);
            adapter->dev_class = NULL;

            return err;
        }

        aip_dbg("Adding device for '%s' major=%d/minor=%d\n",
                devname[i], major, i);

        /* Send uevents to udev, so it'll create /dev node */
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 26)
        dev = device_create(adapter->dev_class, NULL, MKDEV(major, i),
                            devname[i]);
#elif LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 28)
        dev = device_create_drvdata(adapter->dev_class, NULL, MKDEV(major, i),
                                    NULL, devname[i]);
#else
        dev = device_create(adapter->dev_class, NULL, MKDEV(major, i), NULL,
                            devname[i]);
#endif
        if (!IS_ERR(dev)) {
            /* save sysfs dev pointer for creating additional attributes */
            adapter->dev = dev;
        }

        aip_dbg("Adding sysfs for '%s' major=%d/minor=%d returned err %ld\n",
                devname[i], major, i,(long) IS_ERR(dev));
    }

    return 0;
}


void aipbcd_device_destroy(BOARDDATA *adapter)
{
    int i = 0;

    aip_dbg("entered major=%d, count=%d\n",
            adapter->major, adapter->dev_count);

    /* Release the major number */
    if (adapter != NULL && adapter->major > 0) {
        if (adapter->dev_class != NULL) {
            for (i = 0; i < adapter->dev_count && i < MAX_CDEVS; i++) {
                aip_dbg("Removing device major=%d/minor=%d returned\n",
                        adapter->major, i);

                /* Destroy device */
                device_destroy(adapter->dev_class, MKDEV(adapter->major, i));

                /* Remove the cdev */
                cdev_del(&adapter->cdev[i]);
            }

            aip_dbg("Unregistering chrdev major=%d, count=%d\n",
                    adapter->major, adapter->dev_count);

            unregister_chrdev_region(adapter->major, adapter->dev_count);

            adapter->dev_count = 0;

            /* Destroy dev_class */
            class_destroy(adapter->dev_class);
            adapter->dev_class = NULL;
        }
        adapter->major = 0;
    }

    aip_dbg("returning\n");

    return;
}

#endif


/* aipbcd_init: Init device driver
 * ************************************************************************
 *
 *  Function Name:  aipbcd_init
 *
 *  Purpose:        Initialize this device driver (called at insmod/modprobe
 *                  time)
 *
 *  Description:    Find PCI and/or ISA (4694) adapters
 *                  and get configuration information (2K buffer address,
 *                  NVRAM address, IRQ). Register interrupt handler and
 *                  send initial POR.
 *
 *  Input:          none
 *
 *  Output:         0  -- success
 *                  -1 -- error
 *
 * ************************************************************************
 */

static int __init aipbcd_init(void)
{
    int rc = 0;
    unsigned char *pmem;
    unsigned char id_byte1;
    unsigned char id_byte2;
    unsigned char id_byte3;
    unsigned char cdConfig = 0x00;
    struct pci_dev *pcidev = 0;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 18)
    char *dev_names[20] = { "aipbcd"};
    int  dev_count = 1;
#endif

    /* Initialize BoardData */
    memset(&BoardData, 0, sizeof(BOARDDATA));
    BoardData.boardSize = 2;

    if ((pmem = (unsigned char *)ioremap(0xFE000, 3)) == 0) {
        aip_dbg("Unable to map memory at 0xFE000\n");
        rc = -ENODEV;
        goto out;
    }

    id_byte1 = readb(pmem);
    id_byte2 = readb(pmem + 1);
    id_byte3 = readb(pmem + 2);
    iounmap(pmem);

    aip_dbg("ID Bytes= %#x %#x %#x\n", id_byte1, id_byte2, id_byte3);

    if (!((id_byte1 == SP500_MODELID_1) &&
          (id_byte2 == SP500_MODELID_2) &&
          (id_byte3 == SP500_32X_MODELID_3))) {

        rc = -ENODEV;
        goto out;
    }

    aip_info("SP500 Model 32x\n");

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 9)
    pcidev = pci_find_subsys(NM_VENDOR_ID, NM_DEVICE_ID,
                             IBM_VENDOR_ID, SP500_DEVICE_ID, pcidev);
#else
    pcidev = pci_get_subsys(NM_VENDOR_ID, NM_DEVICE_ID,
                            IBM_VENDOR_ID, SP500_DEVICE_ID, pcidev);
#endif

    if (pcidev == NULL) {
        aip_info("Device not found\n");
        rc = -ENODEV;
        goto out;
    }

    BoardData.pcidev = pcidev;
    aip_info("SP500 with Cash Drawer found\n");

    if (pci_enable_device(pcidev) != 0) {
        aip_error("Unable to enable device\n");
        rc = -ENODEV;
        goto out;
    }

    /* Get CD Register address */
    pci_read_config_dword(pcidev, PCI_BASE_ADDRESS_2,
                          (u32 *)&BoardData.CDRegAddr );
    BoardData.CDRegAddr &= (unsigned long)(~PCI_BASE_ADDRESS_SPACE_IO);

    /* Try to claim our I/O space */
    if (request_region(BoardData.CDRegAddr, BoardData.boardSize,
                       DEVDRVR_ID) == 0) {
        aip_error("Unable to allocate adapter region\n");
        rc = -EINVAL;
        goto out;
    }

    /* Read the cash drawer config byte */
    cdConfig = inb(BoardData.CDRegAddr + 1);

    aip_info("Cash Drawer Config=0x%x\n", cdConfig);

    /* Cash Drawer 1 Attached (0 = attached, 1 = not) */
    if (!(cdConfig & 0x20)) {
        BoardData.SlotDrawers += 1;
    }

    /* Cash Drawer 2 Attached (0 = attached, 1 = not) */
    if (!(cdConfig & 0x80)) {
        BoardData.SlotDrawers += 1;
    }

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 18)
    /* Register as a device with kernel. */
    rc = aipbcd_device_create(aipbcd_major, DEVDRVR_ID, &aipbcd_fops);
#else
    /* Request dynamic allocation of a device major number */
    rc = aipbcd_device_create((char *) DEVDRVR_ID, dev_names, dev_count,
                              "aipbcd", &BoardData, &aipbcd_fops);
#endif

    if (rc != 0) {
        if (BoardData.CDRegAddr != 0) {
            aip_dbg("Release port (0x%x) regions\n", BoardData.CDRegAddr);
            release_region(BoardData.CDRegAddr, BoardData.boardSize);
        }
    } else {
        aip_dbg("Device registered with kernel\n");
    }

out:
    aip_dbg("Init returning, rc=%d\n", -rc);

    return rc;
}


/* aipbcd_exit: Exit (unload) device driver
 * ************************************************************************
 *
 *  Function Name:  aipbcd_exit
 *
 *  Purpose:        Unload this device driver (called at rmmod time)
 *
 *  Description:    Release (unmap) memory, I/O space, and IRQ.
 *
 *  Input:          none
 *
 *  Output:         none
 *
 * ************************************************************************
 */

static void __exit aipbcd_exit(void)
{
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 5, 0)
    if (MOD_IN_USE) {
        aip_info("device busy, remove delayed\n");
        return;
    }
#endif

    if (BoardData.CDRegAddr != 0) {
        aip_dbg("Release port (0x%x) regions\n", BoardData.CDRegAddr);
        release_region(BoardData.CDRegAddr, BoardData.boardSize);
    }

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 18)
    aipbcd_device_destroy(aipbcd_major, DEVDRVR_ID);
#else
    aipbcd_device_destroy(&BoardData);
#endif

    aip_dbg("Unload module\n");
}


module_init(aipbcd_init);
module_exit(aipbcd_exit);

MODULE_AUTHOR("Toshiba Global Commerce Solutions, Inc.");
MODULE_DESCRIPTION("Toshiba Cash Drawer Driver");
MODULE_LICENSE("GPL");
