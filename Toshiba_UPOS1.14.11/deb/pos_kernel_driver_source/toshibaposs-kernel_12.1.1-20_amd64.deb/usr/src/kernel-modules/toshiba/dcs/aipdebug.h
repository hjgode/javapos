/*
 *  Module Name:     aipdebug.h
 *
 *  Description:     kernel driver debug support
 *
 *  Copyright (C) 2008-2015 Toshiba Global Commerce Solutions, Inc.
 *  All right reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA; Otherwise,
 *  see <http://www.gnu.org/licenses/>.
 *
 *
 * Should you need to contact me, the author, you can do so either by
 * e-mail - mail your message to <gha@toshibagcs.com>.
 */

#ifndef _H_AIPDEBUG
#define _H_AIPDEBUG 1

static bool debug = 0;
static bool verbose = 0;

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 0)

MODULE_PARM(debug, "i");

#else

module_param(debug, bool, S_IRUGO | S_IWUSR);
MODULE_PARM_DESC(debug, "true to log all debug statements");

module_param(verbose, bool, S_IRUGO | S_IWUSR);
MODULE_PARM_DESC(verbose, "true to log all verbose statements");

#endif


#define aip_warning(fmt, args...)               \
    do {                            \
        printk(KERN_WARNING "%s(%s): " fmt , DEVDRVR_ID , __FUNCTION__ , ## args); \
    } while (0)

#define aip_error(fmt, args...)             \
    do {                            \
        printk(KERN_ERR "%s(%s): " fmt , DEVDRVR_ID , __FUNCTION__ , ## args); \
    } while (0)

#define aip_info(fmt, args...)              \
    do {                            \
        printk(KERN_INFO "%s: " fmt , DEVDRVR_ID , ## args); \
    } while (0)

#define aip_dbg(fmt, args...)               \
    do {                        \
        if (debug)              \
            printk(KERN_INFO "%s(%s): " fmt , DEVDRVR_ID , __FUNCTION__ , ## args); \
    } while (0)

#define aip_verbose(fmt, args...)               \
    do {                        \
        if (verbose && debug)               \
            printk(KERN_INFO "%s(%s): " fmt , DEVDRVR_ID , __FUNCTION__ , ## args); \
    } while (0)

#endif
