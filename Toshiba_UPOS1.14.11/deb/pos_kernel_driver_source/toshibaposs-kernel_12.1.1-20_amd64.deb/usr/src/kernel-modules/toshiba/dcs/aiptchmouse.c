/*
 * Module Name:     aiptchmouse.c
 *
 * Description:     Touchscreen Mouse Emulation Driver For Linux
 *
 *  Copyright (C) 2002-2015 Toshiba Global Commerce Solutions, Inc.
 *  All right reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA; Otherwise,
 *  see <http://www.gnu.org/licenses/>.
 *
 *
 * Should you need to contact me, the author, you can do so either by
 * e-mail - mail your message to <gha@toshibagcs.com>.
 */

/* System Headers */
#ifdef MODVERSIONS
#include <linux/modversions.h>
#endif

#include <linux/version.h>
#include <linux/config.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/input.h>
#include <linux/compiler.h>
#include <linux/slab.h>
#include <linux/init.h>
#include <linux/poll.h>
// #include <linux/ioport.h>
#include <linux/smp_lock.h>
// #include <linux/fs.h>
// #include <linux/types.h>
// #include <asm/io.h>

/* Local configuration constants */
#ifndef __LINUX__
#define __LINUX__
#endif
#ifndef __UNIX__
#define __UNIX__
#endif

/* Local Headers */
#include "aipkernel.h"


MODULE_AUTHOR("Toshiba Global Commerce Solutions, Inc");
MODULE_DESCRIPTION("Toshiba RS-485 Touchscreen Mouse Emulation");
MODULE_LICENSE("GPL compatible");

/* Local Types */
struct touchemu {
    struct input_dev dev;
};

struct touchdev {
    int exist;
    int open;
    int minor;
    wait_queue_head_t wait;
    struct touchdev_list *list;
    struct input_handle handle;
    devfs_handle_t devfs;
};

struct touchdev_list {
    struct fasync_struct *fasync;
    struct touchdev *touchdev;
    struct touchdev_list *next;
    int x, y, oldx, oldy;
    signed char mts[10], writebuf[10];
    unsigned char buttons;
    unsigned char ready, buffer, bufsiz;
};



/* Local Constants */
#define INPUT_DEVICE_MAJOR    248
#define TOUCHDEV_MINOR_BASE   248
#define TOUCHDEV_MINORS       3 /* Support only 2 touch devices */
#define TOUCHDEV_COM          2
#define TOUCHDEV_COM_MINOR    "touch"

#define MOUSEEVENTF_MOVE      0x0001
#define MOUSEEVENTF_LEFTDOWN  0x0002
#define MOUSEEVENTF_LEFTUP    0x0004
#define MOUSEEVENTF_ABSOLUTE  0x8000

static const char INPUT_DEVICE[] = "aiptchmouse";

#ifdef DEBUG
#define DPRINTK(fmt, args...) printk(KERN_DEBUG "%s(%s): " fmt, INPUT_DEVICE, __FUNCTION__ , ## args)
#else
#define DPRINTK(fmt, args...)
#endif


static struct touchdev *touchdev_table[TOUCHDEV_MINORS];
static struct touchdev touchdev_com;


/* Function Prototypes */
static int __init touchemu_init(void);
static void __exit touchemu_exit(void);
static int touchemu_open(struct inode *inode, struct file *file);
static int touchemu_release(struct inode *inode, struct file *file);
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 36)
static int touchemu_ioctl(struct inode *inode, struct file *file,
                          unsigned int cmd, unsigned long arg);
#else
static long touchemu_ioctl(struct file *file, unsigned int cmd, unsigned long arg);
#endif
static int touchdev_open(struct inode *inode, struct file *file);
static int touchdev_release(struct inode *inode, struct file *file);
static ssize_t touchdev_read(struct file *file, char *buffer, size_t count,
                             loff_t *ppos);
static ssize_t touchdev_write(struct file *file, const char *buffer,
                              size_t count, loff_t *ppos);
static unsigned int touchdev_poll(struct file *file, poll_table *wait);
static int touchdev_fasync(int fd, struct file *file, int on);
static struct input_handle *touchdev_connect(struct input_handler *handler,
                                             struct input_dev *dev);
static void touchdev_disconnect(struct input_handle *handle);
static void touchdev_event(struct input_handle *handle, unsigned int type,
                           unsigned int code, int value);
static void touchdev_packet(struct touchdev_list *list);
static int send_mouse_event(struct inode *inode, struct file *file,
                            char *pBuffer);

module_init(touchemu_init);
module_exit(touchemu_exit);

/* static Global Variables */
// static int errno;

static struct file_operations touchemu_fops = {
    .open           = touchemu_open,
    .release        = touchemu_release,
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 36)
    .ioctl          = touchemu_ioctl,
#else
    .unlocked_ioctl = touchemu_ioctl,
#endif
#if LINUX_VERSION_CODE > KERNEL_VERSION(3, 11, 0)
    .compat_ioctl   = touchemu_ioctl,
#endif
    .owner          = THIS_MODULE,
};

struct file_operations touchdev_fops = {
    .open       = touchdev_open,
    .release    = touchdev_release,
    .read       = touchdev_read,
    .write      = touchdev_write,
    .poll       = touchdev_poll,
    .fasync     = touchdev_fasync,
    .owner      = THIS_MODULE,
};

static struct input_handler touchdev_handler = {
    .connect    = touchdev_connect,
    .disconnect = touchdev_disconnect,
    .event      = touchdev_event,
    .fops       = &touchdev_fops,
    .minor      = TOUCHDEV_MINOR_BASE,
};


/* touchemu_init: Registers the input driver and it's handler
 * ************************************************************************
 *
 *  Function Name:  touchemu_init
 *
 *  Purpose:        Registers the input driver and it's handler
 *
 *  Description:    This function is called when the driver is loaded
 *                  i.e. "insmod aiptchmouse" is invoked on the command
 *                  line
 *
 * ************************************************************************
 */
static int __init touchemu_init(void)
{
    int rc = 0;

    /* Register touch device */
    input_register_handler(&touchdev_handler);

    /* Register the common node */
    memset(&touchdev_com, 0, sizeof(struct touchdev));
    init_waitqueue_head(&touchdev_com.wait);

    touchdev_table[TOUCHDEV_COM] = &touchdev_com;
    touchdev_com.exist = 1;
    touchdev_com.minor = TOUCHDEV_COM;
    touchdev_com.devfs = input_register_minor(TOUCHDEV_COM_MINOR, TOUCHDEV_COM,
                                              TOUCHDEV_MINOR_BASE);

    /* Register input device */
    rc = register_chrdev(INPUT_DEVICE_MAJOR, INPUT_DEVICE, &touchemu_fops);
    if (rc != 0) {
        printk(KERN_WARNING "%s: Failure to load module, rc=%d\n", INPUT_DEVICE, -rc);
    }

    return rc;
}


/* touchemu_exit: Unregisters the input driver and it's handler
 * ************************************************************************
 *
 *  Function Name:  touchemu_exit
 *
 *  Purpose:        Unregisters the input driver and it's handler
 *
 *  Description:    This function is called when the driver is unloaded
 *                  i.e. "rmmod aiptchmouse" is invoked on the command
 *                  line
 *
 * ************************************************************************
 */
static void __exit touchemu_exit(void)
{
    int rc = 0;

    /* Unregister input device */
    rc = unregister_chrdev(INPUT_DEVICE_MAJOR, INPUT_DEVICE);
    if (rc != 0) {
        printk(KERN_WARNING "%s: Unable to unregister input device, rc=%d\n",
               INPUT_DEVICE, rc);
    }

    /* Unregister touch device */
    input_unregister_minor(touchdev_com.devfs);
    input_unregister_handler(&touchdev_handler);
}


/* touchemu_open: Initialize and register the input device
 * ************************************************************************
 *
 *  Function Name:  touchemu_open
 *
 *  Purpose:        Initialize and register the input device
 *
 *  Description:    This is the Open call used by the user mode
 *                  application that provides the input data.
 *
 * ************************************************************************
 */
static int touchemu_open(struct inode *inode, struct file *file)
{
    struct touchemu *touchemu;
    int rc = 0;

    MOD_INC_USE_COUNT;

    DPRINTK("touchemu_open(Entry)\n");

    touchemu = kmalloc(sizeof(struct touchemu), GFP_KERNEL);
    if (!touchemu) {
        rc = -ENOMEM;
        goto out;
    }

    memset(touchemu, 0, sizeof(*touchemu));

    /* Input events this driver uses */
    touchemu->dev.evbit[0] = BIT(EV_KEY) | BIT(EV_ABS);
    set_bit(ABS_X,    touchemu->dev.absbit);
    set_bit(ABS_Y,    touchemu->dev.absbit);
    set_bit(BTN_BACK, touchemu->dev.keybit);

    /* Use a name to connect to custom handler */
    touchemu->dev.name = "4820 RS485";

    /* Register the input device */
    input_register_device(&touchemu->dev);
    file->private_data = touchemu;

out:
    DPRINTK("touchemu_open(Exit) rc=%d\n", rc);

    return rc;
}


/* touchemu_release: Unregister the input device
 * ************************************************************************
 *
 *  Function Name:  touchemu_release
 *
 *  Purpose:        Unregister the input device
 *
 *  Description:    This is the Release call used by the user mode
 *                  application that provides the input data.
 *
 * ************************************************************************
 */
static int touchemu_release(struct inode *inode, struct file *file)
{
    struct touchemu *touchemu = file->private_data;

    MOD_DEC_USE_COUNT;

    DPRINTK("touchemu_release(Entry)\n");

    input_unregister_device(&touchemu->dev);
    kfree(touchemu);

    DPRINTK("touchemu_release(Exit)\n");

    return 0;
}


/* touchemu_ioctl: Entry point for touchdata
 * ************************************************************************
 *
 *  Function Name:  touchemu_ioctl
 *
 *  Purpose:        Entry point for touchdata
 *
 *  Description:    This is the ioctl call used by the user mode
 *                  application. The commands are processed by seperate
 *                  functions.
 *
 * ************************************************************************
 */
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 36)
static int touchemu_ioctl(struct inode *inode, struct file *file,
                          unsigned int cmd, unsigned long arg)
#else
static long touchemu_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
#endif
{
    int rc = 0;

    switch (_IOC_NR(cmd)) {
        case _IOC_NR(SEND_MOUSE_EVENT):
            DPRINTK("touchemu_ioctl(SEND_MOUSE_EVENT)\n");

            rc = send_mouse_event(inode, file, (char *) arg);
            break;
    }

    return rc;
}


/* touchdev_open: Gets a handle to the opened device
 * ************************************************************************
 *
 *  Function Name:  touchdev_open
 *
 *  Purpose:        Gets a handle to the opened device
 *
 *  Description:    This is the Open call used by the user mode
 *                  application that receives the output data.
 *
 * ************************************************************************
 */
static int touchdev_open(struct inode *inode, struct file *file)
{
    struct touchdev_list *list;
    int i = MINOR(inode->i_rdev) - TOUCHDEV_MINOR_BASE;
    int rc = 0;

    MOD_INC_USE_COUNT;

    DPRINTK("touchdev_open(Entry)\n");

    if (i >= TOUCHDEV_MINORS || !touchdev_table[i]) {
        rc = -ENODEV;
        goto out;
    }

    if (!(list = kmalloc(sizeof(struct touchdev_list), GFP_KERNEL))) {
        rc = -ENOMEM;
        goto out;
    }
    memset(list, 0, sizeof(struct touchdev_list));

    list->touchdev = touchdev_table[i];
    list->next = touchdev_table[i]->list;
    touchdev_table[i]->list = list;
    file->private_data = list;

    if (!list->touchdev->open++) {
        if (list->touchdev->minor == TOUCHDEV_COM) {
            struct input_handle *handle = touchdev_handler.handle;

            while (handle) {
                struct touchdev *touchdev = handle->private;

                if (!touchdev->open) {
                    if (touchdev->exist) {
                        input_open_device(handle);
                    }
                }
                handle = handle->hnext;
            }
        } else {
            if (!touchdev_com.open) {
                if (list->touchdev->exist) {
                    input_open_device(&list->touchdev->handle);
                }
            }
        }
    }

out:
    DPRINTK("touchdev_open(Exit) rc=%d\n", rc);

    return rc;
}


/* touchdev_release: Releases the handle to the opened device
 * ************************************************************************
 *
 *  Function Name:  touchdev_release
 *
 *  Purpose:        Releases the handle to the opened device
 *
 *  Description:    This is the Release call used by the user mode
 *                  application that receives the output data.
 *
 * ************************************************************************
 */
static int touchdev_release(struct inode *inode, struct file *file)
{
    struct touchdev_list *list = file->private_data;
    struct touchdev_list **listptr;

    MOD_DEC_USE_COUNT;

    DPRINTK("touchdev_release(Entry)\n");

    lock_kernel();
    listptr = &list->touchdev->list;
    touchdev_fasync(-1, file, 0);

    while (*listptr && (*listptr != list)) {
        listptr = &((*listptr)->next);
    }
    *listptr = (*listptr)->next;

    if (!--list->touchdev->open) {
        if (list->touchdev->minor == TOUCHDEV_COM) {
            struct input_handle *handle = touchdev_handler.handle;

            while (handle) {
                struct touchdev *touchdev = handle->private;

                if (!touchdev->open) {
                    if (touchdev->exist) {
                        input_close_device(&touchdev->handle);
                    } else {
                        input_unregister_minor(touchdev->devfs);
                        touchdev_table[touchdev->minor] = NULL;
                        kfree(touchdev);
                    }
                }
                handle = handle->hnext;
            }
        } else {
            if (!touchdev_com.open) {
                if (list->touchdev->exist) {
                    input_close_device(&list->touchdev->handle);
                } else {
                    input_unregister_minor(list->touchdev->devfs);
                    touchdev_table[list->touchdev->minor] = NULL;
                    kfree(list->touchdev);
                }
            }
        }
    }

    kfree(list);
    unlock_kernel();

    DPRINTK("touchdev_release(Exit)\n");

    return 0;
}


/* touchdev_read: Allows the user mode application to read the output data
 * ************************************************************************
 *
 *  Function Name:  touchdev_read
 *
 *  Purpose:        Allows the user mode application to read the output
 *                  data
 *
 *  Description:    This is the Read call used by the user mode
 *                  application that receives the output data.
 *
 * ************************************************************************
 */
static ssize_t touchdev_read(struct file *file, char *buffer, size_t count,
                loff_t *ppos)
{
    DECLARE_WAITQUEUE(wait, current);
    struct touchdev_list *list = file->private_data;
    int rc = 0;

    DPRINTK("touchdev_read(Entry)\n");

    if (!list->ready && !list->buffer) {
        /* Put the current process to sleep and let others run */
        add_wait_queue(&list->touchdev->wait, &wait);
        set_current_state(TASK_INTERRUPTIBLE);

        while (!list->ready) {
            if (file->f_flags & O_NONBLOCK) {
                rc = -EAGAIN;
                break;
            }

            if (signal_pending(current)) {
                rc = -ERESTARTSYS;
                break;
            }
            schedule();
        }
        set_current_state(TASK_RUNNING);
        remove_wait_queue(&list->touchdev->wait, &wait);
    }

    if (rc != 0) {
        goto out;
    }

    /* Pack the data if buffer is not empty */
    if (!list->buffer) {
        touchdev_packet(list);
    }

    /* Copy data packet to user space */
    if (copy_to_user(buffer, list->mts + list->bufsiz - list->buffer, count)) {
        rc = -EFAULT;
        goto out;
    }

    list->buffer -= count;

out:
    if (rc == 0) {
        rc = count;
    }

    DPRINTK("touchdev_read(Exit) rc=%d\n", rc);

    return rc;
}


/* touchdev_write: Allows the user mode application to send data to this module
 * ************************************************************************
 *
 *  Function Name:  touchdev_write
 *
 *  Purpose:        Allows the user mode application to send data to this
 *                  module
 *
 *  Description:    This is the Write call used by the user mode
 *                  application that receives the output data.
 *
 * ************************************************************************
 */
static ssize_t touchdev_write(struct file *file, const char *buffer,
                              size_t count, loff_t *ppos)
{
    struct touchdev_list *list = file->private_data;
    int rc = 0;

    DPRINTK("touchdev_write(Entry)\n");

    /* ******************************************************************
     * GPM does not require a response from the write so we just read
     * off the buffer for now.
     * ******************************************************************
     */
    if (copy_from_user(list->writebuf, buffer, count)) {
        rc = -EFAULT;
        goto out;
    }

    kill_fasync(&list->fasync, SIGIO, POLL_IN);
    wake_up_interruptible(&list->touchdev->wait);

out:
    if (rc == 0) {
        rc = count;
    }

    DPRINTK("touchdev_write(Exit) rc=%d\n", rc);

    return rc;
}


/* touchdev_poll: Allows the user mode application to poll this module
 * ************************************************************************
 *
 *  Function Name:  touchdev_poll
 *
 *  Purpose:        Allows the user mode application to poll this module
 *
 *  Description:    This is the Poll call used by the user mode
 *                  application that receives the output data.
 *                  User mode application uses this call to wait until the
 *                  next read/write operation is available.
 *
 * ************************************************************************
 */
static unsigned int touchdev_poll(struct file *file, poll_table *wait)
{
    struct touchdev_list *list = file->private_data;
    int rc = 0;

    DPRINTK("touchdev_poll\n");

    poll_wait(file, &list->touchdev->wait, wait);

    if (list->ready || list->buffer) {
        rc = POLLIN | POLLRDNORM;
    }

    return rc;
}


/* touchdev_fasync: Support for asynchronous notification
 * ************************************************************************
 *
 *  Function Name:  touchdev_fasync
 *
 *  Purpose:        Support for asynchronous notification
 *
 *  Description:    This is the Fasync call used by the user mode
 *                  application that receives the output data.
 *                  User mode application uses this call to register
 *                  themselves as asynchronous readers.
 *
 * ************************************************************************
 */
static int touchdev_fasync(int fd, struct file *file, int on)
{
    int rc = 0;
    struct touchdev_list *list = file->private_data;

    DPRINTK("touchdev_fasync\n");

    rc = fasync_helper(fd, file, on, &list->fasync);
    return rc < 0 ? rc : 0;
}


/* touchdev_connect: Connects the handler to the opened device
 * ************************************************************************
 *
 *  Function Name:  touchdev_connect
 *
 *  Purpose:        Connects the handler to the opened device
 *
 *  Description:    This is the Connect call used by the input core when
 *                  input_register_device is called.
 *
 * ************************************************************************
 */
static struct input_handle *touchdev_connect(struct input_handler *handler, struct input_dev *dev)
{
    struct touchdev *touchdev;
    struct input_handle *handle = NULL;
    int minor = 0;

    if (dev->name != "4820 RS485") {
        handle = NULL;
        goto out;
    }

    DPRINTK("touchdev_connect(Entry)\n");

    for (minor = 0; minor < TOUCHDEV_MINORS && touchdev_table[minor]; minor++)
        ;

    if (minor == TOUCHDEV_MINORS) {
        printk(KERN_ERR "%s: no more free touchdev devices\n", INPUT_DEVICE);
        handle = NULL;
        goto out;
    }

    if (!(touchdev = kmalloc(sizeof(struct touchdev), GFP_KERNEL))) {
        handle = NULL;
        goto out;
    }

    memset(touchdev, 0, sizeof(struct touchdev));
    init_waitqueue_head(&touchdev->wait);

    touchdev->exist = 1;
    touchdev->minor = minor;
    touchdev_table[minor] = touchdev;

    touchdev->handle.dev = dev;
    touchdev->handle.handler = handler;
    touchdev->handle.private = touchdev;

    touchdev->devfs = input_register_minor("touch%d", minor,
                                           TOUCHDEV_MINOR_BASE);

    if (touchdev_com.open) {
        input_open_device(&touchdev->handle);
    }

    DPRINTK("touchdev_connect(Exit)\n");

    handle = &touchdev->handle;

out:
    return handle;
}


/* touchdev_disconnect: Close the input device
 * ************************************************************************
 *
 *  Function Name:  touchdev_disconnect
 *
 *  Purpose:        Close the input device
 *
 *  Description:    This is the Disconnect call used by the input core
 *                  when input_unregister_device is called. The handler
 *                  is disconnected by input_unregister_device and this
 *                  function is then called to close the device.
 *
 * ************************************************************************
 */
static void touchdev_disconnect(struct input_handle *handle)
{
    struct touchdev *touchdev = handle->private;

    touchdev->exist = 0;

    DPRINTK("touchdev_disconnect(Entry)\n");

    if (touchdev->open) {
        input_close_device(handle);
    } else {
        if (touchdev_com.open) {
            input_close_device(handle);
        }
        input_unregister_minor(touchdev->devfs);
        touchdev_table[touchdev->minor] = NULL;
        kfree(touchdev);
    }

    DPRINTK("touchdev_disconnect(Exit)\n");
}


/* touchdev_event: Event handler for the input device
 * ************************************************************************
 *
 *  Function Name:  touchdev_event
 *
 *  Purpose:        Event handler for the input device
 *
 *  Description:    This is the Event Handler for the input device
 *                  It cannot be used as a generic handler!
 *                  Buttons are remapped to indicate mouse functions as
 *                  a hack to GPM.
 *
 * ************************************************************************
 */
static void touchdev_event(struct input_handle *handle, unsigned int type,
                           unsigned int code, int value)
{
    struct touchdev *touchdevs[3] = { handle->private, &touchdev_com, NULL };
    struct touchdev **touchdev = touchdevs;
    struct touchdev_list *list;
    int index = 0;

    DPRINTK("touchdev_event(Entry)\n");

    while (*touchdev) {
        list = (*touchdev)->list;

        while (list) {
            switch (type) {
                case EV_ABS:
                    if (test_bit(BTN_TRIGGER, handle->dev->keybit)) {
                        break;
                    }
                    switch (code) {
                        case ABS_X:
                            list->x = (value / 4); /* resize value to MTS Format Tablet */
                            break;
                        case ABS_Y:
                            list->y = (value / 4); /* resize value to MTS Format Tablet */
                            break;
                    }
                    break;

                case EV_KEY:
                    switch (code) {
                        case BTN_BACK:
                            index = 6;
                            break;
                    }
                    switch (value) {
                        case 0:
                            clear_bit(index, &list->buttons);
                            break;
                        case 1:
                            set_bit(index, &list->buttons);
                            break;
                        default:
                            return;
                    }
                    break;
            }

            list->ready = 1;
            kill_fasync(&list->fasync, SIGIO, POLL_IN);
            list = list->next;
        }

        wake_up_interruptible(&((*touchdev)->wait));
        touchdev++;
    }

    DPRINTK("touchdev_event(Exit)\n");
}


/* touchdev_packet: Packets the output data to the required format
 * ************************************************************************
 *
 *  Function Name:  touchdev_packet
 *
 *  Purpose:        Packets the output data to the required format
 *
 *  Description:    Called before the output data is read by the user
 *                  mode application that receives this data.
 *
 * ************************************************************************
 */
static void touchdev_packet(struct touchdev_list *list)
{
    list->mts[0] = (list->buttons | 0x80);
    list->mts[1] = (list->x % 128);
    list->mts[2] = (list->x / 128);
    list->mts[3] = (list->y % 128);
    list->mts[4] = (list->y / 128);
    list->buffer = list->bufsiz = 5;

    /* Not ready if there's no change */
    if ((list->x == list->oldx) && (list->y == list->oldy)) {
        list->ready = 0;
    }

    list->oldx = list->x;
    list->oldy = list->y;

    DPRINTK("touchdev_packet\n");
}


/* send_mouse_event: Notifies the handler of incoming events
 * ************************************************************************
 *
 *  Function Name:  send_mouse_event
 *
 *  Purpose:        Notifies the handler of incoming events
 *
 *  Description:    Called by the Ioctl to get the input data from user
 *                  space and notifies the handler.
 *
 * ************************************************************************
 */
static int send_mouse_event(struct inode *inode, struct file *file, char *pBuffer)
{
    struct touchemu *touchemu = file->private_data;
    struct input_dev *dev = &touchemu->dev;
    unsigned short wFlags, wX, wY;
    int rc = 0;

    MOUSE_COORD mouse_event = {0};

    /* Copy over the structure from user space */
    if (copy_from_user(&mouse_event, pBuffer, sizeof(MOUSE_COORD))) {
        rc = -EFAULT;
        goto out;
    }

    wFlags = mouse_event.wFlags;
    wX = mouse_event.wX;
    wY = (0xFFFF - mouse_event.wY); /* Y axis is inverted w.r.t. MS Windows */

    /* Process the mouse event */
    switch (wFlags) {
        case (MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_MOVE):
            input_event(dev, EV_ABS, ABS_X, wX);
            input_event(dev, EV_ABS, ABS_Y, wY);
            input_event(dev, EV_KEY, BTN_BACK, 1);
            break;
        case MOUSEEVENTF_LEFTDOWN:
            input_event(dev, EV_KEY, BTN_BACK, 1);
            break;
        case MOUSEEVENTF_LEFTUP:
            input_event(dev, EV_KEY, BTN_BACK, 0);
            break;
    }

    mouse_event.CompletionCode = RPDONE;
    if (copy_to_user(pBuffer, &mouse_event, sizeof(MOUSE_COORD))) {
        rc = -EFAULT;
        goto out;
    }

out:
    return rc;
}
