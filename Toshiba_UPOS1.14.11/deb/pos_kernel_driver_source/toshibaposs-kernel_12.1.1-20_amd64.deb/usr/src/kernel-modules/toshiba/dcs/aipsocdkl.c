/*
 * Module Name:     aipsocdkl.c
 *
 * Description:     Cash Drawer & KeyLock Driver for Linux on SureOne 4614.
 *
 * Copyright (C) 2005-2018 Toshiba Global Commerce Solutions, Inc.
 * All right reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA; Otherwise,
 *  see <http://www.gnu.org/licenses/>.
 *
 *
 * Should you need to contact me, the author, you can do so either by
 * e-mail - mail your message to <gha@toshibagcs.com>.
 */



/*
 * Linux defs and headers
 */
#ifndef __KERNEL__
#define __KERNEL__
#endif
#ifndef MODULE
#define MODULE
#endif

#ifdef MODVERSIONS
#include <linux/modversions.h>
#endif

#include <linux/module.h>
#include <linux/version.h>
#include <linux/fs.h>
#include <asm/io.h>
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 11, 0)
#include <linux/uaccess.h>
#else
#include <asm/uaccess.h>
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 18)
#include <linux/cdev.h>
#endif
#include <linux/init.h>
#include <linux/kernel.h>
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 0)
#include <linux/moduleparam.h>
#include <linux/device.h>
#endif
#include "aipkernel.h"
#include "aipdebug.h"



/*
 * SureOne machine specific declarations
 */
#define SUREONE 0xFE040         /* Model Number Address in Bios */
#define SUREONEID 0x34313634    /* "4614" */

#define IBM_4613  8     /* Anyplace Kiosk ID as a command paramater of aipstart srcipt*/
#define IBM_4614  7     /* SureOne ID as command paramater of aipstart script*/

/*
 * Driver specific declarations
 */
static const char DEVDRVR_ID[] = "aipsocdkl";
#define AIPSOCDKL_MAJOR_DEV 249



static int machine_type = IBM_4614;  /*Default to IBM_4614*/
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 0)
MODULE_PARM_DESC(machine_type, "i");
#else
module_param(machine_type,int,0);
MODULE_PARM_DESC(machine_type,"Integer Value");
#endif

/*
 *  ASIC Port definitions
 */
#define INDEX_PORT_ADDRESS     0x240    /* ASIC Data port index selector (W) */
#define DATA_PORT_ADDRESS      0x241    /* Data I/O Port Address */
#define KL_STATUS_INDEX        0x26     /* Keylock status data port (R) */
#define CD_SETUP_INDEX         0x28     /* Cash Drawer setup data port (RW) */
#define CD_OPEN_INDEX          0x29     /* Cash Drawer firing port (W) */
#define CD_STATUS_INDEX        0x30     /* Cash Drawer status port (RW) */

#define CD_ENABLE              0x06     /* xxxx x110 Use ASIC, 100ms, /Enable */
#define CD_OPEN                0x01     /* xxxx xxx1 Fire Cash Drawer */


/*
 * Return Code
 */
#define SUCCESS 0


/*
 * Function Prototypes
 */
static int  __init  aipsocdkl_init(void);
static void __exit  aipsocdkl_exit(void);
static int  aipsocdkl_open(struct inode *inode, struct file *flip);
static ssize_t  aipsocdkl_read(struct file *flip, char *buf, size_t count, loff_t *f_pos);
static ssize_t  aipsocdkl_write(struct file *flip, const char *buf, size_t count, loff_t *f_pos);
static int  aipsocdkl_release(struct inode *inode, struct file *flip);
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 36)
static int  aipsocdkl_ioctl(struct inode *inode, struct file *flip,
                            unsigned int cmd, unsigned long arg);
#else
static long aipsocdkl_ioctl(struct file *flip, unsigned int cmd, unsigned long arg);
#endif
static int  aipsocdkl_ioctl_GetSlotInfo(char *pBuffer);
static int  aipsocdkl_ioctl_GetKLStatus(char *pBuffer);
static int  aipsocdkl_ioctl_OpenCD(char *pBuffer);
static int  aipsocdkl_ioctl_GetCDStatus(char *pBuffer);

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 18)
static int aipsocdkl_major = AIPSOCDKL_MAJOR_DEV;

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 0)
MODULE_PARM(aipsocdkl_major, "i");
#else
module_param_named(major, aipsocdkl_major, int, 0644);
#endif
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 18)
#define MAX_CDEVS 5
typedef struct {
    struct class  *dev_class;
    struct cdev    cdev[MAX_CDEVS];
    struct device *dev;
    int            dev_count;
    int            major;
    dev_t          dev_number;
} socdkl_adapter;
socdkl_adapter Adapter;
#endif

/*
 * Device methods
 */
struct file_operations aipsocdkl_fops = {
    owner:    THIS_MODULE,
    read:     aipsocdkl_read,
    write:    aipsocdkl_write,
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 36)
    ioctl:    aipsocdkl_ioctl,
#else
    .unlocked_ioctl = aipsocdkl_ioctl,
#endif
#if LINUX_VERSION_CODE > KERNEL_VERSION(3, 11, 0)
    .compat_ioctl   = aipsocdkl_ioctl,
#endif
    open:     aipsocdkl_open,
    release:  aipsocdkl_release,
};

/*
 * Driver Global Variables
 */
static unsigned char *pBiosModelNumber = NULL;
static uint32_t CheckModel = 0;



/************************************************************************
 *
 * Function Name:      aipsocdkl_open
 *
 * Purpose:            Device Open
 *
 * Description:        Called by client to access driver services
 *
 * Output:             0 - Success, Non-zero - Failure
 *
 * ***********************************************************************
 */
static int aipsocdkl_open(struct inode *inode, struct file *flip)
{
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 5, 0)
    MOD_INC_USE_COUNT;
#endif
    aip_dbg("open\n");
    return SUCCESS;
}


/************************************************************************
 *
 * Function Name:      aipsocdkl_release
 *
 * Purpose:            Device Close
 *
 * Description:        Called by client to release access to driver services
 *
 * Output:             0 - Success
 *
 * ***********************************************************************
 */
static int aipsocdkl_release(struct inode *inode, struct file *flip)
{
    #if LINUX_VERSION_CODE < KERNEL_VERSION(2, 5, 0)
    MOD_DEC_USE_COUNT;
    #endif
    aip_dbg("close\n");
    return SUCCESS;
}


/************************************************************************
 *
 * Function Name:      aipsocdkl_read
 *
 * Notes:              Read Not supported
 *
 * ***********************************************************************
 */
static ssize_t aipsocdkl_read(struct file *flip, char *buf, size_t count,
                              loff_t *f_pos)
{
    aip_dbg("read unsupported.\n");
    return -EINVAL;
}


/************************************************************************
 *
 * Function Name:      aipsocdkl_write
 *
 * Notes:              Write Not supported
 *
 * ***********************************************************************
 */
static ssize_t aipsocdkl_write(struct file *flip, const char *buf, size_t count,
                               loff_t *f_pos)
{
    aip_dbg("write unsupported.\n");
    return -EINVAL;
}


/************************************************************************
 *
 * Function Name:      aipsocdkl_ioctl
 *
 * Purpose:            Request Device service
 *
 * Description:        Called by client to access device services
 *
 * Inputs:             Dependent on the IOCTL
 *
 * Output:             RPDONE
 *                     0 - Success, -EINVAL - Unknown IOCTL
 *                     Other Non-zero values - specific service errors
 *
 * ***********************************************************************
 */
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 36)
static int aipsocdkl_ioctl(struct inode *inode, struct file *flip,
                           unsigned int cmd, unsigned long arg)
#else
static long aipsocdkl_ioctl(struct file *flip, unsigned int cmd, unsigned long arg)
#endif
{
    int rc = -EINVAL;
    switch (_IOC_NR(cmd)) {

    case _IOC_NR(GET_KL_STATUS):
        aip_dbg("GET_KL_STATUS\n");
        rc = aipsocdkl_ioctl_GetKLStatus((char *) arg);
        break;
    case _IOC_NR(OPEN_CD):
        aip_dbg("OPEN_CD\n");
        rc = aipsocdkl_ioctl_OpenCD((char *) arg);
        break;
    case _IOC_NR(GET_CD_STATUS):
        aip_dbg("GET_CD_STATUS\n");
        rc = aipsocdkl_ioctl_GetCDStatus((char *) arg);
        break;
    case _IOC_NR(GET_SLOT_INFO):
        aip_dbg("GET_SLOT_INFO\n");
        rc = aipsocdkl_ioctl_GetSlotInfo((char *) arg);
        break;
    default:
        aip_dbg("Invalid IOCTL %u\n", cmd);
        rc = -EINVAL;
        break;
    }

    return rc;
}


/************************************************************************
 *
 * Function Name:      aipsocdkl_ioctl_GetKLStatus
 *
 * Purpose:            Get Keylock status
 *
 * Description:        The keylock can be in any of 3 positions. This fn.
 *                     reads the port at index 0x26 and examines bits
 *                     2..0.
 *
 * Inputs:             User buffer pointer
 *
 * Output:             0 - Success, -EFAULT - memory copy problem
 *
 * ***********************************************************************
 */
static int aipsocdkl_ioctl_GetKLStatus(char *pBuffer)
{
    int rc = SUCCESS;
    unsigned char status;
    GET_KL_STATUS_PARMS gksp = {0};

    aip_verbose("Get_KL_Status\n");

    /*
     * Read the KeyLock status
     */
    outb(KL_STATUS_INDEX, INDEX_PORT_ADDRESS);
    status = inb(DATA_PORT_ADDRESS);
    status = status & 0x07;

    aip_dbg("Status of KeyLock is = 0x%02x\n", status);

    gksp.CompletionCode = RPDONE;
    gksp.Slot           = 0;
    gksp.KLStatus       = status;

    if (copy_to_user(pBuffer, &gksp,
                     (unsigned long)sizeof(GET_KL_STATUS_PARMS))) {
        aip_error("Error while copying to user space!\n");
        rc = -EFAULT;
    }

    return rc;
}


/************************************************************************
 *
 * Function Name:      aipsocdkl_ioctl_OpenCD
 *
 * Purpose:            Open the Cash Drawer
 *
 * Description:        This fn. writes a 1 to bit 0 of the port at index 0x29
 *                     which triggers the ASIC to fire the Cash Drawer pulse
 *
 * Inputs:             User buffer pointer
 *
 * Output:             0 - Success, -EFAULT - memory copy problem
 *
 * ***********************************************************************
 */
static int aipsocdkl_ioctl_OpenCD(char *pBuffer)
{
    int rc = SUCCESS;
    OPEN_CD_PARMS gcdp = {0};

    aip_dbg("Open_CD\n");

    /*
     * Fire Cash Drawer
     */
    outb(CD_OPEN_INDEX, INDEX_PORT_ADDRESS);
    outb(CD_OPEN, DATA_PORT_ADDRESS);

    gcdp.CompletionCode = RPDONE;
    gcdp.Slot           = 0;
    gcdp.WhichCD        = 1;

    if (copy_to_user(pBuffer, &gcdp, (unsigned long)sizeof(OPEN_CD_PARMS))) {
        aip_warning("Error while copying to user space!\n");
        rc = -EFAULT;
    }

    return rc;
}


/************************************************************************
 *
 * Function Name:      aipsocdkl_ioctl_GetCDStatus
 *
 * Purpose:            Get Cash Drawer status
 *
 * Description:        This fn. reads the port at index 0x30 and
 *
 * Inputs:             User buffer pointer
 *
 * Output:             0 - Success, -EFAULT - memory copy problem
 *
 * ***********************************************************************
 */
static int aipsocdkl_ioctl_GetCDStatus(char *pBuffer)
{
    int rc = SUCCESS;
    unsigned char status;
    GET_CD_STATUS_PARMS gcsp = {0};

    aip_verbose("Get_CD_Status\n");

    /*
     * Get CD status and mask in bits 2..1, /Open .. /Connected,
     */
    outb(CD_STATUS_INDEX, INDEX_PORT_ADDRESS);
    status = inb(DATA_PORT_ADDRESS);
    status = status & 0x06;

    aip_dbg("Status of CD is = %x\n", status);

    gcsp.CompletionCode = RPDONE;
    gcsp.Slot           = 0;
    gcsp.CDStatus       = status;

    if (copy_to_user(pBuffer, &gcsp,
                     (unsigned long)sizeof(GET_CD_STATUS_PARMS))) {
        aip_warning("Error while copying to user space!\n");
        rc = -EFAULT;
    }

    return rc;
}


/************************************************************************
 *
 * Function Name:      aipsocdkl_ioctl_GetSlotInfo
 *
 * Purpose:            Get 'Adapter' slot info
 *
 * Description:        Called by client to read Adapter slot info
 *
 * Inputs:             User buffer pointer
 *
 * Output:             0 - Success, -EFAULT - memory copy problem
 *
 * Notes:              Hard Coded values
 *
 * ***********************************************************************
 */

static int aipsocdkl_ioctl_GetSlotInfo(char *pBuffer)
{
    int rc = SUCCESS;
    GET_SLOT_INFO_PARMS gsip = {0};

    aip_dbg("GetSlotInfo\n");

    gsip.SlotDrawers[1]   = 1;
    gsip.AdapterID[1]     = 4614;
    if (machine_type == IBM_4613) {
        gsip.AdapterID[1] = 4613;
    }
    gsip.SlotNVRAM[1]     = 0;
    gsip.CompletionCode   = RPDONE;

    if (copy_to_user(pBuffer, &gsip, sizeof(GET_SLOT_INFO_PARMS))) {
        aip_error("Error while copying to user space!\n");
        rc = -EFAULT;
    }

    return rc;
}


#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 18)

int aipsocdkl_device_create(unsigned int major_number, char *modname,
                            const struct file_operations *fops)
{
    int err;

    /* Register as a device with kernel. */
    if ((err = register_chrdev(major_number, modname, fops))) {
        aip_error("Failure to load module. error %d\n", -err);
        return err;
    }

    return 0;
}


void aipsocdkl_device_destroy(unsigned int major_number, char *modname)
{
    if (unregister_chrdev(major_number, modname) != 0) {
        aip_error("unregister_chrdev failed\n");
    }

    return;
}

#else

int aipsocdkl_device_create(char *modname, char *devname[], int dev_count,
                            char *class_name, socdkl_adapter *adapter,
                            const struct file_operations *fops)
{
    int err = 0;
    int i = 0;
    int major = 0;
    struct device *dev;

    adapter->major = 0;

    /* Request dynamic allocation of a device major number */
    aip_dbg("Allocating major device with %d minors\n", dev_count);
    if ((err = alloc_chrdev_region(&adapter->dev_number, 0, dev_count,
                                   modname)) < 0) {
        aip_error("Cannot register device, error=%d\n", -err);
        return err;
    }

    aip_dbg("dev number is %x for '%s'\n", adapter->dev_number, modname);

    /* Populate sysfs entries */
    adapter->dev_class = class_create(THIS_MODULE, class_name);

    if (IS_ERR(adapter->dev_class)) {
        aip_error("Cannot create class '%s' error %ld\n", class_name,
                  PTR_ERR(adapter->dev_class));
        adapter->dev_class = NULL;
        return -EINVAL;
    }

    adapter->dev_count = dev_count;
    adapter->major = 0;

    major = MAJOR(adapter->dev_number);

    adapter->major = major;

    for (i = 0; i < dev_count && i < MAX_CDEVS; i++) {
        aip_dbg("Initialzing cdev for %d '%s'\n", i, devname[i]);

        /* Connect the file operations with the cdev */
        cdev_init(&adapter->cdev[i], fops);

        aip_dbg("Adding cdev for '%s' major=%d/minor=%d\n", devname[i],
                major, i);

        /* Connect the major/minor number to the cdev */
        err = cdev_add(&adapter->cdev[i], MKDEV(major, i), 1);
        adapter->cdev[i].owner = THIS_MODULE;

        if (err) {
            aip_error("Bad cdev add, error %d\n", -err);

            /* Destroy dev_class */
            class_destroy(adapter->dev_class);
            adapter->dev_class = NULL;

            return err;
        }

        aip_dbg("Adding device for '%s' major=%d/minor=%d\n",
                devname[i], major, i);

        /* Send uevents to udev, so it'll create /dev node */
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 26)
        dev = device_create(adapter->dev_class, NULL, MKDEV(major, i),
                            devname[i]);
#elif LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 28)
        dev = device_create_drvdata(adapter->dev_class, NULL, MKDEV(major, i),
                                    NULL, devname[i]);
#else
        dev = device_create(adapter->dev_class, NULL, MKDEV(major, i), NULL,
                            devname[i]);
#endif
        if (!IS_ERR(dev)) {
            /* save sysfs dev pointer for creating additional attributes */
            adapter->dev = dev;
        }

        aip_dbg("Adding sysfs for '%s' major=%d/minor=%d returned err %ld\n",
                devname[i], major, i,(long) IS_ERR(dev));
    }

    return 0;
}


void aipsocdkl_device_destroy(socdkl_adapter *adapter)
{
    int i = 0;

    aip_dbg("entered major=%d, count=%d\n",
            adapter->major, adapter->dev_count);

    /* Release the major number */
    if (adapter != NULL && adapter->major > 0) {
        if (adapter->dev_class != NULL) {
            for (i = 0; i < adapter->dev_count && i < MAX_CDEVS; i++) {
                aip_dbg("Removing device major=%d/minor=%d returned\n",
                        adapter->major, i);

                /* Destroy device */
                device_destroy(adapter->dev_class, MKDEV(adapter->major, i));

                /* Remove the cdev */
                cdev_del(&adapter->cdev[i]);
            }

            aip_dbg("Unregistering chrdev major=%d, count=%d\n",
                    adapter->major, adapter->dev_count);

            unregister_chrdev_region(adapter->major, adapter->dev_count);

            adapter->dev_count = 0;

            /* Destroy dev_class */
            class_destroy(adapter->dev_class);
            adapter->dev_class = NULL;
        }
        adapter->major = 0;
    }

    aip_dbg("returning\n");

    return;
}

#endif


/************************************************************************
 *
 * Function Name:      aipsocdkl_init
 *
 * Purpose:            Intialization routine
 *
 * Description:        Entry point for this driver.
 *
 * Output:             0 - Success, Non-zero - Failure
 *
 * ***********************************************************************
 */
static int __init aipsocdkl_init(void)
{
    int err = 0;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 18)
    char *dev_names[20] = { "aipsocdkl"};
    int  dev_count = 1;
#endif

    pBiosModelNumber = (unsigned char *) ioremap(SUREONE, 4);
    CheckModel = readl(pBiosModelNumber);
    iounmap(pBiosModelNumber);

    /*
     * Don't install the driver, if it's not a SureOne or Anyplace Kiosk
     * machine.
     */
    if (machine_type == IBM_4613) {
    } else if (machine_type == IBM_4614) {
        pBiosModelNumber = (unsigned char *) ioremap(SUREONE, 4);
        CheckModel = readl(pBiosModelNumber);
        iounmap(pBiosModelNumber);

        if (CheckModel != SUREONEID) {
            aip_error("This does not seem to be a SureOne or Anyplace Kiosk machine, model 0x%08x\n", (unsigned)  CheckModel);
            aip_error("This driver is for a SureOne or Anyplace Kiosk machines only\n");
            return -EINVAL;
        }
        aip_info("Found SureOne machine, model 0x%08x\n",
                 (unsigned) CheckModel);
    }

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 18)
    /* Register as a device with kernel. */
    err = aipsocdkl_device_create(aipsocdkl_major, DEVDRVR_ID,
                                  &aipsocdkl_fops);
#else
    /* Request dynamic allocation of a device major number */
    err = aipsocdkl_device_create((char *) DEVDRVR_ID, dev_names, dev_count,
                                  "aipsocdkl", &Adapter, &aipsocdkl_fops);
#endif

    if (err != 0) {
        aip_error("Device register failed, rc=%dn", -err);
        return -EINVAL;
    }

    /*
     * Enable the Cash Drawer, controll it through the ASIC and set default
     * pulse width 100ms
     */
    outb(CD_SETUP_INDEX, INDEX_PORT_ADDRESS);
    outb(CD_ENABLE, DATA_PORT_ADDRESS);

    aip_dbg("initialised cash drawer\n");

    return SUCCESS;
}



/************************************************************************
 *
 * Function Name:      aipsocdkl_exit
 *
 * Purpose:            Teardown
 *
 * Description:        Called when module is about to unload
 *
 * ***********************************************************************
 */
static void __exit aipsocdkl_exit(void)
{
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 5, 0)
    if (MOD_IN_USE) {
        aip_warning("device busy, remove delayed\n");
        return;
    }
#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 18)
    aipsocdkl_device_destroy(aipsocdkl_major, DEVDRVR_ID);
#else
    aipsocdkl_device_destroy(&Adapter);
#endif

    aip_dbg("module removed\n");
}


module_init(aipsocdkl_init);
module_exit(aipsocdkl_exit);

MODULE_AUTHOR("Toshiba Retail Store Solutions, Inc.");
MODULE_DESCRIPTION("Driver for the SureOne Cash Drawer & KeyLock");
MODULE_LICENSE("GPL");
