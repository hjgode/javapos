/*
 *  Module Name:     aipsp700.h
 *
 *  Description:     kernel driver include
 *
 *  Copyright (C) 2014-2015 Toshiba Global Commerce Solutions, Inc.
 *  All right reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA; Otherwise,
 *  see <http://www.gnu.org/licenses/>.
 *
 *
 * Should you need to contact me, the author, you can do so either by
 * e-mail - mail your message to <gha@toshibagcs.com>.
 */


#ifndef _H_AIPTC700
#define _H_AIPTC700

/* ************************************************************************
 * A2 BARs
 * ************************************************************************
 */
#define TC700_CONFIG_BAR                     0
#define TC700_NVRAM_BAR                      1
#define TC700_SIO_BAR                        2
#define TC700_FPGA_UPGRADE_BAR               3


/* ************************************************************************
 * A2 I/O Registers mapped into PCI BAR 0
 * ************************************************************************
 */
#define TC700_ASIC_CD_PORT_0                 0x00
#define TC700_ASIC_CD_PORT_1                 0x01
#define TC700_ASIC_CD_PORT_2                 0x02
#define TC700_ASIC_DUMP_SWITCH               0x03
#define TC700_ASIC_EEPROM_CONTROL            0x04
#define TC700_ASIC_CD_CONTROL                0x05
#define TC700_ASIC_NVRAM_PAGE                0x08
#define TC700_ASIC_GPIO_PORT_0               0x09
#define TC700_ASIC_GPIO_PORT_1               0x0A
#define TC700_ASIC_INTERRUPT_STATUS_REGISTER 0x0B


/* ************************************************************************
 * Cash Drawer Control Port 0 (setup/configuration/status)
 * ************************************************************************
 */
#define TC700_CD0_DRAWER_ENABLE              0x01
#define TC700_CD0_PULSE_WIDTH_200MS          0x02
#define TC700_CD0_ENABLE_8051_INTERFACE      0x04
#define TC700_CD0_INTERRUPT_ENABLE           0x08
#define TC700_CD0_DRAWER_2_CONNECTED         0x10
#define TC700_CD0_DRAWER_2_CLOSED            0x20
#define TC700_CD0_DRAWER_1_CONNECTED         0x40
#define TC700_CD0_DRAWER_1_CLOSED            0x80

#define TC700_D0_DRAWER_INTERRUPTS_ENABLED_MASK (TC700_CD0_DRAWER_ENABLE| \
                                                 TC700_CD0_INTERRUPT_ENABLE)

#define TC700_CD0_DRAWER_STATUS_MASK (TC700_CD0_DRAWER_2_CONNECTED| \
                                      TC700_CD0_DRAWER_2_CLOSED| \
                                      TC700_CD0_DRAWER_1_CONNECTED| \
                                      TC700_CD0_DRAWER_1_CLOSED)


/* ************************************************************************
 * Cash Drawer Control Port 1 (Cash Drawer Open)
 * ************************************************************************
 */
#define TC700_CD1_OPEN_DRAWER_1              0x6D
#define TC700_CD1_OPEN_DRAWER_2              0xEA


/* ************************************************************************
 * Cash Drawer Control Port 2 (Cash Drawer Interrupt Control)
 * ************************************************************************
 */
#define TC700_CD2_DRAWER_1_INTERRUPTED       0x01
#define TC700_CD2_DRAWER_2_INTERRUPTED       0x02
#define TC700_INTERRUPT_MASK                 0x03

/* ************************************************************************
 * Cash Drawer Control Register
 * ************************************************************************
 */
#define TC700_CD3_38_VOLTS_SETTING           0x10  /* 0:24V, 1:38V */
#define TC700_CD3_38_VOLTS_STATUS            0x20  /* 0:24V, 1:38V */
#define TC700_CD3_HW_VOLTAGE_SETTING         0x40  /* 0:ASIC, 1:HW */
#define TC700_CD3_JUMPER_OVERRIDE            0x80  /* 0:No, 1:Yes  */


/* ************************************************************************
 * Dump Switch Interface
 * ************************************************************************
 */
#define TC700_DUMP_SWITCH_SET                0x01
#define TC700_DUMP_SWITCH_CLEAR_MASK         ~TC700_DUMP_SWITCH_SET


/* ************************************************************************
 * NVRAM Page Register
 * ************************************************************************
 */
#define TC700_NVRAM_PAGE_0                   0x00  /* Page 0   */
#define TC700_NVRAM_MAX_PAGE                 0xFF  /* Page 256 */


/* ************************************************************************
 * EEPROMT/FLASH ROM Control Port
 * ************************************************************************
 */
#define TC700_EEPROM_0_READ                  0x01
#define TC700_EEPROM_0_WRITE                 0x02
#define TC700_EEPROM_1_AND_2_READ            0x04
#define TC700_EEPROM_1_AND_2_WRITE           0x08
#define TC700_EEPROM_FLASH_WRITE_ARMED       0xA0
#define TC700_EEPROM_WRITE_MASK              0xEF


/* ************************************************************************
 * Interrupt Status Register
 * ************************************************************************
 */
#define TC700_SIO_INTERRUPT                  0x01
#define TC700_CD_INTERRUPT                   0x02


/* ************************************************************************
 * EEPROM Config Mapping
 * ************************************************************************
 */
#define TC700_EEPPROM_FUNC0_VENDOR_ID        0x00   /* two bytes */
#define TC700_EEPPROM_FUNC0_SUBSYSTEM_ID     0x02   /* two bytes */
#define TC700_EEPPROM_FUNC1_VENDOR_ID        0x04   /* two bytes */
#define TC700_EEPPROM_FUNC1_SUBSYSTEM_ID     0x06   /* two bytes */
#define TC700_EEPPROM_A2_CONFIG_REG_0        0x08   /* NVRAM & SIO RAM */
#define TC700_EEPPROM_A2_CONFIG_REG_1        0x09   /* Exp ROM & CD auto */
#define TC700_EEPPROM_A2_CONFIG_REG_2        0x0A   /* UART Enable/Disable */
#define TC700_EEPPROM_A2_CHECKSUM            0xff   /* 2's complement */


/* ************************************************************************
 * ASIC Configuration Register 0 (NVRAM/SIO Control)
 * ************************************************************************
 */
#define TC700_CONFIG0_SIO_ENABLED            0x02   /* 1:Enable, 0:Disable */
#define TC700_CONFIG0_SIO_BELOW_1MB          0x04
#define TC700_CONFIG0_NVRAM_SIZE_BIT_0       0x08
#define TC700_CONFIG0_NVRAM_SIZE_BIT_1       0x10
#define TC700_CONFIG0_NVRAM_SIZE_BIT_2       0x20
#define TC700_CONFIG0_NVRAM_SIZE_MASK        0x38
#define TC700_CONFIG0_NVRAM_BELOW_1MB        0x40
#define TC700_CONFIG0_NVRAM_ENABLED          0x80

#define TC700_NVRAM_SIZE_32KB                0x00
#define TC700_NVRAM_SIZE_128KB               0x01
#define TC700_NVRAM_SIZE_256K                0x02
#define TC700_NVRAM_SIZE_512K                0x03
#define TC700_NVRAM_SIZE_1MB                 0x04
#define TC700_NVRAM_SIZE_RESERVED_0          0x05
#define TC700_NVRAM_SIZE_RESERVED_1          0x06
#define TC700_NVRAM_SIZE_0KB                 0x07

/* ************************************************************************
 * Cash Drawer timer interval after S3 resume (milliseconds)
 * ************************************************************************
 */
#define TC700_CD_TIMER                       5


// ************************************************************************
// FPGA IAP Data Buffer (Offset 0x1000)
// This is a 256B data buffer used to store blocks of FPGA upgrade image data.
// ************************************************************************o
#define FPGA_DATA_BUFFER_OFFSET            0x0000
#define FPGA_DATA_BUFFER_LENGTH            0x1000
#define FPGA_STATUS_ADDR                   0x1000
#define FPGA_STATUS_LENGTH                 1
#define FPGA_COMMAND_ADDR                  0x1004
#define FPGA_COMMAND_LENGTH                1
#define FPGA_SPI_START_ADDR                0x1008
#define FPGA_SPI_START_LENGTH              4
#define FPGA_SPI_NUM_SECTORS_ADDR          0x100C
#define FPGA_SPI_NUM_SECTORS_LENGTH        4
#define FPGA_IAP_RAW_SERVICE_STATUS        0x1010
#define FPGA_IAP_RAW_SERVICE_STATUS_LENGTH 1

#define FPGA_IAP_COMMAND_RESET             0x00
#define FPGA_IAP_COMMAND_ERASE_START       0x01
#define FPGA_IAP_COMMAND_FLASH_START       0x02
#define FPGA_IAP_COMMAND_READ_START        0x03
#define FPGA_IAP_COMMAND_AUTH_START        0x04
#define FPGA_IAP_COMMAND_PROGRAM_START     0x05

#define FPGA_IAP_STATUS_RESET              0x00
#define FPGA_IAP_STATUS_ERASE_COMPLETE     0x02
#define FPGA_IAP_STATUS_FLASH_COMPLETE     0x03
#define FPGA_IAP_STATUS_READ_COMPLETE      0x04
#define FPGA_IAP_STATUS_AUTH_COMPLETE_GOOD 0x04
#define FPGA_IAP_STATUS_AUTH_COMPLETE_FAIL 0x14


#define FPGA_FLASH_ADDRESS                 0x00200000
#define FPGA_W25Q64FV_SIZE                 1024 * 1024
#define FPGA_FLASH_SECTOR_COUNT            2048
#define FPGA_FLASH_SECTOR_SIZE             4096
#define FPGA_FLASH_SECTOR_ERASE_TIME       400
#define FPGA_FLASH_ERASE_TIMEOUT           FPGA_FLASH_SECTOR_SIZE * FPGA_FLASH_SECTOR_ERASE_TIME
#define FPGA_FLASH_STATUS_POLL_DELAY       100
#define FPGA_FLASH_STATUS_POLL_TIME        100
#define FPGA_FLASH_AUTHENTICATION_TIME     30000
#define FPGA_FLASH_READ_TIME               1000
#define FPGA_FLASH_WRITE_TIME              1000

#define FPGA_COPY_FROM_FPGA_BUFFER         0
#define FPGA_COPY_TO_FPGA_BUFFER           1

#endif
