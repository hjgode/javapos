/*
 *  Module Name:     aipkernel.h
 *
 *  Description:     kernel driver include
 *
 *  Copyright (C) 2004-2015 Toshiba Global Commerce Solutions Inc.
 *  All right reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA; Otherwise,
 *  see <http://www.gnu.org/licenses/>.
 *
 *
 * Should you need to contact me, the author, you can do so either by
 * e-mail - mail your message to <gha@toshibagcs.com>.
 */


#ifndef _H_AIPKERNEL
#define _H_AIPKERNEL 1



/* typedefs */
#if defined(_WIN32)
#ifndef _STDINT
typedef unsigned int uint32_t;
#endif
#elif defined(__GNUC__)
#if!defined(__KERNEL__)
#include <stdint.h>
#endif
#endif
#include <stddef.h>
#if !defined(_H_LGCYTYPE)
typedef unsigned char  uchar_t;
typedef unsigned long  ulong_t;
typedef unsigned short ushort_t;
typedef unsigned int   uint_t;
#endif


/* :H1.#defines
 ***********************************************************************
 */

/* :H2.IOCtl functions
 * *********************************************************************
 */
#define IOCTL_MAGIC         'w'
#define IOCTL_TCHMOUSE      'x'

#if defined(_WIN32)

#define DD_POST_REGISTER        0
#define DD_POST_UNREGISTER      1
#define OPEN_DEVICE             2
#define CLOSE_DEVICE            3
#define ENABLE_ASYNC_COMM       4
#define DISABLE_ASYNC_COMM      5
#define ENABLE_ASYNC_CD_COMM    6
#define DISABLE_ASYNC_CD_COMM   7
#define REQUEST_BUFFER          8
#define WAIT_FOR_BUFFER         9
#define RETURN_BUFFER           10
#define POR_8051                11
#define GET_DCS_INFO            12
#define GET_SLOT_INFO           13
#define SET_CD_INTERFACE        14
#define OPEN_CD                 15
#define GET_CD_STATUS           16
#define GET_INTERRUPT_SLOT      17
#define GET_CD_INTERRUPT_SLOT   18
#define WAIT_FOR_EVENT          19
#define WAIT_FOR_CD_EVENT       20
#define GET_VIDEO_STRETCH_INFO  21
#define GET_MTN_STATUS          22
#define WAIT_FOR_MTN_EVENT      23
#define GET_KL_STATUS           24

#define NVRAM_READ_DATA         31
#define NVRAM_WRITE_DATA        32
#define SET_NVRAM_AREA_SIZES    33
#define SET_VALID_DATA_FLAG     34
#define RESET_VALID_DATA_FLAG   35
#define QUERY_VALID_DATA_FLAG   36
#define GET_NVRAM_INFO          37
#define QUERY_NVRAM_CARD_TYPE   38
#define GET_VITAL_PRODUCT_DATA  39
#define GET_DRIVER_VERSION      40

#define SEND_MOUSE_EVENT        44

#define FPGA_GET_STATUS         50
#define FPGA_FLASH_ERASE        51
#define FPGA_FLASH_BLOCK        52
#define FPGA_READ_BLOCK         53
#define FPGA_AUTHENTICATE_IMAGE 54
#define FPGA_PROGRAM_UPDATE     55
#define FPGA_RAS_UPDATE         56

#elif defined(__GNUC__)

#define DD_POST_REGISTER        _IOR(IOCTL_MAGIC,   0, COMPLETION_CODE_PARMS)
#define DD_POST_UNREGISTER      _IOR(IOCTL_MAGIC,   1, COMPLETION_CODE_PARMS)
#define OPEN_DEVICE             _IOR(IOCTL_MAGIC,   2, COMPLETION_CODE_PARMS)
#define CLOSE_DEVICE            _IOR(IOCTL_MAGIC,   3, COMPLETION_CODE_PARMS)
#define ENABLE_ASYNC_COMM       _IOR(IOCTL_MAGIC,   4, ENABLE_ASYNC_COMM_PARMS)
#define DISABLE_ASYNC_COMM      _IOR(IOCTL_MAGIC,   5, COMPLETION_CODE_PARMS)
#define ENABLE_ASYNC_CD_COMM    _IOR(IOCTL_MAGIC,   6, ENABLE_ASYNC_COMM_PARMS)
#define DISABLE_ASYNC_CD_COMM   _IOR(IOCTL_MAGIC,   7, COMPLETION_CODE_PARMS)
#define REQUEST_BUFFER          _IOWR(IOCTL_MAGIC,  8, REQ_BUFFER_PARMS)
#define WAIT_FOR_BUFFER         _IOWR(IOCTL_MAGIC,  9, WAIT_BUFFER_PARMS)
#define RETURN_BUFFER           _IOWR(IOCTL_MAGIC, 10, RET_BUFFER_PARMS)
#define POR_8051                _IOWR(IOCTL_MAGIC, 11, POR_8051_PARMS)
#define GET_DCS_INFO            _IOWR(IOCTL_MAGIC, 12, GET_DCS_INFO_PARMS)
#define GET_SLOT_INFO           _IOR(IOCTL_MAGIC,  13, GET_SLOT_INFO_PARMS)
#define SET_CD_INTERFACE        _IOWR(IOCTL_MAGIC, 14, SET_CD_INTERFACE_PARMS)
#define OPEN_CD                 _IOWR(IOCTL_MAGIC, 15, OPEN_CD_PARMS)
#define GET_CD_STATUS           _IOWR(IOCTL_MAGIC, 16, GET_CD_STATUS_PARMS)
#define GET_INTERRUPT_SLOT      _IOR(IOCTL_MAGIC,  17, GET_INTERRUPT_SLOT_PARMS)
#define GET_CD_INTERRUPT_SLOT   _IOR(IOCTL_MAGIC,  18, GET_INTERRUPT_SLOT_PARMS)
#define WAIT_FOR_EVENT          _IOR(IOCTL_MAGIC,  19, COMPLETION_CODE_PARMS)
#define WAIT_FOR_CD_EVENT       _IOR(IOCTL_MAGIC,  20, COMPLETION_CODE_PARMS)
#define GET_VIDEO_STRETCH_INFO  _IOR(IOCTL_MAGIC,  21, COMPLETION_CODE_PARMS)
#define GET_MTN_STATUS          _IOWR(IOCTL_MAGIC, 22, GET_MTN_STATUS_PARMS)
#define WAIT_FOR_MTN_EVENT      _IOWR(IOCTL_MAGIC, 23, WAIT_FOR_MTN_EVENT_PARMS)
#define GET_KL_STATUS           _IOWR(IOCTL_MAGIC, 24, GET_KL_STATUS_PARMS)

#define NVRAM_READ_DATA         _IOR(IOCTL_MAGIC,  31, NVRAM_READ_PARMS)
#define NVRAM_WRITE_DATA        _IOWR(IOCTL_MAGIC, 32, NVRAM_WRITE_PARMS)
#define SET_NVRAM_AREA_SIZES    _IOWR(IOCTL_MAGIC, 33, GET_NVRAM_DATA_PARMS)
#define SET_VALID_DATA_FLAG     _IOWR(IOCTL_MAGIC, 34, VALID_DATA_FLAG_PARMS)
#define RESET_VALID_DATA_FLAG   _IOWR(IOCTL_MAGIC, 35, VALID_DATA_FLAG_PARMS)
#define QUERY_VALID_DATA_FLAG   _IOR(IOCTL_MAGIC,  36, VALID_DATA_FLAG_PARMS)
#define GET_NVRAM_INFO          _IOWR(IOCTL_MAGIC, 37, GET_NVRAM_DATA_PARMS)
#define QUERY_NVRAM_CARD_TYPE   _IOR(IOCTL_MAGIC,  38, VALID_DATA_FLAG_PARMS)
#define GET_VITAL_PRODUCT_DATA  _IOWR(IOCTL_MAGIC, 39, GET_VPD_PARMS)
#define GET_DRIVER_VERSION      _IOR(IOCTL_MAGIC,  40, GET_DRIVER_VERSION_PARMS)

#define SEND_MOUSE_EVENT        _IOWR(IOCTL_TCHMOUSE, 44, MOUSE_COORD)

/* FPGA firmware Update commands */
#define FPGA_GET_STATUS         _IOWR(IOCTL_MAGIC, 50, FPGA_DATA_PARMS)
#define FPGA_FLASH_ERASE        _IOWR(IOCTL_MAGIC, 51, FPGA_DATA_PARMS)
#define FPGA_FLASH_BLOCK        _IOWR(IOCTL_MAGIC, 52, FPGA_DATA_PARMS)
#define FPGA_READ_BLOCK         _IOWR(IOCTL_MAGIC, 53, FPGA_DATA_PARMS)
#define FPGA_AUTHENTICATE_IMAGE _IOWR(IOCTL_MAGIC, 54, FPGA_DATA_PARMS)
#define FPGA_PROGRAM_UPDATE     _IOWR(IOCTL_MAGIC, 55, FPGA_DATA_PARMS)
#define FPGA_RAS_UPDATE         _IOWR(IOCTL_MAGIC, 56, FPGA_DATA_PARMS)

/* 4690 specific commands */
#define SET_INTERRUPT_MODE      _IOR(IOCTL_MAGIC,     60, NULL)
#define RETURN_BUFFER_NOINT     _IOR(IOCTL_MAGIC,     61, NULL)

#define IOCTL_DCS_MINNR     4
#define IOCTL_DCS_MAXNR     18

#define IOCTL_NVRAM_MINNR   31
#define IOCTL_NVRAM_MAXNR   40


#define IOCTL_CD_MINNR      6
#define IOCTL_CD_MAXNR      16
#endif


/* Slot types */
#define SLOT_TYPE_NONE      0
#define SLOT_TYPE_PLANAR    1
#define SLOT_TYPE_IBM_SIO   2
#define SLOT_TYPE_USB       4
#define SLOT_TYPE_ENET4     5
#define SLOT_TYPE_IBM_NVRAM 8


/* Current length of Vital Product Data (VPD) */
#define VITAL_PRODUCT_DATA_LENGTH 24


/* Number of areas in NVRAM */
#define NUM_AREAS       3


/* NVRAM access type */
#define NVRAM_MEMORY_MAP 0
#define NVRAM_IO_MAP     1
#define NVRAM_PAGED      2
#define NVRAM_WCR_PAGED  3


/* The three areas in each NVRAM */
#define DEVICE_DRVRS        0
#define SERVICES        1
#define APPLICATION     2


/* Device error return values */
#define RPERR           0x8000
#define RPDEV           0x4000
#define RPBUSY          0x2000
#define RPDONE          0x0100


/* Device Driver extended error codes */
#define UNKNOWN_COMMAND         0x0003 /* unknown strategy command    */
#define PROCESS_DEATH           0x0011 /* process death               */
#define ERROR_BAD_CONFIG_PARM   0x0013 /* bad parameter on DEVICE=    */
#define NVRAM_WRITE_ERROR       0x00f0 /* NVRAM area data corrupted   */
#define NVRAM_AREA_IN_USE       0x00f1 /* NVRAM area in-use flag set  */
#define PC_DONE_NOT_SET         0x00f1 /* PC DONE not set by adapter  */
#define PROG_POWER_FAILURE      0x00f2 /* Programmable power problem  */
#define SIZE_OUT_OF_RANGE       0x00f3 /* NVRAM offset+size is bad    */
#define OFFSET_OUT_OF_RANGE     0x00f4 /* NVRAM offset is bad         */
#define GDT_MAP_ERROR           0x00f5 /* GDT mapping error           */
#define GDT_ALLOC_ERROR         0x00f6 /* GDT allocation error        */
#define BAD_BUFFER              0x00f7 /* Problem with buffer         */
#define NO_ADAPTERS             0x00f8 /* No adapters in machine      */
#define BAD_PARAMETERS          0x00f9 /* Bad parameter block         */
#define UNKNOWN_ADAPTER         0x00fa /* Slot # has unknown adapter  */
#define INVALID_SLOT_NO         0x00fb /* Invalid Slot number         */
#define BLOCK_TIMEOUT           0x00fc /* Block timeout               */
#define IRQ_ERROR               0x00fd /* failed IRQ operation        */
#define LOST_8051               0x00fe /* 8051 not present            */
#define LDT_ERROR               0x00ff /* alloc/dealloc buffer failed */
#define FPGA_COMMAND_FAILED     0x00ef /* FPGA Command Failure        */
#define FPGA_FLASH_NOT_READY    0x00ee /* FPGA Flash not available    */
#define UNEXPECTED_READ_FAILURE 0x00ed /* Unexpect read failure       */



/* IOCtl function parameter blocks */
#ifdef __cplusplus
extern "C" {
#endif

#if !defined(MAX_SLOTS)
#define MAX_SLOTS 9
#endif


typedef struct
{
    ushort_t    AdapterID;
    short       KnownAdapter;   /* 1 - Adapter that we handle */
    ulong_t     Buffer;
    uint32_t    BaseIOAddr;     /* ISA -> 220, 260, 2A0  */
    volatile uchar_t *p2KBuffer;
    volatile uchar_t *pSSB;
    short       offsetSSB;
    ushort_t    Ports;          /* # of ports */
    ushort_t    IRQLevel;       /* IRQ Level */
    ushort_t    SlotType;       /* Type of slot (none, planar, sio) */
#if defined(_WIN32)
    ulong_t     hDCSSem;
#endif
    short       ReturnCode;     /* Return code */
    uchar_t     StatusRegA;     /* PCI Status Reg A (who interrupted) */
    uchar_t     CDStatusReg;    /* PCI CD Ctrl Port 0 (config/status) */
    uchar_t     CDIntCtrlReg;   /* PCI CD Ctrl Port 2 (which CD) */
    uint32_t    PCIBusNumber;
    uint32_t    PCIDeviceNumber;
    uint32_t    PCIFunctionNumber;
} SLOTDATA, *PSLOTDATA;

/* NVRAM Slot Data structure */
typedef struct
{
    uint32_t    Offset;
    uint32_t    Size;
    uint32_t    InUseFlag;
} AREA_DATA, *PAREA_DATA;

typedef struct
{
    ushort_t    AdapterID;
    short       KnownAdapter;   /* 1 - Adapter that we handle */
    ulong_t     Buffer;
    uint32_t     BaseIOAddr;     /* ISA -> 220, 260, 2A0 */
                                /* MC  -> offset in POS105 */
    uint32_t     NVRAMSize;      /* Size of this block of NVRAM */
    uint32_t     NVRAMBuffer;    /* Buffer location */
    uchar_t     *pNVRAM;        /* Pointer to memory mapped storage */
    uint32_t     BottomJunk;     /* Size of the RAS Junk at the bottom */
    uint32_t     JunkOffset;     /* Offset of RAS Junk in page 0 */
    uint32_t     JunkLength;     /* Length of RAS Junk in page 0 */
    uint32_t     NVRAMPageSize;  /* Size of pages in paged NVRAM */
    uint32_t     NVRAMPages;     /* Number of pages in paged NVRAM  */
    uint32_t     PageRegOffset;  /* I/O Space Offset of page reg (NVRAM_PAGED)*/
    ushort_t    NVRAMMap;       /* Memory or I/O mapped? */
    short       ReturnCode;     /* Return code */
    AREA_DATA   NVRAMArea[NUM_AREAS];   /* How NVRAM is divided... */
    ushort_t    BuiltIn;        /* 1=Planar NVRAM, 0=Adapter NVRAM */
} NVSLOTDATA, *PNVSLOTDATA;



/* 2K Buffer #defines */
#define NO_MSGS         5                   /* Number of msgs byte */
#define MSG_LOC         6    /* 0x012F */   /* Location of messages */
#define SSB          2047    /* 0x07FF */   /* System status byte */

#define REQUEST         0
#define FUNCTION        1

#define BUFF_LEN        2048                /* 2K Shared Buffer */


/* System Status Byte (SSB) Bits */
#define SSB_BUFFER_ACCESS       0x01
#define SSB_PC_DONE             0x02
#define SSB_INTERRUPTED         0x04
#define SSB_INTERRUPT_PC_ENABLE 0x08
#define SSB_SOFT_POR            0x40

typedef struct _2KBufferStruct
{
    uchar_t bRequest;              /* 8051 request byte             */
    uchar_t bFuncCmd;              /* 8051 function command         */
    uchar_t bPtoTime[2];           /* poll time out - milliseconds  */
    uchar_t bPtoCount;             /* poll time out count           */
    uchar_t bXmitMsgCnt;           /* transmit message count        */
    uchar_t bXmitMsgStart[2];      /* offset to first xmit message  */
    uchar_t bReserved[4];          /* only engineering knows why... */
    uchar_t bStatus;               /* 8051 status                   */
    uchar_t bRcvMsgOff[2];         /* receive message offset        */
    uchar_t bPollList[96];         /* max 48 entries, each 2 bytes  */
    uchar_t bPTOInfo[160];         /* for master 8051 to count PTOs */
    uchar_t bErrMsgLen[2];         /* length (1-30) of following... */
    uchar_t bErrMsg[30];           /* error entries                 */
    union {
        uchar_t bMsgArea[1743];    /* send/rcv message area         */
        struct {
            uchar_t bMsgLen[2];    /* Incoming message length       */
            uchar_t bPort;         /* Port number                   */
            uchar_t bAddr;         /* Address                       */
        } datamsg;
        struct {
            uchar_t bMsgLen[2];    /* Incoming message length       */
            uchar_t bEC;           /* 8051 EC Level                 */
        } ecmsg;
    };
    uchar_t bSequence;             /* Message sequence for NSI      */
    uchar_t bSSB;                  /* System status byte            */
} SIO2KBuffer, *pSIO2KBuffer;

typedef struct
{
    uint32_t CompletionCode;
} COMPLETION_CODE_PARMS, *PCOMPLETION_CODE_PARMS;

typedef struct
{
    uint32_t CompletionCode;
    uint32_t Slot;
} REQ_BUFFER_PARMS, *PREQ_BUFFER_PARMS;

typedef struct
{
    uint32_t     CompletionCode;
    uint32_t     Slot;
    uint32_t     Timeout;
    char        Buffer[2048];
} WAIT_BUFFER_PARMS, *PWAIT_BUFFER_PARMS;

typedef struct
{
    uint32_t     CompletionCode;
    uint32_t     Slot;
    char        Buffer[2048];
} RET_BUFFER_PARMS, *PRET_BUFFER_PARMS;

typedef struct
{
    uint32_t CompletionCode;
    uint32_t  Slot;
} POR_8051_PARMS, *PPOR_8051_PARMS;

typedef struct
{
    uint32_t CompletionCode;
    ushort_t Slot;
} GET_INTERRUPT_SLOT_PARMS, *PGET_INTERRUPT_SLOT_PARMS;

typedef struct
{
    uint32_t CompletionCode;
    uint32_t ProcessID;
} ENABLE_ASYNC_COMM_PARMS, *PENABLE_ASYNC_COMM_PARMS;

typedef struct
{
    uint32_t  CompletionCode;
    uint32_t  Slot;
    uint32_t  AdapterID;
    uint32_t  NumPorts;
} GET_DCS_INFO_PARMS, *PGET_DCS_INFO_PARMS;

#ifndef _H_KBSHARED
typedef struct
{
    uint32_t  CompletionCode;
    uint32_t  AdapterID[MAX_SLOTS];
    uint32_t  SlotType[MAX_SLOTS];
    uint32_t  rc[MAX_SLOTS];
    uint32_t  SlotDrawers[MAX_SLOTS];
    uint32_t  SlotNVRAM[MAX_SLOTS];
    uint32_t  SlotMotionSensor[MAX_SLOTS];
} GET_SLOT_INFO_PARMS, *PGET_SLOT_INFO_PARMS;
#endif

typedef struct
{
    uint32_t     CompletionCode;
    uint32_t     Slot;
    uint32_t     CDInterface;
    uint32_t     PulseWidth;
} SET_CD_INTERFACE_PARMS, *PSET_CD_INTERFACE_PARMS;

typedef struct
{
    uint32_t     CompletionCode;
    uint32_t     Slot;
    uint32_t     WhichCD;
} OPEN_CD_PARMS, *POPEN_CD_PARMS;

typedef struct
{
    uint32_t     CompletionCode;
    uint32_t     Slot;
    uint32_t     CDStatus;
} GET_CD_STATUS_PARMS, *PGET_CD_STATUS_PARMS;

typedef struct
{
    uint32_t     TotalSize;
    AREA_DATA   AreaData[NUM_AREAS];
} NVRAM_DATA, *PNVRAM_DATA;

typedef struct
{
    uint32_t CompletionCode;
    uint32_t Slot;
    uint32_t Offset;
    uint32_t Length;
    uchar_t Buffer[2048];
} NVRAM_READ_PARMS, *PNVRAM_READ_PARMS,
NVRAM_WRITE_PARMS, *PNVRAM_WRITE_PARMS;

typedef struct
{
    uint32_t    CompletionCode;
    uint32_t    Slot;
    uint32_t    AreaId;
    uint32_t    ValidDataFlag;
} VALID_DATA_FLAG_PARMS, *PVALID_DATA_FLAG_PARMS;


typedef struct
{
    uint32_t    CompletionCode;
    uint32_t    Slot;
    uint32_t    BuiltIn;
    uint32_t    NumAreas;
    NVRAM_DATA NvramInfo;
} GET_NVRAM_DATA_PARMS, *PGET_NVRAM_DATA_PARMS;

typedef struct
{
    uint32_t CompletionCode;
    uchar_t VPD[VITAL_PRODUCT_DATA_LENGTH];
} GET_VPD_PARMS, *PGET_VPD_PARMS;



typedef struct
{
    uint32_t  StretchInfo;
    uchar_t  VersionRegister;
    uchar_t  MajorVersion;
    uchar_t  VerticalCompensation;
    uchar_t  VerticalStretch;
} GET_VIDEO_STRETCH_INFO_PARMS, *PGET_VIDEO_STRETCH_INFO_PARMS;

typedef struct
{
    uint32_t  CompletionCode;
    ushort_t wFlags;
    ushort_t wX;
    ushort_t wY;
    ushort_t wButtons;
} MOUSE_COORD, *PMOUSE_COORD;

typedef struct
{
    uchar_t  Major;
    uchar_t  Minor;
    uchar_t  Data[1024];
    ushort_t nbytes;
} TRACE_PARMS, *PTRACE_PARMS;

typedef struct
{
    uint32_t CompletionCode;
    uint32_t SlotNumber;
    uint32_t mtnStatus;
} GET_MTN_STATUS_PARMS, *PGET_MTN_STATUS_PARMS;

typedef struct
{
    uint32_t CompletionCode;
    uint32_t Slot;
    uint32_t KLStatus;
} GET_KL_STATUS_PARMS, *PGET_KL_STATUS_PARMS;

typedef struct
{
    uint32_t CompletionCode;
    uint32_t Version;
    uint32_t Reserved_1;
    uint32_t Reserved_2;
} GET_DRIVER_VERSION_PARMS, *PGET_DRIVER_VERSION_PARMS;

typedef struct
{
    uint32_t CompletionCode;
    uint32_t Version;
    uint32_t RevisionID;
    uint32_t FpgaStatus;
    uint32_t StartAddress;
    uint32_t NumberOfSectors;
    uint32_t Timeout;
    uint32_t RawCommand;
    uint32_t RawResponse;
#define FPGA_RAW_ACTION_NONE  0x0000
#define FPGA_RAW_ACTION_WRITE 0x0001
#define FPGA_RAW_ACTION_READ  0x0010
#define FPGA_RAW_ACTION_WAIT  0x0100
    uint32_t RawAction;

#define MAX_FPGA_BUFFER_SIZE 4096
    uint32_t Length;
    char     Buffer[MAX_FPGA_BUFFER_SIZE];
} FPGA_DATA, *PFPGA_DATA,
FPGA_DATA_PARMS, *PFPGA_DATA_PARMS;

// *****************************************************************
// Structure definitions for SMBIOS/DMI table access
// *****************************************************************
struct SMBIOS_entry_table_s
{
    char  SMBIOSanchor[4];
    char  SMBIOSchecksum;
    char  SMBIOSentryPointLength;
    char  SMBIOSMajorVersion;
    char  SMBIOSMinorVersion;
    short SMBIOSmaxStructureSize;
    char  SMBIOSentryPointRevision;
    char  SMBIOSformattedArea[5];
    char  DMIAnchor[5];
    char  DMIChecksum;
    short DMIstructureTableLength;
    long  DMIstructureTableAddress;
    short DMInumberOfStructures;
    short SMBIOSBCDrevision;
};

struct DMIheader_s
{
    unsigned char type;
    unsigned char length;
    unsigned short handle;
};

struct DMI_Type0_Bios_Information_s
{
    struct DMIheader_s header;
    char  BIOSVendor;
    char  BIOSVersion;
    short BIOSSegment;
    char  BIOSReleaseDate;
    char  BIOSROMSize;
    long  BIOSCharacteristics;
};

struct DMI_Type1_System_Information_s
{
    struct DMIheader_s header;
    char Manufacturer;
    char ProductName;
    char Version;
    char SerialNumber;
};

struct DMI_Type2_Base_Board_s
{
    struct DMIheader_s header;
    char Manufacturer;
    char Product;
    char Version;
    char SerialNumber;
};


#ifdef __cplusplus
}
#endif /* __cplusplus */
#endif /* _H_AIPKERNEL */
