/*  LICENSE
 *  Module Name:     aipsokbps.h
 *
 * Description:     PS/2 keyboard/msr filter driver includes on SureOne 4614.
 *
 *  Copyright (C) 2005-2015 Toshiba Global Commerce Solutions, Inc.
 *  All right reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA; Otherwise,
 *  see <http://www.gnu.org/licenses/>.
 *
 *
 * Should you need to contact me, the author, you can do so either by
 * e-mail - mail your message to <gha@toshibagcs.com>.
 */

#ifndef AIPSOKBPS_H
#define AIPSOKBPS_H


#define FALSE 0
#define TRUE  1


/*
 * Bit Definitions for "fStatus" global state flag
 */
#define COLLECTING_EC_LEVEL               0x0001
#define COLLECTING_MSR_DATA               0x2000
#define CHECKING_NEXT_SCANCODE            0x2001 /* Checking Potential
                                                  * StartSentinel
                                                  */
#define POST_FIX_DETECTED                 0x2002 /* POST_FIX_DETECTED */
#define SET_MSR_PREFIX                    0x2003 /* SET MSR PREFIX */
#define SET_MSR_SUFFIX                    0x2004 /* SET MSR SUFFIX */
#define STATE_RESERVED_0                  0x0004
#define STATE_RESERVED_1                  0x0008
#define CHECKING_FOR_MSR_SS_27_ACK        0x0010 /* Checking Ack after receiving
                                                  * 0x27 & sending 0xE5
                                                  */
#define CHECKING_FOR_MSR_SS_06_ACK        0x0020 /* Checking Ack after receiving
                                                  * 0x06 & sending 0xE5
                                                  */
#define CHECKING_SOURCE_KEYBOARD_27       0x0040 /* Checking keyboard source
                                                  * immediately after Ack to
                                                  * 0xE5 with potential SS=0x27
                                                   */
#define CHECKING_SOURCE_KEYBOARD_06       0x0080 /* Checking keyboard source
                                                  * immediately after Ack to
                                                  * 0xE5 with potential SS=0x06
                                                   */
#define CHECKING_FOR_MSR_TRACK_STATUS_ACK 0x0100 /* Checking Ack to 0xE4 sent */
#define CHECKING_MSR_TRACK_STATUS         0x0200 /* Checking number tracks read
                                                  * by MSR
                                                  */

/* PREFIX VALUES */
#define RALT    0x38
#define KEYPAD1 0x4f
#define KEYPAD2 0x50
#define KEYPAD7 0x47
#define KEYPAD6 0x4d


/* A break code has msb set */
#define BREAK        ((unsigned char)0x80)
#define BREAK_SCANCODE(x) ( (x) + (BREAK) )


/* SETTING PREFIX/SUFFIX */
#define COMMAND1                    0xe7
#define COMMAND2                    0xc6
#define SETPREFIX                   0x08
#define SETSUFFIX                   0x09
#define ENABLE_PREF_AND_SUFFIX      0x0A
#define PREFIX_VAL                  127
#define SUFFIX_VAL                  126
#define ENABLE_PREF_AND_SUFFIX_VAL  11


/* To discover the Machine Model number from Bios. Note this Not from SMBios
 */
#define IOMAP_BASE      0x000FE000   /* Base Address in BIOS */
#define IOMAP_SIZE      0x00001000   /* Page size */
#define MODEL_OFFSET    0x00000040   /* Offset of the 4 byte model number in
                                      * BIOS page
                                      */
#define MODEL_LENGTH    4
#define MODEL_4614      0x34313634
#define IS_SUREONE(x)   ((x == MODEL_4614) ? 1 : 0)



/*
 * Safety Timeouts for runaway MSR or missing second track
 */

/* SS->End Track safety timeout, 3.5 seconds in jiffies */
#define END_TRACK_TIMEOUT ((3 * HZ) + (HZ / 2))

/* Inter Track timeout, 0.1 second in jiffies */
#define INTER_TRACK_TIMEOUT (HZ / 10)

/* Safety timeout 35ms in jiffies */
#define END_TIMEOUT_BET_SCANCODES (HZ*250/1000)



/* Lengths of the individual MSR tracks
 * This is duplicated in POSKBD.H also.
 */
#define MAX_TRACK_1               98
#define MAX_TRACK_2               46
#define MAX_TRACK_3              139


/* Scancode Definitions */
#define SCANCODE_ESC            0x01
#define SCANCODE_ESC_UP         0X81
#define SCANCODE_TAB            0x0F
#define SCANCODE_TAB_UP         0x8F
#define SCANCODE_CAPS_LOCK      0x3A
#define SCANCODE_NUM_LOCK       0x45
#define SCANCODE_SCROLL_LOCK    0x46
#define SCANCODE_HOME           0x4F
#define SCANCODE_HOME_UP        0xCF
#define SCANCODE_DELETE         0x53
#define SCANCODE_DELETE_UP      0XD3
#define SCANCODE_SCANSET2_EXT   0xE2
#define SCANCODE_ROL            0xF7
#define SCANCODE_ACK            0xFA
#define SCANCODE_RESEND         0xFE
#define SCANCODE_CAPS_LOCK_UP   0xBA
#define SCANCODE_NUM_LOCK_UP    0xC5
#define SCANCODE_SCROLL_LOCK_UP 0xC6
#define SCANCODE_ONE            0x02
#define SCANCODE_LEFT_SHIFT     0x2A


/* MSR Specific Scancodes */
/* SureOne Start Sentinel Type #1 - Tracks 2 and 3 */
#define SUREONE_SCANCODE_BEG_MSR_DATA_27    0x27

/* SureOne Start Sentinel Type #2 - Track 1 only */
#define SUREONE_SCANCODE_BEG_MSR_DATA_06    0x06

/* SureOne End Sentinel */
#define SUREONE_SCANCODE_END_MSR_DATA       0x35


/* Scan set 1 - Translation by SureOne Kbd controller cannot be disabled */
#define KEYBOARD_SCAN_CODE_SET              0x01


/* Scancode stream Buffer */
#define STREAM_BUFFER_LENGTH          7
#define STREAM_BUFFER_LAST_INDEX      STREAM_BUFFER_LENGTH -1


/* Define Data Struct to store MSR Data */
typedef struct _MSR_DATA {
    unsigned short Flag;
    unsigned short Index;
    uint32_t       MSRDataLength;
    unsigned char  MSRDataBuffer[MAX_TRACK_1 + MAX_TRACK_2 + MAX_TRACK_3 + 1];
} MSR_DATA, *PMSR_DATA;


typedef enum _IBM_MSR_SETPREFIX {
    FirstMsrPrefixCommand = 1,/* Sending first command  to set prefix/suffix */
    SecondMsrPrefixCommand,   /* Sending second command to set prefix/suffix */
    LastMsrPrefixCommand,     /* Sending third  command to set prefix/suffix */
    SetPrefixAndSuffix
} SET_MSR_COMMAND;

/* Define the SureOne MSR Collection states. */
typedef enum _SUREONE_MSR_COLLECTION_STATE {

    Inactive = 0,   /* No one asked for MSR Data, yet. This is the initial
                     * state on driver load.
                     */

    Waiting,        /* User requested MSR data - Waiting for the start of MSR
                     * event sequence
                     */

    got_SS_1,       /* Got a start sentinel for first track */
    got_ES_1,       /* Got an end sentinel for first track */

    FirstTrackComplete, /* Received a 0x1c after the first track - track fully
                         * received
                         */

    got_SS_2,       /* Got a start sentinel for second track */
    got_ES_2,       /* Got an end sentinel for second track */

    Holding,        /* Received a 0x1c after the second track - track fully
                     * received
                     */
    /* Got a complete buffer of MSR Data
     * The buffer is locked ready for user collection
     */
    WAITING_FOR_SS     /* Waiting for Scancode */

} SUREONE_MSR_COLLECTION_STATE;



/* MSR Status for SureOne */
typedef struct _SUREONE_MSR_STATUS {

    /* Stage of MSR collection reached */
    SUREONE_MSR_COLLECTION_STATE    CollectionState;

    /* Safety Timer for SS found but non-arriving End of Track indicator
     * ES, 0xaa, 0x1c
     */
    struct timer_list               EndTrackTimer;

    /* Safety Timer between end of first track indicator 0x1c and SS for
     * second track
     */
    struct timer_list               InterTrackTimer;
} SUREONE_MSR_STATUS, *PSUREONE_MSR_STATUS;



/* Define the Device Extension. */
typedef struct _KEYBOARD_DATA {

    /* Global State Flag */
    uint32_t            fStatus;

    /* Keyboard Controller EC Level */
    unsigned char       EC_Level;

    /* MSR set prefix and suffix status */
    unsigned char       mStatus;

    /* MSR Status */
    SUREONE_MSR_STATUS  SureOneMsrStatus;

    /* MSR Data */
    MSR_DATA            MSRData;

    /* Scancode Stream Buffer */
    unsigned char       StreamBuffer[STREAM_BUFFER_LENGTH];

} KEYBOARD_DATA, *PKEYBOARD_DATA;



/* Temporary Buffer for Ascii converted MSR bytes */
#define MAX_ASCII_BUFFER_SIZE   (MAX_TRACK_1 + MAX_TRACK_2 + MAX_TRACK_3 + 1)

typedef struct _SUREONE_ASCII_BUFFER {
    uint32_t       DataLength;
    unsigned short Index;
    unsigned char  DataBuffer[MAX_ASCII_BUFFER_SIZE];
    unsigned char  Flag;
} SUREONE_ASCII_BUFFER, * PSUREONE_ASCII_BUFFER;



/*
 * Tables
 */


/* The table below is used to convert scancode values that are inside the
 * MSR data frames.  Most of the values do not get altered, but a couple do.
 * Shift break 0xAA is special in that it is always preserved for later ascii
 * conversion.
 */

/*         0     1     2     3     4     5     6     7     8     9     A     B     C     D     E     F */

static  unsigned char convert[256] = {
    0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F,  /* 0_ */
    0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F,  /* 1_ */
    0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x29, 0x2A, 0x2B, 0x2C, 0x2D, 0x2E, 0x2F,  /* 2_ */
    0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3A, 0x3B, 0x3C, 0x3D, 0x3E, 0x3F,  /* 3_ */
    0x40, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49, 0x4A, 0x4B, 0x4C, 0x4D, 0x4E, 0x4F,  /* 4_ */
    0x50, 0x51, 0x52, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58, 0x59, 0x5A, 0x5B, 0x5C, 0x5D, 0x5E, 0x5F,  /* 5_ */
    0x60, 0x61, 0x62, 0x63, 0x64, 0x65, 0x66, 0x67, 0x68, 0x69, 0x6A, 0x6B, 0x6C, 0x6D, 0x6E, 0x6F,  /* 6_ */
    0x70, 0x71, 0x72, 0x73, 0x74, 0x75, 0x76, 0x77, 0x78, 0x79, 0x7A, 0x7B, 0x7C, 0x7D, 0x7E, 0x7F,  /* 7_ */
    0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F,  /* 8_ */
    0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F,  /* 9_ */
    0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x29, 0xAA, 0x2B, 0x2C, 0x2D, 0x2E, 0x2F,  /* A_ */
    0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3A, 0x3B, 0x3C, 0x3D, 0x3E, 0x3F,  /* B_ */
    0x40, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49, 0x4A, 0x4B, 0x4C, 0x4D, 0x4E, 0x4F,  /* C_ */
    0x50, 0x51, 0x52, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58, 0x59, 0x5A, 0x5B, 0x5C, 0x5D, 0x5E, 0x5F,  /* D_ */
    0x60, 0x61, 0x62, 0x63, 0x64, 0x65, 0x66, 0x67, 0x68, 0x69, 0x2A, 0x6B, 0x6C, 0x6D, 0x6E, 0x6F,  /* E_ */
    0x70, 0x71, 0x72, 0x03, 0x04, 0x75, 0x76, 0x77, 0x78, 0x79, 0x7A, 0x2B, 0x7C, 0x7D, 0x7E, 0x7F   /* F_ */
};



/* Scancode->ASCII conversion map. */
static unsigned char kbd_map[256] =
{
    0x00,'\x1b','1',  '2',  '3',  '4',  '5',  '6',  /* 00 - 07 */
    '7',  '8',  '9',  '0',  '-',  '=','\x08','\t',  /* 08 - 0F */
    'q',  'w',  'e',  'r',  't',  'y',  'u',  'i',  /* 10 - 17 */
    'o',  'p',  '[',  ']', '\r',  0x00, 'a',  's',  /* 18 - 1F */
    'd',  'f',  'g',  'h',  'j',  'k',  'l',  ';',  /* 20 - 27 */
    '\'',  '`', 0x00, '\\',  'z',  'x',  'c',  'v', /* 28 - 2F */
    'b',  'n',  'm',  ',',  '.',  '/',  0x00, 0x00, /* 30 - 37 */
    0x00,  ' ', 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* 38 - 3F */
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,  '9', /* 40 - 47 */
    '8',  '9', 0x00,  '4',  '5',  '6',  0x00,  '1', /* 48 - 4F */
    '2',  '3',  '0',  '.',  0x00, 0x00, 0x00, 0x00, /* 50 - 57 */
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* 58 - 5F */
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* 60 - 67 */
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* 68 - 6F */
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* 70 - 77 */
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* 78 - 7F */
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* 80 - 87 */
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* 88 - 8F */
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* 90 - 97 */
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* 98 - 9F */
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* A0 - A7 */
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* A8 - AF */
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* B0 - B7 */
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* B8 - BF */
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* C0 - C7 */
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* C8 - CF */
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* D0 - D7 */
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* D8 - DF */
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* E0 - E7 */
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* E8 - EF */
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* F0 - F7 */
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00  /* F8 - FF */
};



/* Scancode->ASCII conversion map - Same as above but used when SHIFT is
 * active.
 */
static unsigned char shift_kbd_map[256] =
{
    0x00,'\x1b','!',  '@',  '#',  '$',  '%',  '^',  /* 00 - 07 */
    '&',  '*',  '(',  ')',  '_',  '+','\x08','\t', /* 08 - 0F */
    'Q',  'W',  'E',  'R',  'T',  'Y',  'U',  'I', /* 10 - 17 */
    'O',  'P',  '{',  '}', '\r',  0x00, 'A',  'S', /* 18 - 1F */
    'D',  'F',  'G',  'H',  'J',  'K',  'L',  ':', /* 20 - 27 */
    '"',  '~', 0x00,  '|',  'Z',  'X',  'C',  'V', /* 28 - 2F */
    'B',  'N',  'M',  '<',  '>',  '?', 0x00, 0x00, /* 30 - 37 */
    0x00,  ' ', 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* 38 - 3F */
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,  '9', /* 40 - 47 */
    '8',  '9',  0x00,  '4',  '5',  '6', 0x00,  '1', /* 48 - 4F */
    '2',  '3',  '0',  '.',  0x00, 0x00, 0x00, 0x00, /* 50 - 57 */
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* 58 - 5F */
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* 60 - 67 */
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* 68 - 6F */
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* 70 - 77 */
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* 78 - 7F */
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* 80 - 87 */
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* 88 - 8F */
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* 90 - 97 */
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* 98 - 9F */
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* A0 - A7 */
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* A8 - AF */
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* B0 - B7 */
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* B8 - BF */
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* C0 - C7 */
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* C8 - CF */
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* D0 - D7 */
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* D8 - DF */
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* E0 - E7 */
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* E8 - EF */
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* F0 - F7 */
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00  /* F8 - FF */
};



/************************************
 * API Definitions and Structures
 ************************************
 */


/* API ERROR CODES */
#define RPDONE           0x0100
#define RPERR            0x8000
#define RPDEV            0x4000


/* Keyboard IOCTL signature */
#define IBM_KBD_SIG 'k'



/* IOCTL CODES
 *
 * These should match those in src/include/kbshared.h
 * The ones actually implemented are marked with a `*'
 * The rest in this list do nothing but do return success
 * Any not here are not supported and return error if called
 */
#define FN_POS_LEDS           _IOWR(IBM_KBD_SIG, 1, POSLEDS)
#define FN_GET_SHIFT_STATE    _IOWR(IBM_KBD_SIG, 2, SHIFT_STATE)
#define FN_SET_SHIFT_STATE    _IOWR(IBM_KBD_SIG, 3, SHIFT_STATE)
#define FN_READ_KBD_STATUS    _IOWR(IBM_KBD_SIG, 4, READ_KBD_STATUS_PARMS)
#define FN_TONE               _IOWR(IBM_KBD_SIG, 5, TONE)
#define FN_CLICK              _IOWR(IBM_KBD_SIG, 6, CLICK)
#define FN_TYPEMATIC          _IOWR(IBM_KBD_SIG, 7, TYPEMATIC)
#define FN_ENABLE_DISABLE     _IOWR(IBM_KBD_SIG, 8, ENABLE_DISABLE)
#define FN_TRACKS             _IOWR(IBM_KBD_SIG, 9, TRACKS)
#define FN_READ_MSR_DATA      _IOWR(IBM_KBD_SIG, 10, READ_MSR_DATA_PARMS)
#define FN_TRAP_KEYS          _IOWR(IBM_KBD_SIG, 11, TRAP_KEYS)
#define FN_QUERY_KEYBOARD     _IOWR(IBM_KBD_SIG, 12, QUERY_KEYBOARD_PARMS)
#define FN_SET_DOUBLEKEYS     _IOWR(IBM_KBD_SIG, 13, DOUBLE_KEYS)
#define FN_CODE_UPDATE        _IOWR(IBM_KBD_SIG, 14, CODE_UPDATE_DATA)
#define FN_QUERY_CODE_UPDATE  _IOWR(IBM_KBD_SIG, 15, CODE_UPDATE_STR)

/* 16, 17 are Anpos async mode switches
 * 18, 19, 20, 21 are Canpos specific
 *
 * These two are new for Linux SureOne
 */
#define FN_GET_SLOT_INFO      _IOWR(IBM_KBD_SIG, 22, GET_SLOT_INFO_PARMS)
#define FN_CANCEL_MSR_READ    _IOWR(IBM_KBD_SIG, 23, READ_MSR_DATA_PARMS)

/* Only known to the unit test utility */
#ifdef DEVELOPMENT
  #define FN_DEVELOPMENT_READ_RAW_MSR_DATA \
                               _IOWR(IBM_KBD_SIG, 100, READ_MSR_DATA_PARMS)
#endif


/* Get Slot Info Ioctl - Maximum slots reported */
#define MAX_SLOTS   9

/* User supplied buffer max */
#define MAX_BUFFER 1000

typedef struct {
    uint32_t       CompletionCode;
    unsigned short length;
    unsigned short fTrapKeys;
} TRAP_KEYS, *PTRAP_KEYS;


typedef struct {
    uint32_t      CompletionCode;
    uint32_t      length;
    char          buffer[MAX_BUFFER];
} READ_KBD_STATUS_PARMS, *PREAD_KBD_STATUS_PARMS;


typedef struct {
    uint32_t      CompletionCode;
    uint32_t      length;
    char          buffer[MAX_BUFFER];
} READ_MSR_STATUS_PARMS, *PREAD_MSR_STATUS_PARMS;


typedef struct {
    uint32_t      CompletionCode;
    uint32_t      length;
    char          buffer[MAX_BUFFER];
} READ_MSR_DATA_PARMS, *PREAD_MSR_DATA_PARMS;


typedef struct {
    uint32_t       CompletionCode;
    unsigned short keyboardID;
    unsigned short keyboardSubtype;
    unsigned short msrType;
    unsigned char  keyboardEC;
    unsigned char  msrEC;
    unsigned char  features;
    unsigned char  featureByte1;
    unsigned char  firmwareVersion;
    unsigned char  firmwareRelease;
} QUERY_KEYBOARD_PARMS, *PQUERY_KEYBOARD_PARMS;


typedef struct {
    uint32_t      CompletionCode;
    unsigned char deviceType;
    unsigned char deviceID;
    unsigned char features;
    unsigned char commandSet;
    unsigned char ecLevel;
} DEVICE_INFO, *PDEVICE_INFO;


typedef struct {
    uint32_t       CompletionCode;
    unsigned short length;
    unsigned char  tone1;
    unsigned char  tone2;
} TONE, *PTONE;


typedef struct {
    uint32_t       CompletionCode;
    unsigned short length;
    unsigned char  posLEDs;
} POSLEDS, *PPOSLEDS;


typedef struct {
    uint32_t       CompletionCode;
    unsigned short length;
    unsigned short fEnable;
} ENABLE_DISABLE, *PENABLE_DISABLE;


typedef struct {
    uint32_t       CompletionCode;
    unsigned short length;
    unsigned short fTypematic;
} TYPEMATIC, *PTYPEMATIC;


typedef struct {
    uint32_t       CompletionCode;
    unsigned short length;
    unsigned char  fClick;
} CLICK, *PCLICK;


typedef struct {
    uint32_t       CompletionCode;
    unsigned short length;
    unsigned short track1enabled;
    unsigned short track2enabled;
    unsigned short track3enabled;
    unsigned short trackJenabled;
    unsigned short extdatareportenabled;
} TRACKS, *PTRACKS;


typedef struct {
    uint32_t       CompletionCode;
    unsigned short length;
    char           buffer[MAX_BUFFER];
} DOUBLE_KEYS, *PDOUBLE_KEYS;


typedef struct {
    uint32_t       CompletionCode;
    unsigned short state;
    unsigned char  NLS;
} SHIFT_STATE, *PSHIFT_STATE;


typedef struct {
    uint32_t       CompletionCode;
    unsigned short length;
    unsigned char  fStatus;
} CODE_UPDATE_STR, *PCODE_UPDATE_STR;


typedef struct {
    uint32_t       CompletionCode;
    unsigned short length;
    unsigned char  Data[10240];
} CODE_UPDATE_DATA, *PCODE_UPDATE_DATA;


typedef struct {
    uint32_t      CompletionCode;
} ANPOS_COMPLETION_CODE_PARMS, *PANPOS_COMPLETION_CODE_PARMS;


typedef struct {
    uint32_t      CompletionCode;
    uint32_t      ProcessID;
} ENABLE_ANPOS_ASYNC_COMM_PARMS, *PENABLE_ANPOS_ASYNC_COMM_PARMS;


typedef struct {
    uint32_t      CompletionCode;
    uint32_t      AdapterID[MAX_SLOTS];
    uint32_t      SlotType[MAX_SLOTS];
    uint32_t      rc[MAX_SLOTS];
    uint32_t      SlotDrawers[MAX_SLOTS];   /* 0, 1 or 2 */
    uint32_t      SlotNVRAM[MAX_SLOTS];     /* 0 or size of */
    uint32_t      SlotMotionSensor[MAX_SLOTS];
} GET_SLOT_INFO_PARMS, *PGET_SLOT_INFO_PARMS;



/* For returning completion parameters to Supported but not implemented IOCTL`s,
 * with 2 byte length field E.g: FN_POS_LEDS
 * Used by copy_to_user()
 */
typedef struct _completion_6_t {
    uint32_t       CompletionCode;
    unsigned short length;
} COMPLETION_PARMS_6, *PCOMPLETION_PARMS_6;


/*
 * For returning completion parameters to Supported but not implemented IOCTL`s,
 * with 4 byte length field E.g: FN_READ_KBD_STATUS
 * Used by copy_to_user()
 */
typedef struct _completion_8_t {
    uint32_t      CompletionCode;
    uint32_t      length;
} COMPLETION_PARMS_8, *PCOMPLETION_PARMS_8;

#endif /* AIPSOKBPS_H */

