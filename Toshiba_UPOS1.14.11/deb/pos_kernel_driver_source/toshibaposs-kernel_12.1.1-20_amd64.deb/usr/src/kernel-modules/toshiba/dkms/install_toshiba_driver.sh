#!/bin/bash
version=12.1.1.20

echo Copying source files
cp -pf ../dcs/aipbcd.c       ./source
cp -pf ../dcs/aipdcs.c       ./source
cp -pf ../dcs/aipdcs3.c      ./source
cp -pf ../dcs/aipkernel.h    ./source
cp -pf ../dcs/aipmtn.c       ./source
cp -pf ../dcs/aipsp700.h     ./source
cp -pf ../dcs/aiptc700.h     ./source
cp -pf ../dcs/aipdebug.h     ./source

cp -pf ../kbd/aipikbps.c     ./source
cp -pf ../kbd/aipikbps.h     ./source
cp -pf ../kbd/aipikpssc.h    ./source

echo Adding toshiba-poss-kernel to DKMS
sudo dkms add ./source

echo Building toshiba-poss-kernel version ${version}
sudo dkms build -m toshiba-poss-kernel -v ${version}

echo Making source-only tar file of toshiba-poss-kernel version ${version}
sudo dkms mktarball -m toshiba-poss-kernel -v ${version}

echo Making combined tar file of toshiba-poss-kernel version ${version}
sudo dkms mktarball -m toshiba-poss-kernel -v ${version}

echo Copying toshiba-poss-kernel tar files
cp /var/lib/dkms/toshiba-poss-kernel/${version}/tarball/* .

echo Installing toshiba-poss-kernel version ${version}
sudo dkms install toshiba-poss-kernel/${version}

