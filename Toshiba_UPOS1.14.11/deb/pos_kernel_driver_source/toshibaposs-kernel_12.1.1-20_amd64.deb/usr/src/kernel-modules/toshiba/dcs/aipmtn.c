/*
 * Module Name:     aipmtn.c
 *
 * Description:     Motion Sensor Driver for Linux
 *
 *  Copyright (C) 2004-2018 Toshiba Global Commerce Solutions, Inc.
 *  All right reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA; Otherwise,
 *  see <http://www.gnu.org/licenses/>.
 *
 *
 * Should you need to contact me, the author, you can do so either by
 * e-mail - mail your message to <gha@toshibagcs.com>.
 */

/* System Headers */
#include <linux/version.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/compiler.h>
#include <linux/pci.h>
#include <linux/init.h>
#include <linux/ioport.h>
#include <linux/delay.h>
#if LINUX_VERSION_CODE > KERNEL_VERSION(2, 5, 0)
#include <linux/moduleparam.h>
#endif
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 18)
#include <linux/cdev.h>
#endif
#include <linux/timer.h>
#include <linux/interrupt.h>
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 11, 0)
#include <linux/uaccess.h>
#else
#include <asm/uaccess.h>
#include <linux/fs.h>
#endif


#include "aipkernel.h"
#include "aipdebug.h"


static int machine_type = 0;
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 0)
MODULE_PARM(machine_type, "i");
#else
module_param(machine_type,int,0);
MODULE_PARM_DESC(machine_type,"Integer value");
#endif


/* Function Prototypes */
static int __init aipmtn_init(void);
static void __exit aipmtn_exit (void);
static int aipmtn_open(struct inode *inode, struct file *file);
static ssize_t aipmtn_read(struct file *file, char *buf, size_t count,
                           loff_t *ppos);
static ssize_t aipmtn_write(struct file *file, const char *buf, size_t count,
                            loff_t *ppos);
static int aipmtn_release(struct inode *inode, struct file *file);
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 36)
static int aipmtn_ioctl(struct inode *inode, struct file *file,
                        unsigned int cmd, unsigned long arg);
#else
static long aipmtn_ioctl(struct file *file, unsigned int cmd, unsigned long arg);
#endif

static int aipmtn_get_slot_info(char *pBuffer);
static int aipget_motion_status(char *pBuffer);


/* Static Global Variables */
static const char DEVDRVR_ID[] = "aipmtn";
#define DEFAULT_MAJOR_DEV 249

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 18)
int aipmtn_major = DEFAULT_MAJOR_DEV;

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 0)
MODULE_PARM(aipmtn_major, "i");
#else
module_param_named(major, aipmtn_major, int, 0644);
#endif
#endif


struct pci_dev *pcimtn = NULL;


#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 4, 23)
typedef void irqreturn_t;
#define IRQ_RETVAL(arg)
#endif

/* Information for IBM PCI ASIC chip (Vendor ID = 0x1014, Device ID = 0x02A2) */
#define RW_VENDOR_ID    0x1014
#define RW_DEVICE_ID    0x02A2
#define RW_SUBSYSTEM_ID 0x02A3
#define RW_SUBVENDOR_ID 0x1014

/* This value is taken from the EEPROM General storage. It is stored at
 * address 0x38
 */
#define OFFSET_TO_MACHINE_MODEL 0x38
#define RW_MODEL        0x30343834
#define KIOSK_MODEL         0x35333834


/* This value is taken from the EEPROM General storage. It is stored at
 * address 0x3C. The correct reading should be 563.  This value is in ASCII
 * mode and should be 353633.  Since its in endian format it is read backward.
 */
#define OFFSET_TO_MACHINE_TYPE  0x3C
#define RW_MTN_SENSOR_MACHINE   0x333635
#define RW_MTN_SENSOR_PRELOAD   0x333657
#define RW_MTN_SENSOR_4840_5A3  0x334135
#define RW_MTN_SENSOR_4840_WA3  0x334157
#define RW_MTN_SENSOR_4840_E63  0x333645
#define RW_MTN_SENSOR_4840_573  0x333735
#define RW_MTN_SENSOR_4840_W73  0x333757
#define RW_MTN_SENSOR_4840_564  0x343635

#define RW_MTN_SENSOR_KIOSK     0x333531
#define RW_MTN_SENSOR_4835_15W  0x573531
#define RW_MTN_SENSOR_4835_E53  0x333545

#define CONTROL_REG     0x0
#define INTERRUPT_STATUS_REG    0x01
#define PCI_BOARD_SIZE      0x10    /* 16 bytes */


#define FALSE 0
#define TRUE  1

static unsigned long function0port = 0;
static unsigned long mtn_state = 0;
static unsigned short irq_dev_id = 0;


#define INTEL_LPC_VENDOR_ID  0x8086     /*Intel */
#define INTEL_LPC_DEVICE_ID  0x24C0     /* LPC-Interface */
#define PORT_ADDRESS_OFFSET_BYTE 64         /* 40h in configuration space */
#define PORT_OFFSET      0xFFFFFF2B     /* Offset Address */

#define IBM_ANYPLACE_KIOSK   5          /*This is provided in aipscript*/
#define IBM_ANYPLACE_KIOSK_M 6          /*To support ANYPLACE_KIOSK refresh version*/
#define VIA_PM_VENDOR_ID     0x1106     /*VT8237S South Bridge. Power Management Interface*/
#define VIA_PM_DEVICE_ID     0x3372     /*VIA Presence Sensor Device ID*/
#define VIA_ACPI_PORT_ADDRESS 0x400     /*VIA ACPI PORT*/
#define VIA_PORT_OFFSET       0x48      /*Offset Address for presence Sensor*/
#define IBM_APK_M_ADAPTER_ID  13170

static int              get_port_address;
static int              RW = 0;
static int              port_address;

#define MAX_CDEVS 5
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 18)
typedef struct {
    struct class  *dev_class;
    struct cdev    cdev[MAX_CDEVS];
    struct device *dev;
    int            dev_count;
    int            major;
    dev_t          dev_number;
} mtn_adapter;
mtn_adapter Adapter;
#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 18)
int aipmtn_device_create(unsigned int major_number, char *modname,
                         const struct file_operations *fops);
void aipmtn_device_destroy(unsigned int major_number, char *modname);
#else
int aipmtn_device_create(char *modname, char *devname[], int dev_count,
                         char *class_name, mtn_adapter *adapter,
                         const struct file_operations *fops);
void aipmtn_device_destroy(mtn_adapter *adapter);
#endif


/* aipmtn_hw_int_handler: Handler for interrupt event
 * ***********************************************************************
 *
 * Function Name:   aipmtn_hw_int_handler
 *
 * Purpose:         Handler for interrupt event
 *
 * Description:     When an interrupt occurs
 *
 * Input:
 *
 * Output:          None
 *
 * ***********************************************************************
 */
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 19)
static irqreturn_t aipmtn_hw_int_handler(int irq, void *dev_id,
                                         struct pt_regs *regs)
#else
static irqreturn_t aipmtn_hw_int_handler(int irq, void *dev_id)
#endif
{
    int rc = FALSE;

    aip_verbose("aipmtn_hw_int_handler\n");

    if (machine_type != IBM_ANYPLACE_KIOSK
        && machine_type != IBM_ANYPLACE_KIOSK_M) {
        unsigned char func_reg = inb(function0port + INTERRUPT_STATUS_REG);
        int rc = FALSE;

        if (func_reg & 0x01) {
            aip_dbg("INTERRUPT ASSERTED\n");

            /* If interrupt, than clear bit 0 of function0 Interrupt Status
             * Register
            */
            outb(0x00, function0port + INTERRUPT_STATUS_REG);
            rc = TRUE;
        }
    }

    return IRQ_RETVAL(rc == TRUE ? IRQ_HANDLED : IRQ_NONE);
}


struct file_operations aipmtn_fops = {
    .owner          = THIS_MODULE,
    .read           = aipmtn_read,
    .write          = aipmtn_write,
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 36)
    .ioctl          = aipmtn_ioctl,
#else
    .unlocked_ioctl = aipmtn_ioctl,
#endif
#if LINUX_VERSION_CODE > KERNEL_VERSION(3, 11, 0)
    .compat_ioctl   = aipmtn_ioctl,
#endif
    .open           = aipmtn_open,
    .release        = aipmtn_release,
};



/* aipmtn_open: Exits the driver once rmmod is called
 * ***********************************************************************
 *
 * Function Name:   aipmtn_open
 *
 * Purpose:         Activites properties and other initialization not performed
 *                  during the init
 *
 * Description:     on device open
 *
 * Input:
 *
 * Output:          integer value
 *
 * ***********************************************************************
 */
static int aipmtn_open(struct inode *inode, struct file *flip)
{
    aip_dbg("open()\n");

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 5, 0)
    MOD_INC_USE_COUNT;
#endif

    return 0;
}


/* aipmtn_read:
 * ***********************************************************************
 *
 * Function Name:   aipmtn_read
 *
 * Purpose:         no operation
 *
 * Description:     on device read
 *
 * Input:
 *
 * Output:          integer value
 *
 * ***********************************************************************
 */
static ssize_t aipmtn_read(struct file *flip, char *buf, size_t count,
                           loff_t *f_pos)
{
    aip_dbg("Error: read unsupported\n");

    return -EINVAL;
}


/* aipmtn_write:
 * ***********************************************************************
 *
 * Function Name:   aipmtn_write
 *
 * Purpose:         no operation
 *
 * Description:     on device write
 *
 * Input:
 *
 * Output:          integer value
 *
 * ***********************************************************************
 */
static ssize_t aipmtn_write(struct file *flip, const char *buf, size_t count,
                            loff_t *f_pos)
{
    aip_dbg("Error: write unsupported\n");

    return -EINVAL;
}


/* aipmtn_release:
 * **********************************************************************
 *
 * Function Name:   aipmtn_release
 *
 * Purpose:         Releases properties and other initialization
 *
 * Description:     on device release
 *
 * Input:
 *
 * Output:          integer value
 *
 * ***********************************************************************
 */
static int aipmtn_release(struct inode *inode, struct file *flip)
{
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 5, 0)
    MOD_DEC_USE_COUNT;
#endif

    aip_dbg("END close()\n");
    return 0;
}


/* aipmtn_ioctl:
 * **********************************************************************
 *
 * Function Name:   aipmtn_ioctl
 *
 * Purpose:         ioctl service handler
 *
 * Description:     on device ioctl call
 *
 * Input:
 *
 * Output:          integer value
 *
 * ***********************************************************************
 */
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 36)
static int aipmtn_ioctl(struct inode *inode, struct file *flip,
                        unsigned int cmd, unsigned long arg)
#else
static long aipmtn_ioctl(struct file *flip, unsigned int cmd, unsigned long arg)
#endif
{
    int rc = 0;
    switch (_IOC_NR(cmd)) {
    case _IOC_NR(GET_MTN_STATUS):
        rc = aipget_motion_status((char *) arg);
        break;

    case _IOC_NR(GET_SLOT_INFO):
        rc = aipmtn_get_slot_info((char *) arg);
        break;

    default:
        rc = -EINVAL;
        break;
    }
    return rc;
}


/* aipmtn_get_slot_info:
 * **********************************************************************
 *
 * Function Name:   aipmtn_get_slot_info
 *
 * Purpose:         obtain slot information
 *
 * Description:     on device ioctl call
 *
 * Input:
 *
 * Output:          integer value
 *
 * ***********************************************************************
 */
static int aipmtn_get_slot_info(char *pBuffer)
{
    int rc = 0;

    GET_SLOT_INFO_PARMS gsip = {0};

    aip_dbg("aipmtn_get_slot_info\n");

    gsip.SlotType[1] = 1;
    gsip.AdapterID[1] = IBM_APK_M_ADAPTER_ID;
    if (machine_type != IBM_ANYPLACE_KIOSK_M)
        gsip.AdapterID[1] = pcimtn->device;
    gsip.SlotMotionSensor[1] = mtn_state;
    gsip.CompletionCode = 0x100;

    if (copy_to_user(pBuffer, &gsip, sizeof(gsip))) {
        aip_dbg("Error Copy GET_SLOT_INFO_PARMS to user space.\n");
        rc = -EFAULT;
    }

    return rc;
}


/* aipget_motion_status
 * **********************************************************************
 *
 * Function Name:   aipget_motion_status
 *
 * Purpose:         motion status
 *
 * Description:     on device ioctl call
 *
 * Input:
 *
 * Output:          integer value
 *
 * ***********************************************************************
 */
static int aipget_motion_status(char *pBuffer)
{
    int rc = 0;
    unsigned char status;
    GET_MTN_STATUS_PARMS gmsp = {0};
    gmsp.SlotNumber = 1;

    if (RW) {
        status = inb(function0port);

        aip_dbg("Status of Sensor=%x\n", status);

        status &= 0x01;

        if (status == 0x01) {
            aip_dbg("Motion NOT detected\n");
        } else {
            aip_dbg("Motion detected\n");
        }
    } else if (machine_type == IBM_ANYPLACE_KIOSK ||
               machine_type == IBM_ANYPLACE_KIOSK_M) {
        status = inb(VIA_ACPI_PORT_ADDRESS + VIA_PORT_OFFSET);
        status &= 0x08;
        if (status == 0x08) {
            /* Presence Not Detected */
            status = 1;
        } else {
            /* Presence Detected  */
            status = 0;
        }
    } else {
        /* We need to read port(LPC PCI Interface Bridge- 42B, bit 4) */

        /* The following write is to clear the Status bit to get
         * the correct latest status.
         */
        outb(0x10, port_address);

        /* Read the latest status. */
        status = inb(port_address);

        aip_dbg("Status of Sensor=%x\n", status);

        /* Bit4 is Presence Sensor status bit. */
        status &= 0x10;

        if (status == 0x10) {
            /* Return 0 if presence detected */
            status = 0;
            aip_dbg("Motion detected\n");
        } else {
            /* Return 1 if presence not detected */
            status = 1;
            aip_dbg("Motion NOT detected\n");
        }

    }
    gmsp.mtnStatus = status;
    gmsp.CompletionCode = 0x100;

    if (copy_to_user(pBuffer, &gmsp, sizeof(gmsp))) {
        aip_dbg("Error Copy GET_MTN_STATUS_PARMS to user space\n");
        rc = -EFAULT;
    }

    return rc;
}


#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 18)

int aipmtn_device_create(unsigned int major_number, char *modname,
                         const struct file_operations *fops)
{
    int err;

    /* Register as a device with kernel. */
    if ((err = register_chrdev(major_number, modname, fops))) {
        aip_error("Failure to load module. error %d\n", -err);
        return err;
    }

    return 0;
}


void aipmtn_device_destroy(unsigned int major_number, char *modname)
{
    if (unregister_chrdev(major_number, modname) != 0) {
        aip_error("unregister_chrdev failed\n");
    }

    return;
}

#else

int aipmtn_device_create(char *modname, char *devname[], int dev_count,
                         char *class_name, mtn_adapter *adapter,
                         const struct file_operations *fops)
{
    int err = 0;
    int i = 0;
    int major = 0;
    struct device *dev;

    adapter->major = 0;

    /* Request dynamic allocation of a device major number */
    aip_dbg("Allocating major device with %d minors\n", dev_count);
    if ((err = alloc_chrdev_region(&adapter->dev_number, 0, dev_count,
                                   modname)) < 0) {
        aip_error("Cannot register device, error=%d\n", -err);
        return err;
    }

    aip_dbg("dev number is %x for '%s'\n", adapter->dev_number, modname);

    /* Populate sysfs entries */
    adapter->dev_class = class_create(THIS_MODULE, class_name);

    if (IS_ERR(adapter->dev_class)) {
        aip_error("Cannot create class '%s' error %ld\n", class_name,
                  PTR_ERR(adapter->dev_class));
        adapter->dev_class = NULL;
        return -EINVAL;
    }

    adapter->dev_count = dev_count;
    adapter->major = 0;

    major = MAJOR(adapter->dev_number);

    adapter->major = major;

    for (i = 0; i < dev_count && i < MAX_CDEVS; i++) {
        aip_dbg("Initialzing cdev for %d '%s'\n", i, devname[i]);

        /* Connect the file operations with the cdev */
        cdev_init(&adapter->cdev[i], fops);

        aip_dbg("Adding cdev for '%s' major=%d/minor=%d\n", devname[i],
                major, i);

        /* Connect the major/minor number to the cdev */
        err = cdev_add(&adapter->cdev[i], MKDEV(major, i), 1);
        adapter->cdev[i].owner = THIS_MODULE;

        if (err) {
            aip_error("Bad cdev add, error %d\n", -err);

            /* Destroy dev_class */
            class_destroy(adapter->dev_class);
            adapter->dev_class = NULL;

            return err;
        }

        aip_dbg("Adding device for '%s' major=%d/minor=%d\n",
                devname[i], major, i);

        /* Send uevents to udev, so it'll create /dev node */
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 26)
        dev = device_create(adapter->dev_class, NULL, MKDEV(major, i),
                            devname[i]);
#elif LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 28)
        dev = device_create_drvdata(adapter->dev_class, NULL, MKDEV(major, i),
                                    NULL, devname[i]);
#else
        dev = device_create(adapter->dev_class, NULL, MKDEV(major, i), NULL,
                            devname[i]);
#endif
        if (!IS_ERR(dev)) {
            /* save sysfs dev pointer for creating additional attributes */
            adapter->dev = dev;
        }

        aip_dbg("Adding sysfs for '%s' major=%d/minor=%d returned err %ld\n",
                devname[i], major, i,(long) IS_ERR(dev));
    }

    return 0;
}


void aipmtn_device_destroy(mtn_adapter *adapter)
{
    int i = 0;

    aip_dbg("entered major=%d, count=%d\n",
            adapter->major, adapter->dev_count);

    /* Release the major number */
    if (adapter != NULL && adapter->major > 0) {
        if (adapter->dev_class != NULL) {
            for (i = 0; i < adapter->dev_count && i < MAX_CDEVS; i++) {
                aip_dbg("Removing device major=%d/minor=%d returned\n",
                        adapter->major, i);

                /* Destroy device */
                device_destroy(adapter->dev_class, MKDEV(adapter->major, i));

                /* Remove the cdev */
                cdev_del(&adapter->cdev[i]);
            }

            aip_dbg("Unregistering chrdev major=%d, count=%d\n",
                    adapter->major, adapter->dev_count);

            unregister_chrdev_region(adapter->major, adapter->dev_count);

            adapter->dev_count = 0;

            /* Destroy dev_class */
            class_destroy(adapter->dev_class);
            adapter->dev_class = NULL;
        }
        adapter->major = 0;
    }

    aip_dbg("returning\n");

    return;
}

#endif


/* aipmtn_init: Loads and Initializes the driver
 * **********************************************************************
 *                                                                      *
 *  Loads the aipmtn driver.  This is called when "insmod aipmtn.o is   *
 *  invoked on the command line.                                        *
 *                                                                      *
 * **********************************************************************
 */
static int __init aipmtn_init(void)
{
    int err = 0;
    int rc  = 0;
    unsigned char *pEEROMConfig = 0;
    unsigned long EEROMConfigAddr = 0;
    unsigned long EEROMConfigLength = 0;
    unsigned long machineModel;
    unsigned long machineType;
    u32 ctrl_register = 0;
    unsigned int vendor_id = RW_VENDOR_ID;
    unsigned int device_id = RW_DEVICE_ID;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 18)
    char *dev_names[20] = { "aipmtn"};
    int  dev_count = 1;
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 18)
    memset(&Adapter, 0, sizeof(mtn_adapter));
#endif

    if (machine_type == IBM_ANYPLACE_KIOSK) {
        vendor_id = VIA_PM_VENDOR_ID;
        device_id = VIA_PM_DEVICE_ID;
    } else if (machine_type == IBM_ANYPLACE_KIOSK_M) {
        mtn_state = 1;
        goto create_nodes;  // Memory mapped below not available on this machine
    }

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 9)
    pcimtn = pci_find_device(vendor_id, device_id, pcimtn);
#else
    pcimtn = pci_get_device(vendor_id, device_id, pcimtn);
#endif

    if (pcimtn != NULL) {
        aip_dbg("Adapter found...\n");

        if ((rc = pci_enable_device(pcimtn))) {
            aip_error("Cannot enable PCI device\n");
            goto err_out;
        }

        aip_dbg("PCI Device is Enabled\n");

        if (machine_type == IBM_ANYPLACE_KIOSK) {
            mtn_state = 1;
            goto create_nodes;  // Memory mapped below not available on this machine
        }
        EEROMConfigAddr = pci_resource_start(pcimtn, 1);
        EEROMConfigLength = pci_resource_len(pcimtn, 1);

        pEEROMConfig = (unsigned char *) ioremap(EEROMConfigAddr,
                                                 EEROMConfigLength);
        if (pEEROMConfig == 0) {
            goto err_out;
        }

        machineModel = readl((pEEROMConfig + OFFSET_TO_MACHINE_MODEL));
        machineType  = readl((pEEROMConfig + OFFSET_TO_MACHINE_TYPE));
        machineType  = (machineType & 0x00FFFFFF);

        iounmap((unsigned char *) pEEROMConfig);

        aip_dbg("Model=0x%lx, Type=0x%lx\n", machineModel, machineType);

        if (machineModel == RW_MODEL) {
            mtn_state = 1;
            aip_info("RW_MODEL found, Type=0x%lx\n", machineType);
        } else {
            aip_info("UNSUPPORTED MODEL Found\n");
            goto err_out;
        }

        /* should always use irq number from pci_dev routine
         * because of differences in the PCI_INTERRUPT_LINE macro
         */

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 19)
        rc = request_irq(pcimtn->irq, aipmtn_hw_int_handler,
                         SA_INTERRUPT | SA_SHIRQ, DEVDRVR_ID,
                         &irq_dev_id);
#elif LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 36)
        rc = request_irq(pcimtn->irq, aipmtn_hw_int_handler,
                         IRQF_DISABLED | IRQF_SHARED, DEVDRVR_ID,
                         &irq_dev_id);
#else
        rc = request_irq(pcimtn->irq, aipmtn_hw_int_handler,
                         IRQF_SHARED, DEVDRVR_ID,
                         &irq_dev_id);
#endif

        aip_dbg("request_irq rc=%d\n", rc);

        if (rc != 0) {
            aip_dbg("ERROR Requesting irq\n");

            goto err_out;
        }
        aip_dbg("Hooked Interrupt Handler\n");

        if (pci_read_config_dword(pcimtn, PCI_BASE_ADDRESS_0,
                                  (u32 *)&function0port ) < 0) {
            aip_dbg("Unable to read BAR 0\n");

            goto err_out;
        }

        function0port &= (unsigned long)(~PCI_BASE_ADDRESS_SPACE_IO);
        /* Request I/O Space for BAR 0 size 16 bytes */
        if (request_region(function0port, PCI_BOARD_SIZE,
                           DEVDRVR_ID) == NULL) {
            aip_dbg("Unable to request region\n");
            goto err_out;
        }

        aip_dbg("region requested\n");

        /* Reading first byte of BAR 0 */
        ctrl_register = inb(function0port + CONTROL_REG);

        aip_dbg("presence_sensor_ctrl_register (before)=0x%x\n",
                ctrl_register);

        /* enable bit 2 */
        ctrl_register |= 0x04;

        /* write to I/O Space */
        outb(ctrl_register, function0port);

        /* Reading first and second byte to verify results */
        aip_dbg("presence_sensor_ctrl_register (after)=0x%x\n",
                inb(function0port + CONTROL_REG));
        aip_dbg("function0_interrupt_status_register=0x%x\n",
                inb(function0port + INTERRUPT_STATUS_REG));

        RW = 1;

        rc = 0;
    } else {

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 9)
        pcimtn = pci_find_device(INTEL_LPC_VENDOR_ID,
                                 INTEL_LPC_DEVICE_ID, pcimtn);
#else
        pcimtn = pci_get_device(INTEL_LPC_VENDOR_ID,
                                INTEL_LPC_DEVICE_ID, pcimtn);
#endif

        if (pcimtn == NULL) {
            aip_error("Non-supported machine\n");
            goto err_out;
        }

        /* Read the Base Port Address Value. */
        if ((pci_read_config_dword(pcimtn, PORT_ADDRESS_OFFSET_BYTE,
                                   (u32 *)&get_port_address)) < 0) {
            aip_dbg("Cannot read PCI space\n");
            goto err_out;
        }

        mtn_state = 1;

        /* Read Value at Base Port Address and Offset it. */
        port_address = get_port_address & 0xFFFE;
        port_address = port_address + 0x2b;

        aip_dbg("Port Address is %x\n", get_port_address);
        rc = 0;
    }
    aip_dbg("RW Type is %d\n", RW);

create_nodes:

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 18)
    /* Register as a device with kernel. */
    err = aipmtn_device_create(aipmtn_major, DEVDRVR_ID, &aipmtn_fops);
#else
    /* Request dynamic allocation of a device major number */
    err = aipmtn_device_create((char *) DEVDRVR_ID, dev_names, dev_count,
                               "aipmtn", &Adapter, &aipmtn_fops);
#endif

    if (err != 0) {
        aip_error("Device register failed, rc=%dn", -err);
    }

    goto out;

err_out:
    /* Unregister device if it is not equal to the correct model number */
    mtn_state = 0;

    rc = -EINVAL;

out:
    return rc;
}


/* aipmtn_exit: Exits the driver once rmmod is called
 * ***********************************************************************
 *
 * Function Name:   aipmtn_exit
 *
 * Purpose:         Exits the driver once rmmod is called
 *
 * Description:     rmmod of device
 *
 * Input:
 *
 * Output:          None
 *
 * ***********************************************************************
 */
static void __exit aipmtn_exit(void)
{

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 5, 0)
    if (MOD_IN_USE) {
        aip_dbg("device busy, remove delayed\n");
        return;
    }
#endif
    if (machine_type != IBM_ANYPLACE_KIOSK_M) {
        if (machine_type != IBM_ANYPLACE_KIOSK) {
            if (function0port != 0) {
                release_region(function0port, PCI_BOARD_SIZE);
            }
        }

        if (pcimtn->irq != 0) {
            free_irq(pcimtn->irq, &irq_dev_id);
        }
    }

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 18)
    aipmtn_device_destroy(aipmtn_major, DEVDRVR_ID);
#else
    aipmtn_device_destroy(&Adapter);
#endif

    aip_dbg("Module removed\n");
}

module_init(aipmtn_init);
module_exit(aipmtn_exit);

MODULE_AUTHOR("Toshiba Global Commerce Solutions, Inc.");
MODULE_DESCRIPTION("Toshiba Motion Sensor Driver");
MODULE_LICENSE("GPL");
