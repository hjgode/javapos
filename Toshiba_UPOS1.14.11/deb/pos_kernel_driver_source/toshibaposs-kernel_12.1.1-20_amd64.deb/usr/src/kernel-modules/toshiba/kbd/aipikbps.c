/*
 * Module Name:     aipikbps.c
 *
 * Description:     PS/2 attached keyboard driver for Linux.
 *
 * Copyright (C) 2004-2018 Toshiba Global Commerce Solutions, Inc.
 * All right reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA; Otherwise,
 *  see <http://www.gnu.org/licenses/>.
 *
 *
 * Should you need to contact me, the author, you can do so either by
 * e-mail - mail your message to <gha@toshibagcs.com>.
 */

#include <linux/version.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/slab.h>
#include <linux/vmalloc.h>
#include <linux/mm.h>
#include <linux/ioctl.h>
#include <linux/delay.h>
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 16)
#include <linux/serio.h>
#endif
#if LINUX_VERSION_CODE > KERNEL_VERSION(2, 5, 0)
    #include <linux/moduleparam.h>
#endif
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 11, 0)
#include <linux/sched/signal.h>
#else
#include <linux/sched.h>
#endif
#include <linux/kbd_kern.h>
#include <linux/fs.h>
#include <asm/delay.h>
#include <asm/segment.h>
#include <asm/io.h>
#include <asm/segment.h>
#include <asm/uaccess.h>
/* #include <asm/system.h> */

/* ****************************************************************
 * local include files
 * ****************************************************************
 */
#define CANPOS


#include "aipikbps.h"
#include "aipikpssc.h"
#include "aipdebug.h"

/* ****************************************************************
 * constant definitions
 * ****************************************************************
 */
#define SUCCESS             0
#define IBM_POS_KBD_MAJOR   246
#define DEVDRVR_ID          "aipikbps"
#define AIPIKBPS_PHYS_NAME  "aipikbps/serio0"
#define CMD_WAIT_TIMEOUT    HZ*50;

#define POS_KBD_NATIVE_MODE 0
#define POS_KBD_COMPAT_MODE 1

#define DRIVER_DESC "Toshiba PS/2 Point of Sale Keyboard Filter"

/* #define KBD_RESET           0 */

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 18)
#define MAX_CDEVS 5
typedef struct {
    struct class  *dev_class;
    struct cdev    cdev[MAX_CDEVS];
    struct device *dev;
    int            dev_count;
    int            major;
    dev_t          dev_number;
} kbd_adapter;
kbd_adapter Adapter;
#endif

/* ***************************************************************
 * Function Prototypes
 * ***************************************************************
 */
static int kb_open(struct inode *inode, struct file *file);
static int kb_release(struct inode *inode, struct file *file);
static ssize_t kb_read(struct file *file, char *buf, size_t count, loff_t *ppos);
static ssize_t kb_write(struct file *file, const char *buf, size_t count,
                        loff_t *ppos);
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 36)
static int kb_ioctl(struct inode *inode, struct file *fp, unsigned int cmd,
                    unsigned long ioctl_arg);
#else
static long kb_ioctl(struct file *fp, unsigned int cmd, unsigned long user_buffer);
#endif
static int pos_scancode_filter(unsigned char *pScancode);

static int PosKbdReset(void);

static int PosKbdSendData(unsigned char *buf, unsigned int size, long timeout);
static int PosKbdSetInterfaceVersion(unsigned char interfaceVersion);
static int PosKbdReqDevInfo(void);
static int PosMsrReqDevInfo(void);
static unsigned char collect_kbd_status(unsigned char scancode);
static unsigned char collect_msr_status(unsigned char scancode);
static unsigned char DoubleKeyProcessing(unsigned char key,
                                         unsigned char fBreak);
static void SetShiftKeyState(unsigned char scanCode,
                             POS_KEYBOARD_SCAN_STATE *scanState);
static void set_leds_default_state(void);
static void pos_process_code_update(void);
static int  SetDefaultConfiguration(void);
static int  PosKbdReadId(void);
static unsigned char CollectingKBDId(unsigned char scancode);

static unsigned char collecting_canpos_write_config_ack(unsigned char sc);
static int CanposPosKbdSendData(unsigned char *buf, unsigned int size);
static unsigned char collecting_canpos_normal_ack(unsigned char sc);
static unsigned char collecting_canpos_flash_ack(unsigned char sc);
static void wake_up_canpos_process(void);
static unsigned char check_canpos_key_105_106(unsigned char scancode);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 16)
static int aipikbps_write_buffer(unsigned char *data, unsigned int length,
                                 unsigned int *xferred, unsigned int retries,
                                 unsigned int timeout);
#endif

static unsigned char collecting_canpos_ver_info(unsigned char sc);

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 16)
struct pc_keyb_filter {
    int (*filter_scancode)(unsigned char *scancode);
    int (*write_data)(unsigned char *data, unsigned int length,
                      unsigned int *xferred, unsigned int retries,
                      unsigned int timeout);
};
int  register_pc_keyb_filter(struct pc_keyb_filter *filter);
void unregister_pc_keyb_filter(struct pc_keyb_filter *filter);

/* ***************************************************************
 * For patched kernels ONLY
 * Pass the scancode filter function name.  Upon return ,
 * pos_filter.write_data() will contain the address of the
 * actual write funtion supported by pc_keyb driver.
 * ***************************************************************
 */
static struct pc_keyb_filter pos_filter =
{
    filter_scancode:  pos_scancode_filter,
};
#endif

/* ***************************************************************
 * Globals
 * ***************************************************************
 */
static PPOS_KEYBOARD_DATA pPosKbdData;  /* = &posKbdData; */
#if 0
static unsigned char updateBuffer[MAX_BUFFER_SIZE];
#endif
static unsigned long  cmd_busy = 0;
static unsigned long  ack_status = 0;
static int           aipikbps_KbdCompatMode = POS_KBD_NATIVE_MODE;
static unsigned char canpos_key_105_106;
static int           receivingCodeUpdateData = 0;
static int           nextCodeUpdatePosition;

#if defined(V4690)
/* 4690 globals */
static int           is4690mode = 0;
static unsigned char statusBuffer4690[MAX_BUFFER_SIZE];
static unsigned char readBuffer4690[MAX_BUFFER_SIZE];
static int           statusBufferCapturingLength4690 = 0;
static int           statusBufferLength4690 = 0;
static int           statusBufferOverflow4690 = 0;
static int           collectStatus4690 = 0;
#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 18)
static unsigned int  aipikbps_major = IBM_POS_KBD_MAJOR;
#endif
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 16)
static struct serio *aipikbps_serio = NULL;
static struct serio *aipikbps_real_serio = NULL;
static struct semaphore aipikbps_sema;
static unsigned char aipikbps_suppress_kbd_ack = 0;
#endif
static int aipikbps_in_user_call = 0;
static int aipikbps_reset_sent  = 0;
static int aipikbps_prev_key_e0 = 0;

/* ***************************************************************
 * file I/O
 * ***************************************************************
 */
struct file_operations kb_fops = {
    .read = kb_read,
    .write = kb_write,
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 36)
    .ioctl = kb_ioctl,
#else
    .unlocked_ioctl = kb_ioctl,
#endif
#if LINUX_VERSION_CODE > KERNEL_VERSION(3, 11, 0)
    .compat_ioctl   = kb_ioctl,
#endif
    .open = kb_open,
    .release = kb_release,
};

DECLARE_WAIT_QUEUE_HEAD(wq);
DECLARE_WAIT_QUEUE_HEAD(wq_ack);

#if defined(V4690)
DECLARE_WAIT_QUEUE_HEAD(wq4690);
DEFINE_SPINLOCK(bufferLock4690);
/* Additional Lines */
module_param_named(statusANPOS, aipikbps_statusANPOS, bool, 0644);
#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 0)
MODULE_PARM(aipikbps_major, "i");
MODULE_PARM(aipikbps_KbdCompatMode, "i");
#else
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 18)
module_param_named(major, aipikbps_major, int, 0644);
#endif
module_param_named(mode, aipikbps_KbdCompatMode, int, 0644);

static bool javapos = 0;
module_param(javapos, bool, S_IRUGO | S_IWUSR);
MODULE_PARM_DESC(javapos, "Use /dev/ps2driver for JavaPOS");
#endif


int aipikbps_wait_for_kbd_status(int msecs)
{
    long rc = 0;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 16)
    rc = wait_event_interruptible_timeout(wq, !test_bit(0, &cmd_busy),
                                          msecs_to_jiffies(msecs));
    if (rc < 0) {
        aip_error("interrupted while waiting for cmd_busy to clear\n");
        rc = -EINTR;
    } else if (rc == 0) {
        if (test_bit(0, &cmd_busy) != 0) {
            aip_error("timeout while waiting for cmd_busy to clear\n");
            rc = -ETIMEDOUT;
        }
    }
#else
    long timeout = msecs*HZ;

    if (test_bit(0, &cmd_busy))
        rc = interruptible_sleep_on_timeout(&wq, timeout);
#endif

    return rc;
}


int aipikbps_wait_for_scancode_ack(int msecs)
{
    long rc = 0;
    long timeout = 0;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 16)
    timeout = msecs_to_jiffies(msecs);

    rc = wait_event_interruptible_timeout(wq_ack,
                                          !test_bit(WAITING_FOR_KBD_ACK, &ack_status),
                                          timeout);
#else
    timeout = msecs*HZ;

    set_current_state(TASK_INTERRUPTIBLE);
    rc = schedule_timeout(timeout);
#endif

    return rc;
}


int aipikbps_timeout(int msecs)
{
    int timeout = 0;
    int rc = 0;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 16)
    DEFINE_WAIT(wait);
#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 0)
    timeout = msecs*HZ;
#else
    timeout = msecs_to_jiffies(msecs);
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 16)
    prepare_to_wait(&wq, &wait, TASK_INTERRUPTIBLE);
#endif

    set_current_state(TASK_INTERRUPTIBLE);
    rc = schedule_timeout(timeout);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 16)
    finish_wait(&wq, &wait);
#endif

    return rc;
}


int aipikbps_command_start(int retry_count)
{
    int timeout = (retry_count * 50);
    int rc = 0;

    if (test_and_set_bit(0, &cmd_busy)) {
        rc = wait_event_interruptible_timeout(wq, !test_bit(0, &cmd_busy),
                                              msecs_to_jiffies(timeout));

        if (rc < 0) {
            aip_error("interrupted while waiting for cmd_busy to clear\n");
            rc = -EINTR;
        } else if (rc == 0) {
            aip_error("timeout while waiting for cmd_busy to clear\n");
            rc = -ETIMEDOUT;
        } else if (test_and_set_bit(0, &cmd_busy)) {
            aip_error("someone grabbed cmd_busy before I could lock it\n");
            rc = -EBUSY;
        }
    }

    return rc;
}


void aipikbps_command_finish(void)
{
    clear_bit(0, &cmd_busy);
    wake_up_interruptible_all(&wq);

    return;
}

int aipikbps_command_wait_for_complete(int msecs)
{
    return aipikbps_wait_for_kbd_status(msecs);
}


int aipikbps_busy_wait(int msecs)
{
    return aipikbps_wait_for_kbd_status(msecs);
}


#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 18)

int aipikbps_device_create(unsigned int major_number, char *modname,
                           struct file_operations *fops)
{
    int err;

    /* Register as a device with kernel. */
    if ((err = register_chrdev(major_number, modname, fops))) {
        aip_error("Failure to load module. error %d\n", -err);
        return err;
    }

    return 0;
}


void aipikbps_device_destroy(unsigned int aipkbd_major, char *modname)
{

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 0)
    if (unregister_chrdev(aipkbd_major, modname) != 0) {
        aip_error("unregister_chrdev failed\n");
    }
#else
        unregister_chrdev(aipkbd_major, modname);
#endif

    return;
}

#else

int aipikbps_device_create(char *modname, char *devname[], int dev_count,
                           char *class_name, kbd_adapter *adapter,
                           struct file_operations *fops)
{
    int err = 0;
    int i = 0;
    int major = 0;
    struct device *dev;

    adapter->major = 0;

    /* Request dynamic allocation of a device major number */
    aip_dbg("Allocating major device with %d minors\n", dev_count);
    if ((err = alloc_chrdev_region(&adapter->dev_number, 0, dev_count,
                                   modname)) < 0) {
        aip_error("Cannot register device, error=%d\n", -err);
        return err;
    }

    aip_dbg("dev number is %x for '%s'\n", adapter->dev_number, modname);

    /* Populate sysfs entries */
    adapter->dev_class = class_create(THIS_MODULE, class_name);

    if (IS_ERR(adapter->dev_class)) {
        aip_error("Cannot create class '%s' error %ld\n", class_name,
                  PTR_ERR(adapter->dev_class));
        adapter->dev_class = NULL;
        return -EINVAL;
    }

    adapter->dev_count = dev_count;
    adapter->major = 0;

    major = MAJOR(adapter->dev_number);

    adapter->major = major;

    for (i = 0; i < dev_count && i < MAX_CDEVS; i++) {
        aip_dbg("Initialzing cdev for %d '%s'\n", i, devname[i]);

        /* Connect the file operations with the cdev */
        cdev_init(&adapter->cdev[i], fops);

        aip_dbg("Adding cdev for '%s' major=%d/minor=%d\n", devname[i],
                major, i);

        /* Connect the major/minor number to the cdev */
        err = cdev_add(&adapter->cdev[i], MKDEV(major, i), 1);
        adapter->cdev[i].owner = THIS_MODULE;

        if (err) {
            aip_error("Bad cdev add, error %d\n", -err);

            /* Destroy dev_class */
            class_destroy(adapter->dev_class);
            adapter->dev_class = NULL;

            return err;
        }

        aip_dbg("Adding device for '%s' major=%d/minor=%d\n",
                devname[i], major, i);

        /* Send uevents to udev, so it'll create /dev node */
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 26)
        dev = device_create(adapter->dev_class, NULL, MKDEV(major, i),
                            devname[i]);
#elif LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 28)
        dev = device_create_drvdata(adapter->dev_class, NULL, MKDEV(major, i),
                                    NULL, devname[i]);
#else
        dev = device_create(adapter->dev_class, NULL, MKDEV(major, i), NULL,
                            devname[i]);
#endif
        if (!IS_ERR(dev)) {
            /* save sysfs dev pointer for creating additional attributes */
            adapter->dev = dev;
        }

        aip_dbg("Adding sysfs for '%s' major=%d/minor=%d returned err %d\n",
                devname[i], major, i, IS_ERR(dev));
    }

    return 0;
}


void aipikbps_device_destroy(kbd_adapter *adapter)
{
    int i = 0;

    aip_dbg("entered major=%d, count=%d\n",
            adapter->major, adapter->dev_count);

    /* Release the major number */
    if (adapter != NULL && adapter->major > 0) {
        if (adapter->dev_class != NULL) {
            for (i = 0; i < adapter->dev_count && i < MAX_CDEVS; i++) {
                aip_dbg("Removing device major=%d/minor=%d returned\n",
                        adapter->major, i);

                /* Destroy device */
                device_destroy(adapter->dev_class, MKDEV(adapter->major, i));

                /* Remove the cdev */
                cdev_del(&adapter->cdev[i]);
            }

            aip_dbg("Unregistering chrdev major=%d, count=%d\n",
                    adapter->major, adapter->dev_count);

            unregister_chrdev_region(adapter->major, adapter->dev_count);

            adapter->dev_count = 0;

            /* Destroy dev_class */
            class_destroy(adapter->dev_class);
            adapter->dev_class = NULL;
        }
        adapter->major = 0;
    }

    aip_dbg("returning\n");

    return;
}

#endif


#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 16)
/* :H1.do_patch_kb_init() - Called to complete kb_init for patched (non-serio) systems
 * ***********************************************************************
 *
 * Function Name:  do_patch_kb_init()
 *
 * Purpose:        Intialization routine
 *
 * Description:    Finish initializing keyboard device for kernels that
 *                 have a keyboard patch (prior to 2.6.16.57). Load time
 *                 module parameter tells us whether we can use serio or
 *                 not.
 *
 *
 *
 * Output:
 *                 0        - success
 *                 non-zero - failure.
 *
 * Notes:
 *
 * ***********************************************************************
 */

static int __init do_patch_kb_init(void)
{
    int rc = SUCCESS;

#if 0
    /* Initialize keyboard data structure. */
    memset(&posKbdData, 0, sizeof(POS_KEYBOARD_DATA));

    pPosKbdData = &posKbdData;
    memset(&KBDdevinfo, 0, sizeof(DEVICE_INFO));
    memset(&MSRdevinfo, 0, sizeof(DEVICE_INFO));
#endif

    /* Register with low level driver, pc_keyb driver. Upon registration,
     * the pc_keyb driver provides a pointer to write function.  In addtion,
     * it calls our interrupt routine (pos_scancode_filter()) each time
     * keyboard interrupts.
     */
    aip_dbg("register with keyboard driver - atkbd\n");

    /* register_pc_keyb_filter() & unregister_pc_keyb_filter()
     * todo -
     * this should be OK if the patch for atkbd is applied.
     * However, we need to find a way to check for the existing of
     * the symbols before calling them.
     */
    register_pc_keyb_filter(&pos_filter);

    /*  Read Keyboard ID.  If IBM POS Keyboard, continue with Initialization.
     */
    rc = PosKbdReadId();
    if (rc != 0) {
        aip_error("PosKbdReadId failed rc=%02x\n", rc);

        /* unregister with pc_keyb driver. */
        aip_dbg("unregister with atkbd\n");

        unregister_pc_keyb_filter(&pos_filter);

        aipikbps_command_finish();

        return -ENODEV;
    }

    if ((pPosKbdData->PosKbdId.KBDId[0] == 0xAB) &&
        (pPosKbdData->PosKbdId.KBDId[1] == 0x87)) {
        /* Found IBM POS Keyboard */
        aip_info("Toshiba POS Keyboard Id=0x%x.0x%x\n",
                 pPosKbdData->PosKbdId.KBDId[0],
                 pPosKbdData->PosKbdId.KBDId[1]);
    } else if ((pPosKbdData->PosKbdId.KBDId[0] == 0xAB) &&
               (pPosKbdData->PosKbdId.KBDId[1] == 0x41)) {
        /* Found IBM CANPOS Keyboard */
        aip_info("Found Toshiba CANPOS Keyboard Id=0x%x.0x%x\n",
                 pPosKbdData->PosKbdId.KBDId[0],
                 pPosKbdData->PosKbdId.KBDId[1]);

        /* This *might* be CANPOS_V1, will re-evaluate later... */
        pPosKbdData->CanposKeyboard = 1;
    } else {
        /* Did not find IBM POS Keyboard */
        aip_error(   "No Toshiba POS Keyboard Id=0x%x.0x%x\n",
                     pPosKbdData->PosKbdId.KBDId[0],
                     pPosKbdData->PosKbdId.KBDId[1]);

        /* unregister with pc_keyb driver. */
        unregister_pc_keyb_filter(&pos_filter);

        aipikbps_command_finish();
        return -ENODEV;
    }

#if defined(KBD_RESET)
    /*  Reset the keyboard.  There is no need to do any reset.
     *  Otherwise, we loose initial settings.
     */
    rc = PosKbdReset();
    if (rc != 0) {
        unregister_pc_keyb_filter(&pos_filter);

        return -ENODEV;
    }
#endif

    /* Request keyboard device information */
    rc = PosKbdReqDevInfo();

    if (rc != 0) {
        aip_error("PosKbdDevInfo() failed rc=0x%x\n", rc);

        /* unregister with pc_keyb driver. */
        unregister_pc_keyb_filter(&pos_filter);

        return -ENODEV;
    }

    /* Featues byte will tell us whether this is ANPOS_V1 or ANPOS_V2
     * -- only send set interface command to ANPOS_V2
     */
    if ((aipikbps_KbdCompatMode == POS_KBD_NATIVE_MODE) &&
        (((pPosKbdData->PosKbdDeviceInfo.deviceID == 0x04) &&
          (pPosKbdData->PosKbdDeviceInfo.Features == 0x23)) ||
         ((pPosKbdData->PosKbdDeviceInfo.deviceID == 0x08) &&
          (pPosKbdData->PosKbdDeviceInfo.Features & 0x20)) ||
         ((pPosKbdData->PosKbdDeviceInfo.deviceID == 0x07) &&
          (pPosKbdData->PosKbdDeviceInfo.Features == 0x20)))) {

        /* Set the interface to V4
         * TBD: MAKE THE INTERFACE VERSION A LOAD_TIME PARAMETER
         */
        rc = PosKbdSetInterfaceVersion(0x04);
        if (rc != 0) {
            aip_error("PosKbdSetInterfaceVersion() failed rc=0x%x\n", rc);

            /* unregister with pc_keyb driver. */
            unregister_pc_keyb_filter(&pos_filter);

            return -ENODEV;
        }

        /* Request keyboard device information again */
        rc = PosKbdReqDevInfo();

        if (rc != 0) {
            aip_error("PosKbdDevInfo() failed rc=0x%x\n", rc);

            /* unregister with pc_keyb driver. */
            unregister_pc_keyb_filter(&pos_filter);

            return -ENODEV;
        }
    }

    /* This is a V2 Keyboard and thus cannot be CANPOS_V1, either
     */
    if ((pPosKbdData->PosKbdDeviceInfo.deviceID == 0x08) ||
        (pPosKbdData->PosKbdDeviceInfo.deviceID == 0x09) ||
        (pPosKbdData->PosKbdDeviceInfo.deviceID == 0x0A)) {
        pPosKbdData->v2Keyboard = 1;
        pPosKbdData->CanposKeyboard = 0;
        if (pPosKbdData->PosKbdDeviceInfo.CommandSet == 0x04) {
            aip_info("Toshiba V2 Keyboard -- Native Mode\n");
        } else {
            aip_info("Toshiba V2 Keyboard -- Compatibility Mode\n");
        }
    }

    /*  Request msr device information */
    rc = PosMsrReqDevInfo();

    if (rc != 0) {
        aip_error("PosMsrDevInfo() failed rc=0x%x\n", rc);

        /* unregister with pc_keyb driver. */
        unregister_pc_keyb_filter(&pos_filter);

        return -ENODEV;
    }

    /* Set default led state i.e turn off all leds. */
    set_leds_default_state();

    /* Initialze Keyboard */
    pPosKbdData->KbdConfigureCmd[0] = KBD_CONFIGURE_CMD;
    pPosKbdData->KbdConfigureCmd[1] = 0x03;
    pPosKbdData->KbdConfigureCmd[2] = 0x00;
    pPosKbdData->KbdConfigureCmd[3] = 0x00;

    pPosKbdData->MsrConfigureCmd[0] = MSR_CONFIGURE_CMD;
    pPosKbdData->MsrConfigureCmd[1] = 0x00;

    pPosKbdData->MsrROL = FALSE;

    /* Send default Configuration i.e. turn on typematic */
    SetDefaultConfiguration();

    /* Register as a device with kernel. */
    rc = aipikbps_device_create(aipikbps_major, DEVDRVR_ID, &kb_fops);

    if (rc) {
        /* unregister with pc_keyb driver. */
        unregister_pc_keyb_filter(&pos_filter);

        aip_error("register devnode failed rc=%d\n", -rc);
        return -ENODEV;
    } else {
        aip_dbg("devnode created MajorNumber %d\n", aipikbps_major);
    }

    aip_dbg("Loaded, MajorNumber=%d\n", aipikbps_major);

    return rc;
}


#else

static int aipikbps_create_kbd_port(struct serio *serio);

static int aipikbps_connect(struct serio *serio, struct serio_driver *drv)
{
    int rc = SUCCESS;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 18)
    char *dev_names[20] = { "aipikbps", "ps2driver"};
    int  dev_count = 1;
#endif

/* Additional Lines */
#if defined(V4690)
    if (aipikbps_statusANPOS == TRUE){
       aip_error("Running aipikbps statusANPOS");
    }
#endif

    aip_dbg("Serio name='%s', phys='%s'\n", serio->name, serio->phys);
    if (!strncmp(serio->phys, AIPIKBPS_PHYS_NAME, sizeof(serio->phys)))
        return -EINVAL;

    if (aipikbps_real_serio != NULL) {
        aip_dbg("serio already attached\n");
        return -EINVAL;
    }

    if ((rc = serio_open(serio, drv))) {
        aip_error("serio_open failed rc=%02x\n", rc);
        return rc;
    }

    aipikbps_real_serio = serio;

    /*  Read Keyboard ID.  If IBM POS Keyboard, continue with Initialization.
     */
    rc = PosKbdReadId();
    if (rc != 0) {
        aip_error("PosKbdReadId failed rc=%02x\n", rc);

        /* unregister with pc_keyb driver. */
        aip_error("unregister with atkbd\n");

        aipikbps_real_serio = NULL;
        serio_close(serio);
        return -ENODEV;
    }

    if ((pPosKbdData->PosKbdId.KBDId[0] == 0xAB) &&
        (pPosKbdData->PosKbdId.KBDId[1] == 0x87)) {
        /* Found IBM POS Keyboard */
        aip_info("Toshiba POS Keyboard Id=0x%x.0x%x\n",
                 pPosKbdData->PosKbdId.KBDId[0],
                 pPosKbdData->PosKbdId.KBDId[1]);
    } else if ((pPosKbdData->PosKbdId.KBDId[0] == 0xAB) &&
               (pPosKbdData->PosKbdId.KBDId[1] == 0x41)) {
        /* Found IBM CANPOS Keyboard */
        aip_info("Found Toshiba CANPOS Keyboard Id=0x%x.0x%x\n",
                 pPosKbdData->PosKbdId.KBDId[0],
                 pPosKbdData->PosKbdId.KBDId[1]);

        /* This *might* be CANPOS_V1, will re-evaluate later... */
        pPosKbdData->CanposKeyboard = 1;
    } else {
        /* Did not find IBM POS Keyboard */
        aip_error("No Toshiba POS Keyboard Id=0x%x.0x%x\n",
                  pPosKbdData->PosKbdId.KBDId[0],
                  pPosKbdData->PosKbdId.KBDId[1]);

        aipikbps_real_serio = NULL;
        serio_close(serio);
        return -ENODEV;
    }

#if defined(KBD_RESET)
    /*  Reset the keyboard.  There is no need to do any reset.
     *  Otherwise, we loose initial settings.
     */
    rc = PosKbdReset();
    if (rc != 0) {
        aipikbps_real_serio = NULL;
        serio_close(serio);
        return -ENODEV;
    }
#endif

    /* Request keyboard device information */
    rc = PosKbdReqDevInfo();

    if (rc != 0) {
        aip_error("PosKbdReqDevInfo() failed rc=0x%x\n", rc);

        aipikbps_real_serio = NULL;
        serio_close(serio);
        return -ENODEV;
    }

    /* Featues byte will tell us whether this is ANPOS_V1 or ANPOS_V2
     * -- only send set interface command to ANPOS_V2
     */
    if ((aipikbps_KbdCompatMode == POS_KBD_NATIVE_MODE) &&
        ( ((pPosKbdData->PosKbdDeviceInfo.deviceID == 0x04) &&
           (pPosKbdData->PosKbdDeviceInfo.Features == 0x23)) ||
          ((pPosKbdData->PosKbdDeviceInfo.deviceID == 0x08) &&
           (pPosKbdData->PosKbdDeviceInfo.Features & 0x20)) ||
          ((pPosKbdData->PosKbdDeviceInfo.deviceID == 0x07) &&
           (pPosKbdData->PosKbdDeviceInfo.Features == 0x20)) )) {

        /* Set the interface to V4
         * TBD: MAKE THE INTERFACE VERSION A LOAD_TIME PARAMETER
        */
        rc = PosKbdSetInterfaceVersion(0x04);
        if (rc != 0) {
            aipikbps_real_serio = NULL;
            serio_close(serio);
            return -ENODEV;
        }

        /* Request keyboard device information again */
        rc = PosKbdReqDevInfo();

        if (rc != 0) {
            aip_error("PosKbdReqDevInfo() failed rc=0x%x\n", rc);

            aipikbps_real_serio = NULL;
            serio_close(serio);
            return -ENODEV;
        }
    }

    /* Keyboard ID may have indicated CANPOS but if it is CANPOS_V2
     * and Interface V4 then we do not want to treat it as a CANPOS_V1
     */
    if ((pPosKbdData->PosKbdDeviceInfo.deviceID == 0x08) ||
        (pPosKbdData->PosKbdDeviceInfo.deviceID == 0x09) ||
        (pPosKbdData->PosKbdDeviceInfo.deviceID == 0x0A)) {
        pPosKbdData->v2Keyboard = 1;
        pPosKbdData->CanposKeyboard = 0;

        if (pPosKbdData->PosKbdDeviceInfo.CommandSet == 0x04) {
            aip_info("Toshiba V2 Keyboard -- Native Mode\n");
        } else {
            aip_info("Toshiba V2 Keyboard -- Compatibility Mode\n");
        }
    }

    /*  Request msr device information */
    rc = PosMsrReqDevInfo();

    if (rc != 0) {
        aip_error("PosReqMsrDevInfo() failed rc=0x%x\n", rc);

        aipikbps_real_serio = NULL;
        serio_close(serio);
        return -ENODEV;
    }

    /* Set default led state i.e turn off all leds. */
    set_leds_default_state();

    /* Initialze Keyboard */
    pPosKbdData->KbdConfigureCmd[0] = KBD_CONFIGURE_CMD;
    pPosKbdData->KbdConfigureCmd[1] = 0x03;
    pPosKbdData->KbdConfigureCmd[2] = 0x00;
    pPosKbdData->KbdConfigureCmd[3] = 0x00;

    pPosKbdData->MsrConfigureCmd[0] = MSR_CONFIGURE_CMD;
    pPosKbdData->MsrConfigureCmd[1] = 0x00;

    /* Send default Configuration i.e. turn on typematic */
    SetDefaultConfiguration();

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 18)
    /* Register as a device with kernel. */
    rc = aipikbps_device_create(aipikbps_major, DEVDRVR_ID, &kb_fops);
#else
    /* Request dynamic allocation of a device major number */
    if (javapos != 0) {
        dev_count = 2;
    }
    rc = aipikbps_device_create((char *) DEVDRVR_ID, dev_names, dev_count,
                                "aipikbps", &Adapter, &kb_fops);
#endif

    if (rc != 0) {
        aip_error("register devnode failed rc=%d\n", -rc);
        aipikbps_real_serio = NULL;
        serio_close(serio);
        return -ENODEV;
    }

    rc = aipikbps_create_kbd_port(serio);

    if (rc != 0) {
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 18)
        aipikbps_device_destroy(aipikbps_major, DEVDRVR_ID);
#else
        aipikbps_device_destroy(&Adapter);
#endif

        aipikbps_real_serio = NULL;
        serio_close(serio);
        return rc;
    }

    aip_dbg("Loaded, rc=%d\n", -rc);

    return rc;
}
#endif


/* :H1.kb_open()
 * ***********************************************************************
 *
 * Function Name:  kb_open()
 *
 * Purpose:        driver open routine.
 *
 * Description:    This routine gets called when application opens this
 *                 driver.
 *
 *
 * Output:
 *                 0  -  success
 *
 *
 * Notes:
 *
 * ***********************************************************************
 */

static int kb_open(struct inode *inode, struct file *file)
{
    aip_dbg("MAJOR=%d, MINOR=%d\n",
            MAJOR(inode->i_rdev), MINOR(inode->i_rdev));

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 5, 0)
    MOD_INC_USE_COUNT;
#endif
    return SUCCESS;
}


/* :H1.kb_release()
 * ***********************************************************************
 *
 * Function Name:  kb_release()
 *
 * Purpose:        driver close routine.
 *
 * Description:    This routine gets called when application closes this
 *                 driver.
 *
 * Output:
 *                 0  -  success
 *
 * Notes:
 *
 * ***********************************************************************
 */

static int kb_release(struct inode *inode, struct file *file)
{
    aip_dbg("closing character device: %s\n", DEVDRVR_ID);

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 5, 0)
    MOD_DEC_USE_COUNT;
#endif

    return SUCCESS;
}


/* :H1.kb_read()
 * ***********************************************************************
 *
 * Function Name:  kb_read()
 *
 * Purpose:        driver read routine.
 *
 * Description:    This routine gets called when application sends a
 *                 read request.
 *
 * Output:
 *                 EINVAL
 *
 * Notes:          read request is not supported.
 *
 * ***********************************************************************
 */

static ssize_t kb_read(struct file *file, char *buf, size_t count, loff_t *ppos)
{
    aip_dbg("character device: %s:\n", DEVDRVR_ID);

#if defined(V4690)
    if (!is4690mode) {
        aip_error("not in 4690 mode; read not supported\n");
        return -ENOSYS;
    }

    if (ppos && *ppos) {
        aip_error("read with ppos offset not supported\n");
        return -EINVAL;
    }

    while (!statusBufferLength4690 && !statusBufferOverflow4690) {
        if (wait_event_interruptible(wq4690, statusBufferLength4690)) {
            aip_error("interrupted while waiting for status\n");
            return -EINTR;
        }
    }

    if (statusBufferLength4690 && !statusBufferOverflow4690) {
        uint32_t flags;
        int len;
        int rc;

        spin_lock_irqsave(&bufferLock4690, flags);

        len = min(statusBufferLength4690, (int)count);

        memcpy(readBuffer4690, statusBuffer4690, len);

        statusBufferLength4690 -= len;
        statusBufferCapturingLength4690 -= len;

        memmove(statusBuffer4690, &statusBuffer4690[len],
                statusBufferCapturingLength4690);

        spin_unlock_irqrestore(&bufferLock4690, flags);

        if ((rc = copy_to_user(buf, readBuffer4690, len))) {
            aip_error("could not copy to user buffer (%d)\n",rc);
            return -EFAULT;
        }

        return len;
    }

    /* This means the statusBuffer4690 overflowed
     * All data in it, and all bytes since the overflow, were dropped
     * This read resets the error and the status will start being saved again
     */
    if (statusBufferOverflow4690) {
        statusBufferOverflow4690 = 0;
        aip_error("buffer had overflowed.  Resetting overflow status\n");
        return -EOVERFLOW;
    }

    return 0;
#else
    return -EINVAL;
#endif
}


/* :H1.kb_write()
 * ***********************************************************************
 *
 * Function Name:  kb_wirte()
 *
 * Purpose:        driver write routine.
 *
 * Description:    This routine gets called when application sends a
 *                 write request.
 *
 * Output:
 *                 EINVAL
 *
 * Notes:          write request is not supported.
 *
 * ***********************************************************************
 */

static ssize_t kb_write(struct file *file, const char *buf, size_t count,
                        loff_t *ppos)
{
#if defined(V4690)
    unsigned char *buffer;
    int xferred = 0;
    int xfer_retry = 5;
    size_t size = count;
    int rc;

    aip_dbg("character device: %s\n", DEVDRVR_ID);

    if (!is4690mode) {
        aip_error("not in 4690 mode; write not supported.\n");
        return -ENOSYS;
    }

    if (ppos && *ppos) {
        aip_error("write with ppos offset not supported\n");
        return -EINVAL;
    }

    if (!(buffer = vmalloc(size))) {
        aip_error("out of memory!\n");
        return -ENOMEM;
    }

    if ((rc = copy_from_user(buffer, buf, size))) {
        vfree(buffer);
        aip_error("could not data in from user buffer (%d)\n",rc);
        return -EFAULT;
    }

    /* Instead of using the home-made "cmd_busy"...
     * use a semaphore!
     * See include/asm-i386/semaphore.h
     *
     * Note that this at least correctly checks/locks cmd_busy,
     * unlike PosKbdSendData and CanposPosKbdSendData which do not
     * correctly check/set it.  In fact none of the bits that use "cmd_retries"
     * are correct; they don't even abort processing if cmd_retries reaches 0,
     * they send data out anyway, breaking whoever else is sending data out.
     */
    if (test_and_set_bit(0, &cmd_busy)) {
        rc = wait_event_interruptible_timeout(wq, cmd_busy,
                                              msecs_to_jiffies(5000));
        if (0 > rc) {
            aip_error("interrupted while waiting for cmd_busy to clear\n");
            vfree(buffer);
            return -EINTR;
        } else if (0 == rc) {
            aip_error("timeout while waiting for cmd_busy to clear\n");
            vfree(buffer);
            return -ETIMEDOUT;
        }

        if (test_and_set_bit(0, &cmd_busy)) {
            aip_error("someone grabbed cmd_busy before I could lock it\n");
            return -EBUSY;
        }
    }

    aipikbps_in_user_call = 1;

    do {
        aip_dbg("sending %d bytes to kbd\n", size);

        if (size == 1 && buffer[0] == SCANCODE_PS2_RESET)
        {
            aipikbps_reset_sent = 1;
        }

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 16)
        if ((rc = pos_filter.write_data(buffer, size, &xferred, 2, 500)))
            aip_error("pos_filter.write_data returned error %d\n", rc);
#else
        if ((rc = aipikbps_write_buffer(buffer, size, &xferred, 2, 500)))
            aip_error("aipikbps_write_buffer() returned error %d\n", rc);
#endif

        /* the kernel patch misses ACK, and does
         * not increment the xferred count
         */
        if (rc == (-EINTR))
            xferred++;

/* Additional Lines */
#if defined(V4690)
        /*This part of code was added to fix the defect IO19485
          Enhanced 745 terminals with PS/2-ANPOS KB dump*/
        else if (aipikbps_statusANPOS == TRUE
                 && rc == (-ETIMEDOUT)) {
            /* We are here because there was a timeout waiting for an ACK.  Either:
             *   - the keyboard did not get the command, therefore never issued the ACK
             *   - the keyboard got the command, but the ACK was never received by the host
             * We have no way of knowing which is the case. We can either treat as a fatal error
             * (and/or dump), or try to recover by guessing one of these scenarios.  Since we have
             * seen this problem in the field and it did appear the keyboard got the command, we
             * will assume the first scenario (and cross our fingers!!).  Either way, we will log
             * this occurence.
             */
            xferred++;
            lostACKcount++;
            aip_error("aipikbps statusANPOS executed: %d\n",lostACKcount);
        }
#endif

        if (xferred < size) {
            buffer += xferred;
            size -= xferred;
            xferred = 0;
        }
    } while (xferred < size && xfer_retry--);

    if (xferred < size) {
        aip_error("did not transfer all data\n");
        if (!rc)
            rc = -ETIMEDOUT;
    }

    vfree(buffer);
    aipikbps_command_finish();

    aipikbps_in_user_call = 0;

    return rc ? rc : count;
#else
    aip_dbg("character device: %s\n", DEVDRVR_ID);

    return -EINVAL;
#endif
}


int kb_canpos_read_config(unsigned char *buffer, unsigned short length)
{
    int                   rc = SUCCESS;
    uint32_t              CompletionCode;
    int                   i,j;
    int                   readConfigErr = 0;

    PPOS_CANPOS_READ_CONFIG  pCanposReadConfig;
    char Canpos_read_config_cmd[] = {0xE4, 0xC1, 0xC2, 0xC3};
    unsigned char        *pBuffer = (unsigned char *) Canpos_read_config_cmd;

    aip_dbg("enter\n");

    if (pPosKbdData->CanposKeyboard != 1) {
        /* invalid command */
        CompletionCode = RPERR;

        if (copy_to_user(&((POS_CANPOS_READ_CONFIG *) buffer)->CompletionCode,
                         &CompletionCode, sizeof(CompletionCode)) != 0) {
            rc = -EFAULT;
        }

        aip_error("Not a CANPOS KBD\n");

        return rc;
    }

    pPosKbdData->CanposState = CANPOS_COLLECT_READ_CONFIG_DATA;
    pPosKbdData->CanposConfigBytesCollected = 0;
    pPosKbdData->canposConfigAck = 0;

    aip_dbg("send config read command\n");

    rc = CanposPosKbdSendData(pBuffer, sizeof(Canpos_read_config_cmd));
    if (rc == 0) {
        aip_dbg("send success\n");
    } else {
        aip_dbg("send failed!! rc=%x\n", rc);

        pPosKbdData->CanposState = CANPOS_READY;
        readConfigErr = 1;
    }

/*  gha - PROBLEM:  SEV 1 APAR HERE if State never set to READY!!!!!  */
    while (pPosKbdData->CanposState == CANPOS_COLLECT_READ_CONFIG_DATA) {
        /* wait here */
        if (pPosKbdData->CanposState == CANPOS_READY)
            break;

        mdelay(20);
    }

    /* Convert and copy canpos configuration data to user data
     * configuration data start at offset 9 (or 10 for new code) and
     * is converted to specific format before transmitt.
     * For example, byte 0xab is converted to 0x9a and 0xab, byte 00
     * is converted to 0x90 and 0xa0
     */
    j = pPosKbdData->canposConfigAck + 6;   /* index to user data */

    /* 9 for older code (with 3 ack),
     * 10 for code with 4 ack
     */
    i = 0;
    pCanposReadConfig         = (PPOS_CANPOS_READ_CONFIG) buffer;
    pCanposReadConfig->length = CANPOS_READ_CONFIG_SIZE;

    while (i <  pCanposReadConfig->length) {
        /* even bytes */
        pCanposReadConfig->Data[j] = (pPosKbdData->canpos_config.Data[i++] & 0x0f) << 4;

        /* odd bytes */
        pCanposReadConfig->Data[j] |= (pPosKbdData->canpos_config.Data[i++] & 0x0f);
        j++;
    }

    wake_up_canpos_process();
    if (readConfigErr)
        CompletionCode = RPERR;
    else
        CompletionCode = RPDONE;

    if (copy_to_user(&((POS_CANPOS_READ_CONFIG *) buffer)->CompletionCode,
                     &CompletionCode, sizeof(CompletionCode)) != 0) {
        rc = -EFAULT;
    }

    aip_dbg("exit rc=%d, CompletionCode=%x\n", rc, CompletionCode);

    return rc;
}


int kb_canpos_write_config(unsigned char *buffer, unsigned short length)
{
    int                   rc = SUCCESS;
    unsigned char         LRC = 0;
    int                   i;

    PPOS_CANPOS_WRITE_CONFIG pCanposWriteConfig = (PPOS_CANPOS_WRITE_CONFIG) buffer;
    char Canpos_write_config_cmd[] = {0xE3, 0xC1, 0xC2, 0xC3};
    unsigned char        *pBuffer = (unsigned char *) Canpos_write_config_cmd;
    unsigned char         *configData = NULL;

    aip_dbg("enter\n");

    if (pPosKbdData->CanposKeyboard != 1) {
        /* invalid Keyboard */
        aip_error("Not a CANPOS KBD\n");

        return -EINVAL;
    }

    /* allocate memory to hold flash data + 2 bytes length * 1 byte
     * LRC
     */
    if (!(configData = (unsigned char *)vmalloc(W_CONFIG_SIZE + 1))) {
        aip_error("Cannot allocate memory for config data\n");

        return -EINVAL;
    }

    if (copy_from_user(configData, pCanposWriteConfig->Data,
                       sizeof(pCanposWriteConfig->Data))) {
        aip_error("copy user's config data failed\n");

        /* free memory */
        if (configData != NULL)
            vfree(configData);

        return -EINVAL;
    }

    /* Defect fix, some utility generated LRC for configuration file!
     */
    configData[0] = 0;

    /* compute the lrc */
    /* XAC simply xor all bytes -- !!!!! */
    for (i = 0; i < W_CONFIG_SIZE; i++)
        LRC = (unsigned char) (LRC ^ configData[i]);

    configData[0] = (unsigned char) LRC;

    /* Sending Config Command */
    pPosKbdData->CanposState = CANPOS_COLLECT_NORMAL_ACK;

    rc = CanposPosKbdSendData(pBuffer, sizeof(Canpos_write_config_cmd));

    aipikbps_timeout(100);

    if (pPosKbdData->CanposState == CANPOS_GOT_CONFIG_KEY_1) {
        rc = 0;
    }

    /* come here */
    if (rc != 0) {
        aip_error("Send config cmd failed!! rc=%x\n", rc);

        pPosKbdData->CanposState = CANPOS_READY;

        /* free memory */
        if (configData != NULL)
            vfree(configData);

        return -EINVAL;
    }

    if (pPosKbdData->CanposState != CANPOS_GOT_CONFIG_KEY_1) {
        aip_error("Error-Not Rxed KeyPress 1\n");

        pPosKbdData->CanposState = CANPOS_READY;

        /* free memory */
        if (configData != NULL)
            vfree(configData);

        return -EINVAL;
    }

    /* write cofiguration data */
    pPosKbdData->canposConfigAck = 0;
    pPosKbdData->CanposState = CANPOS_COUNT_WRITE_CONFIG_ACK;

    /* How is this going to work reliably???  The Data size is the
     * same as the config size.  This byte is being stuffed into
     * a location not allocated
     */
    configData[W_CONFIG_SIZE] = 0xE5;

    rc = CanposPosKbdSendData(configData, W_CONFIG_SIZE + 1);

    /* Wait for CANPOS ACK*/
    aipikbps_timeout(50);

    if (pPosKbdData->CanposState == CANPOS_GOT_CONFIG_KEY_1) {
        rc = 0;
    }

    if (rc != 0) {
        aip_error("Send config data Failed!! rc=%x\n", rc);

        pPosKbdData->CanposState = CANPOS_READY;
        pPosKbdData->canposConfigAck = 0;

        /* free memory */
        if (configData != NULL)
            vfree(configData);

        return -EINVAL;
    }

    if (pPosKbdData->CanposState != CANPOS_GOT_CONFIG_KEY_1) {
        aip_error("Error-Not Rxed KeyPress 1\n");

        pPosKbdData->CanposState = CANPOS_READY;
        pPosKbdData->canposConfigAck = 0;

        /* free memory */
        if (configData != NULL)
            vfree(configData);

        return -EINVAL;
    }

    rc = SUCCESS;

    pPosKbdData->CanposState = CANPOS_READY;
    pPosKbdData->canposConfigAck = 0;

    /* free memory */
    if (configData != NULL)
        vfree(configData);

    aip_dbg("exit\n");

    return rc;
}


int kb_canpos_flash_update(unsigned char *buffer, unsigned short length)
{
    int            rc = SUCCESS;
    unsigned char  LRC = 0;
    unsigned char *flashData;
    int            i;

    PPOS_CANPOS_FLASH_UPDATE  pCanposFlash;
    char Canpos_flash_cmd[] = {0xE6, 0xC1, 0xC2, 0xC3};
    unsigned char        *pBuffer = (unsigned char *) Canpos_flash_cmd;

    aip_dbg("enter\n");

    if (pPosKbdData->CanposKeyboard != 1) {
        /* invalid command */
        aip_error("Not a CANPOS KBD\n");

        return -EINVAL;
    }

    pCanposFlash = (PPOS_CANPOS_FLASH_UPDATE) buffer;
    pPosKbdData->flashSize = pCanposFlash->length;

    aip_dbg("flash size=%d\n", pPosKbdData->flashSize);

    /* allocate memory to hold flash data + 2 bytes length * 1 byte
     * LRC
     */
    if (!(flashData = (unsigned char *)vmalloc(pPosKbdData->flashSize+3))) {
        aip_error("Cannot allocate memory for flash");

        return -EINVAL;
    }

    if (copy_from_user(&flashData[2], pCanposFlash->Data,
                       pPosKbdData->flashSize)) {
        aip_error("copy user's flash data failed\n");

        /* free memory */
        if (flashData != NULL)
            vfree(flashData);

        return -EINVAL;
    }

    /* add size bytes */
    flashData[0] = (unsigned char)(pPosKbdData->flashSize >> 8);
    flashData[1] = (unsigned char)pPosKbdData->flashSize;

    aip_dbg("size: hi=%x, lo= %x\n", flashData[0], flashData[1]);

    /* computer the lrc
     * XAC simply xor all bytes -- !!!!!
     */
    LRC = 0;
    for (i = 0; i < (pPosKbdData->flashSize + 2); i++)
        LRC = (unsigned char) (LRC ^ flashData[i]);

    flashData[pPosKbdData->flashSize+2] = (unsigned char) LRC;

    /* send flash cmd */
    pBuffer = (unsigned char *)Canpos_flash_cmd;

    pPosKbdData->CanposState = CANPOS_COLLECT_NORMAL_ACK;

    rc = CanposPosKbdSendData(pBuffer, sizeof(Canpos_flash_cmd));

    /* Give time to KBD to process Flash CMD*/
    aipikbps_timeout(500);

    if (pPosKbdData->CanposState == CANPOS_GOT_CONFIG_KEY_1) {
        rc = 0;
    }

    /* come here */
    if (rc != 0) {
        aip_error("Send flash cmd failed!!rc=%x\n", rc);

        /* free memory */
        if (flashData != NULL)
            vfree(flashData);

        pPosKbdData->CanposState = CANPOS_READY;
        return -EINVAL;
    }

    if (pPosKbdData->CanposState != CANPOS_GOT_CONFIG_KEY_1) {
        aip_error("Error-Not Rxed KeyPress 1.\n");

        /* free memory */
        if (flashData != NULL)
            vfree(flashData);

        pPosKbdData->CanposState = CANPOS_READY;
        return -EINVAL;
    }

    /* Up to this point, every thing ok, send  flash data
     * keep up with the acks
     */
    pPosKbdData->canposFlashAck = 0;
    pPosKbdData->CanposState = CANPOS_COUNT_FLASH_ACK;

    aip_dbg("send flash data\n");

    rc = CanposPosKbdSendData(flashData, (int)(pPosKbdData->flashSize+3));

    /* Stop here to give enough time to process */
    aipikbps_timeout(1000);

    if (pPosKbdData->CanposState == CANPOS_GOT_CONFIG_KEY_1) {
        rc = 0;
    }

    if (rc != 0) {
        aip_error("Send flash data failed!! rc=%x\n", rc);

        /* free memory */
        if (flashData != NULL)
            vfree(flashData);

        pPosKbdData->canposFlashAck = 0;
        pPosKbdData->CanposState = CANPOS_READY;
        return -EINVAL;
    }

    if (pPosKbdData->CanposState != CANPOS_GOT_CONFIG_KEY_1) {
        aip_error("Error-Not Rxed KeyPress 1\n");

        /* free memory */
        if (flashData != NULL)
            vfree(flashData);

        pPosKbdData->canposFlashAck = 0;
        pPosKbdData->CanposState = CANPOS_READY;
        return -EINVAL;
    }

    pPosKbdData->canposFlashAck = 0;
    pPosKbdData->CanposState = CANPOS_READY;

    /* free memory */
    if (flashData != NULL)
        vfree(flashData);

    aip_dbg("exit\n");

    return SUCCESS;
}


int kb_canpos_query_keyboard(unsigned char *buffer, unsigned short length)
{
    int                   rc = SUCCESS;
    int                   i;

    MODQUERY_KEYBOARD_PARMS     QueryKeyboard;
    MODQUERY_KEYBOARD_PARMS_V1  QueryKeyboardV1;
    unsigned char Canpos_query_config_cmd[]  = {0xE1, 0xC5, 0xCA};
    unsigned char Canpos_query_config_cmd1[] = {0xE2};
    unsigned char        *pBuffer = (unsigned char *)Canpos_query_config_cmd;

    aip_dbg("Enter\n");

    /* Send Ver Info Command. */
    pPosKbdData->CanposState = CANPOS_COLLECT_NORMAL_ACK;

    rc = CanposPosKbdSendData(pBuffer, 3);

    /* Wait for CANPOS ACK*/
    aipikbps_timeout(50);

    if (pPosKbdData->CanposState == CANPOS_GOT_CONFIG_KEY_1) {
        rc = 0;
    }

    if (rc != 0) {
        pPosKbdData->CanposState = CANPOS_READY;

        aip_error("Send Version Info cmd failed!! rc=%x\n", rc);
        return -EINVAL;
    }

    if (pPosKbdData->CanposState != CANPOS_GOT_CONFIG_KEY_1) {
        pPosKbdData->CanposState = CANPOS_READY;

        aip_error("Error-Not Rxed KeyPress 1\n");
        return -EINVAL;
    }

    /* Send Version Info Command 2 */
    pPosKbdData->CanposState = CANPOS_COLLECT_VER_INFO_START;
    pPosKbdData->verinfosize = 0;
    pBuffer = (unsigned char *) Canpos_query_config_cmd1;

    rc = CanposPosKbdSendData(pBuffer, 1);

    /* Give enough time to receive FW information*/
    set_current_state(TASK_UNINTERRUPTIBLE);
    aipikbps_timeout(100);

    if (pPosKbdData->CanposState == CANPOS_COLLECT_VER_INFO_COLLECTED) {
        rc = 0;
    }

    if (rc != 0) {
        pPosKbdData->verinfosize = 0;
        pPosKbdData->CanposState = CANPOS_READY;

        aip_error("Send config data Failed - rc=%x\n", rc);
        return -EINVAL;
    }

    if (pPosKbdData->CanposState != CANPOS_COLLECT_VER_INFO_COLLECTED) {
        pPosKbdData->verinfosize = 0;
        pPosKbdData->CanposState = CANPOS_READY;

        aip_error("Error-Collecting Version Info\n");
        return -EINVAL;
    }

    pPosKbdData->verinfosize = 0;
    pPosKbdData->CanposState = CANPOS_READY;

    if (length > sizeof(MODQUERY_KEYBOARD_PARMS_V1)) {
        for (i = 0; i < VER_INFO_SIZE; i++)
            QueryKeyboard.data[i] = pPosKbdData->verinfo[i];

        if (copy_to_user((MODQUERY_KEYBOARD_PARMS *)buffer,
                         (unsigned char *) &QueryKeyboard,
                         sizeof(MODQUERY_KEYBOARD_PARMS)) != 0) {
            return -EFAULT;
        }
    } else {
        for (i = 0; i < VER_INFO_SIZE; i++)
            QueryKeyboardV1.data[i] = pPosKbdData->verinfo[i];

        if (copy_to_user((MODQUERY_KEYBOARD_PARMS_V1 *)buffer,
                         (unsigned char *) &QueryKeyboardV1,
                         sizeof(MODQUERY_KEYBOARD_PARMS_V1)) != 0) {
            return -EFAULT;
        }
    }

    aip_dbg("exit\n");

    return SUCCESS;
}


int kb_set_pos_leds(unsigned char *buffer, unsigned short length)
{
    int                 rc = SUCCESS;
    uint32_t            CompletionCode = RPDONE;
    KBD_SET_INDICATORS  setIndicators;
    unsigned char      *pBuffer = (unsigned char *) &setIndicators;

    aip_dbg("enter\n");

    /* Save the POS LED state. */
    pPosKbdData->KeyboardIndicators.POSLedFlags = ((PPOSLEDS) buffer)->posLEDs;

    /* Setup Pos Leds command to send. */
    setIndicators.Command = POS_LEDS_COMMAND;
    setIndicators.Parm1   = pPosKbdData->KeyboardIndicators.POSLedFlags;

    /* State of Leds from Linux is saved in KeyboardIndicators.LedFlags */
    /* -- set state of caps_lock, num_lock, scroll_lock from there.     */
    setIndicators.Parm1 |= (unsigned char) (pPosKbdData->KeyboardIndicators.LedFlags);

    rc = PosKbdSendData(pBuffer, sizeof(setIndicators), 1000);


    if (copy_to_user(&((POSLEDS *) buffer)->CompletionCode,
                     &CompletionCode, sizeof(CompletionCode)) != 0)
        rc = -EFAULT;

    aip_dbg("exit  rc=%d\n", rc);

    return rc;
}


int kb_set_tone(unsigned char *buffer, unsigned short length)
{
    int            rc = SUCCESS;
    uint32_t       CompletionCode = RPDONE;
    KBD_SET_TONE   setTone;
    unsigned char *pBuffer = (unsigned char *) &setTone;
    unsigned char  bytesToSend;

    aip_dbg("enter\n");

    /* Setup Tone command to send. */
    setTone.Command = POS_TONE_COMMAND;
    setTone.Parm1 = ((PTONE) buffer)->tone1;
    setTone.Parm2 = ((PTONE) buffer)->tone2;

    /* If Tone ON or Tone OFF (0x60), then send 2 bytes, otherwise
     * send three bytes.  The third byte contains the tone duration.
     */
    bytesToSend = (setTone.Parm1 & 0x60) ? 2 : 3;

    rc = PosKbdSendData(pBuffer, bytesToSend, 1000);

    if (copy_to_user(&((TONE *) buffer)->CompletionCode,
                     &CompletionCode, sizeof(CompletionCode)) != 0)
        rc = -EFAULT;

    aip_dbg("exit  rc=%d\n", rc);

    return rc;
}


int kb_set_click(unsigned char *buffer, unsigned short length)
{
    int                 rc = SUCCESS;
    uint32_t            CompletionCode = RPDONE;
    unsigned char       setConfig[KBD_CONFIGURE_CMD_LENGTH];
    unsigned char      *pBuffer = (unsigned char *) &setConfig;

    aip_dbg("enter\n");

    switch (((PCLICK) buffer)->fClick) {
    case PosOFF:
        pPosKbdData->KbdConfigureCmd[1] &= ~(POS_CLICK_LOUD |
                                             POS_CLICK_SOFT);
        break;

    case PosSOFT:
        pPosKbdData->KbdConfigureCmd[1] &= ~(POS_CLICK_LOUD);
        pPosKbdData->KbdConfigureCmd[1] |= (POS_CLICK_SOFT);
        break;

    case PosLOUD:
        pPosKbdData->KbdConfigureCmd[1] &= ~(POS_CLICK_SOFT);
        pPosKbdData->KbdConfigureCmd[1] |= (POS_CLICK_LOUD);
        break;
    }

    /* Copy configure command into local buffer. */
    setConfig[0] = pPosKbdData->KbdConfigureCmd[0];
    setConfig[1] = pPosKbdData->KbdConfigureCmd[1];
    setConfig[2] = pPosKbdData->KbdConfigureCmd[2];
    setConfig[3] = pPosKbdData->KbdConfigureCmd[3];

    rc = PosKbdSendData(pBuffer, sizeof(setConfig), 1000);

    if (copy_to_user(&((CLICK *) buffer)->CompletionCode,
                     &CompletionCode, sizeof(CompletionCode)) != 0)
        rc = -EFAULT;

    aip_dbg("exit  rc=%d\n", rc);

    return rc;
}



int kb_set_typematic(unsigned char *buffer, unsigned short length)
{
    int                 rc = SUCCESS;
    uint32_t            CompletionCode = RPDONE;
    unsigned char       setConfig[KBD_CONFIGURE_CMD_LENGTH];
    unsigned char      *pBuffer = (unsigned char *) &setConfig;

    aip_dbg("enter\n");

    /* First save the info into device extension. */
    if (((PTYPEMATIC) buffer)->fTypematic)
        pPosKbdData->KbdConfigureCmd[1] |= POS_TYPEMATIC_ON;
    else
        pPosKbdData->KbdConfigureCmd[1] &= ~POS_TYPEMATIC_ON;

    /* First copy what is in the configure command. */
    setConfig[0] = pPosKbdData->KbdConfigureCmd[0];
    setConfig[1] = pPosKbdData->KbdConfigureCmd[1];
    setConfig[2] = pPosKbdData->KbdConfigureCmd[2];
    setConfig[3] = pPosKbdData->KbdConfigureCmd[3];

    rc = PosKbdSendData(pBuffer, sizeof(setConfig), 1000);

    if (copy_to_user(&((TYPEMATIC *) buffer)->CompletionCode,
                     &CompletionCode, sizeof(CompletionCode)) != 0)
        rc = -EFAULT;

    aip_dbg("exit  rc=%d\n", rc);

    return rc;
}


int kb_enable_disable(unsigned char *buffer, unsigned short length)
{
    int                 rc = SUCCESS;
    uint32_t            CompletionCode = RPDONE;
    unsigned char       setConfig[KBD_CONFIGURE_CMD_LENGTH];
    unsigned char      *pBuffer = (unsigned char *) &setConfig;

    aip_dbg("enter\n");

    /* First save the info into device extension. */
    if (((PENABLE_DISABLE) buffer)->fEnable)
        pPosKbdData->KbdConfigureCmd[1] |= POS_SCANNING_ON;
    else
        pPosKbdData->KbdConfigureCmd[1] &= ~POS_SCANNING_ON;

    /* First copy what is in the configure command. */
    setConfig[0] = pPosKbdData->KbdConfigureCmd[0];
    setConfig[1] = pPosKbdData->KbdConfigureCmd[1];
    setConfig[2] = pPosKbdData->KbdConfigureCmd[2];
    setConfig[3] = pPosKbdData->KbdConfigureCmd[3];

    rc = PosKbdSendData(pBuffer, sizeof(setConfig), 1000);

    if (copy_to_user(&((ENABLE_DISABLE *) buffer)->CompletionCode,
                     &CompletionCode, sizeof(CompletionCode)) != 0) {
        rc = -EFAULT;
    }

    aip_dbg("exit  rc=%d\n", rc);

    return rc;
}


int kb_set_msr_tracks(unsigned char *buffer, unsigned short length)
{
    int                 rc = SUCCESS;
    uint32_t            CompletionCode = RPDONE;
    unsigned char       setTracks[MSR_CONFIGURE_CMD_LENGTH];

    aip_dbg("enter\n");

    setTracks[0] = pPosKbdData->MsrConfigureCmd[0];

    setTracks[1] = (unsigned char) ((PTRACKS) buffer)->track1enabled
                   ? 0x1 : 0x00;

    setTracks[1] |= (unsigned char) ((PTRACKS) buffer)->track2enabled
                    ? 0x2 : 0x00;

    setTracks[1] |= (unsigned char) ((PTRACKS) buffer)->track3enabled
                    ? 0x4 : 0x00;

    setTracks[1] |= (unsigned char) ((PTRACKS) buffer)->trackJenabled
                    ? 0x8 : 0x00;

    if (length > sizeof(TRACKS_V1)) {
        setTracks[1] |= (unsigned char) ((PTRACKS) buffer)->extdatareportenabled
                        ? 0x20 : 0x00;
    }
    pPosKbdData->MsrConfigureCmd[1] = setTracks[1];

    rc = PosKbdSendData((unsigned char *) &setTracks, sizeof(setTracks), 1000);

    if (copy_to_user(&((TRACKS *) buffer)->CompletionCode,
                     &CompletionCode, sizeof(CompletionCode)) != 0)
        rc = -EFAULT;

    aip_dbg("exit  rc=%d\n", rc);

    return rc;
}


int kb_set_trap_keys(unsigned char *buffer, unsigned short length)
{
    int                 rc = SUCCESS;
    uint32_t            CompletionCode = RPDONE;

    aip_dbg("enter\n");

    pPosKbdData->fTrap = ((PTRAP_KEYS) buffer)->fTrapKeys;

    if (copy_to_user(&((TRAP_KEYS *) buffer)->CompletionCode,
                     &CompletionCode, sizeof(CompletionCode)) != 0) {
        rc = -EFAULT;
    }

    aip_dbg("exit  rc=%d\n", rc);

    return rc;
}


int kb_set_double_keys(unsigned char *buffer, unsigned short length)
{
    int                 rc = SUCCESS;
    uint32_t            CompletionCode = RPDONE;
    PDOUBLE_KEYS        pParms = (PDOUBLE_KEYS) buffer;
    int                 dblKey109108 = 0;
    int                 i = 0;
    int                 j = 0;

    aip_dbg("enter\n");

    memset(&pPosKbdData->doubleKey, 0,
           MAX_DOUBLE_KEYS * sizeof(DOUBLE_KEY));

    pPosKbdData->nDoubleKeys = ((PDOUBLE_KEYS) buffer)->length;
    pPosKbdData->double_key_active = 0;

    aip_dbg("Double Keys: total=%d\n", pPosKbdData->nDoubleKeys);


    while (j < pPosKbdData->nDoubleKeys) {
        pPosKbdData->doubleKey[i].primaryKey = pParms->buffer[j++];
        pPosKbdData->doubleKey[i].secondaryKey = pParms->buffer[j++];
        pPosKbdData->doubleKey[i].primaryMake = 0;
        pPosKbdData->doubleKey[i].secondaryMake = 0;
        pPosKbdData->doubleKey[i].lastKey = 0;

        /* Need to set flag if key switches 109 & 108 are doubled
         */
        if ((pPosKbdData->doubleKey[i].primaryKey == 109) &&
            (pPosKbdData->doubleKey[i].secondaryKey == 108))
            dblKey109108 = 1;

        aip_dbg("Double Keys: uBuf Key 1=%d, Key 2=%d\n",
                pParms->buffer[j-2], pParms->buffer[j-1]);

        aip_dbg("Double Keys: kBuf Key 1=%d, Key 2=%d \n",
                pPosKbdData->doubleKey[i].primaryKey,
                pPosKbdData->doubleKey[i].secondaryKey);
        i++;
    }

    if (dblKey109108)
        pPosKbdData->fStatus |= DOUBLE_KEYS_109_108;
    else
        pPosKbdData->fStatus &= ~DOUBLE_KEYS_109_108;

    /* Reset it to actual number of double keys. */
    pPosKbdData->nDoubleKeys = i;

    if (copy_to_user(&((DOUBLE_KEYS *) buffer)->CompletionCode,
                     &CompletionCode, sizeof(CompletionCode)) != 0)
        rc = -EFAULT;

    aip_dbg("exit  rc=%d\n", rc);

    return rc;
}


int kb_get_shift_state(unsigned char *buffer, unsigned short length)
{
    int                 rc = SUCCESS;
    uint32_t            CompletionCode = RPDONE;

    aip_dbg("enter\n");

    /* This function implemented in USER MODE, but not
     * in KERNEL MODE.
     */
    if (copy_to_user(&((SHIFT_STATE *) buffer)->CompletionCode,
                     &CompletionCode, sizeof(CompletionCode)) != 0)
        rc = -EFAULT;

    aip_dbg("exit  rc=%d\n", rc);

    return rc;
}


int kb_set_shift_state(unsigned char *buffer, unsigned short length)
{
    int                 rc = SUCCESS;
    uint32_t            CompletionCode = RPDONE;
    KBD_SET_INDICATORS  setIndicators;
    unsigned char      *pBuffer = (unsigned char *) &setIndicators;
    unsigned char       LedFlags = 0;

    aip_dbg("enter\n");

    /* This function is implemnted in USER MODE  - not in KERNEL.
     * The driver obtains initial state of LEDs from user mode from
     * aipanpos utility.
     */
    pPosKbdData->KeyboardIndicators.LedFlags = (((PSHIFT_STATE) buffer)->state);
    LedFlags = pPosKbdData->KeyboardIndicators.LedFlags;

    /* Modify the shift state to match the keyboard state */
    if (LedFlags & SCROLL_LOCK_ON)
        pPosKbdData->ShiftFlags |= SCROLL_LOCK_DOWN;
    else
        pPosKbdData->ShiftFlags &= ~SCROLL_LOCK_DOWN;

    if (LedFlags & NUM_LOCK_ON)
        pPosKbdData->ShiftFlags |= NUM_LOCK_DOWN;
    else
        pPosKbdData->ShiftFlags &= ~NUM_LOCK_DOWN;

    if (LedFlags & CAPS_LOCK_ON)
        pPosKbdData->ShiftFlags |= CAPS_LOCK_DOWN;
    else
        pPosKbdData->ShiftFlags &= ~CAPS_LOCK_DOWN;

    /* Need to send the updated state to the keyboard. POS LEDs and "normal"
     * LEDs are in the same byte...
     */

    /* Setup Pos Leds command to send. */
    setIndicators.Command = POS_LEDS_COMMAND;

    /* State of POS Leds is saved in KeyboardIndicators.POSLedFlags */
    setIndicators.Parm1   = pPosKbdData->KeyboardIndicators.POSLedFlags;

    /* Set state of caps_lock, num_lock, scroll_lock as set here.     */
    setIndicators.Parm1 |= LedFlags;

    rc = PosKbdSendData(pBuffer, sizeof(setIndicators), 1000);

    if (copy_to_user(&((SHIFT_STATE *) buffer)->CompletionCode,
                     &CompletionCode, sizeof(CompletionCode)) != 0)
        rc = -EFAULT;

    aip_dbg("exit  rc=%d\n", rc);

    return rc;
}


int kb_query_keyboard(unsigned char *buffer, unsigned short length)
{
    int                      rc = SUCCESS;
    uint32_t                 CompletionCode = RPDONE;
    QUERY_KEYBOARD_PARMS     QueryKeyboard;
    QUERY_KEYBOARD_PARMS_V1  QueryKeyboardV1;
    unsigned short           keyboardSubtype = 0;
    unsigned short           keyboardID = 0;

    aip_dbg("enter - DeviceID=%04x\n", pPosKbdData->PosKbdDeviceInfo.deviceID);

    if (pPosKbdData->PosKbdDeviceInfo.deviceID)
        keyboardID = OB_KBD;

    if (pPosKbdData->CanposKeyboard) {
        aip_dbg("Found a CANPOS Keybaord\n");
        keyboardSubtype = 3;          /* CANPOS */
    } else {
        switch (pPosKbdData->PosKbdDeviceInfo.deviceID) {
        case  0x04:
            keyboardSubtype =  1;     /* ANPOS_V1 */
            break;
        case  0x05:
            keyboardSubtype = 2;      /* ANKPOS */
            break;
        case  0x08:
            if (pPosKbdData->PosKbdDeviceInfo.CommandSet == 0x04)
                keyboardSubtype = 9;      /* 67-Key */
            else
                keyboardSubtype = 4;      /* IBM 4820 */

            break;
        case  0x09:
            keyboardSubtype = 7;      /* ANPOS_V2 */
            break;
        case  0x0A:
            keyboardSubtype = 8;      /* CANPOS_V2 */
            break;
        }
    }

    if (length > sizeof(QUERY_KEYBOARD_PARMS_V1)) {
        QueryKeyboard.keyboardID      = keyboardID;
        QueryKeyboard.keyboardSubtype = keyboardSubtype;
        QueryKeyboard.msrType         = pPosKbdData->PosMsrDeviceInfo.deviceID;
        QueryKeyboard.keyboardEC      = pPosKbdData->PosKbdDeviceInfo.ECLevel;
        QueryKeyboard.msrEC           = pPosKbdData->PosMsrDeviceInfo.ECLevel;

        QueryKeyboard.features        = pPosKbdData->PosKbdDeviceInfo.Features;
        QueryKeyboard.featureByte1    = pPosKbdData->PosKbdDeviceInfo.FeatureByte1;
        QueryKeyboard.firmwareVersion = pPosKbdData->PosKbdDeviceInfo.FirmwareVersion;
        QueryKeyboard.firmwareRelease = pPosKbdData->PosKbdDeviceInfo.FirmwareRelease;

        if (copy_to_user(buffer, (unsigned char *) &QueryKeyboard,
                         sizeof(QUERY_KEYBOARD_PARMS)) != 0) {
            rc = -EFAULT;
        }

        if (copy_to_user(&((QUERY_KEYBOARD_PARMS *) buffer)->CompletionCode,
                         &CompletionCode, sizeof(CompletionCode)) != 0) {
            rc = -EFAULT;
        }
    } else {
        QueryKeyboardV1.keyboardID      = keyboardID;
        QueryKeyboardV1.keyboardSubtype = keyboardSubtype;
        QueryKeyboardV1.msrType    = pPosKbdData->PosMsrDeviceInfo.deviceID;
        QueryKeyboardV1.keyboardEC = pPosKbdData->PosKbdDeviceInfo.ECLevel;
        QueryKeyboardV1.msrEC      = pPosKbdData->PosMsrDeviceInfo.ECLevel;

        if (copy_to_user(buffer, (unsigned char *) &QueryKeyboardV1,
                         sizeof(QUERY_KEYBOARD_PARMS_V1)) != 0) {
            rc = -EFAULT;
        }

        if (copy_to_user(&((QUERY_KEYBOARD_PARMS_V1 *) buffer)->CompletionCode,
                         &CompletionCode, sizeof(CompletionCode)) != 0) {
            rc = -EFAULT;
        }
    }

    aip_dbg("exit  rc=%d, ID=%04x, Subtype=%d\n", rc, keyboardID,
            keyboardSubtype);

    return rc;
}


int kb_read_kbd_status(unsigned char *buffer, unsigned short length)
{
    int           rc = SUCCESS;
    uint32_t      CompletionCode = RPDONE;

    /*
    aip_verbose("enter\n");
    */

    /* copy STATUS data */
    if (copy_to_user(((READ_KBD_STATUS_PARMS *) buffer)->buffer,
                     &pPosKbdData->PosKbdStatus.KBDStatus, 4) != 0)
        rc = -EFAULT;

    if (copy_to_user(&((QUERY_KEYBOARD_PARMS *) buffer)->CompletionCode,
                     &CompletionCode, sizeof(CompletionCode)) != 0)
        rc = -EFAULT;

    /*
    aip_dbg("exit rc=%d Status=%02x.%02x.%02x.%02x\n", rc,
            pPosKbdData->PosKbdStatus.KBDStatus[0],
            pPosKbdData->PosKbdStatus.KBDStatus[1],
            pPosKbdData->PosKbdStatus.KBDStatus[2],
            pPosKbdData->PosKbdStatus.KBDStatus[3]);
    */

    return rc;
}


int kb_read_msr_data(unsigned char *buffer, unsigned short length)
{
    int            rc = SUCCESS;
    uint32_t       CompletionCode = RPDONE;

    /*
    aip_verbose("enter\n");
    */

    if (pPosKbdData->MsrROL == TRUE) {
        int           rc_enable = SUCCESS;
        unsigned char setTracks[MSR_CONFIGURE_CMD_LENGTH];

        setTracks[0] = pPosKbdData->MsrConfigureCmd[0];
        setTracks[1] = pPosKbdData->MsrConfigureCmd[1];

        rc_enable = PosKbdSendData((unsigned char *) &setTracks,
                                   sizeof(setTracks), 1000);

        if (rc_enable == SUCCESS)
            pPosKbdData->MsrROL = FALSE;
    }

    if (pPosKbdData->MSRData.MSRDataLength &&
        !(pPosKbdData->fStatus & COLLECTING_MSR_STATUS)) {

        if (copy_to_user(((PREAD_MSR_DATA_PARMS) buffer)->buffer,
                         &pPosKbdData->MSRData.MSRDataBuffer,
                         pPosKbdData->MSRData.MSRDataLength) != 0)
            rc = -EFAULT;

        if (copy_to_user(&(((PREAD_MSR_DATA_PARMS) buffer)->length),
                         &pPosKbdData->MSRData.MSRDataLength,
                         sizeof(pPosKbdData->MSRData.MSRDataLength)) != 0)
            rc = -EFAULT;

        /*
        aip_dbg("MSR Buffer (length=%ld) buffer=%02x.%02x.%02x.%02x.%02x.%02x.%02x, ...\n",
                pPosKbdData->MSRData.MSRDataLength,
                pPosKbdData->MSRData.MSRDataBuffer[0],
                pPosKbdData->MSRData.MSRDataBuffer[1],
                pPosKbdData->MSRData.MSRDataBuffer[2],
                pPosKbdData->MSRData.MSRDataBuffer[3],
                pPosKbdData->MSRData.MSRDataBuffer[4],
                pPosKbdData->MSRData.MSRDataBuffer[5],
                pPosKbdData->MSRData.MSRDataBuffer[6]);
        */
        /* Reset MSR Data Length */
        memset(&pPosKbdData->MSRData, 0, sizeof(pPosKbdData->MSRData));

        pPosKbdData->MSRData.MSRDataLength = 0;
    } else {
        uint32_t Length = 0;

        if (copy_to_user(&((READ_MSR_DATA_PARMS *) buffer)->length,
                         &Length, sizeof(Length)) != 0)
            rc = -EFAULT;
    }

    if (copy_to_user(&((READ_MSR_DATA_PARMS *) buffer)->CompletionCode,
                     &CompletionCode, sizeof(CompletionCode)) != 0)
        rc = -EFAULT;

    aip_dbg("exit  rc=%d\n", rc);

    return rc;
}


int kb_code_update(unsigned char *buffer, unsigned short length)
{
    int             rc = SUCCESS;
    uint32_t        CompletionCode = RPDONE;
    unsigned char  *pCurUpdate;
    unsigned char  *pNextUpdate;
    unsigned short  CurLength;
    int             i, j;

    aip_verbose("enter\n");

    if (!receivingCodeUpdateData) {
        nextCodeUpdatePosition = 0;
        receivingCodeUpdateData = 1;

        pPosKbdData->RawCodeUpdateData = kzalloc(UPDATE_FILE_SIZE, GFP_KERNEL);
        if (!pPosKbdData->RawCodeUpdateData) {
            aip_dbg("exit  rc=-ENOMEM\n");

            return -ENOMEM;
        }
    }

    if ((((PCODE_UPDATE_DATA) buffer)->length != 0 ) &&
        receivingCodeUpdateData) {

        pCurUpdate = (unsigned char *) ((PCODE_UPDATE_DATA) buffer)->Data;
        CurLength  = ((PCODE_UPDATE_DATA) buffer)->length;

        aip_info("Receiving code update data, position=%d, length=%d\n",
                 nextCodeUpdatePosition, CurLength);

        memcpy(&pPosKbdData->RawCodeUpdateData[nextCodeUpdatePosition],
               pCurUpdate, CurLength);
        nextCodeUpdatePosition += CurLength;
    } else {
        aip_dbg("starting code update\n");

        /* Codeupdate format of the data received is:
         *
         *   o | length | data | length | data | length | data |
         *   o The length of zero indicates end of code update.
         *
         * Data format sent to a V1 keyboard must be:
         *
         *   o | 0x22 (cmd) | length | data |
         *   o | 0x22 (cmd) | 0x00 | must be sent to end code update.
         *
         * Data format sent to a V2 keyboard must be:
         *
         *   o | 0x22 (cmd) | 0x01 --> Start of flash update
         *   o | 0x22 (cmd) | 0x02 | length | record id | data |
         *   o | 0x22 (cmd) | 0x00 | YYYY --> End of flash update
         *                                    YYYY is checksum
         */

        /*
         * Initilize Buffer: Buffer[0] = 0x22 (update command)
         *                   Rest of buffer to zero
         */
        pPosKbdData->fCodeUpdtDone          = 0x00;
        pPosKbdData->CodeUpdate.iUpdate     = 0;
        pPosKbdData->CodeUpdate.iBuffer     = 0;
        pPosKbdData->CodeUpdate.State       = 0;
        pPosKbdData->CodeUpdate.EndOfaBlock = 0;

        for (i = 0;  i < UPDATE_SIZE; i++) {
            pPosKbdData->CodeUpdate.Update[i].Buffer[0] = 0x22;
            pPosKbdData->CodeUpdate.Update[i].Length    = 2;

            for (j = 1; j < MAX_BUFFER_SIZE; j++) {
                pPosKbdData->CodeUpdate.Update[i].Buffer[j] = 0;
            }

            /* For V2 keyboards, update command has second command byte:
            *      2201h -- start (no data included)
            *      2202h -- flash update record (data included)
            *      2200h -- end (checksum included)
            *
            * Fill in all second bytes as 0x02 and we'll change first/last
            * later
            */
            if (pPosKbdData->v2Keyboard)
                pPosKbdData->CodeUpdate.Update[i].Buffer[1] = 0x02;
        }

        /* Copy the data into devince extension in the correct format.
        */
        pCurUpdate = pPosKbdData->RawCodeUpdateData;
        CurLength  = *pCurUpdate;

        if (CurLength != 0) {

            i = 0;

            if (pPosKbdData->v2Keyboard)
                pNextUpdate = pCurUpdate + (CurLength + 4);
            else
                pNextUpdate = pCurUpdate + (CurLength + 1);

            while (CurLength != 0) {

                /* For V2, Length is only the length of the data and does not
                 * include the length byte or record ID (3 bytes) -- we'll add
                 * those later...
                 */
                pPosKbdData->CodeUpdate.Update[i].Length = CurLength;

                if (pPosKbdData->v2Keyboard) {

                    /* Need to copy (Length + 4) bytes to include
                     * length byte and records id bytes (3).
                     * Data starts in third byte for V2 keyboards.
                    */
                    memcpy(&pPosKbdData->CodeUpdate.Update[i].Buffer[2],
                           pCurUpdate, CurLength + 4);

                    /* With additional cmd bytes (2), length byte, and record
                     * ID bytes (3), the last byte of the buffer is at
                     * ((CurLength + 6) - 1)
                     */
                    aip_dbg("Buffer[%d]: Length=%d  %02x.%02x.%02x.%02x...%02x.%02x.%02x.%02x\n",
                            i,
                            pPosKbdData->CodeUpdate.Update[i].Length,
                            pPosKbdData->CodeUpdate.Update[i].Buffer[0],
                            pPosKbdData->CodeUpdate.Update[i].Buffer[1],
                            pPosKbdData->CodeUpdate.Update[i].Buffer[2],
                            pPosKbdData->CodeUpdate.Update[i].Buffer[3],
                            pPosKbdData->CodeUpdate.Update[i].Buffer[CurLength+2],
                            pPosKbdData->CodeUpdate.Update[i].Buffer[CurLength+3],
                            pPosKbdData->CodeUpdate.Update[i].Buffer[CurLength+4],
                            pPosKbdData->CodeUpdate.Update[i].Buffer[CurLength+5]);

                } else {

                    /* Need to copy (Length + 1) bytes to include
                     * length byte.
                     * Data starts in second byte for V1 keyboards.
                     */
                    memcpy(&pPosKbdData->CodeUpdate.Update[i].Buffer[1],
                           pCurUpdate, CurLength + 1);

                    /* With additional cmd byte and length byte, the last byte
                     * of the buffer is at (CurLength + 1)
                     */
                    aip_dbg("Buffer[%d]: Length=%d  %02x.%02x.%02x.%02x...%02x.%02x.%02x.%02x\n",
                            i,
                            pPosKbdData->CodeUpdate.Update[i].Length,
                            pPosKbdData->CodeUpdate.Update[i].Buffer[0],
                            pPosKbdData->CodeUpdate.Update[i].Buffer[1],
                            pPosKbdData->CodeUpdate.Update[i].Buffer[2],
                            pPosKbdData->CodeUpdate.Update[i].Buffer[3],
                            pPosKbdData->CodeUpdate.Update[i].Buffer[CurLength-2],
                            pPosKbdData->CodeUpdate.Update[i].Buffer[CurLength-1],
                            pPosKbdData->CodeUpdate.Update[i].Buffer[CurLength],
                            pPosKbdData->CodeUpdate.Update[i].Buffer[CurLength+1]);
                }

                i++;
                pCurUpdate = pNextUpdate;

                if (pPosKbdData->v2Keyboard)
                    pNextUpdate += *pNextUpdate + 4;
                else
                    pNextUpdate += *pNextUpdate + 1;

                CurLength = *pCurUpdate;
            }

            /* CurLength = 0
             * For V2, need to get checksum into last record, too
             */
            if (pPosKbdData->v2Keyboard) {

                pPosKbdData->CodeUpdate.Update[i].Length = 2;

                /* Need to copy end indication (00h) and the two bytes
                 * following it (checksum) into buffer.
                 * Data starts in third byte for V2 keyboards.
                 */
                memcpy(&pPosKbdData->CodeUpdate.Update[i].Buffer[2],
                       pCurUpdate, 3);

                aip_dbg("Buffer[%d]: Length=%d  %02x.%02x.%02x.%02x.%02x\n",
                        i,
                        pPosKbdData->CodeUpdate.Update[i].Length,
                        pPosKbdData->CodeUpdate.Update[i].Buffer[0],
                        pPosKbdData->CodeUpdate.Update[i].Buffer[1],
                        pPosKbdData->CodeUpdate.Update[i].Buffer[2],
                        pPosKbdData->CodeUpdate.Update[i].Buffer[3],
                        pPosKbdData->CodeUpdate.Update[i].Buffer[4]);
            }
        }

        /* Now insert an ioctl to handle the actual code update. */
        aip_dbg("Send Code Update\n");

        /* Process the code update. */
        pos_process_code_update();

        receivingCodeUpdateData = 0;
        if (pPosKbdData->RawCodeUpdateData) {
            kfree(pPosKbdData->RawCodeUpdateData);

            pPosKbdData->RawCodeUpdateData = NULL;
        }
    }

    if (copy_to_user(&((CODE_UPDATE_DATA *) buffer)->CompletionCode,
                     &CompletionCode, sizeof(CompletionCode)) != 0)
        rc = -EFAULT;

    aip_dbg("exit  rc=%d\n", rc);

    return rc;
}


int kb_query_code_update(unsigned char *buffer, unsigned short length)
{
    int           rc = SUCCESS;
    uint32_t      CompletionCode = RPDONE;
    CODE_UPDATE_STR  tmpQueryUpdate;

    aip_verbose("enter\n");

    tmpQueryUpdate.fStatus = pPosKbdData->fCodeUpdtDone;

    /* Send the return code through buffer */
    if (copy_to_user((CODE_UPDATE_STR *) buffer, &tmpQueryUpdate,
                     sizeof(CODE_UPDATE_STR)) != 0)
        rc = -EFAULT;

    aip_dbg("fCodeUpdtDone=0x%x, Status=0x%x\n", pPosKbdData->fCodeUpdtDone,
            ((PCODE_UPDATE_STR) buffer)->fStatus);

    if (copy_to_user(&((CODE_UPDATE_STR *) buffer)->CompletionCode,
                     &CompletionCode, sizeof(CompletionCode)) != 0)
        rc = -EFAULT;

    aip_dbg("exit  rc=%d\n", rc);

    return rc;
}


int kb_enable_anpos_async_com(unsigned char *buffer, unsigned short length)
{
    int                           rc = SUCCESS;
    ENABLE_ANPOS_ASYNC_COMM_PARMS Parms;

    aip_verbose("enter\n");

    /* Save process ID to notify, and set flag. */
    if (copy_from_user(&Parms, (void *) buffer, sizeof(Parms)))
        return -EFAULT;

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 27)
    pPosKbdData->asyncPID = (int)Parms.ProcessID;
#else
    pPosKbdData->asyncPID = find_vpid((int) Parms.ProcessID);
#endif
    pPosKbdData->asyncEnabled = 1;

    Parms.CompletionCode = RPDONE;

    if (copy_to_user((void*) buffer, &Parms, sizeof(Parms)))
        rc = -EFAULT;

    /* Send signal right away, so aipctrl can process any
     * pending messages.
     */
    if (pPosKbdData->asyncEnabled) {
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 27)
        kill_proc(pPosKbdData->asyncPID, SIGUSR2, 1);
#else
        kill_pid(pPosKbdData->asyncPID, SIGUSR2, 1);
#endif
    }

    aip_dbg("exit  rc=%d\n", rc);

    return rc;
}


int kb_disable_anpos_async_com(unsigned char *buffer, unsigned short length)
{
    int                         rc = SUCCESS;
    ANPOS_COMPLETION_CODE_PARMS completionCodeParms;

    aip_verbose("enter\n");

    /* reset flag and processID. */
    pPosKbdData->asyncPID     = 0;
    pPosKbdData->asyncEnabled = 0;

    completionCodeParms.CompletionCode = RPDONE;

    if (copy_to_user((ANPOS_COMPLETION_CODE_PARMS *) buffer,
                     &completionCodeParms,
                     sizeof(ANPOS_COMPLETION_CODE_PARMS)))
        rc = -EFAULT;

    aip_dbg("exit  rc=%d\n", rc);

    return rc;
}


#if defined(V4690)
int kb_enable_4690_mode(void)
{
    int rc = SUCCESS;

    aip_verbose("enter\n");

    if (!is4690mode) {
        is4690mode = 1;
    }

    aip_dbg("exit rc=%d, is4690mode=%d\n", rc, is4690mode);


    return rc;
}
#endif


#if defined(V4690)
int kb_disable_4690_mode(void)
{
    int rc = SUCCESS;

    aip_verbose("enter\n");

    if (is4690mode) {
        uint32_t flags;

        is4690mode = 0;

        spin_lock_irqsave(&bufferLock4690, flags);
        statusBufferLength4690 = 0;
        statusBufferCapturingLength4690 = 0;
        spin_unlock_irqrestore(&bufferLock4690, flags);
    }

    aip_dbg("exit rc=%d, is4690mode=%d\n", rc, is4690mode);

    return rc;
}
#endif


/* :H1.kb_ioctl()
 * ***********************************************************************
 *
 * Function Name:  kb_ioctl()
 *
 * Purpose:        driver ioctl routine.
 *
 * Description:    This routine gets called when application sends a
 *                 ioctl request.
 *
 * Output:
 *                 SUCCESS, EINVAL
 *
 * Notes:
 *
 * ***********************************************************************
 */

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 36)
static int kb_ioctl(struct inode *inode, struct file *fp, unsigned int cmd,
                    unsigned long user_buffer)
#else
static long kb_ioctl(struct file *fp, unsigned int cmd, unsigned long user_buffer)
#endif
{
    int            rc = SUCCESS;
    unsigned char *pInputBuffer = (unsigned char *) user_buffer;
    unsigned short  direction = _IOC_DIR(cmd);
    unsigned short  type      = _IOC_TYPE(cmd);
    unsigned short  nr        = _IOC_NR(cmd);
    unsigned short  length    = _IOC_SIZE(cmd);

    aipikbps_in_user_call = 1;

    switch (nr) {

    case _IOC_NR(FN_CANPOS_READ_CONFIG):
        rc = kb_canpos_read_config(pInputBuffer, length);
        break;
    case _IOC_NR(FN_CANPOS_WRITE_CONFIG):
        rc = kb_canpos_write_config(pInputBuffer, length);
        break;
    case  _IOC_NR(FN_CANPOS_FLASH_UPDATE):
        rc = kb_canpos_flash_update(pInputBuffer, length);
        break;
    case _IOC_NR(FN_QUERY_CANPOS_KEYBOARD):
        rc = kb_canpos_query_keyboard(pInputBuffer, length);
        break;
    case _IOC_NR(FN_POS_LEDS):
        rc = kb_set_pos_leds(pInputBuffer, length);
        break;
    case _IOC_NR(FN_TONE):
        rc = kb_set_tone(pInputBuffer, length);
        break;
    case _IOC_NR(FN_CLICK):
        rc = kb_set_click(pInputBuffer, length);
        break;
    case _IOC_NR(FN_TYPEMATIC):
        rc = kb_set_typematic(pInputBuffer, length);
        break;
    case _IOC_NR(FN_ENABLE_DISABLE):
        rc = kb_enable_disable(pInputBuffer, length);
        break;
    case _IOC_NR(FN_TRACKS):
        rc = kb_set_msr_tracks(pInputBuffer, length);
        break;
    case _IOC_NR(FN_TRAP_KEYS):
        rc = kb_set_trap_keys(pInputBuffer, length);
        break;
    case _IOC_NR(FN_SET_DOUBLEKEYS):
        rc = kb_set_double_keys(pInputBuffer, length);
        break;
    case _IOC_NR(FN_GET_SHIFT_STATE):
        rc = kb_get_shift_state(pInputBuffer, length);
        break;
    case _IOC_NR(FN_SET_SHIFT_STATE):
        rc = kb_set_shift_state(pInputBuffer, length);
        break;
    case _IOC_NR(FN_QUERY_KEYBOARD):
        rc = kb_query_keyboard(pInputBuffer, length);
        break;
    case _IOC_NR(FN_READ_KBD_STATUS):
        rc = kb_read_kbd_status(pInputBuffer, length);
        break;
    case _IOC_NR(FN_READ_MSR_DATA):
        rc = kb_read_msr_data(pInputBuffer, length);
        break;
    case _IOC_NR(FN_CODE_UPDATE):
        rc = kb_code_update(pInputBuffer, length);
        break;
    case _IOC_NR(FN_QUERY_CODE_UPDATE):
        rc = kb_query_code_update(pInputBuffer, length);
        break;
    case _IOC_NR(ENABLE_ANPOS_ASYNC_COMM):
        rc = kb_enable_anpos_async_com(pInputBuffer, length);
        break;
    case _IOC_NR(DISABLE_ANPOS_ASYNC_COMM):
        rc = kb_disable_anpos_async_com(pInputBuffer, length);
        break;
#if defined(V4690)
    case _IOC_NR(ENABLE_4690_MODE):
        rc = kb_enable_4690_mode();
        break;
    case _IOC_NR(DISABLE_4690_MODE):
        rc = kb_disable_4690_mode();
        break;
#endif
    default:
        aip_dbg("Invalid IOCTL, dir=%d, type=%x, nr=%d, length=%d\n",
                direction, type, nr, length);

        rc = -EINVAL;
    }

    aipikbps_in_user_call = 0;

    return rc;
}


#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 16)
static int aipikbps_write(unsigned char data, int suppress)
{
    int rc = 0;

    if (aipikbps_real_serio) {
        if (suppress)
            aipikbps_suppress_kbd_ack++;
        if ((rc = serio_write(aipikbps_real_serio, data)) && suppress)
            aipikbps_suppress_kbd_ack--;
    } else
        rc = -ENODEV;

    return rc;
}


static int aipikbps_write_buffer(unsigned char *data, unsigned int length,
                                 unsigned int *xferred, unsigned int retries,
                                 unsigned int timeout)
{
    int i;
    int rc = 0;
    unsigned int x = 0;
    long timeleft = msecs_to_jiffies(timeout);
    long ret = 0;
    int  retry_count = 0;

    down(&aipikbps_sema);

    for (i = 0; i < length;) {
        aip_verbose("sending byte %d, value=%02x\n", i + 1, data[i]);

        set_bit(WAITING_FOR_KBD_ACK, &ack_status);
        clear_bit(KBD_ACK_RECEIVED,  &ack_status);
        clear_bit(KBD_NAK_RECEIVED,  &ack_status);
        clear_bit(KBD_ROL_RECEIVED,  &ack_status);

        if ((rc = aipikbps_write(data[i], 1))) {
            aip_error("aipikbps_write returned error %d\n", rc);

            break;
        }

        ret = wait_event_interruptible_timeout(wq_ack,
                                         !test_bit(WAITING_FOR_KBD_ACK, &ack_status),
                                         timeleft);

        if (ret > 0) {
            timeleft = ret;
        }

        if (test_bit(KBD_ACK_RECEIVED, &ack_status)) {
            i++;
            x++;
        } else if (test_bit(KBD_NAK_RECEIVED, &ack_status)) {
            aip_error("NAK received, resending\n");
            if (++retry_count > retries)
            {
                aip_error("Excessive NAK's, stopping\n");
                rc = -EIO;
                break;
            }
        } else if (test_bit(KBD_ROL_RECEIVED, &ack_status)) {
            aip_error("ROL received, stopping\n");
            rc = -EBUSY;
            break;
        } else if (ret == 0) {
            aip_error("timeout waiting for response, stopping\n");
            rc = -ETIMEDOUT;
            break;
        } else {
            aip_error("no valid response received, stopping\n");
            rc = -EIO;
            break;
        }
    }

    up(&aipikbps_sema);

    if (xferred)
        *xferred = x;

    return rc;
}
#endif


/* :H1.PosKbdSendData() - Send data to keyborad.
 * ***********************************************************************
 *
 * Function Name:  PosKbdSendData()
 *
 * Purpose:        To send data to keyboard.
 *
 * Description:    A common routine to send data to keyboard.
 *
 * Input:          unsigned char * buffer.
 *                 size of buffer
 *
 * Output:         returns number of bytes transferred.
 *                 0 - success
 *                 1 - failure.
 *
 * Notes:
 *
 * ***********************************************************************
 */

static int PosKbdSendData(unsigned char *buf, unsigned int size, long timeout)
{
    int     rc = 0;
    long    timeleft = 500;
    int     xferred = 0, xfer_retry = size;
    int     write_size = size;
    int     sent_count = 0;
    unsigned char b = 0;

    if (size > 1)
        b = *(buf + 1);

    aip_verbose("enter\n");

    if (timeout > 0) {
        rc = aipikbps_command_start(100);
        if (rc < 0) {
            aip_error("could not lock keyboard (error=%d)\n", rc);
            return rc;
        }
    }

    do {
        aip_dbg("sending %d bytes to kbd\n", size);

        /* size: number of retires and size of buffer */
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 16)
        rc = pos_filter.write_data(buf, size, &xferred, size, 1000);

        sent_count += xferred;

        if (rc != 0) {
            aip_dbg("pos_filter.write_data returned error %d\n", rc);

            /* the kernel patch misses ACK, and does not increment the
             * xferred count
             */
            if (rc == (-EINTR))
            {
                xferred++;
                sent_count++;
            }

#else
        rc = aipikbps_write_buffer(buf, size, &xferred, 2, 1000);

        sent_count += xferred;

        if (rc != 0) {
            aip_error("aipikbps_write_buffer() returned error %d\n", rc);
#endif

            if (xferred < size) {
                buf += xferred;
                size -= xferred;
                xferred = 0;
            }
        }
    } while (xferred < size && xfer_retry--);

    /* Go to sleep.  The wait queue is awakened in pos_kbd_filter() routine
     * when command is complete i.e. receipt of
     *
     *   -  0xF2 end of keyboard status OR
     *   -  0xF6 end of msr status      OR
     *   -  0xF7 ROL in response to keyboard reset.
     */
    if (timeout > 0)
    {
        if (sent_count != write_size)
            aipikbps_command_finish();
        else {
            timeleft = aipikbps_command_wait_for_complete(timeout);

            if (timeleft <= 0) {
                aip_error("write timed out: returning ENODEV\n");
                aipikbps_command_finish();

                rc = -ENODEV;
            }
        }
    }

    aip_dbg("returning, rc=%d(%s)\n", rc, rc == 0 ? "Success" : "Failed");

    return rc;
}


/* :H1.PosKbdSetInterfaceVersion() - Set Keyboard Inteface Version
 * ***********************************************************************
 *
 * Function Name:  PosKbdSetInterfaceVersion()
 *
 * Purpose:        To set POS keyboard interface version.
 *
 * Description:    This routine sends the set interface version command.
 *                 This is a new command for IBM V2 POS keyboards.
 *                 framing bytes as it would send for status.
 *
 * Input:          interfaceVersion: valid values are X'03' or X'04'
 *
 * Output:         none
 *
 * Notes:
 *
 * ***********************************************************************
 */

static int PosKbdSetInterfaceVersion(unsigned char interfaceVersion)
{
    int rc;
    unsigned char inputBuffer[2];

    aip_verbose("enter\n");

    /* Set up Set Interface Version Command */
    inputBuffer[0] = SET_INTERFACE_VERSION_CMD;
    inputBuffer[1] = interfaceVersion;

    rc = PosKbdSendData(inputBuffer, sizeof(inputBuffer), 1000);

    aip_dbg("returning, rc=%d(%s)\n", rc, rc == 0 ? "Success" : "Failed");

    return rc;
}


/* :H1.PosKbdReadId() - Read Keyboard ID.
 * ***********************************************************************
 *
 * Function Name:  PosKbdReadId()
 *
 * Purpose:        To read Keyboard ID.
 *
 * Description:    This routine sends Read Id command. The keyboard
 *                 response contains only two bytes of data with no
 *                 framing bytes as it would send for status.
 *
 *                 IBM POS Kbd  - Id byte 1 = 0xAB, Id byte 2 = 0x87
 *                 CANPOS       - id byte 1 = 0xAB, Id byte 2 = 0x41
 *
 * Input:          none
 *
 * Output:         none
 *
 * Notes:
 *
 * ***********************************************************************
 */

static int PosKbdReadId(void)
{
    int rc;
    unsigned char inputBuffer[1];

    aip_verbose("enter\n");

    /* Set up Device Info Command */
    inputBuffer[0] = 0xF2;

    /* Write to keyboard */
    pPosKbdData->fStatus |= COLLECTING_PRIMARY_ID;

    rc = PosKbdSendData(inputBuffer, sizeof(inputBuffer), 1000);

    aip_dbg("returning, rc=%d(%s)\n", rc, rc == 0 ? "Success" : "Failed");

    return rc;
}


/* :H1.PosKbdReqDevInfo() - ReqDevInfo Keyboard.
 * ***********************************************************************
 *
 * Function Name:  PosKbdReqDevInfo()
 *
 * Purpose:        To request device information.
 *
 * Description:    This routine sends device info request to POS keyboard,
 *                 and response is saved.  The routine is called once
 *                 during initialization.
 *
 * Input:          none
 *
 * Output:         none
 *
 * Notes:
 *
 * ***********************************************************************
 */

static int PosKbdReqDevInfo(void)
{
    int rc;
    DEV_INFO_REQ devInfoReq;
    unsigned char *inputBuffer = (unsigned char *) &devInfoReq;

    aip_verbose("enter\n");

    /* Set up Device Info Command */
    devInfoReq.cmd1 = POS_KBD_DEV_INFO_CMD_BYTE1;
    devInfoReq.cmd2 = POS_KBD_DEV_INFO_CMD_BYTE2;
    devInfoReq.cmd3 = POS_KBD_DEV_INFO_CMD_BYTE3;

    /* Write to keyboard */
    rc = PosKbdSendData(inputBuffer, sizeof(devInfoReq), 1000);

    aip_dbg("returning, rc=%d(%s)\n", rc, rc == 0 ? "Success" : "Failed");

    return rc;
}


/* :H1.PosMsrReqDevInfo() - ReqDevInfo Keyboard.
 * ***********************************************************************
 *
 * Function Name:  PosMsrReqDevInfo()
 *
 * Purpose:        To request device information.
 *
 * Description:    This routine sends device info request to POS keyboard,
 *                 and response is saved.  The routine is called once
 *                 during initialization.
 *
 * Input:          none
 *
 * Output:         none
 *
 * Notes:
 *
 * ***********************************************************************
 */

static int PosMsrReqDevInfo(void)
{
    int rc;
    DEV_INFO_REQ devInfoReq;
    unsigned char *inputBuffer = (unsigned char *) &devInfoReq;

    aip_verbose("enter\n");

    /* Set up Device Info Command */
    devInfoReq.cmd1 = POS_MSR_DEV_INFO_CMD_BYTE1;
    devInfoReq.cmd2 = POS_MSR_DEV_INFO_CMD_BYTE2;
    devInfoReq.cmd3 = POS_MSR_DEV_INFO_CMD_BYTE3;

    /* Write to keyboard */
    rc = PosKbdSendData(inputBuffer, sizeof(devInfoReq), 1000);

    aip_dbg("returning, rc=0x%x %s\n", rc, rc == 0 ? "Success" : "Failed");

    return rc;
}


/* :H1.set_leds-default_state() - set leds to default state.
 * ***********************************************************************
 *
 * Function Name:  set_leds-default_state()
 *
 * Purpose:        To set leds default state.
 *
 * Description:    This routine turns off all leds by default.
 *                 -  pos specific leds.
 *                 -  CapsLock/NumLock/ScrollLock leds also..
 *
 * Input:          none
 *
 * Output:         none
 *
 * Notes:
 *
 * ***********************************************************************
 */

static void set_leds_default_state(void)
{
    int rc;
    KBD_SET_INDICATORS   setIndicators;
    unsigned char       *pBuffer;

    aip_verbose("enter\n");

    /* Setup Pos Leds command to send. */
    setIndicators.Command = POS_LEDS_COMMAND;
    setIndicators.Parm1 = 0;

    /* Get State of Leds from Linux. */

    /* ***********    add   ************ */

    /* set up the state of caps_lock, num_lock, scroll_lock. */
    setIndicators.Parm1 |= (unsigned char) (pPosKbdData->KeyboardIndicators.LedFlags);

    pBuffer = (unsigned char *) &setIndicators;

    rc = PosKbdSendData(pBuffer, sizeof(setIndicators), 1000);

    aip_dbg("returning, rc=%d(%s)\n", rc, rc == 0 ? "Success" : "Failed");
}


/* :H1.SetDefaultConfiguration() - Send default configuration..
 * ***********************************************************************
 *
 * Function Name:  SetDefaultConfiguration()
 *
 * Purpose:        To send default configuration.
 *
 * Description:    This routine sends default configuration to keyboard.
 *                 By default, it turns on typematic.
 *
 * Input:          none
 *
 * Output:         rc = 0 success
 *
 * Notes:
 *
 * ***********************************************************************
 */

static int SetDefaultConfiguration(void)
{
    int rc;
    unsigned char setConfig[KBD_CONFIGURE_CMD_LENGTH];

    aip_verbose("enter\n");

    /* Copy configure command into local buffer. */
    setConfig[0] = pPosKbdData->KbdConfigureCmd[0];
    setConfig[1] = pPosKbdData->KbdConfigureCmd[1];
    setConfig[2] = pPosKbdData->KbdConfigureCmd[2];
    setConfig[3] = pPosKbdData->KbdConfigureCmd[3];

    /* Write to keyboard */
    rc = PosKbdSendData(setConfig, sizeof(setConfig), 1000);

    aip_dbg("returning, rc=%d(%s)\n", rc, rc == 0 ? "Success" : "Failed");

    return rc;
}


/* :H1.PosKbdReset() - Reset Keyboard.
 * ***********************************************************************
 *
 * Function Name:  PosKbdReset()
 *
 * Purpose:        To reset the keyboard.
 *
 * Description:    This routine sends reset to POS keyboard, and is called
 *                 during driver initialization.
 *
 * Input:          none
 *
 * Output:         none
 *
 * Notes:
 *
 * ***********************************************************************
 */

static int PosKbdReset(void)
{
    int rc;
    unsigned char inputBuffer[2] = {0, 0};

    aip_verbose("enter\n");

    /* Set up Device Info Command */
    inputBuffer[0] = (unsigned char) POS_KBD_RESET_CMD_BYTE1;
    inputBuffer[1] = (unsigned char) POS_KBD_RESET_CMD_BYTE2;

    /* Write to keyboard */
    rc = PosKbdSendData(inputBuffer, sizeof(inputBuffer), 30000);

    aip_dbg("returning, rc=%d(%s)\n", rc, rc == 0 ? "Success" : "Failed");

    return rc;
}


/* :H1.pos_process_code_update - Processes CodeUpdate.
 * ********************************************************************
 *
 * Function Name:  pos_process_code_update()
 *
 * Purpose:        Supports CodeUpdate for POS Keybaord.
 *
 * Description:    This is routine processes code updates synchronously.
 *                 It builds an irp for each code update block and sends
 *                 it down the stack.  The routines exits when it senses
 *                 the code update complete bit.
 *
 * Input:          Target - The top of the stack
 *
 *                 Ioctl  - The IOCTL to send
 *
 * Output:         status - NTSTATUS
 *
 * Notes:
 *
 * ********************************************************************
 */

static void pos_process_code_update(void)
{
    int rc = 0;
    int SendCodeUpdateStart = 1;
    unsigned char updateBuffer[MAX_BUFFER_SIZE];
    unsigned char idbyte = 0;

    aip_verbose("enter\n");

    /* Set flag to indicate code update in progress. */
    pPosKbdData->CodeUpdate.State |= SENDING_CODE_UPDATE;
    pPosKbdData->CodeUpdate.State &= ~CODE_UPDATE_LAST_BLOCK_SENT;

    /* Need to initialize this in order to send first record
     */
    pPosKbdData->CodeUpdate.State |= CODE_UPDATE_STORED;

    while ((pPosKbdData->CodeUpdate.State & SENDING_CODE_UPDATE)) {
        if (pPosKbdData->CodeUpdate.State & CODE_UPDATE_STORED) {
            unsigned int updateBufferLength;

            pPosKbdData->CodeUpdate.State &= ~CODE_UPDATE_STORED;

            memset(updateBuffer, 0, MAX_BUFFER_SIZE);

            /* For V2 keyboards, there is a new 'Start Update'
             * command that must be sent first
             */
            if (pPosKbdData->v2Keyboard && SendCodeUpdateStart) {
                updateBuffer[0] = 0x22;
                updateBuffer[1] = 0x01;
                updateBufferLength = 2;
                pPosKbdData->CodeUpdate.State |= CODE_UPDATE_STARTED;

                aip_dbg("Sending CodeUpdate Start Cmd, Length=%d Data=%02x.%02x\n",
                        updateBufferLength,
                        updateBuffer[0],
                        updateBuffer[1]);
            } else {

                /* Setup a block of code update to send. */
                updateBufferLength = pPosKbdData->CodeUpdate.Update[pPosKbdData->CodeUpdate.iUpdate].Length;
                idbyte = pPosKbdData->CodeUpdate.Update[pPosKbdData->CodeUpdate.iUpdate].Buffer[2];

                if ((updateBufferLength == 2) && (pPosKbdData->v2Keyboard) &&
                    (idbyte == 0)) {

                    pPosKbdData->CodeUpdate.State &= ~SENDING_CODE_UPDATE;
                    pPosKbdData->CodeUpdate.State |= CODE_UPDATE_LAST_BLOCK_SENT;

                    /* For V2 keyboards, length = 2 indicates last block but
                     * this length does not include command bytes or the length
                     * (00h) byte; for V1 keyboards, length remains 2
                     */
                    updateBufferLength += 3;

                } else if ((updateBufferLength == 2) &&
                           (pPosKbdData->v2Keyboard == 0)) {

                    pPosKbdData->CodeUpdate.State &= ~SENDING_CODE_UPDATE;
                    pPosKbdData->CodeUpdate.State |= CODE_UPDATE_LAST_BLOCK_SENT;
                } else {
                    updateBufferLength += 2;

                    /* For V2, there is an additional command byte plus the
                     * length byte and record ID (3 bytes) which are not
                     * included in the specified length
                     */
                    if (pPosKbdData->v2Keyboard) {
                        updateBufferLength += 4;
                    }
                }

                memcpy(updateBuffer,
                       &pPosKbdData->CodeUpdate.Update[pPosKbdData->CodeUpdate.iUpdate].Buffer[0],
                       updateBufferLength);

                aip_dbg("Sending CodeUpdate Block=%d, Length=%d"
                        " Data=%02x.%02x.%02x.%02x...%02x.%02x.%02x,%02x\n",
                        pPosKbdData->CodeUpdate.iUpdate,
                        updateBufferLength,
                        updateBuffer[0],
                        updateBuffer[1],
                        updateBuffer[2],
                        updateBuffer[3],
                        updateBuffer[updateBufferLength - 4],
                        updateBuffer[updateBufferLength - 3],
                        updateBuffer[updateBufferLength - 2],
                        updateBuffer[updateBufferLength - 1]);
            }

            /* Write to keyboard */
            rc = PosKbdSendData(updateBuffer, updateBufferLength, 1000);

            if (pPosKbdData->v2Keyboard && SendCodeUpdateStart) {
                SendCodeUpdateStart = 0;
            } else {
                /* Increment the index to point to next block. */
                pPosKbdData->CodeUpdate.iUpdate++;
            }
        }
        /* Sleep for 25 milliseconds between packets or checking for status */
        mdelay(25);
    }

    /* For V2 Keyboards, we need to basically redo the entire initialization
     * sequence -- the V1 keyboards seem to keep their state through the reset
     * though the V1 reset is internal and not driver initiated...
     */
    if (pPosKbdData->v2Keyboard) {
        mdelay(500);
        mdelay(500);
        mdelay(500);
        mdelay(500);
        aip_dbg("Sending reset to the keyboard\n");
        rc = PosKbdReset();

#if 0
        if (rc != 0) {
            rc = aipikbps_command_start(100);
            if (rc < 0) {
                aip_error("could not lock keyboard (error=%d)\n", rc);
                return rc;
            }
        }

        /* Wait until we have received ROL
         * max wait = 5*10(ms)*20 = 1000 ms, timer tick = 10ms
         */
        aipikbps_busy_wait(20);
#endif

        /* If we did code update, we were in Native Mode but the reset takes
         * us back to Compatibility Mode -- Set Interface again to Native Mode.
         */
        aip_dbg("Sending set interface version to the keyboard\n");
        rc = PosKbdSetInterfaceVersion(0x04);
#if 0
        if (rc == 0) {
            /* Wait for command to complete
             * max wait = 5*10(ms)*20 = 1000 ms, timer tick = 10ms
             */
            aipikbps_busy_wait(1000);

            aip_dbg("Set Interface Wait: cmd_busy=%d\n",
                    test_bit(0, &cmd_busy));
        }
#endif

        /* Request keyboard device information after reset */
        aip_dbg("Sending Request Device Information to the keyboard\n");
        rc = PosKbdReqDevInfo();

#if 0
        if (rc == 0) {

            /* Wait until we have received Device Information response
             * max wait = 5*10(ms)*20 = 1000 ms, timer tick = 10ms
             */
            aipikbps_busy_wait(20);

            aip_dbg("DevInfo Wait: cmd_busy=%d\n", test_bit(0, &cmd_busy));
        }
#endif

        /* Reset default led state (i.e turn off all leds) after POS Reset */
        set_leds_default_state();

        /* Initialze Keyboard */
        pPosKbdData->KbdConfigureCmd[0] = KBD_CONFIGURE_CMD;
        pPosKbdData->KbdConfigureCmd[1] = 0x03;
        pPosKbdData->KbdConfigureCmd[2] = 0x00;
        pPosKbdData->KbdConfigureCmd[3] = 0x00;

        pPosKbdData->MsrConfigureCmd[0] = MSR_CONFIGURE_CMD;
        pPosKbdData->MsrConfigureCmd[1] = 0x00;

        pPosKbdData->MsrROL = FALSE;

        /* Send default Configuration i.e. turn on typematic */
        SetDefaultConfiguration();

    }
    aip_verbose("returning\n");
}


/* :H1.CollectingKBDId() - Collect Keyboard Id
 * ***********************************************************************
 *
 * Function Name:  CollectingKBDId()
 *
 * Purpose:        Save KBD ID bytes
 *
 * Description:    This function saves the KBD Id bytes.
 *                 The keyboard sends only two bytes of id bytes.
 *                   -  ID byte 1 = 0xAB
 *                   -  ID byte 2 = 0x87
 *
 * Input:          scancode-  the scancode received from the keyboard
 *
 * Output:         scancode - the scancode
 *                  0x00    - if we filter it off
 *
 * Notes:
 *
 * ***********************************************************************
 */

static unsigned char CollectingKBDId(unsigned char scancode)
{
    aip_verbose("scancode=0x%x, index=%d, status=0x%x\n", scancode,
                pPosKbdData->PosKbdId.Index, pPosKbdData->fStatus);

    if (pPosKbdData->PosKbdId.Index < 2) {
        pPosKbdData->PosKbdId.KBDId[pPosKbdData->PosKbdId.Index] = scancode;

        if (pPosKbdData->PosKbdId.Index == 1) {
            pPosKbdData->fStatus &= ~COLLECTING_PRIMARY_ID;

            aip_dbg("Keyboard ID: %02x.%02x\n",
                    pPosKbdData->PosKbdId.KBDId[0],
                    pPosKbdData->PosKbdId.KBDId[1]);

            /* wake up the process */
            aipikbps_command_finish();
        } else {
            ++pPosKbdData->PosKbdId.Index;
        }
        scancode = 0;
    }

    aip_verbose("returning scancode=0x%x, index=%d, status=0x%x\n",
                scancode, pPosKbdData->PosKbdId.Index, pPosKbdData->fStatus);

    return scancode;
}


/* :H1.collect_kbd_status() - Collect Keyboard Status
 * ***********************************************************************
 *
 * Function Name:  collect_kbd_status()
 *
 * Purpose:        Save KBD status scancodes
 *
 * Description:    This function saves the KBD status scancodes in the
 *                 KBDStatus buffer.  This function checks to see if there
 *                 is enough room to store the value.  If the value is
 *                 saved, the scancode is set to 0 so that no further
 *                 processing will be done.  The 0xF2 at the end of the
 *                 status message is not stored, but is passed back to
 *                 POSFilter for further processing.
 *
 * Input:          scancode        -  the scancode received from the keyboard
 *
 * Output:         scancode - the scancode
 *                  0x00    - if we filter it off
 *
 * Notes:
 *
 * ***********************************************************************
 */

static unsigned char collect_kbd_status(unsigned char scancode)
{
    unsigned char orig_scancode = scancode;

    if (SCANCODE_END_KBD_STATUS != scancode) {
        if (pPosKbdData->PosKbdStatus.Index < 12) {
            pPosKbdData->PosKbdStatus.KBDStatus[pPosKbdData->PosKbdStatus.Index] = convert[scancode];

            if ((OB_KBD == KbdHWIDs) &&
                pPosKbdData->PosKbdStatus.Index == 2) {
                keyLockState = (unsigned char)((scancode >> 4) & 0x03);
            } else if ((ANPOS_KBD == KbdHWIDs) &&
                       pPosKbdData->PosKbdStatus.Index == 0) {
                keyLockState = (unsigned char)((scancode >> 6) & 0x01);
            }

            ++pPosKbdData->PosKbdStatus.Index;
        } else {
            pPosKbdData->fStatus &= ~COLLECTING_KBD_STATUS;

            aip_dbg("Keyboard Status Collection complete\n");
        }

        scancode = 0;
    }

    aip_verbose("scancode=0x%02x(was=0x%02x), index=%d, status=0x%x\n",
                scancode, orig_scancode, pPosKbdData->PosKbdStatus.Index,
                pPosKbdData->fStatus);

    return scancode;
}


/* :H1.collect_msr_status()  - Collect MSR Status
 * ********************************************************************
 *
 * Function Name: collect_msr_status
 *
 * Purpose:       Save MSR data (status) scancodes
 *
 * Description:   This function saves the MSR data scancodes in the
 *                MSRData buffer.  This function checks to see if there
 *                is enough room to store the value.  If the value is
 *                saved, the scancode is set to 0 so that no further
 *                processing will be done.  The 0xF6 at the end of the
 *                status message is not stored, but is passed back to
 *                POSFilter for further processing.
 *
 * Input:         scancode - the scancode received from the keyboard
 *
 * Output:        scancode - the scancode
 *                0x00     - if we filter it off
 *
 * Notes:
 *
 * ********************************************************************
 */

static unsigned char collect_msr_status(unsigned char scancode)
{
    unsigned char orig_scancode = scancode;

    if ((scancode != SCANCODE_END_MSR_STATUS) && (scancode != SCANCODE_ACK)) {

        if (pPosKbdData->MSRData.Index < sizeof(pPosKbdData->MSRData)) {
            int index = pPosKbdData->MSRData.Index;

            /* ***************************************************
             * Check to see if the previous scancode was a 0xFF.
             * If so, we need to handle this scancode differently:
             * ***************************************************
             */
            if (pPosKbdData->MSRData.MSRDataBuffer[index] == 0xFF) {
                switch (scancode) {
                case 0xF3:
                case 0xF4:
                case 0xEA:
                    pPosKbdData->MSRData.MSRDataBuffer[index] = scancode & (unsigned char) 0x7F;

                    break;

                default:
                    pPosKbdData->MSRData.MSRDataBuffer[index] = convert[scancode];

                    break;
                }
            } else {
                pPosKbdData->MSRData.MSRDataBuffer[index] = convert[scancode];
            }

            /* ***************************************************
             * If this is a 0xFF, we will not increment the pointer.
             * The next time through, we will check for 0xFF to see
             * if we need to process the incoming scancode
             * differently.  The following is the list of 0xFF
             * prefixed scancodes:
             *  0xF3 -> 0x73
             *  0xF4 -> 0x74
             *  0xEA -> 0x6A
             * ***************************************************
             */
            if (scancode != 0xFF) {
                pPosKbdData->MSRData.Index += 1;
                pPosKbdData->MSRData.MSRDataLength += 1;
            }
        } else {
            pPosKbdData->fStatus &= ~COLLECTING_MSR_STATUS;

            aip_dbg("MSR Data Collection complete\n");
        }

        scancode = 0;
    }

    aip_verbose("scancode=0x%02x(was=0x%02x), index=%d, status=0x%x\n",
                scancode, orig_scancode, pPosKbdData->MSRData.Index,
                pPosKbdData->fStatus);

    return scancode;
}


/* :H1.DoubleKeyProcessing() - Process Double Keys
 * ***********************************************************************
 *
 * Function Name:  DoubleKeyProcessing
 *
 * Purpose:        Handle doublekeys
 *
 * Description:    This function examines the scancode passed in to
 *                 determine if it is part of a doublekey pair.  If it
 *                 is the primary scancode of the doublekey pair, it is
 *                 passed along and a flag is set.  If it is the secondary
 *                 value of the doublekey pair, the primary value is
 *                 passed in and a flag is set.  In either case, if the
 *                 flag has been set already, the scancode is set to 0.
 *
 * Input:          key             - key switch number.
 *                 fBreak          - break code flag
 *                 deviceExtension - Pointer to DevExt.
 *
 * Output:         scancode - the scancode its double pair
 *                 0x00
 *
 * Notes: NONE
 *
 * ***********************************************************************
 */

static unsigned char DoubleKeyProcessing(unsigned char key,
                                         unsigned char fBreak)
{
    unsigned short i;
    unsigned char orig_key = key;

    for (i = 0; i < pPosKbdData->nDoubleKeys; i++) {
        if ((key == pPosKbdData->doubleKey[i].primaryKey) ||
            (key == pPosKbdData->doubleKey[i].secondaryKey)) {
            unsigned short fPressed = FALSE;

            if ((pPosKbdData->doubleKey[i].primaryMake == TRUE) ||
                (pPosKbdData->doubleKey[i].secondaryMake == TRUE)) {
                fPressed = TRUE;
            }

            aip_dbg("%i: Primary=%d(%d) Secondary=%d(%d) Break=%d, Pressed=%d\n", i,
                    pPosKbdData->doubleKey[i].primaryKey,
                    pPosKbdData->doubleKey[i].primaryMake,
                    pPosKbdData->doubleKey[i].secondaryKey,
                    pPosKbdData->doubleKey[i].secondaryMake,
                    fBreak, fPressed);

            if (key == pPosKbdData->doubleKey[i].primaryKey) {
                if (fBreak) {
                    pPosKbdData->doubleKey[i].primaryMake = FALSE;
                } else {
                    pPosKbdData->doubleKey[i].primaryMake = TRUE;
                }
            } else if (key == pPosKbdData->doubleKey[i].secondaryKey) {
                if (fBreak) {
                    pPosKbdData->doubleKey[i].secondaryMake = FALSE;
                } else {
                    pPosKbdData->doubleKey[i].secondaryMake = TRUE;
                }
            }

            if ((pPosKbdData->doubleKey[i].primaryMake == TRUE) ||
                (pPosKbdData->doubleKey[i].secondaryMake == TRUE)) {

                if (pPosKbdData->double_key_active == 0) {
                    pPosKbdData->doubleKey[i].lastKey = key;
                    pPosKbdData->double_key_active = 1;
                }

                if (fPressed == FALSE) {
                    key = pPosKbdData->doubleKey[i].primaryKey;
                } else {
                    key = 0;
                }
            } else {
                if (fPressed == TRUE) {
                    key = pPosKbdData->doubleKey[i].primaryKey;

                    if ((pPosKbdData->double_key_active == 2) &&
                        (pPosKbdData->doubleKey[i].lastKey == 109)) {
                        aip_dbg("queueing E0 to be sent\n");
                        pPosKbdData->double_key_active = 3;
                    } else if ((pPosKbdData->double_key_active == 2) &&
                               (pPosKbdData->doubleKey[i].lastKey == 94) &&
                               (aipikbps_prev_key_e0 == 1)) {
                        aip_dbg("queueing E0 to be sent\n");
                        pPosKbdData->double_key_active = 3;
                    } else {
                        pPosKbdData->double_key_active = 0;
                    }
                } else {
                    key = 0;
                }
                pPosKbdData->doubleKey[i].lastKey = 0;
            }

            if (key) {
                aip_dbg("Key updated key=%d, break=%d\n", key, fBreak);
            } else {
                aip_dbg("Key grounded key=%d, break=%d\n", key, fBreak);
            }
            break;
        }
    }

    if (key != orig_key) {
        aip_dbg("Double: Changed scancode %d to %d (fBreak=%d)\n",
                orig_key, key, fBreak);
    }

    return key;
}


/* :H1.SetShiftKeyState() - Maintain Shift Key States
 * ***********************************************************************
 *
 * Function Name:  SetShiftKeyState()
 *
 * Purpose:        Support the shift states of the keyboard.
 *
 * Description:    This routine saves the shift status of the keys such
 *                 as SHIFT, ALT, CTRL keys.
 *
 * Input:           unsigned char        scanCode,
 *                  POS_KEYBOARD_SCAN_STATE *scanState
 *
 * Output:          none
 *
 * Notes:
 *
 * ***********************************************************************
 */

static void SetShiftKeyState(unsigned char scanCode,
                             POS_KEYBOARD_SCAN_STATE *scanState)
{
    if (scanCode <= (unsigned char) 0x7F) {
        /* make code */
        switch (scanCode) {
        case 0x1D:                                  /* 'CTRL' */
            if (*scanState == OK)                   /*  Left */
                pPosKbdData->ShiftFlags |= 0x20;
            else if (*scanState == gotE0)           /*  Right */
                pPosKbdData->ShiftFlags |= 0x02;
            break;
        case 0x38:                                  /* 'ALT' */
            if (*scanState == OK)                   /*  Left */
                pPosKbdData->ShiftFlags |= 0x40;
            else if (*scanState == gotE0)           /*  Right */
                pPosKbdData->ShiftFlags |= 0x04;
            break;
        case 0x36:                                  /* Right 'Shift' */
            if (*scanState == OK)
                pPosKbdData->ShiftFlags |= 0x01;
            break;
        case 0x2A:                                  /* Left 'Shift' */
            if (*scanState == OK)
                pPosKbdData->ShiftFlags |= 0x10;
            break;
        default:
            break;
        }
    } else {
        /* break code */
        switch (scanCode & 0x7F) {
        case 0x1D:                                  /* 'CTRL' */
            if (*scanState == OK)                   /*  Left */
                pPosKbdData->ShiftFlags &= ~0x320;
            else if (*scanState == gotE0)           /*  Right */
                pPosKbdData->ShiftFlags &= ~0x302;
            break;
        case 0x38:                                  /* 'ALT' */
            if (*scanState == OK)                   /*  Left */
                pPosKbdData->ShiftFlags &= ~0x340;
            else if (*scanState == gotE0)           /*  Right */
                pPosKbdData->ShiftFlags &= ~0x304;
            break;
        case 0x36:                                  /* Right 'Shift' */
            if (*scanState == OK)
                pPosKbdData->ShiftFlags &= ~0x301;
            break;
        case 0x2A:                                  /* Left 'Shift' */
            if (*scanState == OK)
                pPosKbdData->ShiftFlags &= ~0x310;
            break;
        default:
            break;
        }
    }

    aip_dbg("scancode=0x%02x, shift_state=0x%02x\n", scanCode,
            pPosKbdData->ShiftFlags);
}


/* :H1.pos_scancode_filter() - Main Proc To Filter Out POS Keys.
 * ********************************************************************
 *
 * Function Name:  pos_scancode_filter
 *
 * Purpose:        Filter out the POS specific data
 *
 * Description:    This function looks for POS specific data (like MSR
 *                 and status) and filters it before the normal keyboard
 *                 interrupt routine gets a chance to process it.
 *
 * Input:          none
 *
 * Output:
 *
 * Notes:
 *
 * ********************************************************************
 */

static int pos_scancode_filter(unsigned char *pScancode)
{
    unsigned char key = 0;
    unsigned char fBreak = 0xFF;
    int rc = 0;
    POS_KEYBOARD_SCAN_STATE  *scanState;
    unsigned char scancode = *pScancode;
    unsigned char original_scancode = scancode;
    int devInfoInd;
    unsigned char i;

#if defined(V4690)
    if (is4690mode && !statusBufferOverflow4690) {

        if (!collectStatus4690) {
            if (SCANCODE_BEG_KBD_STATUS == scancode)
                collectStatus4690 = SCANCODE_END_KBD_STATUS;
            if (SCANCODE_BEG_MSR_STATUS == scancode)
                collectStatus4690 = SCANCODE_END_MSR_STATUS;
            if (SCANCODE_ROL == scancode)
                collectStatus4690 = SCANCODE_ROL;
        }

        if (collectStatus4690) {

            spin_lock(&bufferLock4690);

            if (MAX_BUFFER_SIZE > statusBufferCapturingLength4690)
                statusBuffer4690[statusBufferCapturingLength4690++] = scancode;
            else {
                aip_error("error collecting 4690 status: buffer overflowed.\n");
                statusBufferCapturingLength4690 = 0;
                statusBufferLength4690          = 0;
                statusBufferOverflow4690        = 1;
                collectStatus4690               = 0;
            }

            if (collectStatus4690 == scancode) {
                statusBufferLength4690 = statusBufferCapturingLength4690;
                collectStatus4690      = 0;

                wake_up_interruptible_all(&wq4690);
            }

            spin_unlock(&bufferLock4690);
        }
    }
#endif

    scanFlag = 0;
    scanState = &pPosKbdData->CurrentScanState;

    /* *******************************************************************
     * If read keyboard id is sent, we need to collect next two bytes
     * from keyborad.  Start collecting after we receive ACK (0xFA).
     * Note that keyboard does not send any framing bytes for readID
     * command unlike it would for other Pos Keyboards commands.
     * Checking for 0x9c (break code for enter key) also it represents part
     * of the enter key that was hit.  I have see this break code come in
     * during cmd/response processing.
     * *******************************************************************
     */
    if ((pPosKbdData->fStatus & COLLECTING_PRIMARY_ID) &&
        (scancode != ACKNOWLEDGE) &&
        (scancode != SCANCODE_RESEND) &&
        (scancode != 0x9c)) {
        scancode = CollectingKBDId(scancode);
        scanFlag = 1;
    }

    /* *******************************************************************
     * If we have received a 0xF5, save the incoming scancodes in the MSR
     * data buffer until we receive a 0xF6.  When we receive the 0xF6, we
     * will send a notification scancode through (see the switch below).
     * *******************************************************************
     */
    if ((scancode != SCANCODE_ACK) &&
        (scancode != SCANCODE_ROL) &&
        (scancode != RESEND)) {
        if (pPosKbdData->fStatus & COLLECTING_MSR_STATUS) {
            scancode = collect_msr_status(scancode);
            scanFlag = 1;
        }

        /* ***********************************************************
         * If we have received a 0xF1 and have not yet received a 0xF2,
         * we collect the status bytes in the buffer.
         * ***********************************************************
         */
        else if (scancode && (pPosKbdData->fStatus & COLLECTING_KBD_STATUS)) {
            scancode = collect_kbd_status(scancode);
            scanFlag = 1;
        }
    }

    if (scanFlag == 0) {
        if (pPosKbdData->CanposKeyboard == 1) {
            /* write canpos configuration */
            if (pPosKbdData->CanposState == CANPOS_COUNT_WRITE_CONFIG_ACK) {
                scancode = collecting_canpos_write_config_ack(scancode);
            }
            /* write flash */
            else if ((pPosKbdData->CanposState == CANPOS_COUNT_FLASH_ACK)) {
                scancode = collecting_canpos_flash_ack(scancode);
            }
            /* Collect Version Info */
            else if ((pPosKbdData->CanposState == CANPOS_COLLECT_VER_INFO_START)) {
                scancode = collecting_canpos_ver_info(scancode);
            }
            /* canpos ack */
            else if ((pPosKbdData->CanposState == CANPOS_COLLECT_NORMAL_ACK)) {
                scancode = collecting_canpos_normal_ack(scancode);
            }
            /* handle canpos new key 105 106 */
            else {
                scancode = check_canpos_key_105_106(scancode);
            }
        } else if (pPosKbdData->PosKbdDeviceInfo.deviceID == 0x0A) {
            scancode = check_canpos_key_105_106(scancode);
        }
    }

    /* *******************************************************************
     * At this point we have a scancode that we haven't stuffed into a
     * buffer.  This is either a valid scancode or an END OF something
     * scancode.  If it is an END OF something scanCODE, we need to take
     * some action and ground the scancode.  If it is a normal keystroke
     * scanCODE, we will pass it on to the Boca code for handling.
     * *******************************************************************
     */
    switch (scancode) {
    case 0xFF:
        aip_verbose("scancode=0xff\n");
        scanFlag = 1;
        break;

    case SCANCODE_DELETE:
    case SCANCODE_DELETE_UP:
        aip_verbose("scancode=Delete Down or Delete Up, shift_flag=%x, fTrap=%x\n",
                    pPosKbdData->ShiftFlags, pPosKbdData->fTrap);

        if (pPosKbdData->fTrap & PosTRAP_CTRL_ALT_DELETE) {
            if ((pPosKbdData->ShiftFlags & CTRL_DOWN) &&
                (pPosKbdData->ShiftFlags & ALT_DOWN)) {
                /* *******************************************
                 * At least one ctrl and one alt key are down,
                 * so ground the keystroke.
                 * *******************************************
                 */
                scancode = 0;
                scanFlag = 1;
            }
        }
        break;

    case SCANCODE_ESC:
    case SCANCODE_ESC_UP:
        aip_verbose("scancode=Escape Down or Escape Up, shift_flag=%x, fTrap=%x\n",
                    pPosKbdData->ShiftFlags, pPosKbdData->fTrap);

        if ((pPosKbdData->ShiftFlags & CTRL_DOWN) &&
            (pPosKbdData->fTrap & PosTRAP_CTRL_ESC)) {
            scancode = 0;
            scanFlag = 1;
        }

        if ((pPosKbdData->ShiftFlags & ALT_DOWN) &&
            (pPosKbdData->fTrap & PosTRAP_ALT_ESC)) {
            scancode = 0;
            scanFlag = 1;
        }
        break;

    case SCANCODE_HOME:
    case SCANCODE_HOME_UP:
        aip_verbose("scancode=Home Down or Home Up, shift_flag=%x, fTrap=%x\n",
                    pPosKbdData->ShiftFlags, pPosKbdData->fTrap);

        if ((pPosKbdData->ShiftFlags & ALT_DOWN) &&
            (pPosKbdData->fTrap & PosTRAP_ALT_HOME)) {
            scancode = 0;
            scanFlag = 1;
        }
        break;

    case SCANCODE_TAB:
    case SCANCODE_TAB_UP:
        aip_verbose("scancode=Tab Down or Tab Up, shift_flag=%x, fTrap=%x\n",
                    pPosKbdData->ShiftFlags, pPosKbdData->fTrap);

        if ((pPosKbdData->ShiftFlags & ALT_DOWN) &&
            (!(pPosKbdData->ShiftFlags & SHIFT_DOWN)) &&
            (pPosKbdData->fTrap & PosTRAP_ALT_TAB)) {
            scancode = 0;
            scanFlag = 1;
        }
        if ((pPosKbdData->ShiftFlags & ALT_DOWN) &&
            (pPosKbdData->ShiftFlags & SHIFT_DOWN) &&
            (pPosKbdData->fTrap & PosTRAP_ALT_SHIFT_TAB)) {
            scancode = 0;
            scanFlag = 1;
        }
        break;

    case SCANCODE_CAPS_LOCK:
        aip_verbose("scancode=Caps Lock, fTrap=%x\n", pPosKbdData->fTrap);
        if (pPosKbdData->fTrap & PosTRAP_CAPS_LOCK) {
            scancode = 0;
            scanFlag = 1;
            pPosKbdData->ShiftFlags |= CAPS_LOCK_DOWN;
        }
        break;

    case SCANCODE_NUM_LOCK:
        aip_verbose("scancode=Num Lock, fTrap=%x\n", pPosKbdData->fTrap);
        if (pPosKbdData->fTrap & PosTRAP_NUM_LOCK) {
            scancode = 0;
            scanFlag = 1;
            pPosKbdData->ShiftFlags |= NUM_LOCK_DOWN;
        }
        break;

    case SCANCODE_SCROLL_LOCK:
        aip_verbose("scancode=Scroll Lock, fTrap=%x\n", pPosKbdData->fTrap);
        if (pPosKbdData->fTrap & PosTRAP_SCROLL_LOCK) {
            scancode = 0;
            scanFlag = 1;
            pPosKbdData->ShiftFlags |= SCROLL_LOCK_DOWN;
        }
        break;

    case SCANCODE_CAPS_LOCK_UP:
        aip_verbose("scancode=Caps Lock Up, shift_flag=%x, fTrap=%x\n",
                    pPosKbdData->ShiftFlags, pPosKbdData->fTrap);

        if ((pPosKbdData->fTrap & PosTRAP_CAPS_LOCK) &&
            (pPosKbdData->ShiftFlags & CAPS_LOCK_DOWN)) {
            scancode = 0;
            scanFlag = 1;
            pPosKbdData->ShiftFlags &= ~CAPS_LOCK_DOWN;
        }
        break;

    case SCANCODE_NUM_LOCK_UP:
        aip_verbose("scancode=Num Lock Up, fTrap=%x\n", pPosKbdData->fTrap);
        if ((pPosKbdData->fTrap & PosTRAP_NUM_LOCK) &&
            (pPosKbdData->ShiftFlags & NUM_LOCK_DOWN)) {
            scancode = 0;
            scanFlag = 1;
            pPosKbdData->ShiftFlags &= ~NUM_LOCK_DOWN;
        }
        break;

    case SCANCODE_SCROLL_LOCK_UP:
        aip_verbose("scancode=Scroll Lock Up, shift_flag=%x, fTrap=%x\n",
                    pPosKbdData->ShiftFlags, pPosKbdData->fTrap);

        if ((pPosKbdData->fTrap & PosTRAP_SCROLL_LOCK) &&
            (pPosKbdData->ShiftFlags & SCROLL_LOCK_DOWN)) {
            scancode = 0;
            scanFlag = 1;
            pPosKbdData->ShiftFlags &= ~SCROLL_LOCK_DOWN;
        }
        break;

    case SCANCODE_ROL:
        scancode = 0;
        scanFlag = 1;
        keyBufferIndex = 0;

        for (i = 0; i < sizeof(keyBuffer); ++i) {
            keyBuffer[i] = 0;
        }

        pPosKbdData->PosKbdStatus.Index = 0;
        pPosKbdData->fStatus = 0;
        pPosKbdData->MSRData.Index = 0;

        if (pPosKbdData->MsrConfigureCmd[1] != 0) {
            pPosKbdData->MsrROL = TRUE;
        }

        aip_verbose("scancode=ROL, shift_flag=%x, fTrap=%x\n",
                    pPosKbdData->ShiftFlags, pPosKbdData->fTrap);

        if (test_bit(WAITING_FOR_KBD_ACK, &ack_status)) {
            clear_bit(WAITING_FOR_KBD_ACK, &ack_status);
            set_bit(KBD_ROL_RECEIVED, &ack_status);

            wake_up_interruptible_all(&wq_ack);
        }

        /* wake up the process */
        aipikbps_command_finish();

        /* notify aipctrl pid. */
        if (pPosKbdData->asyncEnabled) {
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 27)
            kill_proc(pPosKbdData->asyncPID, SIGUSR2, 1);
#else
            kill_pid(pPosKbdData->asyncPID, SIGUSR2, 1);
#endif
        }
        break;

    case SCANCODE_BAT_COMPLETE:             /* 0xAA (BAT complete) */
        /* case 0xEE: */        /* ECHO, key128 need to get remapped
                                * to 0x59/0xd9
                                */
            scanFlag = 1;
            if (aipikbps_reset_sent == 1)
            {
                aipikbps_reset_sent = 0;

                aipikbps_suppress_kbd_ack++;

                pPosKbdData->PosKbdId.Index     = 0;
                pPosKbdData->PosKbdStatus.Index = 0;
                pPosKbdData->MSRData.Index      = 0;

                pPosKbdData->fStatus &= ~(WAITING_FOR_KBD_STATUS |
                                          COLLECTING_KBD_STATUS |
                                          WAITING_FOR_MSR_STATUS |
                                          COLLECTING_MSR_STATUS);

                pPosKbdData->fStatus |= COLLECTING_PRIMARY_ID;
            }
        break;

    case SCANCODE_ACK:
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 16)
        if (aipikbps_suppress_kbd_ack) {
            aipikbps_suppress_kbd_ack--;
            if (aipikbps_in_user_call == 1)
                scancode = 0;
        }

        if (pPosKbdData->fStatus & COLLECTING_PRIMARY_ID) {
            scancode = 0;
        }
#endif

        if (test_bit(WAITING_FOR_KBD_ACK, &ack_status)) {
            clear_bit(WAITING_FOR_KBD_ACK, &ack_status);
            set_bit(KBD_ACK_RECEIVED, &ack_status);

            wake_up_interruptible_all(&wq_ack);
        }

        scanFlag = 1;
        break;

    case SCANCODE_RESEND:
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 16)
        if (aipikbps_suppress_kbd_ack) {
            aipikbps_suppress_kbd_ack--;
            if (aipikbps_in_user_call == 1)
                scancode = 0;
        }
#endif

        if (test_bit(WAITING_FOR_KBD_ACK, &ack_status)) {
            clear_bit(WAITING_FOR_KBD_ACK, &ack_status);
            set_bit(KBD_NAK_RECEIVED, &ack_status);

            wake_up_interruptible_all(&wq_ack);
        }

        scanFlag = 1;
        break;

    case SCANCODE_BEG_KBD_STATUS:
        pPosKbdData->PosKbdStatus.Index = 0;
        pPosKbdData->fStatus &= ~WAITING_FOR_KBD_STATUS;
        pPosKbdData->fStatus |= COLLECTING_KBD_STATUS;
        scancode = 0;
        scanFlag = 1;

        aip_verbose("scancode=Begin Keyboard Status, status=%x\n",
                    pPosKbdData->fStatus);

        break;

    case SCANCODE_END_KBD_STATUS:
        /* ***********************************************************
         * The same value is used for end of keyboard status and for
         * the extended key break sequence of scan set 2.  We will
         * assume that if we haven't seen a 0xF1 come by that this
         * is a break sequence.
         * ***********************************************************
         */
        aip_verbose("scancode=End Keyboard Status, status=%x\n",
                    pPosKbdData->fStatus);

        if (pPosKbdData->fStatus & COLLECTING_KBD_STATUS) {
            pPosKbdData->fStatus &= ~COLLECTING_KBD_STATUS;

            /*  Keyboard Status */
            aip_dbg("Kbd Status %02x.%02x.%02x.%02x\n",
                    pPosKbdData->PosKbdStatus.KBDStatus[0],
                    pPosKbdData->PosKbdStatus.KBDStatus[1],
                    pPosKbdData->PosKbdStatus.KBDStatus[2],
                    pPosKbdData->PosKbdStatus.KBDStatus[3]);

            /* Capture and save Dev Info Data */
            if (pPosKbdData->PosKbdStatus.KBDStatus[1] &
                POS_KBD_DEV_INFO_MSG_PRESENT) {
                /* Need to mask upper bit of DeviceId, Features,
                 * CommandSet and EC level except when a field
                 * is F3h or F4h -- in those cases, the entire
                 * upper nibble should be masked.
                 */

                for (devInfoInd = 4; devInfoInd <= 8; devInfoInd++) {
                    if ((pPosKbdData->PosKbdStatus.KBDStatus[devInfoInd] == 0xF3) ||
                        (pPosKbdData->PosKbdStatus.KBDStatus[devInfoInd] == 0xF4)) {
                        pPosKbdData->PosKbdStatus.KBDStatus[devInfoInd] &= 0x0F;
                    } else {
                        pPosKbdData->PosKbdStatus.KBDStatus[devInfoInd] &= 0x7F;
                    }
                }


                /* save Device Info into a structure from Status
                 * info
                 */
                if ((pPosKbdData->PosKbdStatus.KBDStatus[5] == 0x04) ||
                    (pPosKbdData->PosKbdStatus.KBDStatus[5] == 0x05)) {

                    for (devInfoInd = 9; devInfoInd <= 11; devInfoInd++) {
                        pPosKbdData->PosKbdStatus.KBDStatus[devInfoInd] &= 0x0;
                    }

                    memcpy(&pPosKbdData->PosKbdDeviceInfo,
                           &pPosKbdData->PosKbdStatus.KBDStatus[4],
                           5);
                } else {

                    for (devInfoInd = 9; devInfoInd <= 11; devInfoInd++) {
                        if ((pPosKbdData->PosKbdStatus.KBDStatus[devInfoInd] == 0xF3) ||
                            (pPosKbdData->PosKbdStatus.KBDStatus[devInfoInd] == 0xF4)) {
                            pPosKbdData->PosKbdStatus.KBDStatus[devInfoInd] &= 0x0F;
                        } else {
                            pPosKbdData->PosKbdStatus.KBDStatus[devInfoInd] &= 0x7F;
                        }
                    }

                    memcpy(&pPosKbdData->PosKbdDeviceInfo,
                           &pPosKbdData->PosKbdStatus.KBDStatus[4],
                           8);
                }

                aip_dbg("Kbd DevInfo %02x.%02x.%02x.%02x.%02x.%02x.%02x.%02x\n",
                        pPosKbdData->PosKbdDeviceInfo.deviceType,
                        pPosKbdData->PosKbdDeviceInfo.deviceID,
                        pPosKbdData->PosKbdDeviceInfo.Features,
                        pPosKbdData->PosKbdDeviceInfo.CommandSet,
                        pPosKbdData->PosKbdDeviceInfo.ECLevel,
                        pPosKbdData->PosKbdDeviceInfo.FeatureByte1,
                        pPosKbdData->PosKbdDeviceInfo.FirmwareVersion,
                        pPosKbdData->PosKbdDeviceInfo.FirmwareRelease);
            }

            /* Check if the code update is completed. */
            if ((pPosKbdData->PosKbdStatus.KBDStatus[1] & CODE_UPDATE_STORED) ||
                (pPosKbdData->CodeUpdate.State & CODE_UPDATE_LAST_BLOCK_SENT)) {
                if ((pPosKbdData->PosKbdDeviceInfo.deviceID == 0x08) ||
                    (pPosKbdData->PosKbdDeviceInfo.deviceID == 0x09) ||
                    (pPosKbdData->PosKbdDeviceInfo.deviceID == 0x0A)) {

                    if (pPosKbdData->PosKbdStatus.KBDStatus[1] & OPERATION_IN_ERROR) {

                        pPosKbdData->fCodeUpdtDone = 0x02;

                        aip_dbg("CodeUpdate State=0x%x\n", pPosKbdData->fCodeUpdtDone);

                    } else {

                        if (pPosKbdData->PosKbdStatus.KBDStatus[1] & COMMAND_COMPLETE) {

                            pPosKbdData->CodeUpdate.State |= CODE_UPDATE_STORED;

                            if (pPosKbdData->CodeUpdate.State & CODE_UPDATE_LAST_BLOCK_SENT) {

                                pPosKbdData->fCodeUpdtDone = 0x01;
                                aip_dbg("CodeUpdate State=0x%x\n", pPosKbdData->fCodeUpdtDone);
                            }
                        }
                    }

                } else {

                    if (!(pPosKbdData->CodeUpdate.State & CODE_UPDATE_STORED)) {
                        aip_dbg("CodeUpdate Complete\n");
                    }

                    /* Set code update completion flag bit. */
                    pPosKbdData->CodeUpdate.State |= CODE_UPDATE_STORED;

                    if (pPosKbdData->CodeUpdate.State & CODE_UPDATE_LAST_BLOCK_SENT) {
                        pPosKbdData->fCodeUpdtDone = 0x01;

                        aip_dbg("CodeUpdate State=0x%x\n",
                                pPosKbdData->fCodeUpdtDone);
                    }
                }
            }

            pPosKbdData->PosKbdStatus.Index = 0;
            scancode = 0;
            scanFlag = 1;

            /* wake up the process */
            aipikbps_command_finish();

            /* notify aipctrl pid. */
            if (pPosKbdData->asyncEnabled) {
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 27)
                kill_proc(pPosKbdData->asyncPID, SIGUSR2, 1);
#else
                kill_pid(pPosKbdData->asyncPID, SIGUSR2, 1);
#endif
            }
        } else {
            /* ***************************************************
             * If we are not collecting MSR status, then the 0xF2
             * needs to be handled below.  Do nothing here.
             * ***************************************************
             */
        }
        break;

    case SCANCODE_BEG_MSR_STATUS:
        pPosKbdData->MSRData.Index          = 0;
        pPosKbdData->MSRData.MSRDataLength  = 0;
        pPosKbdData->fStatus               &= ~WAITING_FOR_MSR_STATUS;
        pPosKbdData->fStatus               |= COLLECTING_MSR_STATUS;
        scancode                            = 0;
        scanFlag                            = 1;

        aip_verbose("scancode=Begin MSR Status, status=%x\n",
                    pPosKbdData->fStatus);

        break;

    case SCANCODE_END_MSR_STATUS:
        aip_verbose("scancode=End MSR Status, status=%x\n",
                    pPosKbdData->fStatus);

        if (pPosKbdData->fStatus & COLLECTING_MSR_STATUS) {
            /* ************* IMPORTANT NOTICE ********************
             * The simple check for 0xF6 as the end of MSR data seems
             * to be valid.  The ISO standards for Track 1, 2 & 3
             * define characters to be 4 or 6 bit bytes.  The JIS
             * standard for the JIS-II track allow for 8 bit bytes.
             * The value 0xF6 falls in a range defined as "undefined"
             * by the spec.  We will be safe as long as nobody tries
             * to define 0xF6 as a meaningful value.
             * ***************************************************
             */
            if (ECBitMSR & pPosKbdData->MSRData.MSRDataBuffer[0]) {
                ECLevelMSR = pPosKbdData->MSRData.MSRDataBuffer[2];
            } else if (0x01 & pPosKbdData->MSRData.MSRDataBuffer[0]
                       && OB_KBD == KbdHWIDs) {
                /* *********************************************
                 * For Outerbanks keyboards, the first bit of
                 * the first status byte set tells us that this
                 * is a DEVICE INFO response.  We need to save
                 * the information so that we can be queried
                 * later.
                 * *********************************************
                 */
                ECLevelMSR = MSRdevinfo.ecLevel;
            }

            /* Capture and save Dev Info Data */
            if (pPosKbdData->MSRData.MSRDataBuffer[0] &
                POS_MSR_DEV_INFO_MSG_PRESENT) {
                /* First copy data from Msr Data buffer into
                 * Msr Status buffer.
                 */
                memcpy(&pPosKbdData->PosMsrStatus.MSRStatus,
                       &pPosKbdData->MSRData.MSRDataBuffer, 7);

                /* Need to mask bit 7 since keyboard sets it */
                pPosKbdData->PosMsrStatus.MSRStatus[2] &= 0x3F;
                pPosKbdData->PosMsrStatus.MSRStatus[3] &= 0x0F;
                pPosKbdData->PosMsrStatus.MSRStatus[4] &= 0x0F;
                pPosKbdData->PosMsrStatus.MSRStatus[5] &= 0x0F;
                pPosKbdData->PosMsrStatus.MSRStatus[6] &= 0x0F;

                /* save Device Info into a structure from Status
                 * info
                 */
                memcpy(&pPosKbdData->PosMsrDeviceInfo,
                       &pPosKbdData->PosMsrStatus.MSRStatus[2],
                       5);

                /* Reset MSR Data Length */
                memset(&pPosKbdData->MSRData, 0,
                       sizeof(pPosKbdData->MSRData));

                pPosKbdData->MSRData.MSRDataLength  = 0;


                aip_dbg("Msr DevInfo %02x.%02x.%02x.%02x.%02x\n",
                        pPosKbdData->PosMsrDeviceInfo.deviceType,
                        pPosKbdData->PosMsrDeviceInfo.deviceID,
                        pPosKbdData->PosMsrDeviceInfo.Features,
                        pPosKbdData->PosMsrDeviceInfo.CommandSet,
                        pPosKbdData->PosMsrDeviceInfo.ECLevel);
            }

            /* ************************************************************
             * Save the data length and reset the index to 0.  Also,
             * reset the COLLECTING_MSR_STATUS flag.
             * ************************************************************
             */
            pPosKbdData->MSRData.Index = 0;

            pPosKbdData->fStatus &= ~COLLECTING_MSR_STATUS;
            scancode = 0;
            scanFlag = 1;

            /* wake up the process */
            aipikbps_command_finish();

            /* notify aipctrl pid. */
            if (pPosKbdData->asyncEnabled) {
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 27)
                kill_proc(pPosKbdData->asyncPID, SIGUSR2, 1);
#else
                kill_pid(pPosKbdData->asyncPID, SIGUSR2, 1);
#endif
            }

        }
        break;

    default:
        /* ***************************************************************
         * Don't do anything here.  We will handle just past this
         * switch statement.  It is possible to get a scancode that
         * fits into a case statement above and is not grounded and
         * hence needs to be handled (ie 0xF2 when we have not
         * received a 0xF1 yet).
         * ***************************************************************
         */
        break;
    }

    /* ********************************************************************
     *  Crystal Support:
     *    - simply send out the scancode without any sort of translation
     *      since the double keys not supported.
     *    - the nanpos keyboard key positions do not make any sense except
     *      get lost in translation
     *    - return scancode right here w/o any processing.
     * ********************************************************************
     */
    if ((pPosKbdData->PosKbdDeviceInfo.deviceID == 0x08) && scancode) {
        *pScancode = scancode;
        rc = 0;
        return rc;

    }


    /* ********************************************************************
     * If we still have a non-grounded scancode at this point, we will
     * need to determine if we have a full keystroke yet.  If we do, we
     * will set the key value for doublekey and remap processing.
     * ********************************************************************
     */
    if (scancode && (0 == scanFlag)) {
        /* ****************************************************************
         * At this point, the scancode hasn't been grounded, so we will
         * put it in the buffer.
         * ****************************************************************
         */
        if (keyBufferIndex >= 3)
            keyBufferIndex = 0;

        keyBuffer[keyBufferIndex++] = scancode;

        aip_dbg("KeyBufferIndex=%d, KeyBuffer=%02x.%02x.%02x\n",
                keyBufferIndex, keyBuffer[0], keyBuffer[1],
                keyBuffer[2]);

        if (keyBufferIndex == 1) {
            if ((pPosKbdData->fStatus & DOUBLE_KEYS_109_108) &&
                ((scancode == 0x1C) || (scancode == 0x9C))) {
                key = E0Table[KBD][scancode];
                aip_dbg("E0Table[%d][%02x]=0x%02x(%d)\n", KBD, scancode, key, key);
            } else {
                key = ScanSet1Table[scancode];
                aip_dbg("ScanSet1Table[%d][%02x]=0x%02x(%d)\n", KBD, scancode, key, key);
            }

            if (key) {
                fBreak = scancode > 0x7F ? (unsigned char) 1 : (unsigned char) 0;
            } else {
                scancode = 0;
            }

        } else if (0xE2 == keyBuffer[0]) {
            if (0xF2 != scancode) {
                if ((0xD9 <= scancode) && (scancode <= 0xEE)) {
                    key = E2Table[scancode - 0xD9];
                    fBreak = (0xF2 == keyBuffer[1] ? (unsigned char) 1: (unsigned char) 0);
                } else {
                    scancode = 0;
                }
            }
        }

        if ((keyBuffer[0] == 0xE0) || (keyBuffer[0] == 0xE1)) {
            scancode = keyBuffer[0];
            keyBufferIndex = 0;
            key = 0;

            /* check for double-key processing already on XXX */
            if (pPosKbdData->double_key_active == 1) {
                /* Indicate E0 has been skipped */
                pPosKbdData->double_key_active = 2;
                scancode = 0;
            } else if (pPosKbdData->double_key_active == 2) {
                scancode = 0;
            }
        } else if ((scancode == 0xE2) || (scancode == 0xF2)) {
            /* don't reset keyBufferIndex, expecting more
             * scancodes
             */
            scancode = 0;
            key = 0;
        }
    }

    /* *******************************************************************
     * If we still haven't grounded the keystroke, check for double key.
     * *******************************************************************
     */
    if (key) {
        /* ***********************************************************
         * For now, make sure that we have explicitly set this value.
         * Once the code is bug-free, we can choose an initial value and
         * only change it if necessary.
         * ***********************************************************
         */
        key = DoubleKeyProcessing(key, fBreak);

        if (0 == key) {
            /* ***************************************************
             * Clear the scancode buffer
             * ***************************************************
             */
            while (keyBufferIndex)
                keyBuffer[--keyBufferIndex] = 0;

            scancode = 0;
        }
    }

    /* *******************************************************************
     * If we still have a key, clear out the scancode buffer and replace
     * what's there with the desired scancodes for the keystroke.  This
     * may very well have changed if we have replaced a secondary double
     * key value with the primary.  In the future we may want to do this
     * only if we know that the double key substitution has been done.
     * *******************************************************************
     */
    if (key) {

#if !defined(V4690)
        if ((key == 136) &&
            ((pPosKbdData->ShiftFlags && 0x40) ||
             (pPosKbdData->ShiftFlags && 0x04))) {
            /* Pass the original scancode through in this case... */
        } else {
#endif
            /* ***********************************************************
             * Clear the scancode buffer
             * ***********************************************************
             */

            while (keyBufferIndex)
                keyBuffer[--keyBufferIndex] = 0;

            /* ***********************************************************
             * Copy in the scancodes.
             * ***********************************************************
             */
            while (ScancodesToGo[key][keyBufferIndex]) {
                keyBuffer[keyBufferIndex] = ScancodesToGo[key][keyBufferIndex];
#if 0
                aip_dbg("scTogo ==> keyBuf[keyBufferIndex] = 0x%x\n",
                        keyBuffer[keyBufferIndex]);
#endif

                ++keyBufferIndex;
            }
#if !defined(V4690)
        }
#endif

#if defined(V4690)
        /* Fix bug in this driver for Alt-SysRq */
        if (keyBufferIndex == 1 && 136 == key && 0x54 == (0x7f & scancode)) {
            keyBuffer[0] = 0x54;
            fBreak = 0x80 & scancode ? 1 : 0;
        }
#endif

        /* ***********************************************************
         * If this is a break sequence, we either need to set the high
         * bit (scan set 1) or shift the second byte into the third
         * position and add a 0xF2 as the new second byte.
         * ***********************************************************
         */
        if (fBreak) {
            keyBuffer[keyBufferIndex - 1] |= 0x80;
        }

        /* ***********************************************************
         * First, if the key is a POS unique key and we are trapping off
         * POS unique keys, then ground it here.  Second, we need to
         * remap the POS unique key scancodes to the Mark McClanahan
         * defined ones.
         * ***********************************************************
         */

        /* ***********************************************************
         * If we are trapping off POS unique keys and this is one of
         * them, ground the key.
         * ***********************************************************
         */
        if (pPosKbdData->fTrap & PosTRAP_POS_SPECIFIC &&
            POSSpecific[key]) {
            key = 0;

            while (keyBufferIndex)
                keyBuffer[--keyBufferIndex] = 0;
        }

        /* ***********************************************************
         * Allow the remap function to change the scancodes.  This is
         * used to set the Intrepid defined scancodes for POS unique
         * keys.  Later, it can be used to do general remapping of
         * keys.
         * ***********************************************************
         */
        if (key) {
            /* ***************************************************
             * Remap POS specific scancodes.  Remapping is needed
             * to ensure the OS passes the scancodes to applications.
             * ***************************************************
             */

            unsigned char remapKey = RemapTable[key];

#if defined(V4690)
            if (is4690mode && !(*scanState & gotE0))
                remapKey = RemapTable4690[key];
#endif

            if (remapKey) {
                while (keyBufferIndex)
                    keyBuffer[--keyBufferIndex] = 0;

                keyBuffer[0] = fBreak ? remapKey | (unsigned char) 0x80 : remapKey;
                keyBufferIndex = 1;
            }

        }
#if 0
        aip_dbg("5) key = 0x%x, buf[0] = 0x%x, Index1 = 0x%x\n",
                key, keyBuffer[0], keyBufferIndex);
#endif

        scancode = keyBuffer[0];
        keyBufferIndex = 0;
    }

    /* We need to maintain the shift state of SHIFT, CTRL, ALT keys.
     * This is needed to trap certain keys.
     */
    if (scancode == (unsigned char) 0xFF) {
        *scanState = OK;
    } else {
        switch (*scanState) {
        case OK:
            if (scancode == (unsigned char) 0xE0) {
                *scanState |= gotE0;
                break;
            } else if (scancode == (unsigned char) 0xE1) {
                *scanState |= gotE1;
                break;
            }

        case gotE0:
        case gotE1:
            /*
             * The POS keyboards repeat E0/E1 if interrupted
             * with an outgoing command, this ignores the repeated scancode
             */
            if (scancode == 0xE0 || scancode == 0xE1)
                scancode = 0;
            /* Save Shift States for Pos Keyboard */
            if (scancode != 0) {
                SetShiftKeyState(scancode, scanState);

                /* Reset the state to OK. */
                *scanState = OK;
            }
            break;
        }
    }

    /* setup rc and scancode to be pass. */
    if (scancode == 0) {
        /* scancode is consumed by us */
        *pScancode = 0;
        rc = 1;
    } else {
        /* return scancode for further processing */
        *pScancode = scancode;
        rc = 0;
    }

    /* handle new canpos key 105-106 */
    if ((pPosKbdData->CanposKeyboard == 1) ||
        (pPosKbdData->PosKbdDeviceInfo.deviceID == 0x0A)) {
        if (canpos_key_105_106 != 0) {
            aip_dbg("canpos key_105-106");
            scancode = canpos_key_105_106;
            keyBuffer[0] = scancode;
            *pScancode = scancode;
            keyBufferIndex = 0;
            rc = 0;
            canpos_key_105_106 = 0;
        }
    }

    if (original_scancode == 0xE0) {
        aipikbps_prev_key_e0 = 1;
    } else {
        aipikbps_prev_key_e0 = 0;
    }

    if (keyBufferIndex > 0) {
        aip_dbg("Index=%d, KeyBuffer=%02x.%02x.%02x\n",
                keyBufferIndex, keyBuffer[0], keyBuffer[1],
                keyBuffer[2]);
    }

    aip_verbose("rc=%d, input_scancode=0x%x, scancode=0x%x\n",
                rc, original_scancode, *pScancode);

    return rc;
}


/* :H1.CanposPosKbdSendData() - Send data to keyborad (canpos).
 * ***********************************************************************
 *
 * Function Name:  CanposPosKbdSendData()
 *
 * Purpose:        To send data to keyboard (canpos).
 *
 * Description:    A routine to send data to canpos keyboard (larger buffer).
 *
 * Input:          unsigned char * buffer.
 *                 size of buffer
 *
 * Output:         returns number of bytes transferred.
 *                 0 - success
 *                 1 - failure.
 *
 * Notes:
 *
 * ***********************************************************************
 */

static int CanposPosKbdSendData(unsigned char *buf, unsigned int size)
{
    int     rc = 0;
    long    timeleft = 500;
    int     i = 0;
    int     xferred = 0;

    aipikbps_busy_wait(4);

    /* Call pc_key driver's send routine to send data. */
    rc = aipikbps_command_start(100);
    if (rc < 0) {
        aip_error("could not lock keyboard (error=%d)\n", rc);
        return rc;
    }

    for (i = 0; i < size; i++) {

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 16)
        rc = pos_filter.write_data((buf+i),1, &xferred, 1, 1000);
#else
        rc = aipikbps_write_buffer((buf+i),1, &xferred, 1, 1000);
#endif
        if (rc != 0) {

            aip_warning("unsuccessful transfer, return:%d, the %d byte\n",
                        rc, i);
        }
        mdelay(2);
    }


    /* Go to sleep.  The wait queue is awakened in pos_kbd_filter() routine
     * when command is complete i.e. receipt of
     *
     *   -  0xF2 end of keyboard status OR
     *   -  0xF6 end of msr status      OR
     *   -  0xF7 ROL in response to keyboard reset.
     */

    aip_dbg("Completed the call-waiting for timeout, rc=%d\n", rc);

    if (rc != 0) {
        aipikbps_command_finish();
    }

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 16)
    if (cmd_busy != 0) {
        timeleft = aipikbps_timeout(500);
    }
#else
    if (cmd_busy != 0)
        timeleft = interruptible_sleep_on_timeout(&wq, 50*HZ);
#endif

    if (cmd_busy != 0 && timeleft == 0) {
        aip_error("exit, write timed out\n");
        cmd_busy = 0;
        wake_up_interruptible_all(&wq);

        rc = -ENODEV;
    }

    aip_dbg("exit, rc=%d %s\n", rc, rc == 0 ? "Success" : "Failed");

    return rc;
}


/* todo -- add prolog
 * collect canpos configuration data
 * set CanposState = CANPOS_COLLECT_READ_CONFIG_DATA upon enter this routine
 * when collecting done, exit with CanposState = CANPOS_READY
 *
 */

#if 0
static unsigned char colleting_canpos_read_config_data(unsigned char sc)
{
    unsigned char rc = sc;

    if (pPosKbdData->CanposState == CANPOS_COLLECT_READ_CONFIG_DATA) {
        if (rc == 0xFA)
            pPosKbdData->canposConfigAck++;

        /* save it all in buffer */
        pPosKbdData->canpos_config.Data[pPosKbdData->CanposConfigBytesCollected++] = sc;

        if (pPosKbdData->CanposConfigBytesCollected >= W_CONFIG_READ_RETURN_SIZE - W_CONFIG_READ_RETURN_OFFSET) {
            aip_dbg("Canpos collect config data: CanposState=CANPOS_READY\n");
            pPosKbdData->CanposState = CANPOS_READY;
        }

        if (rc != 0xfa)
            rc = 0;     /* pass only ack character back */
    }

    return rc;
}
#endif


/* TODO:  Function header
 * collecting normal ack
 * return 0 if scancode being filter out
 * return scancode otherwise
 */

unsigned char collecting_canpos_normal_ack(unsigned char sc)
{

    if (sc == 0x02) {
        aip_verbose("CANPOS_COLLECT_NORMAL_ACK: Make of Key Press 1\n");
        sc =  0x00;
        scanFlag = 1;
    } else if (sc == 0x82) {
        /* got keypress of 1 sequence */
        aip_verbose("CANPOS_COLLECT_NORMAL_ACK: key-of-1: sc=0x%x\n", sc);
        sc =  0x00;
        scanFlag = 1;
        pPosKbdData->CanposState = CANPOS_GOT_CONFIG_KEY_1;
    }
    return sc;
}


/*TODO:  Function header
 * return 0 if scancode being filter out
 * return scancode otherwise
 * this routine trap the scancode of key-press 1
 */

static unsigned char collecting_canpos_write_config_ack(unsigned char sc)
{
    if (pPosKbdData->canposConfigAck < 1281) {
        /* wait for acks */
        pPosKbdData->canposConfigAck++;

        /*Ack for E5 */
        /* here is a hack for 2.4 kernel losts ACK */
        if (sc != 0xfa && pPosKbdData->canposConfigAck == 1281) {
            aip_dbg("CANPOS_COLLECT_WRITE_CONFIG_ACK: ACk for E5\n");
            sc = 0xFA;    /* debug */
        }
    } else if (sc == 0x82 || sc == 0xaa) {
        /* got keypress of 1 sequence */
        aip_dbg("CANPOS_COLLECT_WRITE_CONFIG_ACK: key-of-1: sc=0x%x\n", sc);

        if (sc == 0x82)
            pPosKbdData->CanposState = CANPOS_GOT_CONFIG_KEY_1;
        sc =  0;
        scanFlag = 1;
    }
    return sc;
}


/*TODO:  Function header
 * collecting ack during a canpos write flash update data
 * return 0 if scancode being filter out
 * return scancode otherwise
 */

static unsigned char collecting_canpos_flash_ack(unsigned char sc)
{

    if (pPosKbdData->canposFlashAck < (pPosKbdData->flashSize + 3)) {
        /* wait for acks */
        pPosKbdData->canposFlashAck++;
        scanFlag =1;

        /*Ack for the Last Flash Data Byte i.e. LRC */
        /* HACK for lost ACK on Linux 2.4 */
        /* if (sc == 0xFE && pPosKbdData->canposFlashAck==(pPosKbdData->flashSize+3) ) */
        if (sc != 0xFA && pPosKbdData->canposFlashAck == (pPosKbdData->flashSize + 3)) {

            aip_dbg("CANPOS_COLLECT_FLASH_ACK: ACk for LRC\n");
            sc =  0xFA;
            scanFlag = 1;
        }
        if (pPosKbdData->canposFlashAck == (pPosKbdData->flashSize + 3)) {

            aip_dbg(" Last byte of Flashing SC=0x%x", sc);
        }
    } else if (sc == 0x02) {
        /* got keypress of 1 sequence */
        aip_dbg("CANPOS_COLLECT_FLASH_ACK: Make code  for Key1: sc=0x%x\n",
                sc);

        sc =  0;
        scanFlag = 1;
    } else if (sc == 0x82 || sc == 0xaa) {
        /* got keypress of 1 sequence */
        aip_dbg("CANPOS_COLLECT_FLASH_ACK: key-of-1: sc=0x%x\n", sc);
        aip_dbg("The total ACK recieved is: %d\n", pPosKbdData->canposFlashAck);
        if (sc == 0x82)
            pPosKbdData->CanposState = CANPOS_GOT_CONFIG_KEY_1;
        sc =  0;
        scanFlag = 1;
    }

    return sc;
}


/* wake up the process */
static void wake_up_canpos_process(void)
{
    /* wake up the process */
    aipikbps_command_finish();

    /* notify aipctrl pid. */
    if (pPosKbdData->asyncEnabled) {
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 27)
        kill_proc(pPosKbdData->asyncPID, SIGUSR2, 1);
#else
        kill_pid(pPosKbdData->asyncPID, SIGUSR2, 1);
#endif
    }
}


static unsigned char check_canpos_key_105_106(unsigned char scancode)
{
    canpos_key_105_106 = 0;

    if (scancode == 0x4a ||
        scancode == 0xca ||
        scancode == 0x4e ||
        scancode == 0xce) {
        aip_dbg("canpos-key-105-106: 0x%x\n", scancode);

        canpos_key_105_106 = scancode;
    }

    return scancode;
}

unsigned char collecting_canpos_ver_info(unsigned char sc)
{

    if (sc == 0xFA)
        scanFlag = 1;
    else {
        pPosKbdData->verinfo[pPosKbdData->verinfosize] = sc;
        pPosKbdData->verinfosize++;
        scanFlag = 1;
        sc =0;

        if (pPosKbdData->verinfosize == VER_INFO_SIZE) {
            aip_dbg("Version Info Collected Successfully\n");
            pPosKbdData->verinfosize = 0;
            pPosKbdData->CanposState = CANPOS_COLLECT_VER_INFO_COLLECTED;
        }
    }

    return sc;
}


#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 16)
static int aipikbps_port_enabled = 0;
static int aipikbps_port_cmd_remaining_bytes = 0;

static int aipikbps_port_write(struct serio *serio, unsigned char data)
{
    int rc;

    if (!aipikbps_serio || !aipikbps_port_enabled)
        return -ENODEV;

    /* If in a code update, respond with busy status */
    if (pPosKbdData->RawCodeUpdateData) {
        aip_verbose("!!Code Update In Progress!! byte not sent...value=%02x, returning EBUSY\n",
            data);
        return -EBUSY;
    }

    if (!aipikbps_port_cmd_remaining_bytes) {
        rc = aipikbps_command_start(100);
        if (rc < 0) {
            aip_error("could not lock keyboard (error=%d)\n", rc);
            return rc;
        }

        down(&aipikbps_sema);
    }

    aip_verbose("sending byte: value=%02x\n", data);
    rc = aipikbps_write(data, 0);

    if (aipikbps_port_cmd_remaining_bytes)
        aipikbps_port_cmd_remaining_bytes--;
    else if (data == 0xed)
        aipikbps_port_cmd_remaining_bytes = 1;

    if (!aipikbps_port_cmd_remaining_bytes) {
        up(&aipikbps_sema);

        aipikbps_command_finish();
    }

    return rc;
}

static int aipikbps_port_open(struct serio *serio)
{
    aipikbps_port_enabled = 1;
    return 0;
}

static void aipikbps_port_close(struct serio *serio)
{
    aipikbps_port_enabled = 0;
}

static int aipikbps_port_start(struct serio *serio)
{
    return 0;
}

static void aipikbps_port_stop(struct serio *serio)
{
}

static int aipikbps_create_kbd_port(struct serio *serio)
{
    aipikbps_serio = kzalloc(sizeof(struct serio), GFP_KERNEL);
    if (!aipikbps_serio)
        return -ENOMEM;

    pPosKbdData->RawCodeUpdateData = NULL;

    aipikbps_serio->id.type = serio->id.type;
    aipikbps_serio->write       = aipikbps_port_write;
    aipikbps_serio->open        = aipikbps_port_open;
    aipikbps_serio->close       = aipikbps_port_close;
    aipikbps_serio->start       = aipikbps_port_start;
    aipikbps_serio->stop        = aipikbps_port_stop;
    strlcpy(aipikbps_serio->name, "aipikbps virtual i8042 Kbd Port",
            sizeof(aipikbps_serio->name));
    strlcpy(aipikbps_serio->phys, AIPIKBPS_PHYS_NAME,
            sizeof(aipikbps_serio->phys));

    serio_register_port(aipikbps_serio);

    return 0;
}


#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 19)
static irqreturn_t aipikbps_interrupt(struct serio *serio, unsigned char data,
                                      unsigned int flags, struct pt_regs *regs)
{
    if (!pos_scancode_filter(&data) && aipikbps_port_enabled) {
        serio_interrupt(aipikbps_serio, data, flags, regs);
    }

    return IRQ_HANDLED;
}
#else
static irqreturn_t aipikbps_interrupt(struct serio *serio, unsigned char data,
                                      unsigned int flags)
{
    int rc = 0;
    aip_dbg("Received %02x flags=%04x\n", data, flags);
    rc = pos_scancode_filter(&data);
    if  (aipikbps_port_enabled) {
        if (rc == 0) {
           if (pPosKbdData->double_key_active == 3) {
                unsigned char e0 = 0xE0;

                aip_dbg("Sending (skipped) %02x flags=%04x\n", e0, flags);
                serio_interrupt(aipikbps_serio, e0, flags);
                pPosKbdData->double_key_active = 0;
            }
            aip_dbg("Sending %02x flags=%04x\n", data, flags);
            serio_interrupt(aipikbps_serio, data, flags);
        }
    }

    return IRQ_HANDLED;
}
#endif


static int aipikbps_reconnect(struct serio *serio)
{
    if (aipikbps_port_enabled)
        serio_reconnect(aipikbps_serio);

    return 0;
}


static void aipikbps_disconnect(struct serio *serio)
{
    if ((serio != NULL) && (aipikbps_real_serio == serio)) {
        aip_dbg("Disconnect from name='%s', phys='%s'\n",
                serio->name, serio->phys);

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 18)
        aipikbps_device_destroy(aipikbps_major, DEVDRVR_ID);
#else
        aipikbps_device_destroy(&Adapter);
#endif

        serio_unregister_port(aipikbps_serio);

        aipikbps_real_serio = NULL;

        serio_close(serio);
    }
}


static void aipikbps_cleanup(struct serio *serio)
{
}


static struct serio_device_id aipikbps_serio_ids[] = {
    {
        .type   = SERIO_8042,
        .proto  = SERIO_ANY,
        .id = SERIO_ANY,
        .extra  = SERIO_ANY,
    },
    {
        .type   = SERIO_8042_XL,
        .proto  = SERIO_ANY,
        .id = SERIO_ANY,
        .extra  = SERIO_ANY,
    },
    { 0}
};


MODULE_DEVICE_TABLE(serio, aipikbps_serio_ids);

static struct serio_driver aipikbps_drv = {
    .driver     = {
        .name   = "aipikbps",
    },
    .description    = DRIVER_DESC,
    .id_table   = aipikbps_serio_ids,
    .interrupt  = aipikbps_interrupt,
    .connect    = aipikbps_connect,
    .reconnect  = aipikbps_reconnect,
    .disconnect = aipikbps_disconnect,
    .cleanup    = aipikbps_cleanup,
};
#endif


/* :H1.kb_init() - Driver entry point.
 * ***********************************************************************
 *
 * Function Name:  kb_init()
 *
 * Purpose:        Intialization routine
 *
 * Description:    Entry point for this driver
 *
 *
 *
 * Output:
 *                 0        - success
 *                 non-zero - failure.
 *
 * Notes:
 *
 * ***********************************************************************
 */
static int __init kb_init(void)
{
    int err = 0;

    pPosKbdData = kzalloc(sizeof(POS_KEYBOARD_DATA), GFP_KERNEL);
    if (!pPosKbdData)
        return -ENOMEM;

    pPosKbdData->RawCodeUpdateData = NULL;

    memset(&KBDdevinfo, 0, sizeof(DEVICE_INFO));
    memset(&MSRdevinfo, 0, sizeof(DEVICE_INFO));

    pPosKbdData->CanposState = CANPOS_READY;
    pPosKbdData->CanposConfigBytesCollected = 0;
    pPosKbdData->CanposKeyboard = 0;
    pPosKbdData->v2Keyboard = 0;
    pPosKbdData->verinfosize = 0;

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 16)
    err = do_patch_kb_init();
#else
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 18)
    memset(&Adapter, 0, sizeof(kbd_adapter));
#endif

#ifndef init_MUTEX
    sema_init(&aipikbps_sema, 1);
#else
    init_MUTEX(&aipikbps_sema);
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 21)
    err = serio_register_driver(&aipikbps_drv);
#else
    serio_register_driver(&aipikbps_drv);
#endif
#endif

    return err;
}

static void __exit kb_exit(void)
{
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 16)
    /* Unregister driver with the kernel */
    aipikbps_device_destroy(aipikbps_major, DEVDRVR_ID);

    aip_dbg("unregister devnode success\n");

    /* unregister with pc_keyb driver. */
    unregister_pc_keyb_filter(&pos_filter);
#else
    serio_unregister_driver(&aipikbps_drv);
#endif
    if (pPosKbdData) {
        kfree(pPosKbdData);
        pPosKbdData = NULL;
    }
}

module_init(kb_init);
module_exit(kb_exit);


MODULE_AUTHOR("Toshiba Global Commerce Solutions, Inc");
MODULE_DESCRIPTION(DRIVER_DESC);
MODULE_LICENSE("GPL");
