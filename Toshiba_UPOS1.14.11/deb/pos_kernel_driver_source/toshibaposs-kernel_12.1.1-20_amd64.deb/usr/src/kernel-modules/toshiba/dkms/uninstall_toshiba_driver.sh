#!/bin/bash
version=12.1.1.20

echo Uninstalling toshiba-poss-kernel version ${version}
sudo dkms uninstall toshiba-poss-kernel/${version}

echo Removing toshiba-poss-kernel version ${version}
sudo dkms remove toshiba-poss-kernel/${version} --all

sudo rm -rf /usr/src/toshiba-poss-kernel-${version}
