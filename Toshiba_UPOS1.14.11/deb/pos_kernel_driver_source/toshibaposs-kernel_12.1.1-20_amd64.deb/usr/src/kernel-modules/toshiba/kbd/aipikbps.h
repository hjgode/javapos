/*
 *  Module Name:     aipikbps.h
 *
 *  Description:     keyboard kernel driver include
 *
 *  Copyright (C) 2004-2015 Toshiba Global Commerce Solutions, Inc.
 *  All right reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA; Otherwise,
 *  see <http://www.gnu.org/licenses/>.
 *
 *
 * Should you need to contact me, the author, you can do so either by
 * e-mail - mail your message to <gha@toshibagcs.com>.
 */

#ifndef AIPIKBPS_H
#define AIPIKBPS_H

#define FALSE 0
#define TRUE  1


/*   POS ERROR CODES */
#define RPDONE           0x0100
#define RPERR            0x8000
#define RPDEV            0x4000


/* POS Keybaord Signature */
#define IBM_KBD_SIG 'k'

/* IOCTL CODES for Keyboard */
#define FN_POS_LEDS               _IOWR(IBM_KBD_SIG, 1, POSLEDS)
#define FN_GET_SHIFT_STATE        _IOWR(IBM_KBD_SIG, 2, SHIFT_STATE)
#define FN_SET_SHIFT_STATE        _IOWR(IBM_KBD_SIG, 3, SHIFT_STATE)
#define FN_READ_KBD_STATUS        _IOWR(IBM_KBD_SIG, 4, READ_KBD_STATUS_PARMS)
#define FN_TONE                   _IOWR(IBM_KBD_SIG, 5, TONE)
#define FN_CLICK                  _IOWR(IBM_KBD_SIG, 6, CLICK)
#define FN_TYPEMATIC              _IOWR(IBM_KBD_SIG, 7, TYPEMATIC)
#define FN_ENABLE_DISABLE         _IOWR(IBM_KBD_SIG, 8, ENABLE_DISABLE)
#define FN_TRACKS                 _IOWR(IBM_KBD_SIG, 9, TRACKS)
#define FN_READ_MSR_DATA          _IOWR(IBM_KBD_SIG, 10, READ_MSR_DATA_PARMS)
#define FN_TRAP_KEYS              _IOWR(IBM_KBD_SIG, 11, TRAP_KEYS)
#define FN_QUERY_KEYBOARD         _IOWR(IBM_KBD_SIG, 12, QUERY_KEYBOARD_PARMS)
#define FN_SET_DOUBLEKEYS         _IOWR(IBM_KBD_SIG, 13, DOUBLE_KEYS)
#define FN_CODE_UPDATE            _IOWR(IBM_KBD_SIG, 14, CODE_UPDATE_DATA)
#define FN_QUERY_CODE_UPDATE      _IOWR(IBM_KBD_SIG, 15, CODE_UPDATE_STR)
#define ENABLE_ANPOS_ASYNC_COMM   _IOWR(IBM_KBD_SIG, 16, ENABLE_ANPOS_ASYNC_COMM_PARMS)
#define DISABLE_ANPOS_ASYNC_COMM  _IOWR(IBM_KBD_SIG, 17, ANPOS_COMPLETION_CODE_PARMS)

#define FN_CANPOS_READ_CONFIG     _IOWR(IBM_KBD_SIG, 18, POS_CANPOS_READ_CONFIG )
#define FN_CANPOS_WRITE_CONFIG    _IOWR(IBM_KBD_SIG, 19, POS_CANPOS_WRITE_CONFIG)
#define FN_CANPOS_FLASH_UPDATE    _IOWR(IBM_KBD_SIG, 20, POS_CANPOS_FLASH_UPDATE)
#define FN_QUERY_CANPOS_KEYBOARD  _IOWR(IBM_KBD_SIG, 21, MODQUERY_KEYBOARD_PARMS)
#define ENABLE_4690_MODE          _IOWR(IBM_KBD_SIG, 22, NULL)
#define DISABLE_4690_MODE         _IOWR(IBM_KBD_SIG, 23, NULL)

#define IOCTL_MAX_NUMBER      21    /* maxinum ordinal number */

/* Miscellaneous Constants */
#define OB_KBD       0x87AB
#define ANPOS_KBD    0x88AB
#define ENHANCED_KBD 0x41AB

/* 4694 CONTROLLER TYPE 1 (Scanset 2) */
/* #define  CONTROLLER  0 */

/* PS/2 CONTROLLER TYPE 2 (Scanset 1) */
#define  CONTROLLER  1

#define KbdHWIDs     OB_KBD            /* ENHANCED_KBD */
#define KBD ( OB_KBD == KbdHWIDs )

#define OB_EC_BIT    0x40
#define ANPOS_EC_BIT 0x01
#define BREAK        ((unsigned char)0x80)

/* Define the 8042 responses. */
#define ACKNOWLEDGE         0xFA
#define RESEND              0xFE
#define REQUEST_ON_LINE     0xF7

/* Keyboard Status Byte 1 Response Definitions. */
#define CODE_UPDATE_STORED  0x20    /* V1:Update stored, V2:Update in process */
#define OPERATION_IN_ERROR  0x02    /* V2 Only: Error onlast command sent */
#define COMMAND_COMPLETE    0x01

/* Bit Definitions for "fStatus" flag */
#define COLLECTING_PRIMARY_ID   0x0001
#define COLLECTING_KBD_STATUS   0x0002
#define COLLECTING_MSR_STATUS   0x0004
#define SENDING_CODE_UPDATE     0x0008
#define WAITING_FOR_KBD_STATUS  0x0010
#define WAITING_FOR_MSR_STATUS  0x0020
#define COLLECTING_SECONDARY_ID 0x0040
#define KBD_ROL_RECEIVED        0x0080
#define CODE_UPDATE_STARTED     0x0100
#define WAITING_FOR_KBD_ACK     0x0200
#define KBD_ACK_RECEIVED        0x0400
#define KBD_NAK_RECEIVED        0x0800
#define DOUBLE_KEYS_109_108     0x1000
#define DEV_INFO_REQUEST_SENT   0x2000
#define CODE_UPDATE_LAST_BLOCK_SENT  0x4000

/* Bit Definitions for CONFIGURE COMMAND */
#define POS_CLICK_SOFT    0x04
#define POS_CLICK_LOUD    0x08

#define POS_SCANNING_OFF  0x00
#define POS_SCANNING_ON   0x01

#define POS_TYPEMATIC_OFF 0x00
#define POS_TYPEMATIC_ON  0x02

#define POS_LEDS_OFF      0x00

/* excerpts from keyboard.h and device.h */
#define PosOFF          0x00
#define PosON           0x01
#define PosSOFT         0x01
#define PosLOUD         0x02

/* POS Keyboard  Commands */
#define POS_MAX_COMMAND_LENGTH        4
#define RPIOCTL                    0x10
#define POS_LEDS_COMMAND           0x1C
#define POS_TONE_COMMAND           0x13

#define POS_KBD_DEV_INFO_CMD_BYTE1 0x11
#define POS_KBD_DEV_INFO_CMD_BYTE2 0x00
#define POS_KBD_DEV_INFO_CMD_BYTE3 0x01

#define POS_MSR_DEV_INFO_CMD_BYTE1 0x00
#define POS_MSR_DEV_INFO_CMD_BYTE2 0x00
#define POS_MSR_DEV_INFO_CMD_BYTE3 0x01

#define KBD_CONFIGURE_CMD  0X21
#define MSR_CONFIGURE_CMD  0X01

#define POS_KBD_RESET_CMD_BYTE1 0x11
#define POS_KBD_RESET_CMD_BYTE2 0x40

#define MAX_DOUBLE_KEYS 90
#define KBD_CONFIGURE_CMD_LENGTH  4

#define CODE_UPDATE_CMD   0x22

#define SET_INTERFACE_VERSION_CMD  0x24

/* Status bit definitons for Dev Info */
#define POS_KBD_DEV_INFO_MSG_PRESENT  0x04
#define POS_MSR_DEV_INFO_MSG_PRESENT  0x01

/* Lengths of the individual MSR tracks */
#define MAX_TRACK_1               98
#define MAX_TRACK_2               46
#define MAX_TRACK_3              139
#define MAX_TRACK_J              176
#define MSR_CONFIGURE_CMD_LENGTH   2

/* Scancode Definitions of POS Keyboard */
#define SCANCODE_ESC            0x01
#define SCANCODE_ESC_UP         0X81
#define SCANCODE_TAB            0x0F
#define SCANCODE_TAB_UP         0x8F
#define SCANCODE_CAPS_LOCK      0x3A
#define SCANCODE_NUM_LOCK       0x45
#define SCANCODE_SCROLL_LOCK    0x46
#define SCANCODE_HOME           0x4F
#define SCANCODE_HOME_UP        0xCF
#define SCANCODE_DELETE         0x53
#define SCANCODE_DELETE_UP      0XD3
#define SCANCODE_SCANSET2_EXT   0xE2
#define SCANCODE_BEG_KBD_STATUS 0xF1
#define SCANCODE_END_KBD_STATUS 0xF2
#define SCANCODE_BEG_MSR_STATUS 0xF5
#define SCANCODE_END_MSR_STATUS 0xF6
#define SCANCODE_ROL            0xF7
#define SCANCODE_ACK            0xFA
#define SCANCODE_RESEND         0xFE
#define SCANCODE_CAPS_LOCK_UP   0xBA
#define SCANCODE_NUM_LOCK_UP    0xC5
#define SCANCODE_SCROLL_LOCK_UP 0xC6
#define SCANCODE_BAT_COMPLETE   0xAA
#define SCANCODE_PS2_RESET      0xFF

/*  Keyboard Shift States (Bit positions maintained by the Driver)
 *
 *   LEFT  =>  CTRL = 0x0020, ALT = 0x0040, SHIFT = 0x0010
 *   RIGHT =>  CTRL = 0x0002, ALT = 0x0004, SHIFT = 0x0001
 */
#define CTRL_DOWN  0x0022
#define ALT_DOWN   0x0044
#define SHIFT_DOWN 0x0011

/* As defined for API */
#define SCROLL_LOCK_ON  0x10
#define NUM_LOCK_ON     0x20
#define CAPS_LOCK_ON    0x40

/* State of CapsLock, ScrollLock, NumLock: To indicate whether or not key
 * down scancode is received.
 */
#define SCROLL_LOCK_DOWN  0x1000
#define NUM_LOCK_DOWN     0x2000
#define CAPS_LOCK_DOWN    0x4000

/* Default keyboard scan code mode. */
#define KEYBOARD_SCAN_CODE_SET 0x01



/* Define the keyboard Command Types. */
typedef enum _KEYBOARD_CMD_TYPE {
    PC,                  /* As supported in NT Command */
    POS,                 /* POS Kbd Specific Command */
    CodeUpdt             /* POS Kbd Code Update Command */
} KEYBOARD_CMD_TYPE;

/* Structure for Keyboard LEDs. */
typedef struct _POS_KEYBOARD_INDICATOR_PARAMETERS {

    /* Unit identifier.  Specifies the device unit for which this
     * request is intended.
     */
    unsigned short UnitId;

    /* LED indicator state. */
    unsigned short    LedFlags;

    /* POS LED indicator state */
    unsigned char   POSLedFlags;

} POS_KEYBOARD_INDICATOR_PARAMETERS, *PPOS_KEYBOARD_INDICATOR_PARAMETERS;

/* Define Double Key Buffer */
typedef struct _DOUBLE_KEY {
    unsigned char primaryKey;   /* Key whose scancodes we want */
    unsigned char primaryMake;  /* T/F is the primary key down? */
    unsigned char secondaryKey; /* Key whose scancodes we don't want */
    unsigned char secondaryMake;    /* T/F is the secondary key down? */
    unsigned char lastKey;      /* Last key detected (for typematic) */
} DOUBLE_KEY, *PDOUBLE_KEY;

/* Structures related to code/flash udpate */
#define MAX_BUFFER_SIZE    261
#define UPDATE_SIZE        300
#define UPDATE_FILE_SIZE   65535

typedef struct _CODE_UPDATE {
    unsigned char Length;                   /* Length of Code Update */
    unsigned char Buffer[MAX_BUFFER_SIZE];  /* Buffer[0] always 0x22 (update cmd) */
} CODE_UPDATE, *PCODE_UPDATE;

typedef struct _CODE_UPDATE_BUFFER {
    unsigned short iUpdate;     /* Index into Code Update Buffer */
    unsigned short iBuffer;     /* Index into the Update Block Buffer */
    unsigned short State;       /* State of Command */
    unsigned short EndOfaBlock; /* Signal end of a block of update */
    CODE_UPDATE Update[UPDATE_SIZE];/* Handle upto 300 code update blocks */
} CODE_UPDATE_BUFFER, *PCODE_UPDATE_BUFFER;

typedef struct _CODE_UPDATE_CONTEXT {
    unsigned short Cmd;     /* Command Type */
    unsigned short iUpdate;     /* Index into Code Update Buffer */
    unsigned short iBuffer;     /* Index into the Update Block Buffer */
    unsigned short State;       /* State of Command */
    unsigned short EndOfaBlock; /* Signal end of a block of update */
    CODE_UPDATE Update[UPDATE_SIZE];/* Handle upto 300 code update blocks */

} CODE_UPDATE_CONTEXT, *PCODE_UPDATE_CONTEXT;

/* Define the keyboard set request packet for POS Keyboard */
typedef struct _POS_KEYBOARD_SET_PACKET {
    unsigned short State;
    unsigned short CommandLength;
    unsigned short CommandIndex;
    unsigned char  CommandBuffer[POS_MAX_COMMAND_LENGTH];
} POS_KEYBOARD_SET_PACKET, *PPOS_KEYBOARD_SET_PACKET;

/* Define the keyboard set request packet. */
typedef struct _KEYBOARD_SET_PACKET {
    unsigned short Cmd;
    unsigned short State;
    unsigned char  FirstByte;
    unsigned char  LastByte;
    POS_KEYBOARD_SET_PACKET Pos;
    PCODE_UPDATE_BUFFER pCU;
} KEYBOARD_SET_PACKET, *PKEYBOARD_SET_PACKET;

/* Define Data Struct to store POS Keyboard IDs
 *
 *   - ID byte 1 = 0xAB
 *   - ID byte 2 = 0x87
 */
typedef struct _POS_KEYBOARD_ID {
    unsigned short Flag;
    unsigned short Index;
    unsigned char  KBDId[2];
} POS_KEYBOARD_ID, *PPOS_KEYBOARD_ID;

/* Define Data Struct to store POS Keyboard
 *
 *   - Status bytes       (4 bytes)
 *   - Device Information (5 bytes)
 */
typedef struct _POS_KEYBOARD_STATUS {
    unsigned short Flag;
    unsigned short Index;
    unsigned char  KBDStatus[12];
} POS_KEYBOARD_STATUS, *PPOS_KEYBOARD_STATUS;

/* Define Data Struct to store POS Keyboard Device Info */
typedef struct _POS_KEYBOARD_DEVICE_INFO {
    unsigned char  deviceType;
    unsigned char  deviceID;
    unsigned char  Features;        // Feature Byte 0
    unsigned char  CommandSet;
    unsigned char  ECLevel;
    unsigned char  FeatureByte1;    // Interface V4
    unsigned char  FirmwareVersion; // Interface V4
    unsigned char  FirmwareRelease; // Interface V4
} POS_KEYBOARD_DEVICE_INFO, *PPOS_KEYBOARD_DEVICE_INFO;

/* Define Data Struct to store POS MSR
 *
 *   - Status bytes       (2 bytes)
 *   - Device Information (5 bytes)
 */
typedef struct _POS_MSR_STATUS {
    unsigned short Flag;
    unsigned short Index;
    unsigned char  MSRStatus[7];
} POS_MSR_STATUS, *PPOS_MSR_STATUS;

/* Define Data Struct to store POS MSR Device Info */
typedef struct _POS_MSR_DEVICE_INFO {
    unsigned char  deviceType;
    unsigned char  deviceID;
    unsigned char  Features;
    unsigned char  CommandSet;
    unsigned char  ECLevel;         // Not used for Keelung
} POS_MSR_DEVICE_INFO, *PPOS_MSR_DEVICE_INFO;

/* Define Data Struct to store POS MSR Data */
typedef struct _POS_MSR_DATA {
    unsigned short Flag;
    unsigned short Index;
    uint32_t       MSRDataLength;
    unsigned char  MSRDataBuffer[MAX_TRACK_1 + MAX_TRACK_2 + MAX_TRACK_3 + 1];
} POS_MSR_DATA, *PPOS_MSR_DATA;

/* Keyboard Configure Command */
typedef struct _KBD_CONFIGURE_COMMAND {
    unsigned char Command;
    unsigned char Parm1;
    unsigned char Parm2;
    unsigned char Parm3;
} KBD_CONFIGURE_COMMAND, *PKBD_CONFIGURE_COMMAND;

/* Msr Configure Command */
typedef struct _MSR_CONFIGURE_COMMAND {
    unsigned char Command;
    unsigned char Parm1;
} MSR_CONFIGURE_COMMAND, *PMSR_CONFIGURE_COMMAND;

/* Set Indicators Command */
typedef struct _KBD_SET_INDICATORS {
    unsigned char Command;
    unsigned char Parm1;
} KBD_SET_INDICATORS, *PKBD_SET_INDICATORS;

/* Set Tone Command */
typedef struct _KBD_SET_TONE {
    unsigned char Command;
    unsigned char Parm1;
    unsigned char Parm2;
} KBD_SET_TONE, *PKBD_SET_TONE;

/* Define the keyboard scan code input states. */
typedef enum _POS_SCAN_STATE {
    OK,
    gotE0,
    gotE1
} POS_KEYBOARD_SCAN_STATE, *PPOS_KEYBOARD_SCAN_STATE;

/* Define struct for Device Information Command */
typedef struct {
    unsigned char cmd1;
    unsigned char cmd2;
    unsigned char cmd3;
} DEV_INFO_REQ, *PDEV_INFO_REQ;


#define MAX_BUFFER 1000

/****************************************
 * PosNtrapKeys resource values
 ****************************************
 */
#define PosTRAP_NONE            0x0000
#define PosTRAP_CTRL_ALT_DELETE 0x0001
#define PosTRAP_CTRL_ESC        0x0002
#define PosTRAP_ALT_ESC         0x0004
#define PosTRAP_ALT_TAB         0x0008
#define PosTRAP_ALT_SHIFT_TAB   0x0010
#define PosTRAP_ALT_HOME        0x0020
#define PosTRAP_NUM_LOCK        0x0040
#define PosTRAP_CAPS_LOCK       0x0080
#define PosTRAP_SCROLL_LOCK     0x0100
#define PosTRAP_POS_SPECIFIC    0x0200

#define PosTRAP_HOT_KEYS      ( PosTRAP_CTRL_ESC | PosTRAP_ALT_ESC | PosTRAP_ALT_TAB | PosTRAP_ALT_SHIFT_TAB | PosTRAP_ALT_HOME )
#define PosTRAP_ALL             -1


typedef struct {
    uint32_t       CompletionCode;
    unsigned short length;
    unsigned short fTrapKeys;
} TRAP_KEYS, *PTRAP_KEYS;

typedef struct {
    uint32_t      CompletionCode;
    uint32_t      length;
    char          buffer[MAX_BUFFER];
} READ_KBD_STATUS_PARMS, *PREAD_KBD_STATUS_PARMS;

typedef struct {
    uint32_t      CompletionCode;
    uint32_t      length;
    char          buffer[MAX_BUFFER];
} READ_MSR_STATUS_PARMS, *PREAD_MSR_STATUS_PARMS;

typedef struct {
    uint32_t      CompletionCode;
    uint32_t      length;
    char          buffer[MAX_BUFFER];
} READ_MSR_DATA_PARMS, *PREAD_MSR_DATA_PARMS;

typedef struct {
    uint32_t       CompletionCode;
    unsigned short keyboardID;
    unsigned short keyboardSubtype;
    unsigned short msrType;
    unsigned char  keyboardEC;
    unsigned char  msrEC;
    unsigned char  features;
    unsigned char  featureByte1;
    unsigned char  firmwareVersion;
    unsigned char  firmwareRelease;
} QUERY_KEYBOARD_PARMS, *PQUERY_KEYBOARD_PARMS;

typedef struct {
    uint32_t       CompletionCode;
    unsigned short keyboardID;
    unsigned short keyboardSubtype;
    unsigned short msrType;
    unsigned char  keyboardEC;
    unsigned char  msrEC;
} QUERY_KEYBOARD_PARMS_V1, *PQUERY_KEYBOARD_PARMS_V1;

typedef struct {
    uint32_t      CompletionCode;
    unsigned char deviceType;
    unsigned char deviceID;
    unsigned char features;         // feature byte 0
    unsigned char commandSet;
    unsigned char ecLevel;
    unsigned char featureByte1;     // Interface V4
    unsigned char firmwareVersion;  // Interface V4
    unsigned char firmwareRelease;  // Interface V4
} DEVICE_INFO, *PDEVICE_INFO;

typedef struct {
    uint32_t       CompletionCode;
    unsigned short length;
    unsigned char  tone1;
    unsigned char  tone2;
} TONE, *PTONE;

typedef struct {
    uint32_t       CompletionCode;
    unsigned short length;
    unsigned char  posLEDs;
} POSLEDS, *PPOSLEDS;

typedef struct {
    uint32_t       CompletionCode;
    unsigned short length;
    unsigned short fEnable;
} ENABLE_DISABLE, *PENABLE_DISABLE;

typedef struct {
    uint32_t       CompletionCode;
    unsigned short length;
    unsigned short fTypematic;
} TYPEMATIC, *PTYPEMATIC;

typedef struct {
    uint32_t       CompletionCode;
    unsigned short length;
    unsigned char  fClick;
} CLICK, *PCLICK;

typedef struct {
    uint32_t       CompletionCode;
    unsigned short length;
    unsigned short track1enabled;
    unsigned short track2enabled;
    unsigned short track3enabled;
    unsigned short trackJenabled;
    unsigned short extdatareportenabled;
} TRACKS, *PTRACKS;

typedef struct {
    uint32_t       CompletionCode;
    unsigned short length;
    unsigned short track1enabled;
    unsigned short track2enabled;
    unsigned short track3enabled;
    unsigned short trackJenabled;
} TRACKS_V1, *PTRACKS_V1;

typedef struct {
    uint32_t       CompletionCode;
    unsigned short length;
    char           buffer[MAX_BUFFER];
} DOUBLE_KEYS, *PDOUBLE_KEYS;

typedef struct {
    uint32_t       CompletionCode;
    unsigned short state;
    unsigned char  NLS;
} SHIFT_STATE, *PSHIFT_STATE;

typedef struct {
    uint32_t       CompletionCode;
    unsigned short length;
    unsigned char  fStatus;
} CODE_UPDATE_STR, *PCODE_UPDATE_STR;

typedef struct {
    uint32_t       CompletionCode;
    unsigned short length;
    unsigned char  Data[15360];
} CODE_UPDATE_DATA, *PCODE_UPDATE_DATA;

typedef struct {
    uint32_t      CompletionCode;
} ANPOS_COMPLETION_CODE_PARMS, *PANPOS_COMPLETION_CODE_PARMS;

typedef struct {
    uint32_t      CompletionCode;
    uint32_t      ProcessID;
} ENABLE_ANPOS_ASYNC_COMM_PARMS, *PENABLE_ANPOS_ASYNC_COMM_PARMS;

/* CANPOS */
#define CANPOS_READ_CONFIG_SIZE    1280
#define CANPOS_WRITE_CONFIG_SIZE   1280
#define CANPOS_CONFIG_DATA_OFFSET  10
#define CANPOS_READ_RAW_DATA_SIZE  2*CANPOS_READ_CONFIG_SIZE+CANPOS_CONFIG_DATA_OFFSET

#define W_NANPOS            1000
#define W_CANPOS_GET_CONFIG 5000


/* canpos state machine */
#define CANPOS_READY                        0x00

/* read config */
#define CANPOS_COLLECT_READ_CONFIG_DATA     0x01

/* write config */
#define CANPOS_COLLECT_WRITE_CONFIG_ACK     0x02
#define CANPOS_COLLECT_WRITE_CONFIG_KEY     0x03
#define CANPOS_GOT_CONFIG_KEY_1             0x04
#define CANPOS_GOT_CONFIG_KEY_0             0x05
#define CANPOS_COUNT_WRITE_CONFIG_ACK       0x06
#define CANPOS_COUNT_FLASH_ACK              0x07

/* constant */
#define MAX_TRY 10

#define CANPOS_COLLECT_VER_INFO_START       0x10
#define CANPOS_COLLECT_VER_INFO_COLLECTED   0x20
#define CANPOS_COLLECT_NORMAL_ACK           0x40
#define VER_INFO_SIZE                       0x1A


/* CANPOS read configuration structure */
typedef struct {
    uint32_t       CompletionCode;
    unsigned short length;
    unsigned char  Data[CANPOS_READ_RAW_DATA_SIZE];
} POS_CANPOS_READ_CONFIG, *PPOS_CANPOS_READ_CONFIG;

/* CANPOS write configuration structure */
typedef struct {
    uint32_t       CompletionCode;
    unsigned short length;
    unsigned char  Data[CANPOS_WRITE_CONFIG_SIZE];
} POS_CANPOS_WRITE_CONFIG, *PPOS_CANPOS_WRITE_CONFIG;

/* CANPOS flash update structure */
typedef struct {
    uint32_t       CompletionCode;
    unsigned short length;
    unsigned char  *Data;
} POS_CANPOS_FLASH_UPDATE, * PPOS_CANPOS_FLASH_UPDATE;


typedef struct {
    uint32_t       CompletionCode;
    unsigned short keyboardID;
    unsigned short keyboardSubtype;
    unsigned short msrType;
    unsigned char  keyboardEC;
    unsigned char  msrEC;
    unsigned char  features;
    unsigned char  featureByte1;
    unsigned char  firmwareVersion;
    unsigned char  firmwareRelease;
    unsigned char  data[40];
} MODQUERY_KEYBOARD_PARMS, *PMODQUERY_KEYBOARD_PARMS;

typedef struct {
    uint32_t       CompletionCode;
    unsigned short keyboardID;
    unsigned short keyboardSubtype;
    unsigned short msrType;
    unsigned char  keyboardEC;
    unsigned char  msrEC;
    unsigned char  data[40];
} MODQUERY_KEYBOARD_PARMS_V1, *PMODQUERY_KEYBOARD_PARMS_V1;


/* Constants */
#define W_CONFIG_SIZE 1280
#define W_CONFIG_READ_RETURN_SIZE   2580
#define W_CONFIG_READ_RETURN_OFFSET 9
#define W_CONFIG_LRC_SIZE 0x10
#define W_USER_CONFIG_SIZE (W_CONFIG_SIZE - W_CONFIG_LRC_SIZE)



/* Define the keyboard portion of the port device extension. */
typedef struct _POS_KEYBOARD_DATA {

    /* POS Keyboard Flag */
    uint32_t       fStatus;

    /* POS Keyboard MSR Configure Command */
    unsigned char  MsrConfigureCmd [MSR_CONFIGURE_CMD_LENGTH];

    /* POS Keyboard KBD Configure Command */
    unsigned char  KbdConfigureCmd [KBD_CONFIGURE_CMD_LENGTH];

    /* POS Keyboard Command */
    unsigned char  PosKeyboardCommand;

    /* POS Keyboard Code Update Command */
    unsigned char  CodeUpdateCommand;

    /* Flag for ACK scancode from POS key # 109 */
    unsigned char  BrkScancode109;

    /* POS Keyboard Status */
    POS_KEYBOARD_STATUS PosKbdStatus;

    /* POS Keyboard Key Shift Status (We need to maintain our own status) */
    unsigned short ShiftFlags;

    /* POS Keyboard Device Info Data */
    POS_KEYBOARD_DEVICE_INFO PosKbdDeviceInfo;

    /* POS MSR Status */
    POS_MSR_STATUS PosMsrStatus;

    /* POS Keyboard Device Info Data */
    POS_MSR_DEVICE_INFO PosMsrDeviceInfo;

    /* POS Keyboard MSR Data */
    POS_MSR_DATA MSRData;

    /* POS Keyboard Trap Keys Flag */
    unsigned short fTrap;

    /* POS Keyboard Code Update Buffer */
    CODE_UPDATE_BUFFER CodeUpdate;

    /* POS Keyboard Code Update Buffer Flag */
    unsigned char fCodeUpdtDone;

    /* POS Keyboard Number of Double Keys */
    unsigned short nDoubleKeys;

    /* POS Keyboard Double Key Buffer */
    DOUBLE_KEY doubleKey[MAX_DOUBLE_KEYS];
    unsigned short double_key_active;

    /* Keyboard LEDs structure */
    POS_KEYBOARD_INDICATOR_PARAMETERS KeyboardIndicators;

    /* Keyboard Shift State */
    POS_KEYBOARD_SCAN_STATE CurrentScanState;

    /* POS Keyboard Id */
    POS_KEYBOARD_ID PosKbdId;

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 27)
    int          asyncPID;
#else
    struct pid  *asyncPID;
#endif
    int          asyncEnabled;

    int          CanposState;
    unsigned int CanposConfigBytesCollected;
    int          CanposKeyboard;
    int          v2Keyboard;
    int          MsrROL;

    /* Storage for code/flash update data */
    unsigned char *RawCodeUpdateData;

    /* CANPOS specific */
    POS_CANPOS_READ_CONFIG canpos_config;
    unsigned int   canposConfigAck;
    unsigned int   canposFlashAck;
    unsigned short flashSize;

    int verinfo[40];
    int verinfosize;

} POS_KEYBOARD_DATA, *PPOS_KEYBOARD_DATA;


#endif

