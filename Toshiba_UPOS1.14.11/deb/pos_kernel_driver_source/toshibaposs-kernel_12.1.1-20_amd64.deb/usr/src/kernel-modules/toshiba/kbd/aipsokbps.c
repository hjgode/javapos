/*
 * Module Name:     aipsokbps.c
 *
 * Description:     PS/2 keyboard/msr filter driver for Linux on SureOne 4614.
 *
 * Copyright (C) 2005-2018 Toshiba Global Commerce Solutions, Inc.
 * All right reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA; Otherwise,
 *  see <http://www.gnu.org/licenses/>.
 *
 *
 * Should you need to contact me, the author, you can do so either by
 * e-mail - mail your message to <gha@toshibagcs.com>.
 */


#include <linux/version.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/init.h>
#if LINUX_VERSION_CODE > KERNEL_VERSION(2, 5, 0)
#include <linux/moduleparam.h>
#include <linux/device.h>
#endif
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 18)
#include <linux/cdev.h>
#endif
#include <linux/fs.h>
#include <linux/slab.h>
#include <linux/ioctl.h>
#include <linux/sched.h>
#include <linux/timer.h>
#include <asm/io.h>
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 11, 0)
#include <linux/uaccess.h>
#else
#include <asm/uaccess.h>
#endif
#include <linux/unistd.h>

#include <linux/time.h>
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 16)
#include <linux/serio.h>
#endif



/* ****************************************************************
 * local include files
 * ****************************************************************
 */
#include "aipsokbps.h"
#include "aipdebug.h"

#define IBM_4614   7   /* IBM4614 ID */
#define IBM_4613   8   /* IBM4613 ID */

static int machine_type = 0;
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 0)
MODULE_PARM(machine_type, "i");
#else
module_param(machine_type,int,0);
MODULE_PARM_DESC(machine_type,"Integer value");
#endif

/* ****************************************************************
 * constant definitions
 * ****************************************************************
 */
#define SUCCESS             0
#define IBM_POS_KBD_MAJOR   246
static const char DEVDRVR_ID[] = "aipsokbps";
#define AIPSOKBPS_PHYS_NAME  "aipsokbps/serio0"

#define DRIVER_DESC "Toshiba SureOne Keyboard Driver"


/* ***************************************************************
 * Function Prototypes
 * ***************************************************************
 */

/* Device */
static int open(struct inode *inode, struct file *file);
static int release(struct inode *inode, struct file *file);
static ssize_t read(struct file *file, char *buf, size_t count, loff_t *ppos);
static ssize_t write(struct file *file, const char *buf, size_t count,
                 loff_t *ppos);
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 36)
static int ioctl(struct inode *inode, struct file *fp, unsigned int cmd,
                 unsigned long ioctl_arg);
#else
static long ioctl(struct file *fp, unsigned int cmd, unsigned long ioctl_arg);
#endif


/* SureOne machine */
static int check_model(void);


/* MSR */
static void msr_init(void);
static void reset_msr_status(void);
static void end_track_timed_out(unsigned long data);
static void inter_track_timed_out(unsigned long data);
static void start_end_track_timer(unsigned long data);
static void stop_end_track_timer(void);
static void start_inter_track_timer(void);
static void stop_inter_track_timer(void);
static int is_valid_single_track_data(unsigned char cmd_reply);
static void __discard_and_deactivate_active_data_buffer(void);
static void discard_and_deactivate_active_data_buffer(void);
static void convert_raw_msr_data(void);
static unsigned char collecting_msr_data(unsigned char scancode);

/* IBM 4613 MRS scancode processing */
static int process_IBM4613_scancodes(unsigned char *pScancode);
static unsigned char set_msrprefix(SET_MSR_COMMAND command, int count);
static unsigned char get_reply_setprefix(unsigned char scancode);

/* Stream Buffer */
static inline void update_stream_buffer(unsigned char scancode);

/* Keybooard / Kbd Controller */
static int kbd_get_ec_level(void);
static unsigned char collecting_ec_level(unsigned char scancode);

/* Filter hooks */
static int pos_scancode_filter(unsigned char *pScancode);
static int kbd_send_data(unsigned char *buf, unsigned char size);


#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 16)
/* ***************************************************************
 * Filter Patch
 * ***************************************************************
 */
struct pc_keyb_filter {
    int (*filter_scancode)(unsigned char *scancode);    /* [IN] */
    int (*write_data)(unsigned char *data, unsigned int length, /* [OUT] */
                      unsigned int *xferred, unsigned int retries,
                      unsigned int timeout);
};

extern int  register_pc_keyb_filter(struct pc_keyb_filter *filter);
extern void unregister_pc_keyb_filter(struct pc_keyb_filter *filter);

/* ***************************************************************
 * For patched kernels ONLY
 * Pass the scancode filter function name.  Upon return
 * pos_filter.write_data() will contain the address of the
 * actual write funtion supported by atkbd/pc_keyb driver.
 * ***************************************************************
 */
static struct pc_keyb_filter pos_filter =
{
    filter_scancode:  pos_scancode_filter,
};
#endif


/* ***************************************************************
 * Globals
 * ***************************************************************
 */

/* Our major number - may also be set as a module parameter */
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 18)
static int aipsokbps_major = IBM_POS_KBD_MAJOR;
#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 0)
MODULE_PARM(aipsokbps_major, "i");
#else
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 18)
module_param_named(major, aipsokbps_major, int, 0644);
#endif

static bool javapos = 0;

module_param(javapos, bool, S_IRUGO | S_IWUSR);
MODULE_PARM_DESC(javapos, "Use /dev/ps2driver for JavaPOS");
#endif



/* Flag indicating we sent a command to the keyboard and it is not
 * yet completed.
 */
static int cmd_busy = FALSE;

/* Main structure that holds all keyboard data. */
static KEYBOARD_DATA  KbdData;
static PKEYBOARD_DATA pKbdData;

/* Machine Determination */
static unsigned long model = 0x00000000;

/* Scancode -> Ascii conversion buffer for MSR data */
static SUREONE_ASCII_BUFFER AsciiBuffer;


#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 16)
static struct serio *sokb_serio = NULL;
static struct serio *sokb_real_serio = NULL;
static struct semaphore sokb_sema;
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 18)
#define MAX_CDEVS 5
typedef struct {
    struct class  *dev_class;
    struct cdev    cdev[MAX_CDEVS];
    struct device *dev;
    int            dev_count;
    int            major;
    dev_t          dev_number;
} sokb_adapter;

sokb_adapter Adapter;
#endif


/* ***************************************************************
 * File I/O
 * ***************************************************************
 */
struct file_operations sokb_fops =
{
    .read     = read,
    .write    = write,
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 36)
    .ioctl    = ioctl,
#else
    .unlocked_ioctl = ioctl,
#endif
#if LINUX_VERSION_CODE > KERNEL_VERSION(3, 11, 0)
    .compat_ioctl   = ioctl,
#endif
    .open     = open,
    .release  = release,
};

DECLARE_WAIT_QUEUE_HEAD(wq);


int aipsokbps_timeout(int msecs)
{
    int timeout = 0;

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 0)
    timeout = msecs*HZ;
#else
    timeout = msecs_to_jiffies(msecs);
#endif

    set_current_state(TASK_INTERRUPTIBLE);
    return schedule_timeout(timeout);
}

int aipsokbps_timeout_wait(int msecs)
{
    int timeout = 0;
    int rc = 0;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 16)
    DEFINE_WAIT(wait);
#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 0)
    timeout = msecs*HZ;
#else
    timeout = msecs_to_jiffies(msecs);
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 16)
    prepare_to_wait(&wq, &wait, TASK_INTERRUPTIBLE);
#endif

    set_current_state(TASK_INTERRUPTIBLE);
    rc = schedule_timeout(timeout);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 16)
    finish_wait(&wq, &wait);
#endif

    return rc;
}


/************************************************************************
 *
 * Function Name:  open()
 *
 * Purpose:        driver open routine.
 *
 * Description:    This routine gets called when application opens this
 *                 driver.
 *
 *
 * Output:
 *                 0     -  success
 *
 *
 * ***********************************************************************
 */

static int open(struct inode *inode, struct file *file)
{
    aip_dbg("MAJOR=%d, MINOR=%d\n", MAJOR(inode->i_rdev),
            MINOR (inode->i_rdev));

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 5, 0)
    MOD_INC_USE_COUNT;
#endif

    return SUCCESS;
}


/************************************************************************
 *
 * Function Name:  release()
 *
 * Purpose:        driver close routine.
 *
 * Description:    This routine gets called when application closes this
 *                 driver.
 *
 * Output:
 *                 0  -  success
 *
 * ***********************************************************************
 */

static int release(struct inode *inode, struct file *file)
{
    aip_dbg("closing character device: %s\n", DEVDRVR_ID);

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 5, 0)
    MOD_DEC_USE_COUNT;
#endif

    return SUCCESS;
}


/************************************************************************
 *
 * Function Name:  read()
 *
 * Purpose:        driver read routine.
 *
 * Description:    This routine gets called when application sends a
 *                 read request.
 *
 * Output:
 *                 EINVAL
 *
 * Notes:          read request is not supported.
 *
 * ***********************************************************************
 */

static ssize_t read(struct file *file, char *buf, size_t count, loff_t *ppos)
{
    return -EINVAL;
}


/************************************************************************
 *
 * Function Name:  write()
 *
 * Purpose:        driver write routine.
 *
 * Description:    This routine gets called when application sends a
 *                 write request.
 *
 * Output:
 *                 EINVAL
 *
 * Notes:          write request is not supported.
 *
 * ***********************************************************************
 */

static ssize_t write(struct file *file, const char *buf, size_t count, loff_t *ppos)
{
    return -EINVAL;
}


#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 16)
static int sokb_write(unsigned char data)
{
    if (sokb_real_serio)
        return serio_write(sokb_real_serio, data);
    else
        return -ENODEV;
}


static int sokb_write_buffer(unsigned char *data, unsigned int length,
                             unsigned int *xferred, unsigned int retries,
                             unsigned int timeout)
{
    int i;
    int rc = 0;
    unsigned int x = 0;

    down(&sokb_sema);

    for (i = 0; i < length; i++) {
        aip_dbg("sending byte %d, value=%02x\n", i, data[i]);

        if ((rc = sokb_write(data[i]))) {
            aip_error("sokb_write() returned error %d\n", rc);
            break;
        }
        x++;
    }

    up(&sokb_sema);

    if (xferred)
        *xferred = x;

    return rc;
}
#endif


/************************************************************************
 *
 * Function Name:  kbd_send_data()
 *
 * Purpose:        To send data to keyboard.
 *
 * Description:    A common routine to send data to keyboard.
 *
 * Input:          unsigned char * buffer.
 *                 size of buffer
 *
 * Output:
 *                 0 - success
 *                 1 - failure.
 *
 * ***********************************************************************
 */

static int kbd_send_data(unsigned char *buf, unsigned char size)
{
    int rc = 0;
    int cmd_retries = 100;
    int xferred = 0, xfer_retry = size;
    unsigned char b = 0;

    if (size > 1)
        b = *(buf + 1);

    aip_verbose("enter\n");

    while (cmd_busy && cmd_retries) {
        aip_dbg("going to sleep ...\n");
        aipsokbps_timeout(5);
        --cmd_retries;
        aip_dbg("... return from sleep\n");
    }

    /* Call the Linux kbd driver's send routine to send data. */

    cmd_busy = 1;

    do {
        aip_dbg("sending %d bytes to kbd\n", size);

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 16)
        /* size: number of retires and size of buffer */
        rc = pos_filter.write_data(buf, size, &xferred, size, 1000);
        if (rc != 0) {
            aip_dbg("pos_filter.write_data returned error %d\n", rc);
#else
        rc = sokb_write_buffer(buf, size, &xferred, 1, 1000);

        if (rc != 0) {
            aip_error("sokb_write_buffer() returned error %d\n", rc);
#endif


            /* The kernel patch misses ACK, and does
             * not increment the xferred count
             */
            if (rc == (-EINTR))
                xferred++;

            if (xferred < size) {
                buf += xferred;
                size -= xferred;
                xferred = 0;
            }
        }
    }
    while (xferred < size && xfer_retry--);

    /* Go to sleep
     * The wait queue is awakened from the pos_kbd_filter() routine when the
     * command is complete
     */
    if (rc != 0)
        cmd_busy = 0;

#if LINUX_VERSION_CODE < KERNEL_VERSION(3, 15, 0)
    if (cmd_busy != 0)
        interruptible_sleep_on_timeout(&wq, 100*HZ);
#else
    if (cmd_busy != 0)
        aipsokbps_timeout_wait(100*HZ);
#endif

    aip_dbg("exit, rc=0x%02x %s\n", rc, rc == 0 ? "Success" : "Failed");

    return rc;
}


/************************************************************************
 *
 * Function Name:  kbd_get_ec_level()
 *
 * Purpose:        To read Keyboard Controller EC level
 *
 * Description:    This routine sends 0xEB, Read Keyboard Controller Firmware
 *                 Level command. The keyboard response contains one byte.
 *
 * Input:          none
 *
 * Output:         none
 *
 * Notes:
 *
 * ***********************************************************************
 */

static int kbd_get_ec_level(void)
{
    int rc;
    unsigned char inputBuffer[1];

    aip_verbose("enter\n");

    /* Set up EC Level Command */
    inputBuffer[0] = 0xEB;

    /* Set global state */
    pKbdData->fStatus |= COLLECTING_EC_LEVEL;

    /* Write to keyboard */
    rc = kbd_send_data(inputBuffer, sizeof(inputBuffer));

    aip_dbg("exit, rc=0x%02x %s\n", rc, rc == 0 ? "Success" : "Failed");

    return rc;
}


/************************************************************************
 *
 * Function Name:  collecting_ec_level()
 *
 * Purpose:        To read Keyboard Controller EC level
 *
 * Description:    This routine collects the response to the 0xEB Read
 *                 Keyboard Controller Firmware Level command. The keyboard
 *                 response contains one byte.
 *
 * Input:          scancode
 *
 * Output:         none
 *
 * Notes:
 *
 * ***********************************************************************
 */

static unsigned char collecting_ec_level(unsigned char scancode)
{
    aip_dbg("scancode=0x%02x\n", scancode);

    pKbdData->EC_Level = scancode;

    pKbdData->fStatus &= ~COLLECTING_EC_LEVEL;

    aip_dbg("EC Level %d\n", pKbdData->EC_Level);

    /* Wake up  */
    cmd_busy = 0;
    wake_up_interruptible(&wq);

    scancode = 0;

    return scancode;
}


/************************************************************************
 *
 * Function Name:  get_reply_setprefix()
 *
 * Purpose:        To read Keyboard Controller Status Reply
 *
 * Description:    This routine collects the response to the commands on
 *                 setting the prefix,suffix and enabling the feature.
 *                 The keyboard response contains one byte.
 *
 * Input:          scancode
 *
 * Output:         scancode
 *
 * Notes:
 *
 * ***********************************************************************
 */

static unsigned char get_reply_setprefix(unsigned char scancode)
{
    aip_dbg("scancode=0x%02x\n", scancode);

    pKbdData->mStatus = scancode;

    aip_dbg("Status reply %d\n", pKbdData->mStatus);

    /* Wake up  */
    cmd_busy = 0;
    wake_up_interruptible(&wq);

    scancode = 0;

    return scancode;
}


/*********************************************************************
 *
 * Function Name: collecting_msr_data
 *
 * Purpose:       Save MSR data (status) scancodes
 *
 * Description:   This function saves the MSR data scancodes in the
 *                MSRData buffer.  The the scancode is set to 0
 *
 * Input:         scancode - the scancode received from the keyboard
 *
 * Output:
 *                0
 *
 * ********************************************************************
 */

static unsigned char collecting_msr_data(unsigned char scancode)
{
    aip_dbg("collecting_msr_data scancode=0x%02x\n", scancode);

    /* Collect and convert using mapping table */
    if (scancode <= 127)
        pKbdData->MSRData.MSRDataBuffer[pKbdData->MSRData.Index] = convert[scancode];
    else
        pKbdData->MSRData.MSRDataBuffer[pKbdData->MSRData.Index] = scancode;

    aip_dbg("convert[scancode]=0x%02x\n",
            pKbdData->MSRData.MSRDataBuffer[pKbdData->MSRData.Index]);
    scancode = 0; /* Consumed */

    pKbdData->MSRData.Index += 1;
    pKbdData->MSRData.MSRDataLength += 1;

    return scancode;
}


/**************************************************************************
 * FunctionName: set_msrprefix
 * Purpose     : send command to keyboard controller
 *               to set msr prefix/suffix
 * Input:      : command:
 *               count:
 *               0 : prefix
 *               1 : suffix
 *               2 : enable prefix and suffix
 *
 * Output: status of the last command sent
 *
 **************************************************************************
 */

static unsigned char set_msrprefix(SET_MSR_COMMAND command, int count)
{
    int rc;
    unsigned char inputBuffer[1];

    aip_dbg("set_msrprefix enter\n");

    switch (command) {
    case FirstMsrPrefixCommand:
        inputBuffer[0] = COMMAND1;
        break;
    case SecondMsrPrefixCommand:
        inputBuffer[0] = COMMAND2;
        break;
    case LastMsrPrefixCommand:
        if (count == 0)
            inputBuffer[0] = SETPREFIX;
        else if (count == 1)
            inputBuffer[0] = SETSUFFIX;
        else if (count == 2)
            inputBuffer[0] = ENABLE_PREF_AND_SUFFIX;
        break;
    case SetPrefixAndSuffix:
        if (count == 0)
            inputBuffer[0] = PREFIX_VAL;
        else if (count == 1)
            inputBuffer[0] = SUFFIX_VAL;
        else if (count == 2)
            inputBuffer[0] = ENABLE_PREF_AND_SUFFIX_VAL;
        break;
    default:
        aip_dbg("Unknown command\n");
    }


    /* Write to keyboard */
    rc = kbd_send_data(inputBuffer, sizeof(inputBuffer));

    aip_dbg("exit, rc=0x%02x %s\n", rc, rc == 0 ? "Success" : "Failed");

    return rc;
}


/*********************************************************************
 * Function Name: process_IBM4613_scancodes
 * Purpose:       Filterout IBM4613-MSR specific data
 * Description:   This function is another branch of pos_scancode_filter
 *                which filters only IBM4613 specific scancode processing
 *
 * Input:         scancode sent for latest keyboard interrupt
 *
 * Output:        0 - Ask the Linux kbd driver interrupt routine to
 *                    continue processing this scancode
 *
 *                1 - Ask the Linux kbd driver interrupt routine to
 *                    ignore this scancode and return immediately as
 *                    we have filtered it off (consumed it)
 *
 *********************************************************************
 */
static int process_IBM4613_scancodes(unsigned char *pScancode)
{
    unsigned char scancode = *pScancode;
    int rc = 0;

    SUREONE_MSR_COLLECTION_STATE msrState = pKbdData->SureOneMsrStatus.CollectionState;

    /***********************************
     *  Check for setting prefix and suffix
     *
     ************************************/
    if (pKbdData->fStatus == SET_MSR_PREFIX ||
        pKbdData->fStatus ==  SET_MSR_SUFFIX) {

        scancode = get_reply_setprefix(scancode);
        *pScancode = scancode = 0;
        return 1;

    } else if (pKbdData->fStatus == COLLECTING_MSR_DATA) {
        stop_end_track_timer();
        switch (scancode) {
        case RALT:
            {
                pKbdData->SureOneMsrStatus.CollectionState = POST_FIX_DETECTED;
                *pScancode = scancode = 0;
                return 1;

            }
        case KEYPAD1:
            {
                if (pKbdData->StreamBuffer[1] == RALT) {
                    pKbdData->SureOneMsrStatus.CollectionState = POST_FIX_DETECTED;

                    start_end_track_timer((unsigned long)pKbdData->SureOneMsrStatus.CollectionState);
                    /* aip_dbg("<<<rc=1, scancode=0x%02x\n", scancode); */
                } else
                    pKbdData->fStatus &= ~COLLECTING_MSR_DATA;

                *pScancode = scancode = 0;
                return 1;
            }
        case BREAK_SCANCODE(KEYPAD1):
            {
                if (pKbdData->SureOneMsrStatus.CollectionState == POST_FIX_DETECTED &&
                    pKbdData->StreamBuffer[2] == RALT &&
                    pKbdData->StreamBuffer[1] == KEYPAD1) {
                    start_end_track_timer((unsigned long)pKbdData->SureOneMsrStatus.CollectionState);
                    /* aip_dbg("<<< rc=1, scancode=0x%02x\n", scancode); */
                    *pScancode = scancode = 0;
                    return 1;
                } else {
                    pKbdData->fStatus &= ~COLLECTING_MSR_DATA;
                    __discard_and_deactivate_active_data_buffer();
                    *pScancode = scancode;
                    return 0;
                }
            }
        case KEYPAD2:
            {
                if (pKbdData->SureOneMsrStatus.CollectionState == POST_FIX_DETECTED &&
                    pKbdData->StreamBuffer[3]== RALT &&
                    pKbdData->StreamBuffer[2]== KEYPAD1 &&
                    pKbdData->StreamBuffer[1] == BREAK_SCANCODE(KEYPAD1)) {
                    start_end_track_timer((unsigned long)pKbdData->SureOneMsrStatus.CollectionState);
                    /* aip_dbg("<<< rc=1, scancode=0x%02x\n", scancode); */
                } else
                    pKbdData->fStatus &= ~COLLECTING_MSR_DATA;

                *pScancode = scancode = 0;
                return 1;
            }
        case BREAK_SCANCODE(KEYPAD2):
            {
                if (pKbdData->SureOneMsrStatus.CollectionState == POST_FIX_DETECTED &&
                    pKbdData->StreamBuffer[4] == RALT &&
                    pKbdData->StreamBuffer[3] == KEYPAD1 &&
                    pKbdData->StreamBuffer[2] == BREAK_SCANCODE(KEYPAD1) &&
                    pKbdData->StreamBuffer[1] == KEYPAD2) {
                    start_end_track_timer((unsigned long)pKbdData->SureOneMsrStatus.CollectionState);
                    /* aip_dbg("<<< rc=1, scancode=0x%02x\n", scancode); */
                    *pScancode = scancode = 0;
                    return 1;
                } else {

                    pKbdData->fStatus &= ~COLLECTING_MSR_DATA;
                    __discard_and_deactivate_active_data_buffer();
                    *pScancode = scancode;
                    return 0;
                }
            }
        case KEYPAD6:
            {
                if (pKbdData->SureOneMsrStatus.CollectionState == POST_FIX_DETECTED &&
                    pKbdData->StreamBuffer[5] == RALT &&
                    pKbdData->StreamBuffer[4] == KEYPAD1 &&
                    pKbdData->StreamBuffer[3] == BREAK_SCANCODE(KEYPAD1) &&
                    pKbdData->StreamBuffer[2] == KEYPAD2 &&
                    pKbdData->StreamBuffer[1] == BREAK_SCANCODE(KEYPAD2)) {
                    start_end_track_timer((unsigned long)pKbdData->SureOneMsrStatus.CollectionState);
                    aip_dbg("<<< rc=1, scancode=0x%02x\n", scancode);
                    *pScancode = scancode = 0;
                    return 1;

                } else {
                    pKbdData->fStatus &= ~COLLECTING_MSR_DATA;
                    __discard_and_deactivate_active_data_buffer();
                    aip_dbg("DISCARD AND DEACTIVATE NOT EXPECTED<<< rc=0, scancode=0x%02x\n",scancode);
                    *pScancode = scancode;
                    return 0;
                }
            }
        case BREAK_SCANCODE(KEYPAD6):
            {

                if (pKbdData->SureOneMsrStatus.CollectionState == POST_FIX_DETECTED &&
                    pKbdData->StreamBuffer[6] == RALT &&
                    pKbdData->StreamBuffer[5] == KEYPAD1 &&
                    pKbdData->StreamBuffer[4] == BREAK_SCANCODE(KEYPAD1) &&
                    pKbdData->StreamBuffer[3] == KEYPAD2 &&
                    pKbdData->StreamBuffer[2] == BREAK_SCANCODE(KEYPAD2) &&
                    pKbdData->StreamBuffer[1] == KEYPAD6) {
                    aip_dbg("<<< rc=1, scancode=0x%02x\n", scancode);
                    stop_end_track_timer();
                    start_end_track_timer((unsigned long)pKbdData->SureOneMsrStatus.CollectionState);
                    *pScancode = scancode = 0;
                    return 1;
                } else {
                    pKbdData->fStatus &= ~COLLECTING_MSR_DATA;
                    __discard_and_deactivate_active_data_buffer();
                    aip_dbg("DISCARD AND DEACTIVATE NOT EXPECTED<<< rc=0, scancode=0x%02x\n",
                            scancode);
                    *pScancode = scancode;
                    return 0;
                }
            }
        case BREAK_SCANCODE(RALT):
            {
                if (pKbdData->SureOneMsrStatus.CollectionState == POST_FIX_DETECTED &&
                    pKbdData->StreamBuffer[6] == KEYPAD1 &&
                    pKbdData->StreamBuffer[5] == BREAK_SCANCODE(KEYPAD1) &&
                    pKbdData->StreamBuffer[4] == KEYPAD2 &&
                    pKbdData->StreamBuffer[3] == BREAK_SCANCODE(KEYPAD2) &&
                    pKbdData->StreamBuffer[2] == KEYPAD6 &&
                    pKbdData->StreamBuffer[1] == BREAK_SCANCODE(KEYPAD6)) {

                    pKbdData->fStatus &= ~COLLECTING_MSR_DATA;
                    aip_dbg("<<< rc=0x01, scancode=0x%02x\n",scancode);
                    *pScancode = scancode;

                    /* Switch SureOne MSR Status to 'Holding MSR Data'
                     * This locks the buffer
                     */
                    aip_dbg("Moving to Collection State: Inactive\n");
                    pKbdData->fStatus |= Inactive;
                    pKbdData->SureOneMsrStatus.CollectionState = Inactive;


#ifdef DEBUG
                    aip_dbg("COMPLETE DATA IN BUFFER:\n");
                    for (x = 0; x < pKbdData->MSRData.MSRDataLength ; x++)
                        printk("0x%02x ", pKbdData->MSRData.MSRDataBuffer[x]);
                    printk("\n");
#endif

                    /* Switch Off collecting phase */
                    aip_dbg("Switching Off COLLECTING_MSR_DATA\n");
                    return 0;
                } else {
                    pKbdData->fStatus &= ~COLLECTING_MSR_DATA;
                    __discard_and_deactivate_active_data_buffer();
                    aip_dbg("DISCARD AND DEACTIVATE NOT EXPECTED<<< rc=0x01, scancode=0x%02x\n",scancode);
                    *pScancode = scancode;
                    return 0;
                }
            }

        default:
            {
                /* discard Break scancodes since it causes double data entry
                 * to app
                 */
                if (scancode < BREAK ||
                    scancode == BREAK_SCANCODE(SCANCODE_LEFT_SHIFT)) {
                    scancode = collecting_msr_data(scancode);
                    aip_dbg("COLLECTING MSR DATA<<< rc=0x01, scancode=0x%02x\n", scancode);
                } else
                    aip_dbg("Break Scancode: DONT COLLECT\n");

                /* retain integrity of Status */
                pKbdData->fStatus &= ~pKbdData->fStatus;
                pKbdData->fStatus |= COLLECTING_MSR_DATA;
                *pScancode = scancode = 0;
                return 1;
            }
        }
    } else {
        if (msrState == Inactive && scancode == RALT) {
            /* catch here the scenario where some cards does not report
             * prefixes
             */

            /* This will be true if there were no PREFIX,so this
             * will be the suffix part
             */
            *pScancode = scancode;
            pKbdData->SureOneMsrStatus.CollectionState = Waiting;
        } else if (msrState == Waiting) {
            aip_dbg("MSR WAITING...PROCESSING SCANCODE\n");
            switch (scancode) {
            case KEYPAD1:
                {
                    stop_end_track_timer();
                    if (pKbdData->StreamBuffer[1] == RALT) {
                        /*clear buffer for the uncollected data stream*/
                        __discard_and_deactivate_active_data_buffer();

                        /*resume collection state*/
                        pKbdData->SureOneMsrStatus.CollectionState = Waiting;

                        *pScancode = scancode = 0;

                        start_end_track_timer((unsigned long)pKbdData->SureOneMsrStatus.CollectionState);
                        return 1;
                    }
                    __discard_and_deactivate_active_data_buffer();
                    break;

                }
            case BREAK_SCANCODE(KEYPAD1):
                {
                    stop_end_track_timer();

                    if (pKbdData->StreamBuffer[2] == RALT &&
                        pKbdData->StreamBuffer[1] == KEYPAD1) {
                        start_end_track_timer((unsigned long)pKbdData->SureOneMsrStatus.CollectionState);
                        *pScancode = scancode = 0;
                        return 1;
                    } else {
                        /* return, this is a BREAK/release scancode */
                        __discard_and_deactivate_active_data_buffer();
                        *pScancode = scancode;
                        return 0;
                    }
                    break;
                }
            case KEYPAD2:
                {
                    stop_end_track_timer();

                    if (pKbdData->StreamBuffer[3]== RALT &&
                        pKbdData->StreamBuffer[2]== KEYPAD1 &&
                        pKbdData->StreamBuffer[1] == BREAK_SCANCODE(KEYPAD1)) {
                        *pScancode = scancode = 0;
                        start_end_track_timer((unsigned long)pKbdData->SureOneMsrStatus.CollectionState);
                        return 1;
                    }
                    __discard_and_deactivate_active_data_buffer();
                    break;
                }
            case BREAK_SCANCODE(KEYPAD2):
                {
                    stop_end_track_timer();

                    if (pKbdData->StreamBuffer[4] == RALT &&
                        pKbdData->StreamBuffer[3] == KEYPAD1 &&
                        pKbdData->StreamBuffer[2] == BREAK_SCANCODE(KEYPAD1) &&
                        pKbdData->StreamBuffer[1] == KEYPAD2) {
                        *pScancode = scancode = 0;
                        start_end_track_timer((unsigned long)pKbdData->SureOneMsrStatus.CollectionState);
                        return 1;
                    } else {
                        /* return; this is a BREAK/release scancode */
                        __discard_and_deactivate_active_data_buffer();
                        *pScancode = scancode;
                        return 0;
                    }
                    break;
                }
            case KEYPAD7:
                {
                    if (pKbdData->StreamBuffer[5] == RALT &&
                        pKbdData->StreamBuffer[4] == KEYPAD1 &&
                        pKbdData->StreamBuffer[3] == BREAK_SCANCODE(KEYPAD1) &&
                        pKbdData->StreamBuffer[2] == KEYPAD2 &&
                        pKbdData->StreamBuffer[1] == BREAK_SCANCODE(KEYPAD2)) {
                        *pScancode = scancode = 0;
                        stop_end_track_timer();
                        start_end_track_timer((unsigned long)pKbdData->SureOneMsrStatus.CollectionState);
                        return 1;
                    }
                    __discard_and_deactivate_active_data_buffer();
                    break;
                }
            case BREAK_SCANCODE(KEYPAD7):
                {
                    if (pKbdData->StreamBuffer[6] == RALT &&
                        pKbdData->StreamBuffer[5] == KEYPAD1 &&
                        pKbdData->StreamBuffer[4] == BREAK_SCANCODE(KEYPAD1) &&
                        pKbdData->StreamBuffer[3] == KEYPAD2 &&
                        pKbdData->StreamBuffer[2] == BREAK_SCANCODE(KEYPAD2) &&
                        pKbdData->StreamBuffer[1] == KEYPAD7) {
                        *pScancode = scancode = 0;
                        stop_end_track_timer();
                        start_end_track_timer((unsigned long)pKbdData->SureOneMsrStatus.CollectionState);
                        return 1;
                    }
                    __discard_and_deactivate_active_data_buffer();
                    break;
                }
            case BREAK_SCANCODE(RALT):
                {
                    stop_end_track_timer();

                    if (pKbdData->StreamBuffer[6] == KEYPAD1 &&
                        pKbdData->StreamBuffer[5] == BREAK_SCANCODE(KEYPAD1) &&
                        pKbdData->StreamBuffer[4] == KEYPAD2 &&
                        pKbdData->StreamBuffer[3] == BREAK_SCANCODE(KEYPAD2) &&
                        pKbdData->StreamBuffer[2] == KEYPAD7 &&
                        pKbdData->StreamBuffer[1] == BREAK_SCANCODE(KEYPAD7)) {
                        pKbdData->fStatus &= ~Waiting;
                        pKbdData->fStatus |= COLLECTING_MSR_DATA; /* CHECKING_NEXT_SCANCODE; */
                        pKbdData->SureOneMsrStatus.CollectionState &= ~Waiting;
                        pKbdData->SureOneMsrStatus.CollectionState |= COLLECTING_MSR_DATA;
                        aip_dbg("WILL CHECK FOR NEXT SCANCODE<<< rc=0x01, scancode=0x%02x\n",
                                scancode);
                        start_end_track_timer((unsigned long)pKbdData->SureOneMsrStatus.CollectionState);
                        *pScancode = scancode; /*return the break*/
                        return 0;
                    }
                    __discard_and_deactivate_active_data_buffer();
                    break;
                }

            default:
                __discard_and_deactivate_active_data_buffer();
                aip_dbg("Collecting Reset - Keyboard Data = 0x%02x\n", scancode);
                *pScancode = scancode;

                break;
            }
        } else {
            aip_dbg("Keyboard Data = 0x%02x\n", scancode);
            *pScancode = scancode;
        }
    }

    if (scancode == 0) {
        *pScancode = 0;
        rc = 1;
    } else {
        *pScancode = scancode;
        rc = 0;
    }
    aip_dbg("EXIT <<< rc= 0x%2x, scancode = 0x%2x\n",rc,*pScancode);
    return rc;
}


/*********************************************************************
 *
 * Function Name: pos_scancode_filter
 *
 * Purpose:       Filter out the MSR specific data
 *
 * Description:   This function looks for specific data (like MSR and
 *                EC Level) and filters it out before the normal keyboard
 *                interrupt routine, and thus the linux keyboard driver
 *                stack, gets a chance to process it.
 *
 * Input:         scancode sent for latest keyboard interrupt
 *
 * Output:        0 - Ask the Linux kbd driver interrupt routine to
 *                    continue processing this scancode
 *
 *                1 - Ask the Linux kbd driver interrupt routine to
 *                    ignore this scancode and return immediately as
 *                    we have filtered it off (consumed it)
 *
 * ********************************************************************
 */

static int pos_scancode_filter(unsigned char *pScancode)
{
    unsigned char scancode = *pScancode;
    int rc = 0;

    /* Track latest few scancodes in the stream */
    update_stream_buffer(scancode);

#if 0
    aip_dbg("pos_scancode_filter()->>> scancode=0x%02x, *pScan=0x%02x, pKbdData->fStatus=0x%02x\n",
            scancode, *pScancode, pKbdData->fStatus);
#endif

    if (machine_type == IBM_4613) {
        rc = process_IBM4613_scancodes(pScancode);
        return rc;
    } else if (machine_type == IBM_4614) {
        /* //////////////////////
         * EC Level - cmd 0xEB //
         * //////////////////////
         */
        if ((pKbdData->fStatus & COLLECTING_EC_LEVEL) &&
            (scancode != SCANCODE_ACK) && (scancode != 0x9c)) {
            scancode = collecting_ec_level(scancode);

            /* aip_dbg("COLLECTING EC LEVEL <<<-  rc=0x01, scancode=0x00\n"); */
            *pScancode = scancode = 0;
            return 1;
        }

        /* //////
         * MSR //
         * //////
         */
        else if (pKbdData->fStatus & CHECKING_FOR_MSR_SS_27_ACK) {
            aip_dbg("Current Status is: CHECKING_FOR_MSR_SS_27_ACK\n");
            aip_dbg("Command 0xE5 returns: 0x%02x\n", scancode);

            switch (scancode) {
            /* A missing Ack is the `broken` behaviour the SureOne keyboard
             * controller.
             *
             * If MSR is active it sends a Nack 0xFE plus a bad status byte
             * 0x55.
             *
             * Linux 2.4:
             *   The bad status means that the scancode is ignored by linux
             *   in pc_keyb.c
             *  (handle_kbd_event) and never reaches the driver.
             *
             * Linux 2.6:
             *   0xFE comes to this filter
             */

            case 0xFA:  /* Ack for Command E5, implies Source is keyboard */
                {
                    aip_dbg("Switching Off CHECKING_FOR_MSR_SS_27_ACK\n");

                    pKbdData->fStatus &= ~CHECKING_FOR_MSR_SS_27_ACK;

                    aip_dbg("Switching On CHECKING_SOURCE_KEYBOARD_27\n");

                    pKbdData->fStatus |= CHECKING_SOURCE_KEYBOARD_27;

                    aip_dbg("<<< rc=0x01, scancode=0x00\n");
                    *pScancode = scancode = 0;
                    return 1;
                }
            default:    /* No Ack for Command E5, implies Source is MSR */
                {
                    aip_dbg("aipsokbps.c No ACK for Command E5, implies source is MSR\n");
                    /* Set SureOneMsrStatus collection stage */
                    if (pKbdData->SureOneMsrStatus.CollectionState == Waiting) {
                        aip_dbg("Moving to Collection State: got_SS_1\n");

                        pKbdData->SureOneMsrStatus.CollectionState = got_SS_1;
                    } else if (pKbdData->SureOneMsrStatus.CollectionState == FirstTrackComplete) {
                        aip_dbg("Moving to Collection State: got_SS_2\n");

                        pKbdData->SureOneMsrStatus.CollectionState = got_SS_2;

                        /* Switch Off the safety timer between
                         * FirstTrackComplete and SS 2
                         */
                        stop_inter_track_timer();
                    } else {
                        aip_error("Unexpected Collection state 0x%02x\n",
                                  pKbdData->SureOneMsrStatus.CollectionState);

                        /* Discard the buffer and Deactivate
                         * This also switches Off all Flags and puts us back
                         * into Inactive state
                         */
                        aip_error("Discarding MSR buffer and deactivating\n");

                        __discard_and_deactivate_active_data_buffer();

                        aip_dbg("<<< rc=0x01, scancode=0x00\n");
                        *pScancode = scancode = 0;
                        return 1;
                    }

                    aip_dbg("Switching Off CHECKING_FOR_MSR_SS_27_ACK\n");

                    pKbdData->fStatus &= ~CHECKING_FOR_MSR_SS_27_ACK;

                    aip_dbg("Switching On COLLECTING_MSR_DATA\n");

                    pKbdData->fStatus |= COLLECTING_MSR_DATA;

                    /* Start safety timeout timer: SS->End of Track */
                    start_end_track_timer((unsigned long)pKbdData->SureOneMsrStatus.CollectionState);

                    /* Change scancode to start sentinel
                     * We want to save the sentinel as part of the MSR data
                     * for SureOne
                     */
                    scancode = collecting_msr_data(0x27);

                    aip_dbg("<<< rc=0x01, scancode=0x00\n");
                    *pScancode = scancode = 0;
                    return 1;
                }
            }
        } else if (pKbdData->fStatus & CHECKING_SOURCE_KEYBOARD_27) {
            aip_dbg("Current Status is: CHECKING_SOURCE_KEYBOARD_27\n");
            aip_dbg("Command 0xE5 Reply returns: 0x%02x\n", scancode);
            aip_dbg("Switching Off CHECKING_SOURCE_KEYBOARD_27\n");

            pKbdData->fStatus &= ~CHECKING_SOURCE_KEYBOARD_27;

            /* Change scancode to ';' Keypress
             * We want to pass on the original key
             */
            scancode = 0x27;

            aip_dbg("<<< rc=0x00, scancode=0x27\n");
            *pScancode = scancode;
            return 0;
        } else if (pKbdData->fStatus & CHECKING_FOR_MSR_SS_06_ACK) {
            aip_dbg("Current Status is: CHECKING_FOR_MSR_SS_06_ACK\n");
            aip_dbg("Command 0xE5 returns: 0x%02x\n", scancode);

            switch (scancode) {
            /* A missing Ack is the `broken` behaviour the SureOne keyboard
             * controller.
             *
             * If MSR is active it sends a Nack 0xFE plus a bad status byte
             * 0x55.
             *
             * Linux 2.4:
             *     The bad status means that the scancode is ignored by linux in pc_keyb.c
             * (handle_kbd_event) and never reaches the driver.
             *
             * Linux 2.6:
             *     0xFE comes to this filter
             */

            case 0xFA:  /* Ack for Command E5, implies Source is keyboard */
                {
                    aip_dbg("Switching Off CHECKING_FOR_MSR_SS_06_ACK\n");

                    pKbdData->fStatus &= ~CHECKING_FOR_MSR_SS_06_ACK;

                    aip_dbg("Switching On CHECKING_SOURCE_KEYBOARD_06\n");

                    pKbdData->fStatus |= CHECKING_SOURCE_KEYBOARD_06;

                    aip_dbg("<<< rc=0x01, scancode=0x00\n");
                    *pScancode = scancode = 0;
                    return 1;
                }
            default:    /* No Ack for Command E5, implies Source is MSR */
                {
                    /* Set SureOneMsrStatus collection stage */
                    if (pKbdData->SureOneMsrStatus.CollectionState == Waiting) {
                        aip_dbg("Moving to Collection State: got_SS_1\n");

                        pKbdData->SureOneMsrStatus.CollectionState = got_SS_1;
                    } else if (pKbdData->SureOneMsrStatus.CollectionState ==  FirstTrackComplete) {
                        aip_dbg("Moving to Collection State: got_SS_2\n");

                        pKbdData->SureOneMsrStatus.CollectionState = got_SS_2;

                        /* Switch Off the safety timer between
                         * FirstTrackComplete and SS 2
                         */
                        stop_inter_track_timer();
                    } else {
                        aip_error("Unexpected Collection state 0x%02x\n",
                                  pKbdData->SureOneMsrStatus.CollectionState);

                        /* Discard the buffer and Deactivate
                         * This also switches Off all Flags and puts us back
                         * into Inactive state
                         */
                        aip_error("Discarding MSR buffer and deactivating\n");

                        __discard_and_deactivate_active_data_buffer();

                        aip_dbg("<<< rc=0x01, scancode=0x00\n");
                        *pScancode = scancode = 0;
                        return 1;
                    }

                    aip_dbg("Switching Off CHECKING_FOR_MSR_SS_06_ACK\n");

                    pKbdData->fStatus &= ~CHECKING_FOR_MSR_SS_06_ACK;

                    aip_dbg("Switching On COLLECTING_MSR_DATA\n");

                    pKbdData->fStatus |= COLLECTING_MSR_DATA;

                    /* Start safety timeout timer: SS->End of Track */
                    start_end_track_timer((unsigned long)pKbdData->SureOneMsrStatus.CollectionState);

                    /* Change scancode to start sentinel
                     *
                     * We want to save the sentinel as part of the MSR data
                     * for SureOne We will also interpret it as a shifted
                     * scancode 0x2a, 0x06 for '%' character ... So inject a
                     * leading 0x2a into the buffer first.  We expect break
                     * code 0xaa (for this 0x2a) on the next ISR cycle
                     */
                    scancode = collecting_msr_data(0x2a);
                    scancode = collecting_msr_data(0x06);

                    /* Also adjust externally visible shift state to reflect
                     * that a 0x2a arrived before the 0x06 start sentinel,
                     * which will never be matched by the arrival of a 0xaa
                     * shift break which is visible to the keyboard driver
                     * stack, because it will be collected, buffered and
                     * consumed on the *next* ISR cycle.
                     */

                    aip_dbg("<<< rc=0x00, scancode=0xaa\n");
                    *pScancode = scancode = 0xaa;
                    return 0;
                }
            }
        }

        else if (pKbdData->fStatus & CHECKING_SOURCE_KEYBOARD_06) {
            aip_dbg("Current Status is: CHECKING_SOURCE_KEYBOARD_06\n");
            aip_dbg("Command 0xE5 Reply returns: 0x%02x\n", scancode);
            aip_dbg("Switching Off CHECKING_SOURCE_KEYBOARD_06\n");

            pKbdData->fStatus &= ~CHECKING_SOURCE_KEYBOARD_06;

            /* Change scancode to '%' Keypress
             * We want to pass on the original key
             */
            scancode = 0x06;

            aip_dbg("<<< rc=0x00, scancode=0x06\n");
            *pScancode = scancode;
            return 0;
        }

        /* ///////////////
         * Track Status //
         * ///////////////
         */
        else if (pKbdData->fStatus & CHECKING_FOR_MSR_TRACK_STATUS_ACK) {
            aip_dbg("Current Status is Checking For MSR Track Status\n");
            aip_dbg("Current Status is: CHECKING_FOR_MSR_TRACK_STATUS_ACK\n");
            aip_dbg("Command 0xE4 returns: 0x%02x\n", scancode);

            /* We got here because the Inter-Track timer timed out. This means
             * that there was probably only one track of data read by the MSR.
             *
             * As a result of entering the timeout function we sent an 0xE4
             * command to the Keyboard Controller: Read MSR data format and
             * error code. If there is no new MSR activity we should get a
             * sensible reply on the next ISR cycle telling us how many tracks
             * the MSR reader actually did read. If it really was just one
             * then we will have our data.
             *
             * A missing Ack is the `broken` behaviour the SureOne keyboard
             * controller.
             *
             * If MSR is active it sends a Nack 0xFE plus a bad status byte
             * 0x55.
             *
             * Linux 2.4:
             * The bad status means that the scancode is ignored by linux in
             * pc_keyb.c
             * (handle_kbd_event) and never reaches the driver.
             *
             * Linux 2.6:
             * 0xFE comes to this filter
             *
             * This implies MSR is active (again). In this case we cannot get
             * MSR data format information. We must treat this as an error and
             * make sure the driver is returned to known state:
             * Not COLLECTING_MSR_DATA and 'Inactive'. Client must poll again
             * to put the driver back into the 'Waiting for start of MSR
             * Data' mode.
             */

            switch (scancode) {
            case 0xFA: /* Ack for Command E4, implies MSR is quiescent and the reply is good */
                {
                    aip_dbg("Switching Off CHECKING_FOR_MSR_TRACK_STATUS_ACK\n");

                    pKbdData->fStatus &= ~CHECKING_FOR_MSR_TRACK_STATUS_ACK;

                    aip_dbg("Switching On CHECKING_MSR_TRACK_STATUS\n");

                    pKbdData->fStatus |= CHECKING_MSR_TRACK_STATUS;

                    aip_dbg("<<< rc=0x01, scancode=0x00\n");
                    *pScancode = scancode = 0;
                    return 1;
                }
            default: /* No Ack for Command E4, implies MSR is Active (Again?) */
                {
                    /* Discard the buffer and Deactivate
                     * This also switches Off all Flags and puts us back into
                     * Inactive state
                     */
                    aip_error("Expecting Single track - but MSR is still active\n");
                    aip_error("Discarding MSR buffer and deactivating\n");

                    __discard_and_deactivate_active_data_buffer();

                    aip_dbg("<<< rc=0x01, scancode=0x00\n");
                    *pScancode = scancode = 0;
                    return 1;
                }
            }
        }

        else if (pKbdData->fStatus & CHECKING_MSR_TRACK_STATUS) {
            aip_dbg("Current Status is: CHECKING_FOR_MSR_TRACK_STATUS\n");

            if (is_valid_single_track_data(scancode)) {
                aip_dbg("is valid single track data: TRUE\n");
                aip_dbg("Switching Off CHECKING_MSR_TRACK_STATUS\n");

                pKbdData->fStatus &= ~CHECKING_MSR_TRACK_STATUS;

                /* /////////////////////////////////
                 * Got a full buffer of MSR data //
                 * /////////////////////////////////
                 */

                /* Switch SureOne MSR Status to 'Holding MSR Data'
                 * This locks the buffer
                 */
                aip_dbg("Moving to Collection State: Holding\n");

                pKbdData->SureOneMsrStatus.CollectionState = Holding;
            } else {
                aip_dbg("is valid single trackdata: FALSE\n");

                /* Discard the buffer
                 * This also switches Off all Flags and puts us back into
                 * Waiting state
                 */
                aip_error("Expecting Single track - but MSR actually read two tracks\n");
                aip_error("Discarding MSR buffer and deactivating\n");

                __discard_and_deactivate_active_data_buffer();
            }

            aip_dbg("<<< rc=0x01, scancode=0x00\n");
            *pScancode = scancode = 0;
            return 1;
        }

        /* /////////////////////////
         * Normal MSR Collecting //
         * /////////////////////////
         */
        else if (pKbdData->fStatus & COLLECTING_MSR_DATA) {
            aip_dbg("Current Status is: COLLECTING_MSR_DATA\n");
            aip_dbg("Collection State: 0x%02x\n",
                    pKbdData->SureOneMsrStatus.CollectionState);

            /* ////////////
             * Got SS 1 //
             * ////////////
             */
            if (pKbdData->SureOneMsrStatus.CollectionState == got_SS_1) {
                if (SUREONE_SCANCODE_END_MSR_DATA == scancode) {    /* 0x35 */
                    aip_dbg("GOT Potential ES, 0x35\n");

                    /* Only Shifted 0x35 is End Sentinel */

                    if ((pKbdData->StreamBuffer[1] == 0x2a) &&
                        (pKbdData->StreamBuffer[0] == 0x35)) {
                        aip_dbg("Moving to Collection State: got_ES_1\n");

                        pKbdData->SureOneMsrStatus.CollectionState = got_ES_1;
                    } else {
                        /* else it is '/' as part of the msr data */
                        aip_dbg("Ignoring\n");
                    }
                }

                scancode = collecting_msr_data(scancode);

                aip_dbg("<<< rc=0x01, scancode=0x00\n");
                *pScancode = scancode = 0;
                return 1;
            }

            /* ////////////
             * Got ES 1 //
             * ////////////
             */
            else if (pKbdData->SureOneMsrStatus.CollectionState == got_ES_1) {
                /* We are waiting for a sequence of 0xaa, 0x1c between the
                 * end of first track and the start of the next. Ignore
                 * scancodes that do not fit the pattern.
                 */

                aip_dbg("Collection State = got_ES_1, scancode= 0x%02x\n",scancode);
                switch (scancode) {
                case 0xaa:
                    {
                        scancode = collecting_msr_data(scancode);

                        aip_dbg("<<< rc=0x01, scancode=0x00\n");
                        *pScancode = scancode = 0;
                        return 1;
                    }
                case 0x1c:
                    {
                        scancode = collecting_msr_data(scancode);

                        /* Switch SureOne MSR Status to 'Got 0x1C between
                         * first and second tracks'  This will allow us to
                         * look for start of the next track.
                         */
                        aip_dbg("Moving to Collection State: FirstTrackComplete\n");

                        pKbdData->SureOneMsrStatus.CollectionState = FirstTrackComplete;

                        /* Switch Off first track collect phase */
                        aip_dbg("Switching Off COLLECTING_MSR_DATA\n");

                        pKbdData->fStatus &= ~COLLECTING_MSR_DATA;

                        /* Switch Off the safety timer between SS 1 and
                         * FirstTrackComplete
                         */
                        stop_end_track_timer();

                        /* Switch On the safety timer between
                         * FirstTrackComplete and SS 2
                         */
                        start_inter_track_timer();

                        aip_dbg("<<< rc=0x01, scancode=0x00\n");
                        *pScancode = scancode = 0;
                        return 1;
                    }
                default: /* Report, consume but do not collect */
                    {
                        aip_error("Unexpected scancode 0x%02x while waiting for 0x1C between tracks - consumed\n", scancode);

                        aip_dbg("<<<  rc=0x01, scancode=0x00\n");
                        *pScancode = scancode = 0;
                        return 1;
                    }
                }
            }

            /* ////////////
             * Got SS 2 //
             * ////////////
             */
            else if (pKbdData->SureOneMsrStatus.CollectionState == got_SS_2) {
                if (SUREONE_SCANCODE_END_MSR_DATA == scancode) {    /* 0x35 */
                    aip_dbg("GOT Potential ES, 0x35\n");

                    /* Only Shifted 0x35 is End Sentinel */

                    if ((pKbdData->StreamBuffer[1] == 0x2a) &&
                        (pKbdData->StreamBuffer[0] == 0x35)) {
                        /* Move to next colection state - got ES 2 */
                        aip_dbg("Moving to Collection State: got_ES_2\n");

                        pKbdData->SureOneMsrStatus.CollectionState = got_ES_2;
                    } else {
                        /* else it is '/' as part of the msr data */
                        aip_dbg("Ignoring\n");
                    }
                }

                scancode = collecting_msr_data(scancode);

                aip_dbg("<<<  rc=0x01, scancode=0x00\n");
                *pScancode = scancode = 0;
                return 1;
            }

            /* ///////////
             * Got ES 2 //
             * ///////////
             */
            else if (pKbdData->SureOneMsrStatus.CollectionState == got_ES_2) {
                /* We are waiting for a sequence of 0xaa, 0x1c at the end of
                 * second track Ignore scancodes that do not fit the pattern.
                 */

                switch (scancode) {
                case 0xaa:
                    {
                        scancode = collecting_msr_data(scancode);

                        aip_dbg("<<<  rc=0x01, scancode=0x00\n");
                        *pScancode = scancode = 0;
                        return 1;
                    }
                case 0x1c:
                    {
                        scancode = collecting_msr_data(scancode);

                        /* ////////////////////////////////
                         * Got a full buffer of MSR data //
                         * ////////////////////////////////
                         */

                        /* Switch SureOne MSR Status to 'Holding MSR Data'
                         * This locks the buffer
                         */
                        aip_dbg("Moving to Collection State: Holding\n");

                        pKbdData->SureOneMsrStatus.CollectionState = Holding;

                        /* Switch Off second track collect phase */
                        aip_dbg("Switching Off COLLECTING_MSR_DATA\n");

                        pKbdData->fStatus &= ~COLLECTING_MSR_DATA;

                        /* Switch off the safety timer between SS 2 and
                         * Holding
                         */
                        stop_end_track_timer();

                        aip_dbg("<<<  rc=0x01, scancode=0x00\n");
                        *pScancode = scancode = 0;
                        return 1;
                    }
                default: /* Report, consume but do not collect */
                    {
                        aip_error("Unexpected scancode 0x%02x while waiting for 0x1C between tracks - consumed\n", scancode);

                        aip_dbg("<<<  rc=0x01, scancode=0x00\n");
                        *pScancode = scancode = 0;
                        return 1;
                    }
                }
            } else {     /* Unexpected state */
                aip_error("Unexpected Collection State: 0x%02x\n",
                          pKbdData->SureOneMsrStatus.CollectionState);

                /* Discard the buffer and Deactivate
                 * This also switches Off all Flags and puts us back into
                 * Inactive state
                 */
                aip_error("Discarding MSR buffer and deactivating\n");

                __discard_and_deactivate_active_data_buffer();

                /* Early exit - Handled */
                aip_dbg("<<< rc=0x01, scancode=0x00\n");
                *pScancode = scancode = 0;
                return 1;
            }
        }

        /* /////////////////////////////////////////////////////////////////
         * At this point we have a scancode that we haven't stuffed into
         * a buffer
         * /////////////////////////////////////////////////////////////////
         */

        switch (scancode) {
        case SUREONE_SCANCODE_BEG_MSR_DATA_27:    /* 0x27 */
            {
                SUREONE_MSR_COLLECTION_STATE msrState = pKbdData->SureOneMsrStatus.CollectionState;
                int ValidStartSequence = FALSE;

                aip_dbg("GOT Possible SS 0x27: Collection state=0x%02x\n",
                        msrState);

                if (msrState == Waiting) {
                    /* Look for First Track scancode sequence 0x2a 0xaa 0x27 */
                    aip_dbg("msrState waiting...FIRST PASS Streambuffer 0x%02x 0x%02x 0x%02x\n",
                            pKbdData->StreamBuffer[0],
                            pKbdData->StreamBuffer[1],
                            pKbdData->StreamBuffer[2]);

                    if ((pKbdData->StreamBuffer[2] == 0x2a) &&
                        (pKbdData->StreamBuffer[1] == 0xaa) &&
                        (pKbdData->StreamBuffer[0] == 0x27)) {
                        ValidStartSequence = TRUE;
                        aip_dbg("Valid First Track Start Sequence - Will check if it is from MSR\n");
                    }
                } else if (msrState == FirstTrackComplete) {
                    /* Look for Second Track start sequence 0xaa 0x1c 0x27 */
                    aip_dbg("MSR SECOND TRACK SEQUENCE\n");
                    aip_dbg("pKbdData Stream buffer 0x%02x  0x%02x 0x%02x",
                            pKbdData->StreamBuffer[0],
                            pKbdData->StreamBuffer[1],
                            pKbdData->StreamBuffer[2]);

                    if ((pKbdData->StreamBuffer[2] == 0xaa) &&
                        (pKbdData->StreamBuffer[1] == 0x1c) &&
                        (pKbdData->StreamBuffer[0] == 0x27)) {
                        ValidStartSequence = TRUE;
                        aip_dbg("Valid Second Track Start Sequence - Will check if it is from MSR\n");
                    }
                }

                if (ValidStartSequence == TRUE) {
                    /* Maybe Start of MSR Track
                     * Ask keyboard controller if data source is MSR
                     */

                    unsigned char status = inb(0x64);

                    while (status & 0x03) {
                        status = inb(0x64);
                    }

                    outb(0xE5, 0x60);

                    aip_dbg("SENT 0xE5, status=0x%02x\n", status);
                    aip_dbg("Switching On CHECKING_FOR_MSR_SS_27_ACK\n");

                    pKbdData->fStatus |= CHECKING_FOR_MSR_SS_27_ACK;
                    scancode = 0;
                } else {
                    aip_dbg("Ignoring\n");
                }

                break;
            }

        case SUREONE_SCANCODE_BEG_MSR_DATA_06:    /* 0x06 */
            {
                SUREONE_MSR_COLLECTION_STATE msrState = pKbdData->SureOneMsrStatus.CollectionState;
                int ValidStartSequence = FALSE;

                aip_dbg("GOT Possible SS 0x06: Collection state=0x%02x\n", msrState);

                if (msrState == Waiting) {
                    /* 0x06 is only a valid start sentinel on track #1 of 3
                     * Look for First Track scancode sequence 0x2a 0xaa 0x2a
                     * 0x06
                     */

                    aip_dbg("msrState waiting... ACTUAL STREAM BUFFER CONTENT: "
                            "0x%02x 0x%02x 0x%02x 0x%02x\n",
                            pKbdData->StreamBuffer[0], pKbdData->StreamBuffer[1],
                            pKbdData->StreamBuffer[2], pKbdData->StreamBuffer[3]);

                    if ((pKbdData->StreamBuffer[3] == 0x2a) &&
                        (pKbdData->StreamBuffer[2] == 0xaa) &&
                        (pKbdData->StreamBuffer[1] == 0x2a) &&
                        (pKbdData->StreamBuffer[0] == 0x06)) {
                        ValidStartSequence = TRUE;
                        aip_dbg("Valid First Track Start Sequence - "
                                "Will check if it is from MSR\n");
                    }
                }

                if (ValidStartSequence == TRUE) {
                    /* Ask keyboard controller if data source is MSR */
                    unsigned char status = inb(0x64);

                    while (status & 0x03) {
                        status = inb(0x64);
                    }

                    outb(0xE5, 0x60);

                    aip_dbg("SENT 0xE5, status=0x%02x\n", status);
                    aip_dbg("Switching On CHECKING_FOR_MSR_SS_06_ACK\n");

                    pKbdData->fStatus |= CHECKING_FOR_MSR_SS_06_ACK;
                    scancode = 0;
                } else {
                    aip_dbg("Ignoring\n");
                }

                break;
            }

        default:
            break;
        }
    }

    /* /////////////////////////////////////
     * Setup rc and scancode to be passed //
     * /////////////////////////////////////
     */

    if (scancode == 0) {
        /* Scancode is consumed by us */
        *pScancode = 0;
        rc = 1;
    } else {
        /* Return scancode for further processing */
        *pScancode = scancode;
        rc = 0;
    }

    aip_dbg("<<< rc=0x%02x, scancode=0x%02x\n", rc, *pScancode);

    return rc;
}


/************************************************************************
 *
 * Function Name:  ioctl
 *
 * Purpose:        Receive client requests
 *
 * Description:    Called when client requests service
 *
 *
 * Output:        Specific to the request and the struct passed down
 *                from the client.
 *
 *                Return
 *                    0         - SUCCESS if service is supported
 *                    EINVAL    - Not supported
 *
 * ***********************************************************************
 */

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 36)
static int ioctl(struct inode *inode, struct file *fp, unsigned int cmd,
                 unsigned long userBuffer)
#else
static long ioctl(struct file *fp, unsigned int cmd, unsigned long userBuffer)
#endif
{
    unsigned long         CompletionCode;
    const unsigned long   ZeroLength = 0;

    GET_SLOT_INFO_PARMS   SlotInfo;
    QUERY_KEYBOARD_PARMS  KeyboardInfo;
    COMPLETION_PARMS_6    CompletionParms6;
    COMPLETION_PARMS_8    CompletionParms8;

    int rc = SUCCESS;

    switch (cmd) {
#if defined(DEVELOPMENT)
    case FN_DEVELOPMENT_READ_RAW_MSR_DATA:
        {
            aip_dbg(">> FN_DEVELOPMENT_READ_RAW_MSR_DATA\n");

            if (pKbdData->MSRData.MSRDataLength &&
                (pKbdData->SureOneMsrStatus.CollectionState == Holding)) {
                aip_dbg("reading MSR data %ld raw bytes\n", pKbdData->MSRData.MSRDataLength);

                if (copy_to_user (((PREAD_MSR_DATA_PARMS) userBuffer)->buffer,
                                  &pKbdData->MSRData.MSRDataBuffer,
                                  pKbdData->MSRData.MSRDataLength) != 0) {
                    rc = -EFAULT;
                }

                if (copy_to_user(&(((PREAD_MSR_DATA_PARMS) userBuffer)->length),
                                 &pKbdData->MSRData.MSRDataLength,
                                 sizeof(pKbdData->MSRData.MSRDataLength)) != 0) {
                    rc = -EFAULT;
                }

                aip_dbg("MSR Data Buffer 0x%02x, 0x%02x, 0x%02x, 0x%02x, 0x%02x, 0x%02x, 0x%02x, ...\n",
                        pKbdData->MSRData.MSRDataBuffer[0],
                        pKbdData->MSRData.MSRDataBuffer[1],
                        pKbdData->MSRData.MSRDataBuffer[2],
                        pKbdData->MSRData.MSRDataBuffer[3],
                        pKbdData->MSRData.MSRDataBuffer[4],
                        pKbdData->MSRData.MSRDataBuffer[5],
                        pKbdData->MSRData.MSRDataBuffer[6]);

                /* Reset MSR Data:  Flag, Index, MSRDataLength &&
                 * MSRDataBuffer[]
                 */
                memset(&pKbdData->MSRData, 0, sizeof(pKbdData->MSRData));

                /* Set SureOneMsrStatus collection stage to Inactive */
                pKbdData->SureOneMsrStatus.CollectionState = Inactive;

            } else {

                aip_dbg("------  No Data, Yet  -----\n");

                copy_to_user(&((PREAD_MSR_DATA_PARMS) userBuffer)->length,
                             &ZeroLength,
                             sizeof(ZeroLength));

                /* Set SureOneMsrStatus collection stage to Waiting for new
                 * MSR event, if necessary
                 */
                if (pKbdData->SureOneMsrStatus.CollectionState < Waiting) {
                    pKbdData->SureOneMsrStatus.CollectionState = Waiting;
                }
            }

            rc = SUCCESS;

            CompletionCode = RPDONE;

            if (copy_to_user(&((PREAD_MSR_DATA_PARMS) userBuffer)->CompletionCode,
                             &CompletionCode,
                             sizeof(CompletionCode)) != 0) {
                rc = -EFAULT;
            }

            aip_dbg("<< FN_DEVELOPMENT_READ_RAW_MSR_DATA\n");

            break;
        }
#endif

    case FN_READ_MSR_DATA:
        {
            aip_dbg(">> FN_READ_MSR_DATA\n");

            if (pKbdData->MSRData.MSRDataLength &&
                ( (machine_type == IBM_4614 &&
                   pKbdData->SureOneMsrStatus.CollectionState == Holding) ||
                  (machine_type == IBM_4613 &&
                   pKbdData->SureOneMsrStatus.CollectionState == Inactive))) {
                aip_dbg("reading MSR data %d raw bytes\n",
                        pKbdData->MSRData.MSRDataLength);
                convert_raw_msr_data();

                if (copy_to_user (((PREAD_MSR_DATA_PARMS) userBuffer)->buffer,
                                  &AsciiBuffer.DataBuffer,
                                  AsciiBuffer.DataLength) != 0) {
                    rc = -EFAULT;
                }

                if (copy_to_user(&(((PREAD_MSR_DATA_PARMS) userBuffer)->length),
                                 &AsciiBuffer.DataLength,
                                 sizeof(AsciiBuffer.DataLength)) != 0) {
                    rc = -EFAULT;
                }

                aip_dbg("MSR Ascii Buffer 0x%02x, 0x%02x, 0x%02x, 0x%02x, 0x%02x, 0x%02x, 0x%02x, ...\n",
                        AsciiBuffer.DataBuffer[0],
                        AsciiBuffer.DataBuffer[1],
                        AsciiBuffer.DataBuffer[2],
                        AsciiBuffer.DataBuffer[3],
                        AsciiBuffer.DataBuffer[4],
                        AsciiBuffer.DataBuffer[5],
                        AsciiBuffer.DataBuffer[6]);

                /* Reset MSR Data:  Flag, Index, MSRDataLength &&
                 * MSRDataBuffer[]
                 */
                memset( &pKbdData->MSRData, 0, sizeof(pKbdData->MSRData));

                /* Set SureOneMsrStatus collection stage to Inactive */
                pKbdData->SureOneMsrStatus.CollectionState = Inactive;

            } else {
                aip_dbg("No Data, Yet!\n");

                if (copy_to_user(&((PREAD_MSR_DATA_PARMS) userBuffer)->length,
                                 &ZeroLength, sizeof(ZeroLength)) != 0) {
                    rc = -EFAULT;
                }

                /* Set SureOneMsrStatus collection stage to Waiting for new
                 * MSR event, if necessary
                 */
                if (machine_type == IBM_4614 && pKbdData->SureOneMsrStatus.CollectionState < Waiting) {
                    pKbdData->SureOneMsrStatus.CollectionState = Waiting;
                }
            }
            rc = SUCCESS;

            CompletionCode = RPDONE;

            if (copy_to_user(&((PREAD_MSR_DATA_PARMS) userBuffer)->CompletionCode,
                             &CompletionCode, sizeof(CompletionCode)) != 0) {
                rc = -EFAULT;
            }

            aip_dbg("<<FN_READ_MSR_DATA\n");
            break;
        }

    case FN_CANCEL_MSR_READ:
        {
            aip_dbg(">> FN_CANCEL_MSR_READ\n");

            if (pKbdData->SureOneMsrStatus.CollectionState > Inactive) {
                discard_and_deactivate_active_data_buffer();
            }

            rc = SUCCESS;

            CompletionCode = RPDONE;

            if (copy_to_user(&((PREAD_MSR_DATA_PARMS) userBuffer)->CompletionCode,
                             &CompletionCode, sizeof(CompletionCode)) != 0) {
                rc = -EFAULT;
            }

            if (copy_to_user(&(((PREAD_MSR_DATA_PARMS) userBuffer)->length),
                             &ZeroLength, sizeof(ZeroLength)) != 0) {
                rc = -EFAULT;
            }

            aip_dbg("<< FN_CANCEL_MSR_READ\n");

            break;
        }

    case FN_GET_SLOT_INFO:
        {
            PGET_SLOT_INFO_PARMS pSlotInfo = &SlotInfo;

            aip_dbg(">> FN_GET_SLOT_INFO\n");

            memset(pSlotInfo, 0, sizeof(GET_SLOT_INFO_PARMS));

            pSlotInfo->CompletionCode   = RPDONE;
            pSlotInfo->AdapterID[1]     = 4614;
            if (machine_type == IBM_4613) {
                pSlotInfo->AdapterID[1] = 4613;
            }
            pSlotInfo->SlotDrawers[1]   = 0;
            pSlotInfo->SlotNVRAM[1]     = 0;

            if (copy_to_user((PGET_SLOT_INFO_PARMS) userBuffer,
                             pSlotInfo, sizeof(GET_SLOT_INFO_PARMS)) != 0) {
                rc = -EFAULT;
            } else {
                rc = SUCCESS;
            }

            aip_dbg("<< FN_GET_SLOT_INFO\n");

            break;
        }

    case FN_QUERY_KEYBOARD:
        {
            PQUERY_KEYBOARD_PARMS pKeyboardInfo = &KeyboardInfo;

            aip_dbg(">> FN_QUERY_KEYBOARD\n");

            memset(pKeyboardInfo, 0, sizeof(QUERY_KEYBOARD_PARMS));

            pKeyboardInfo->CompletionCode   = RPDONE;
            pKeyboardInfo->msrType          = 1;
            pKeyboardInfo->keyboardEC       = pKbdData->EC_Level;  /* Kbd Controller EC */
            pKeyboardInfo->msrEC            = pKbdData->EC_Level;  /* Kbd Controller EC */
            pKeyboardInfo->keyboardID       = 4614;
            pKeyboardInfo->keyboardSubtype  = 5;                   /* SureOne Keyboard */
            if (machine_type == IBM_4613) {
                pKeyboardInfo->keyboardID       = 4613;
                pKeyboardInfo->keyboardSubtype  = 6;               /* IBM4613 Keyboard */
            }

            if (copy_to_user((PQUERY_KEYBOARD_PARMS) userBuffer,
                             pKeyboardInfo,
                             sizeof(QUERY_KEYBOARD_PARMS)) != 0) {
                rc = -EFAULT;
            } else {
                rc = SUCCESS;
            }

            aip_dbg("<< FN_QUERY_KEYBOARD\n");

            break;
        }

    case FN_CLICK:
    case FN_TONE:
    case FN_TRAP_KEYS:
    case FN_TRACKS:
    case FN_TYPEMATIC:
    case FN_SET_DOUBLEKEYS:
    case FN_POS_LEDS:
    case FN_ENABLE_DISABLE:
    case FN_GET_SHIFT_STATE:
    case FN_SET_SHIFT_STATE:
    case FN_QUERY_CODE_UPDATE:
        {
            /*aip_dbg(">> SUPPORTED BUT UNIMPLEMENTED FN: 0x%02x\n",cmd);*/

            PCOMPLETION_PARMS_6 pCompletionParms6 = &CompletionParms6;

            pCompletionParms6->CompletionCode = RPDONE;
            pCompletionParms6->length = 0;

            if (copy_to_user((PCOMPLETION_PARMS_6) userBuffer,
                             pCompletionParms6,
                             sizeof(COMPLETION_PARMS_6)) != 0) {
                rc = -EFAULT;
            } else {
                rc = SUCCESS;
            }

            /*aip_dbg("<< SUPPORTED BUT UNIMPLEMENTED FN: 0x%02x\n",cmd);*/

            break;
        }
    case FN_READ_KBD_STATUS:
    case FN_CODE_UPDATE:
        {
            /*aip_dbg(">> SUPPORTED BUT UNIMPLEMENTED FN: 0x%02x\n",cmd);*/

            PCOMPLETION_PARMS_8 pCompletionParms8 = &CompletionParms8;

            pCompletionParms8->CompletionCode = RPDONE;
            pCompletionParms8->length = 0;

            if (copy_to_user((PCOMPLETION_PARMS_8) userBuffer,
                             pCompletionParms8,
                             sizeof(COMPLETION_PARMS_8)) != 0) {
                rc = -EFAULT;
            } else {
                rc = SUCCESS;
            }

            /*aip_dbg("<< SUPPORTED BUT UNIMPLEMENTED FN: 0x%02x\n",cmd);*/

            break;
        }

    default:
        {
            aip_error("<< Invalid IOCTL, CMD=%d\n", cmd);
            rc = -EINVAL;
        }
    }

    return rc;
}


/************************************************************************
 *
 * Function Name:  check_model
 *
 * Purpose:        Read model number from bios.
 *
 *
 * Output:
 *                 none
 *
 *
 * Notes:          This not the SMBios value but the IBM model number at a
 *                 known location in the SureOne Bios
 *
 * ***********************************************************************
 */

static int check_model(void)
{
    void* page = (unsigned char*) ioremap(IOMAP_BASE, IOMAP_SIZE);

    if (!page)
        return FALSE;

    model = readl((unsigned char*)page + MODEL_OFFSET);
    iounmap((unsigned char*)page);

    aip_dbg("model -- 0x%04lx\n", model);
    return TRUE;
}


/************************************************************************
 *
 * Function Name:  msr_init
 *
 * Purpose:        Initialise MSR state variables and objects
 *
 *
 * Output:
 *                 none
 *
 *
 * Notes:         Called once on driver init
 *
 * ***********************************************************************
 */

static void msr_init(void)
{
    PSUREONE_MSR_STATUS pSureOneMsrStatus;

    pSureOneMsrStatus = &(pKbdData->SureOneMsrStatus);

    pSureOneMsrStatus->CollectionState = Inactive;

    init_timer(&(pSureOneMsrStatus->EndTrackTimer));
    init_timer(&(pSureOneMsrStatus->InterTrackTimer));
}


/************************************************************************
 *
 * Function Name:  reset_msr_status
 *
 * Purpose:        Reset MSR state variables and objects to inactive.
 *
 *
 * Output:
 *                 none
 *
 * ***********************************************************************
 */

static void reset_msr_status(void)
{
    PSUREONE_MSR_STATUS pSureOneMsrStatus;

    pSureOneMsrStatus = &(pKbdData->SureOneMsrStatus);

    pSureOneMsrStatus->CollectionState = Inactive;

    del_timer_sync(&(pSureOneMsrStatus->EndTrackTimer));
    del_timer_sync(&(pSureOneMsrStatus->InterTrackTimer));
}


/************************************************************************
 *
 * Function Name:  update_stream_buffer
 *
 * Purpose:        Update the Stream Buffer
 *
 * Description:    Put the latest arrived scancode into the first buffer
 *                 position after shifting the current contents up one.
 *
 *
 *
 * Output:
 *                 none
 *
 *
 * Notes:         The Stream Buffer is used to detect various states
 *                based on which scancode sequences have been received
 *
 * ***********************************************************************
 */

static inline void update_stream_buffer(unsigned char scancode)
{
    int i;

    for (i = STREAM_BUFFER_LAST_INDEX ; i > 0; i--) {
        pKbdData->StreamBuffer[i] = pKbdData->StreamBuffer[i-1];
    }

    pKbdData->StreamBuffer[0] = scancode;

    aip_dbg("StreamBuffer: 0x%02x, 0x%02x, 0x%02x, 0x%02x, 0x%02x, 0x%02x, 0x%02x\n",
            pKbdData->StreamBuffer[0],
            pKbdData->StreamBuffer[1],
            pKbdData->StreamBuffer[2],
            pKbdData->StreamBuffer[3],
            pKbdData->StreamBuffer[4],
            pKbdData->StreamBuffer[5],
            pKbdData->StreamBuffer[6]);
}


/************************************************************************
 *
 * Function Name:  end_track_timed_out
 *
 * Purpose:        Notification that the end of track timer has timed out
 *
 * Description:    Notification that the end of track timer has timed out
 *                 called by the timer object
 *
 *
 * Output:
 *                 none
 *
 *
 * Notes:         Runaway MSR - a start of track was detected but no valid
 *                end was found within END_TRACK_TIMEOUT jiffies
 *
 * ***********************************************************************
 */

static void end_track_timed_out(unsigned long data)
{
#ifdef DEBUG
    SUREONE_MSR_COLLECTION_STATE initialMsrState = (SUREONE_MSR_COLLECTION_STATE) data;

    aip_dbg("end-track timer timed out: jiffies=%lu, initial msrState=0x%02x\n",
            jiffies, initialMsrState);
#endif

    __discard_and_deactivate_active_data_buffer();
}


/************************************************************************
 *
 * Function Name:  inter_track_timed_out
 *
 * Purpose:        Notification that the inter-track timer has timed out
 *
 * Description:    Notification that the inter-track timer has timed out
 *                 called by the timer object
 *
 *
 * Output:
 *                 none
 *
 *
 * Notes:          Either only a single track was read by the MSR reader or
 *                 an error condition has been detected by the driver. To
 *                 find out which we send command 0xE4 to the keyboard
 *                 controller to determine how many tracks were read.
 *
 * ***********************************************************************
 */

static void inter_track_timed_out(unsigned long data)
{
    unsigned char status = inb(0x64);

    aip_dbg("inter-track timer timed out: jiffies=%lu\n", jiffies);

    while (status & 0x03) {
        status = inb(0x64);
    }

    outb(0xE4, 0x60);

    aip_dbg("SENT 0xE4, status=0x%02x\n", status);

    /* Switch On Checking for MSR Track Status Ack */
    pKbdData->fStatus |= CHECKING_FOR_MSR_TRACK_STATUS_ACK;

    aip_dbg("Switching On CHECKING_FOR_MSR_TRACK_STATUS_ACK\n");
}


/************************************************************************
 *
 * Function Name:  start_end_track_timer
 *
 * Purpose:        Start the end of track timer
 *
 * Description:    Start the timer used to determine whether the MSR reader
 *                 has taken too long to read a single track.
 *
 *
 * Output:
 *                 none
 *
 *
 * Notes:         Called when a valid end of track is detected. Used to
 *                guard against runaway MSR - perhaps a damaged card.
 *
 * ***********************************************************************
 */

static void start_end_track_timer(unsigned long data)
{
    struct timer_list * pEndTrackTimer;

    pEndTrackTimer = &(pKbdData->SureOneMsrStatus.EndTrackTimer);

    if (machine_type == IBM_4613)
        pEndTrackTimer->expires = jiffies + END_TIMEOUT_BET_SCANCODES;
    else
        pEndTrackTimer->expires = jiffies + END_TRACK_TIMEOUT;

    pEndTrackTimer->function = end_track_timed_out;
    pEndTrackTimer->data = data;

    aip_dbg("start end-track timer: jiffies=%lu\n", jiffies);

    add_timer(pEndTrackTimer);
}


/************************************************************************
 *
 * Function Name:  stop_end_track_timer
 *
 * Purpose:        Stop the end of track timer
 *
 * Description:    Stop the timer that was started when an MSR Start
 *                 Sentinel was detected
 *
 *
 * Output:
 *                 none
 *
 *
 * Notes:         Called when a valid end of track is detected
 *
 * ***********************************************************************
 */

static void stop_end_track_timer(void)
{
    struct timer_list * pEndTrackTimer;

    pEndTrackTimer = &(pKbdData->SureOneMsrStatus.EndTrackTimer);

    aip_dbg("stop end-track timer: jiffies=%lu\n", jiffies);

    del_timer_sync(pEndTrackTimer);
}


/************************************************************************
 *
 * Function Name:  start_inter_track_timer
 *
 * Purpose:        Start the inter-track timer
 *
 * Description:    Start the timer used to determine whether the MSR reader
 *                 has read one or two tracks
 *
 *
 * Output:
 *                 none
 *
 *
 * Notes:         Called when the end of the first track is detected
 *
 * ***********************************************************************
 */

static void start_inter_track_timer(void)
{
    struct timer_list * pInterTrackTimer;

    pInterTrackTimer = &(pKbdData->SureOneMsrStatus.InterTrackTimer);

    pInterTrackTimer->expires = jiffies + INTER_TRACK_TIMEOUT;
    pInterTrackTimer->function = inter_track_timed_out;
    pInterTrackTimer->data = (unsigned long) 0;

    aip_dbg("start inter-track timer: jiffies=%lu\n", jiffies);

    add_timer(pInterTrackTimer);
}


/************************************************************************
 *
 * Function Name:  stop_inter_track_timer
 *
 * Purpose:        Stop the inter-track timer
 *
 * Description:    Stop the timer that is started after a full first
 *                 track of MSR data was recieved.
 *
 *
 * Output:
 *                 none
 *
 *
 * Notes:         Called when the start of a second track is detected
 *
 * ***********************************************************************
 */

static void stop_inter_track_timer(void)
{
    struct timer_list * pInterTrackTimer;

    pInterTrackTimer = &(pKbdData->SureOneMsrStatus.InterTrackTimer);

    aip_dbg("stop inter-track timer: jiffies=%lu\n", jiffies);

    del_timer_sync(pInterTrackTimer);
}


/************************************************************************
 *
 * Function Name:  is_valid_single_track_data
 *
 * Purpose:        Determine if a single MSR track was read by MSR reader.
 *
 * Description:    Sending command 0xE4 to the keyboard controller
 *                 gets back a byte where bits 1, 2 and 3 show
 *                 whether tracks 1, 2 and/or 3 were read resp. This
 *                 function determines if a single track was read.
 *
 *
 * Output:
 *                 TRUE if only one track was read.
 *
 *
 * Notes:
 *
 * ***********************************************************************
 */

static int is_valid_single_track_data(unsigned char cmd_reply)
{
    int is_valid = FALSE;
    unsigned char reply         = (cmd_reply >> 1) & 0x07;
    unsigned char data_error    = (cmd_reply >> 4) & 0x01;

    if (data_error) {
        return FALSE;
    }

    switch (reply) {
    case 1: /* 001  Track 1 data received */
    case 2: /* 010  Track 2 data received */
    case 4: /* 100  Track 3 data received */
        {
            is_valid = TRUE;
            break;
        }
    }

    return is_valid;
}


/************************************************************************
 *
 * Function Name:  __discard_and_deactivate_active_data_buffer
 *
 * Purpose:        Discard current MSR buffer and return to a known state
 *
 * Description:    Clear MSR buffer, Resets all global state flags, moves
 *                 to MSR collection state: Inactive
 *
 *
 * Output:
 *                 none
 *
 *
 * Notes:         Called from interrupt context when an unrecoverable
 *                condition is detected during MSR collection
 *
 * ***********************************************************************
 */

static void __discard_and_deactivate_active_data_buffer(void)
{
    aip_dbg("discard and deactivate active data buffer:\n");

    /* Reset MSR Data:  Flag, Index, MSRDataLength && MSRDataBuffer[] */
    memset(&pKbdData->MSRData, 0, sizeof(pKbdData->MSRData));

    /* Reset SureOne MSR Status and delete any outstanding timers */
    reset_msr_status();

    /* Set SureOneMsrStatus collection stage to Inactive */
    pKbdData->SureOneMsrStatus.CollectionState = Inactive;

    aip_dbg("Moving to collection state: Inactive\n");

    /* Switch Off All Flags */
    pKbdData->fStatus    = 0x00000000;

    aip_dbg("Switching Off All State flags\n");
}


/************************************************************************
 *
 * Function Name:  discard_and_deactivate_active_data_buffer
 *
 * Purpose:        Discard current MSR buffer and return to a known state
 *
 * Description:    Clear MSR buffer, Resets all global state flags, moves
 *                 to MSR collection state: Inactive
 *
 *
 * Output:
 *                 none
 *
 *
 * Notes:         Called from Sys call context when the client wishes to
 *                cancel current MSR collection.
 *
 * ***********************************************************************
 */

static void discard_and_deactivate_active_data_buffer(void)
{
    unsigned long flags;

    local_irq_save(flags);
    __discard_and_deactivate_active_data_buffer();
    local_irq_restore(flags);
}


/************************************************************************
 *
 * Function Name:  convert_raw_msr_data
 *
 * Purpose:        Convert colected scancodes to Ascii characters
 *
 * Description:    Take the raw MSR scancodes collected in the MSR
 *                 data buffer and create Ascii characters for them
 *                 based on a mapping table in aipsokbps.h. The shift
 *                 state scancodes determine which mapping table is used.
 *
 *
 * Output:
 *                 none
 *
 *
 * Notes:         Called when a complete buffered swipe is about to be passed
 *                up to the client.
 *
 * ***********************************************************************
 */

static void convert_raw_msr_data(void)
{
    int i;
    int LShift = FALSE;
    PSUREONE_ASCII_BUFFER pAsciiBuffer = &AsciiBuffer;

    memset(pAsciiBuffer, 0, sizeof(SUREONE_ASCII_BUFFER));

    for (i = 0; i < pKbdData->MSRData.MSRDataLength; i++) {
        if (pAsciiBuffer->Flag == 1) {
            /* Buffer overrun, exit */
            break;
        }

        if (pKbdData->MSRData.MSRDataBuffer[i] == 0x2a) {
            LShift = TRUE;
        } else if (pKbdData->MSRData.MSRDataBuffer[i] == 0xaa) {
            LShift = FALSE;
        } else if (LShift) {
            pAsciiBuffer->DataBuffer[pAsciiBuffer->Index] =
            shift_kbd_map[pKbdData->MSRData.MSRDataBuffer[i]];

            pAsciiBuffer->Index++;
            pAsciiBuffer->DataLength++;
        } else if (!LShift) {
            pAsciiBuffer->DataBuffer[pAsciiBuffer->Index] =
            kbd_map[pKbdData->MSRData.MSRDataBuffer[i]];

            pAsciiBuffer->Index++;
            pAsciiBuffer->DataLength++;
        }

        /* Check Buffer */
        if (pAsciiBuffer->DataLength >= MAX_ASCII_BUFFER_SIZE) {
            aip_error("AsciiBuffer overrun at %u\n", pAsciiBuffer->DataLength);
            pAsciiBuffer->Flag = 1;
        }
    }
}


#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 18)

int sokb_device_create(unsigned int major_number, char *modname,
                       struct file_operations *fops)
{
    int err;

    /* Register as a device with kernel. */
    if ((err = register_chrdev(major_number, modname, fops))) {
        aip_error("Failure to load module. error %d\n", -err);
        return err;
    }

    return 0;
}


void sokb_device_destroy(unsigned int aipkbd_major, char *modname)
{
    if (unregister_chrdev(aipkbd_major, modname) != 0) {
        aip_error("unregister_chrdev failed\n");
    }

    return;
}

#else

int sokb_device_create(char *modname, char *devname[], int dev_count,
                       char *class_name, sokb_adapter *adapter,
                       struct file_operations *fops)
{
    int err = 0;
    int i = 0;
    int major = 0;
    struct device *dev;

    adapter->major = 0;

    /* Request dynamic allocation of a device major number */
    aip_dbg("Allocating major device with %d minors\n", dev_count);
    if ((err = alloc_chrdev_region(&adapter->dev_number, 0, dev_count,
                                   modname)) < 0) {
        aip_error("Cannot register device, error=%d\n", -err);
        return err;
    }

    aip_dbg("dev number is %x for '%s'\n", adapter->dev_number, modname);

    /* Populate sysfs entries */
    adapter->dev_class = class_create(THIS_MODULE, class_name);

    if (IS_ERR(adapter->dev_class)) {
        aip_error("Cannot create class '%s' error %ld\n", class_name,
                  PTR_ERR(adapter->dev_class));
        adapter->dev_class = NULL;
        return -EINVAL;
    }

    adapter->dev_count = dev_count;
    adapter->major = 0;

    major = MAJOR(adapter->dev_number);

    adapter->major = major;

    for (i = 0; i < dev_count && i < MAX_CDEVS; i++) {
        aip_dbg("Initialzing cdev for %d '%s'\n", i, devname[i]);

        /* Connect the file operations with the cdev */
        cdev_init(&adapter->cdev[i], fops);

        aip_dbg("Adding cdev for '%s' major=%d/minor=%d\n", devname[i],
                major, i);

        /* Connect the major/minor number to the cdev */
        err = cdev_add(&adapter->cdev[i], MKDEV(major, i), 1);
        adapter->cdev[i].owner = THIS_MODULE;

        if (err) {
            aip_error("Bad cdev add, error %d\n", -err);

            /* Destroy dev_class */
            class_destroy(adapter->dev_class);
            adapter->dev_class = NULL;

            return err;
        }

        aip_dbg("Adding device for '%s' major=%d/minor=%d\n",
                devname[i], major, i);

        /* Send uevents to udev, so it'll create /dev node */
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 26)
        dev = device_create(adapter->dev_class, NULL, MKDEV(major, i),
                            devname[i]);
#elif LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 28)
        dev = device_create_drvdata(adapter->dev_class, NULL, MKDEV(major, i),
                                    NULL, devname[i]);
#else
        dev = device_create(adapter->dev_class, NULL, MKDEV(major, i), NULL,
                            devname[i]);
#endif
        if (!IS_ERR(dev)) {
            /* save sysfs dev pointer for creating additional attributes */
            adapter->dev = dev;
        }

        aip_dbg("Adding sysfs for '%s' major=%d/minor=%d returned err %ld\n",
                devname[i], major, i, IS_ERR(dev));
    }

    return 0;
}


void sokb_device_destroy(sokb_adapter *adapter)
{
    int i = 0;

    aip_dbg("entered major=%d, count=%d\n",
            adapter->major, adapter->dev_count);

    /* Release the major number */
    if (adapter != NULL && adapter->major > 0) {
        if (adapter->dev_class != NULL) {
            for (i = 0; i < adapter->dev_count && i < MAX_CDEVS; i++) {
                aip_dbg("Removing device major=%d/minor=%d returned\n",
                        adapter->major, i);

                /* Destroy device */
                device_destroy(adapter->dev_class, MKDEV(adapter->major, i));

                /* Remove the cdev */
                cdev_del(&adapter->cdev[i]);
            }

            aip_dbg("Unregistering chrdev major=%d, count=%d\n",
                    adapter->major, adapter->dev_count);

            unregister_chrdev_region(adapter->major, adapter->dev_count);

            adapter->dev_count = 0;

            /* Destroy dev_class */
            class_destroy(adapter->dev_class);
            adapter->dev_class = NULL;
        }
        adapter->major = 0;
    }

    aip_dbg("returning\n");

    return;
}

#endif


/************************************************************************
 *
 * Function Name:  sokb_init()
 *
 * Purpose:        Intialization routine
 *
 * Description:    entry point for this driver.
 *
 *
 * Output:
 *                 0        - success
 *                 non-zero - failure.
 *
 * ***********************************************************************
 */
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 16)
static int __init sokb_do_patch_kb_init(void)
{
    int rc = SUCCESS;
    int cmd_retries = 0;
    int resend_retries = 0;
    int state = 0;
    int count = 0;
    int rcvd02 = 0;
    int rcvd82 = 0;

    /* Register with low level driver, atkbd / pc_keyb driver. Upon
     * registration, the atkbd / pc_keyb driver provides a pointer to write
     * function.  In addtion, it calls our interrupt routine
     * (pos_scancode_filter()) each time keyboard interrupts.
     * ... this should be OK if the patch for atkbd/pc_keyb is applied.
     * However, we need to find a way to check for the existence of
     * the symbols before calling them
     */
    aip_dbg("Registering with keyboard driver - atkbd\n");
    register_pc_keyb_filter(&pos_filter);

    if (machine_type == IBM_4614) {
        aipsokbps_timeout(10);

        /* Read Keyboard Controller EC Level */
        rc = kbd_get_ec_level();

        if (rc != 0) {
            aip_error("kbd_get_ec_level failed rc=%02x\n", rc);

            /* Unregister with atkb/pc_keyb driver */
            unregister_pc_keyb_filter(&pos_filter);
            return -ENODEV;
        }

        /* Wait until we have received keyboard controller EC byte
         * max wait = 5*10(ms)*20 = 1000 ms, timer tick = 10ms
         */
        cmd_retries = 20;
        while (cmd_busy && cmd_retries) {
            aip_dbg(" ... cmd_busy = %02x\n", cmd_busy);
            aipsokbps_timeout(5);
            --cmd_retries;
        }

        if (pKbdData->EC_Level != 0) {
            aip_info("Found SureOne keyboard controller, EC Level %d\n",
                     pKbdData->EC_Level);
        } else {
            /* Did not find a Keyboard Controller */
            aip_error("No SureOne keyboard controller found\n");

            /* Unregister with atkbd/pc_keyb driver */
            unregister_pc_keyb_filter(&pos_filter);
            return -ENODEV;
        }

        aip_dbg("_init() -->Initializing MSR\n");
    }

    if (machine_type == IBM_4613) {
        pKbdData->fStatus |= SET_MSR_PREFIX;
        for (count = 0; count <= 2; count++) {
            /* For first command */
            for (state = 1; state <= 4; state++) {
                aipsokbps_timeout(10);
                rc = set_msrprefix(state,count);
                if (rc != 0) {
                    aip_error("set_msrprefix failed rc=%02x\n", rc);
                    /* Unregister with atkb/pc_keyb driver */
                    unregister_pc_keyb_filter(&pos_filter);
                    rc = -ENODEV;
                    break;
                }

                /* Wait until we have received keyboard controller EC byte
                 * max wait = 5*10(ms)*20 = 1000 ms, timer tick = 10ms
                 */
                cmd_retries = 5;
                while (cmd_busy && cmd_retries) {
                    aip_dbg(" ... cmd_busy = %02x\n", cmd_busy);
                    aipsokbps_timeout(5);
                    --cmd_retries;
                }

                if (state == 4) {

                    if (pKbdData->mStatus == SCANCODE_ACK) {
                        aip_dbg("ACK Received\n");
                        /*Wait for the next byte*/
                        cmd_retries = 5;
                        while (cmd_busy && cmd_retries) {
                            aip_dbg(" ... cmd_busy = %02x\n", cmd_busy);
                            aipsokbps_timeout(5);
                            --cmd_retries;

                        }
                    }
                    if (pKbdData->mStatus == SCANCODE_ONE) {
                        rcvd02 = 1;
                    } else if (pKbdData->mStatus ==
                               BREAK_SCANCODE(SCANCODE_ONE)) {
                        rcvd82 = 1;
                    }

                    /*Wait for the next byte*/
                    cmd_retries = 5;
                    while (cmd_busy && cmd_retries) {
                        aip_dbg(" ... cmd_busy = %02x\n", cmd_busy);
                        aipsokbps_timeout(5);
                        --cmd_retries;
                    }

                    if (pKbdData->mStatus == SCANCODE_ONE) {
                        rcvd02 = 1;
                    } else if (pKbdData->mStatus ==
                               BREAK_SCANCODE(SCANCODE_ONE)) {
                        rcvd82 = 1;
                    }

                    if (rcvd02 == 0 || rcvd82 == 0) {
                        /*wait last time for the reply pair*/
                        /*Wait for the next byte*/
                        cmd_retries = 5;
                        while (cmd_busy && cmd_retries) {
                            aip_dbg(" ... cmd_busy = %02x\n", cmd_busy);
                            aipsokbps_timeout(5);
                            --cmd_retries;
                        }
                    }
                } else {
                    if (pKbdData->mStatus == SCANCODE_ACK) {
                        aip_dbg("ACK Received\n");
                    } else if (pKbdData->mStatus == SCANCODE_RESEND) {
                        if (resend_retries == 5) {
                            aip_dbg("BAIL OUT..WE HAVE BEEN NACKED 5 times\n");
                            unregister_pc_keyb_filter(&pos_filter);
                            rc = -ENODEV;
                            break;
                        }
                        aip_dbg("NACK RECEIVED?->0x%02x then Retry\n",
                                pKbdData->mStatus);
                        state--;
                        resend_retries++;
                    } else {
                        aip_dbg("Retry -> UNKNOWN REPLY RECEIVED?->0x%02x\n",
                                pKbdData->mStatus);

                        if (resend_retries == 5) {
                            aip_dbg("BAIL OUT..WE HAVE TRIED LONG ENOUGH\n");
                            unregister_pc_keyb_filter(&pos_filter);
                            rc = -ENODEV;
                            break;
                        }
                        state--;
                        resend_retries++;
                    }
                }
            }

            if (rc != 0)
                break;
        }
        pKbdData->fStatus &= ~SET_MSR_PREFIX;
    }

    if (rc != 0)
        return rc;
    /* Initialise MSR variables and objects */
    msr_init();

    /* Register as a device with kernel. */
    rc = sokb_device_create(aipsokbps_major, DEVDRVR_ID, &sokb_fops);

    if (rc != 0) {
        aip_error("Register device with kernel failed rc=0x%02x\n", rc);

        /* Unregister with atkbd/pc_keyb driver */
        unregister_pc_keyb_filter(&pos_filter);
        return -ENODEV;
    }

    aip_info("Loaded, rc=%d\n", -rc);

    return rc;
}
#else

static int sokb_create_kbd_port(struct serio *serio);

static int sokb_connect(struct serio *serio, struct serio_driver *drv)
{
    int rc = SUCCESS;
    int cmd_retries = 0;
    int resend_retries = 0;
    int state = 0;
    int count = 0;
    int rcvd02 = 0;
    int rcvd82 = 0;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 18)
    char *dev_names[20] = { "aipsokbps", "ps2driver"};
    int  dev_count = 1;
#endif

    /* Initialize keyboard data structure. */
    aip_dbg("Serio name='%s', phys='%s'\n", serio->name, serio->phys);
    if (!strncmp(serio->phys, AIPSOKBPS_PHYS_NAME, sizeof(serio->phys)))
        return -EINVAL;

    if (sokb_real_serio != NULL) {
        aip_dbg("serio already attached\n");
        return -EINVAL;
    }

    if ((rc = serio_open(serio, drv))) {
        aip_error("serio_open failed rc=%02x\n", rc);
        return rc;
    }

    sokb_real_serio = serio;

    if (machine_type == IBM_4614) {
        aipsokbps_timeout(10);

        /* Read Keyboard Controller EC Level */
        rc = kbd_get_ec_level();

        if (rc != 0) {
            /* unregister with pc_keyb driver. */
            aip_error("kbd_get_ec_level failed rc=%02x\n", rc);
            aip_dbg("unregister with atkbd\n");

            sokb_real_serio = NULL;
            serio_close(serio);
            return -ENODEV;
        }

        /* Wait until we have received keyboard controller EC byte
         * max wait = 5*10(ms)*20 = 1000 ms, timer tick = 10ms
         */
        cmd_retries = 20;
        while (cmd_busy && cmd_retries) {
            aip_dbg(" ... cmd_busy = %02x\n", cmd_busy);
            aipsokbps_timeout(5);
            --cmd_retries;
        }

        if (pKbdData->EC_Level != 0) {
            aip_info("Found SureOne keyboard controller, EC Level %d\n",
                     pKbdData->EC_Level);
        } else {
            /* Did not find a Keyboard Controller */
            aip_error("No SureOne keyboard controller found\n");

            sokb_real_serio = NULL;
            serio_close(serio);
            return -ENODEV;
        }

        aip_dbg("_init() -->Initializing MSR\n");
    }

    if (machine_type == IBM_4613) {
        pKbdData->fStatus |= SET_MSR_PREFIX;
        for (count = 0; count <= 2; count++) {
            /* For first command */
            for (state = 1; state <= 4; state++) {
                aipsokbps_timeout(10);
                rc = set_msrprefix(state,count);
                if (rc != 0) {
                    aip_error("set_msrprefix failed rc=%02x\n", rc);

                    sokb_real_serio = NULL;
                    serio_close(serio);
                    rc = -ENODEV;
                    break;
                }

                /* Wait until we have received keyboard controller EC byte
                 * max wait = 5*10(ms)*20 = 1000 ms, timer tick = 10ms
                 */
                cmd_retries = 5;
                while (cmd_busy && cmd_retries) {
                    aip_dbg(" ... cmd_busy = %02x\n", cmd_busy);
                    aipsokbps_timeout(5);
                    --cmd_retries;
                }

                if (state == 4) {

                    if (pKbdData->mStatus == SCANCODE_ACK) {
                        aip_dbg("ACK Received\n");
                        /*Wait for the next byte*/

                        cmd_busy = 1;
                        aip_dbg("Waiting on 0x02\n");

                        cmd_retries = 5;
                        while (cmd_busy && cmd_retries) {
                            aip_dbg(" ... cmd_busy = %02x\n", cmd_busy);
                            aipsokbps_timeout(5);
                            --cmd_retries;
                        }
                        cmd_busy = 0;
                    }
                    if (pKbdData->mStatus == SCANCODE_ONE) {
                        rcvd02 = 1;
                    } else if (pKbdData->mStatus ==
                               BREAK_SCANCODE(SCANCODE_ONE)) {
                        rcvd82 = 1;
                    }

                    if (rcvd02 == 1) {
                        cmd_busy = 1;
                        aip_dbg("Waiting on 0x82\n");

                        /*Wait for the next byte*/
                        cmd_retries = 5;
                        while (cmd_busy && cmd_retries) {
                            aip_dbg(" ... cmd_busy = %02x\n", cmd_busy);
                            aipsokbps_timeout(5);
                            --cmd_retries;
                        }
                        cmd_busy = 0;
                    }

                    if (pKbdData->mStatus == SCANCODE_ONE) {
                        rcvd02 = 1;
                    } else if (pKbdData->mStatus ==
                               BREAK_SCANCODE(SCANCODE_ONE)) {
                        rcvd82 = 1;
                    }

                    if (rcvd02 == 0 || rcvd82 == 0) {
                        aip_dbg("0x02 and 0x82 not received... delaying to allow time\n");
                        cmd_busy = 1;
                        /*wait last time for the reply pair*/
                        /*Wait for the next byte*/
                        cmd_retries = 5;
                        while (cmd_busy && cmd_retries) {
                            aip_dbg(" ... cmd_busy = %02x\n", cmd_busy);
                            aipsokbps_timeout(5);
                            --cmd_retries;
                        }
                        cmd_busy = 0;
                    }
                } else {
                    if (pKbdData->mStatus == SCANCODE_ACK) {
                        aip_dbg("ACK Received\n");
                    } else if (pKbdData->mStatus == SCANCODE_RESEND) {
                        if (resend_retries == 5) {
                            aip_dbg("BAIL OUT..WE HAVE BEEN NACKED 5 times\n");

                            sokb_real_serio = NULL;
                            serio_close(serio);
                            rc = -ENODEV;
                            break;
                        }
                        aip_dbg("NACK RECEIVED?->0x%02x then Retry\n",
                                pKbdData->mStatus);
                        state--;
                        resend_retries++;
                    } else {
                        aip_dbg("Retry -> UNKNOWN REPLY RECEIVED?->0x%02x\n",
                                pKbdData->mStatus);

                        if (resend_retries == 5) {
                            aip_dbg("BAIL OUT..WE HAVE TRIED LONG ENOUGH\n");

                            sokb_real_serio = NULL;
                            serio_close(serio);
                            rc = -ENODEV;
                            break;
                        }
                        state--;
                        resend_retries++;
                    }
                }
            }

            if (rc != 0)
                break;
        }
        pKbdData->fStatus &= ~SET_MSR_PREFIX;
    }

    if (rc != 0)
        return rc;
    /* Initialise MSR variables and objects */
    msr_init();

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 18)
    /* Register as a device with kernel. */
    rc = sokb_device_create(aipsokbps_major, DEVDRVR_ID, &sokb_fops);
#else
    /* Request dynamic allocation of a device major number */
    if (javapos != 0) {
        dev_count = 2;
    }
    rc = sokb_device_create((char *) DEVDRVR_ID, dev_names, dev_count,
                            "aipsokbps", &Adapter, &sokb_fops);
#endif

    if (rc != 0) {
        aip_error("Register device with kernel failed rc=0x%02x\n", rc);

        sokb_real_serio = NULL;
        serio_close(serio);
        return -ENODEV;
    }

    rc = sokb_create_kbd_port(serio);

    if (rc != 0) {
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 18)
        sokb_device_destroy(aipsokbps_major, DEVDRVR_ID);
#else
        sokb_device_destroy(&Adapter);
#endif

        sokb_real_serio = NULL;
        serio_close(serio);
        return rc;
    }

    aip_info("Loaded, rc=%d\n", -rc);

    return rc;
}
#endif


#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 16)
static int sokb_port_enabled = 0;

static int sokb_port_write(struct serio *serio, unsigned char data)
{
    int rc;

    if (!sokb_serio || !sokb_port_enabled)
        return -ENODEV;

    if (down_trylock(&sokb_sema))
        return -EBUSY;

    rc = sokb_write(data);

    up(&sokb_sema);

    return rc;
}

static int sokb_port_open(struct serio *serio)
{
    sokb_port_enabled = 1;
    return 0;
}

static void sokb_port_close(struct serio *serio)
{
    sokb_port_enabled = 0;
}

static int sokb_port_start(struct serio *serio)
{
    return 0;
}

static void sokb_port_stop(struct serio *serio)
{
}

static int sokb_create_kbd_port(struct serio *serio)
{
    sokb_serio = kzalloc(sizeof(struct serio), GFP_KERNEL);
    if (!sokb_serio)
        return -ENOMEM;

    sokb_serio->id.type = serio->id.type;
    sokb_serio->write   = sokb_port_write;
    sokb_serio->open    = sokb_port_open;
    sokb_serio->close   = sokb_port_close;
    sokb_serio->start   = sokb_port_start;
    sokb_serio->stop    = sokb_port_stop;
    strlcpy(sokb_serio->name, "aipsokbps virtual i8042 Kbd Port",
            sizeof(sokb_serio->name));
    strlcpy(sokb_serio->phys, AIPSOKBPS_PHYS_NAME, sizeof(sokb_serio->phys));

    serio_register_port(sokb_serio);

    return 0;
}


#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 19)
static irqreturn_t sokb_interrupt(struct serio *serio, unsigned char data,
                                  unsigned int flags, struct pt_regs *regs)
{
    if (!pos_scancode_filter(&data) && sokb_port_enabled) {
        serio_interrupt(sokb_serio, data, flags, regs);
    }

    return IRQ_HANDLED;
}
#else
static irqreturn_t sokb_interrupt(struct serio *serio, unsigned char data,
                                  unsigned int flags)
{
    if (!pos_scancode_filter(&data) && sokb_port_enabled) {
        serio_interrupt(sokb_serio, data, flags);
    }

    return IRQ_HANDLED;
}
#endif


static int sokb_reconnect(struct serio *serio)
{
    if (sokb_port_enabled)
        serio_reconnect(sokb_serio);

    return 0;
}


static void sokb_disconnect(struct serio *serio)
{
    if ((serio != NULL) && (sokb_real_serio == serio)) {
        aip_dbg("Disconnect from name='%s', phys='%s'\n",
                serio->name, serio->phys);

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 18)
        sokb_device_destroy(sokb_major, DEVDRVR_ID);
#else
        sokb_device_destroy(&Adapter);
#endif

        serio_unregister_port(sokb_serio);

        sokb_real_serio = NULL;

        serio_close(serio);
    }
}


static void sokb_cleanup(struct serio *serio)
{
}


static struct serio_device_id sokb_serio_ids[] = {
    {
        .type   = SERIO_8042,
        .proto  = SERIO_ANY,
        .id = SERIO_ANY,
        .extra  = SERIO_ANY,
    },
    {
        .type   = SERIO_8042_XL,
        .proto  = SERIO_ANY,
        .id = SERIO_ANY,
        .extra  = SERIO_ANY,
    },
    { 0}
};


MODULE_DEVICE_TABLE(serio, sokb_serio_ids);

static struct serio_driver sokb_drv = {
    .driver     = {
        .name   = "aipsokbps",
    },
    .description = DRIVER_DESC,
    .id_table   = sokb_serio_ids,
    .interrupt  = sokb_interrupt,
    .connect    = sokb_connect,
    .reconnect  = sokb_reconnect,
    .disconnect = sokb_disconnect,
    .cleanup    = sokb_cleanup,
};
#endif

static int __init sokb_init(void)
{
    int err = 0;

    /* Initialize keyboard data structure */
    memset(&KbdData, 0, sizeof(KEYBOARD_DATA));
    pKbdData = &KbdData;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 18)
    memset(&Adapter, 0, sizeof(sokb_adapter));
#endif

    if (machine_type == IBM_4613)
        aip_info("Found Toshiba 4613 Anyplace Kiosk machine\n");
    else if (machine_type == IBM_4614  && check_model() == TRUE && IS_SUREONE(model))
        aip_info("Found Toshiba 4614 SureOne Machine\n");
    else {
        aip_error("This driver only supports either SureOne or Toshiba 4613\n");
        return -ENOSYS;
    }


#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 16)
    err = sokb_do_patch_kb_init();
#else
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 18)
    memset(&Adapter, 0, sizeof(sokb_adapter));
#endif

#ifndef init_MUTEX
    sema_init(&sokb_sema, 1);
#else
    init_MUTEX(&sokb_sema);
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 21)
    err = serio_register_driver(&sokb_drv);
#else
    serio_register_driver(&sokb_drv);
#endif
#endif

    return err;
}



/************************************************************************
 *
 * Function Name:  sokb_exit()
 *
 * Purpose:        driver exit routine.
 *
 * Description:    This routine gets called when driver unloads.
 *
 *
 * Output:
 *                 none
 *
 * ***********************************************************************
 */
static void __exit sokb_exit(void)
{
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 16)
    /* Unregister driver with the kernel */
    sokb_device_destroy(aipsokbps_major, DEVDRVR_ID);

    /* Unregister with atkbd / pc_keyb driver. */
    unregister_pc_keyb_filter(&pos_filter);
#else
    serio_unregister_driver(&sokb_drv);
#endif

    aip_dbg("Module unloaded\n");
}

module_init(sokb_init);
module_exit(sokb_exit);

MODULE_AUTHOR("Toshiba Global Commerce Solutions, Inc");
MODULE_DESCRIPTION("Toshiba SureOne Keyboard Driver");
MODULE_LICENSE("GPL");
