/*
 *  Module Name:     aipikpssc.h
 *
 *  Description:     keyboard kernel driver include
 *
 *  Copyright (C) 2004-2015 Toshiba Global Commerce Solutions, Inc.
 *  All right reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA; Otherwise,
 *  see <http://www.gnu.org/licenses/>.
 *
 *
 * Should you need to contact me, the author, you can do so either by
 * e-mail - mail your message to <gha@toshibagcs.com>.
 */

#ifndef AIPIKBPSSC_H
#define AIPIKBPSSC_H


/* *********************************************************************
 * MSR  Resolve this later How to make Global with or without static
 * for now remove static whenever other modules need the variable
 * *********************************************************************
 */

static DEVICE_INFO KBDdevinfo;
static DEVICE_INFO MSRdevinfo;
static unsigned char   ECLevelMSR = 0;
static unsigned char   keyLockState = 0;
static unsigned char   ECBitMSR = OB_EC_BIT;


/* Keyboard Buffer */
static unsigned char keyBuffer[20] =
{
    0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0
};

static unsigned short keyBufferIndex = 0;
static unsigned char scanFlag = 0;

static  unsigned char POSSpecific [140] = {
/*        0  1  2  3  4  5  6  7  8  9 */
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,     /* 00_ (NANPOS) */
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,     /* 01_          */
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,     /* 02_          */
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,     /* 03_          */
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,     /* 04_          */
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,     /* 05_          */
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,     /* 06_          */
    0, 0, 0, 0, 0, 0, 0, 1, 1, 0,     /* 07_          */
    0, 0, 1, 0, 0, 0, 0, 1, 1, 0,     /* 08_          */
    1, 0, 0, 0, 0, 1, 0, 0, 0, 1,     /* 09_          */
    1, 0, 0, 0, 0, 1, 1, 1, 1, 0,     /* 10_          */
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,     /* 11_          */
    0, 0, 0, 0, 1, 1, 1, 1, 1, 0,     /* 12_          */
    0, 0, 0, 0, 0, 1, 0, 0, 0, 0      /* 13_          */
};

/* **********************************************************************
 * This table is used to by the remapping function to remap scancodes
 * for some of the keys in OS/2 sessions only.
 *
 * Note for Windows NT:
 *
 *   The key switch 100 is changed to 0x7C to 0x65
 *
 * Remap scancode by key
 * **********************************************************************
 */
static  unsigned char  RemapTable[ 140 ] = {
/*     __0   __1   __2   __3   __4   __5   __6   __7   __8   __9 */
    0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,    /* 00_ (NANPOS) */
    0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,    /* 01_          */
    0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,    /* 02_          */
    0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,    /* 03_          */
    0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,    /* 04_          */
    0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,    /* 05_          */
    0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,    /* 06_          */
    0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x6A, 0x6B, 0x0,    /* 07_          */
    0x0,  0x0,  0x6C, 0x0,  0x0,  0x0,  0x0,  0x6D, 0x6E, 0x0,    /* 08_          */
    0x6F, 0x0,  0x0,  0x0,  0x0,  0x78, 0x0,  0x0,  0x0,  0x77,   /* 09_          */
    0x65, 0x0,  0x0,  0x0,  0x0,  0x7A, 0x7E, 0x5F, 0x71, 0x0,    /* 10_          */
    0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,    /* 11_          */
    0x0,  0x0,  0x0,  0x0,  0x63, 0x74, 0x75, 0x76, 0x59, 0x0,    /* 12_          */
    0x0,  0x0,  0x0,  0x0,  0x0,  0x72, 0x0,  0x0,  0x0,  0x0     /* 13_          */

};

#if defined(V4690)
/* **********************************************************************
 * This table is used to by the remapping function to remap scancodes
 * when in "4690 mode".
 *
 * Remap scancode by key
 * **********************************************************************
 */
static  unsigned char  RemapTable4690[ 140 ] = {
/*     __0   __1   __2   __3   __4   __5   __6   __7   __8   __9 */
       0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,    /* 00_ (NANPOS) */
       0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,    /* 01_          */
       0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,    /* 02_          */
       0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,    /* 03_          */
       0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,    /* 04_          */
       0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,    /* 05_          */
       0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,    /* 06_          */
       0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x5A, 0x6D, 0x0,    /* 07_          */
       0x0,  0x0,  0x74, 0x0,  0x0,  0x0,  0x0,  0x6A, 0x6F, 0x0,    /* 08_          */
       0x6B, 0x0,  0x0,  0x0,  0x6C, 0x53, 0x0,  0x0,  0x0,  0x52,   /* 09_          */
       0x37, 0x0,  0x0,  0x0,  0x6E, 0x4A, 0x4E, 0x7E, 0x59, 0x0,    /* 10_          */
       0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,  0x0,    /* 11_          */
       0x0,  0x0,  0x0,  0x0,  0x5E, 0x5F, 0x55, 0x77, 0x78, 0x0,    /* 12_          */
       0x0,  0x0,  0x0,  0x0,  0x0,  0x5D, 0x0,  0x0,  0x0,  0x0     /* 13_          */

};
#endif

/* **********************************************************************
 * The table below is used to convert scancode values that are inside the
 * keyboard status and MSR status frames.  Most of the values do not get
 * altered, but a couple do.  It was much easier to create this table
 * than writing switch statements in the code.
 * **********************************************************************
 *
 *         0     1     2     3     4     5     6     7     8     9     A     B     C     D     E     F
 */
/*table to convert status bytes */
static  unsigned char convert[256] = {
    0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F,  /* 0_ */
    0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F,  /* 1_ */
    0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x29, 0x2A, 0x2B, 0x2C, 0x2D, 0x2E, 0x2F,  /* 2_ */
    0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3A, 0x3B, 0x3C, 0x3D, 0x3E, 0x3F,  /* 3_ */
    0x40, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49, 0x4A, 0x4B, 0x4C, 0x4D, 0x4E, 0x4F,  /* 4_ */
    0x50, 0x51, 0x52, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58, 0x59, 0x5A, 0x5B, 0x5C, 0x5D, 0x5E, 0x5F,  /* 5_ */
    0x60, 0x61, 0x62, 0x63, 0x64, 0x65, 0x66, 0x67, 0x68, 0x69, 0x6A, 0x6B, 0x6C, 0x6D, 0x6E, 0x6F,  /* 6_ */
    0x70, 0x71, 0x72, 0x73, 0x74, 0x75, 0x76, 0x77, 0x78, 0x79, 0x7A, 0x7B, 0x7C, 0x7D, 0x7E, 0x7F,  /* 7_ */
    0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F,  /* 8_ */
    0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F,  /* 9_ */
    0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x29, 0x2A, 0x2B, 0x2C, 0x2D, 0x2E, 0x2F,  /* A_ */
    0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3A, 0x3B, 0x3C, 0x3D, 0x3E, 0x3F,  /* B_ */
    0x40, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49, 0x4A, 0x4B, 0x4C, 0x4D, 0x4E, 0x4F,  /* C_ */
    0x50, 0x51, 0x52, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58, 0x59, 0x5A, 0x5B, 0x5C, 0x5D, 0x5E, 0x5F,  /* D_ */
    0x60, 0x61, 0x62, 0x63, 0x64, 0x65, 0x66, 0x67, 0x68, 0x69, 0x2A, 0x6B, 0x6C, 0x6D, 0x6E, 0x6F,  /* E_ */
    0x70, 0x71, 0x72, 0x03, 0x04, 0x75, 0x76, 0x77, 0x78, 0x79, 0x7A, 0x2B, 0x7C, 0x7D, 0x7E, 0x7F  /* F_  */
};


/* **********************************************************************
 * The E2Table is indexed by keyboard and scancode to lookup a key value.
 * The first portion of the table is for the ANPOS keyboard and the next
 * portion of the table is for the NANPOS keyboard.
 *
 * NOTE: This table will only be accessed on systems with translating
 *       keyboard controllers.  If the system has a non-translating
 *       controller, the keyboard it set to scan set 1 and E2 will not
 *       be received.  If the system has a translating controller, the
 *       keyboard remains in scan set 2 and most of the scancodes coming
 *       in are translated by the controller.  The scancodes for the POS
 *       unique keys are unknown to the keyboard controller and are not
 *       translated.
 *
 * **********************************************************************
 */
static  unsigned char  E2Table[ 22 ] = {
/*       x0  x1  x2  x3  x4  x5  x6  x7  x8  x9  xA  xB  xC  xD  xE  xF */
    77, 78, 82, 87, 88, 90,107,
    0,  0,  0,108,135,124,125,126,127, 99, 95,100,105,106,128
};


/* **********************************************************************
 * The E0Table is indexed by keyboard, scancode.  This table is used to
 * determine the key that was pressed when an E0 is the first character
 * in the buffer.  The possibilities are:
 *
 *  E0 sc          - MAKE of key associated with sc
 *  E0 F0 sc       - BREAK of key associates with sc
 *
 * **********************************************************************
 */
/* Lookup table for E0 scan sequences */
static  unsigned char  E0Table[ 2 ][ 256 ] = {
/*      x0   x1  x2 x3  x4   x5  x6 x7  x8  x9  xA  xB  xC  xD  xE  xF */
    {  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  /* 0_ (ANPOS)  */
        0,  0, 44,  0,  0,  0,  0,  0,  0,  0,  0,  0,109, 64,  0,  0,  /* 1_          */
        0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 44,  0,  0,  0,  0,  0,  /* 2_          */
        0,  0,  0,  0,  0,  0, 56,131, 62,  0,  0,  0,  0,  0,  0,  0,  /* 3_          */
        0,  0,  0,  0,  0,  0,132, 80, 83, 85,  0, 79,  0, 89,  0, 81,  /* 4_          */
        84, 86, 75, 76,  0,  0,  0,  0,  0, 56,  0,  0,  0,  0,  0,  0,  /* 5_          */
        0,  0,  0,  0,  0,  0,  0,  0,  0, 81,  0, 79, 80,  0,  0,  0,  /* 6_          */
        75, 76, 84,  0, 89, 83,  0,  0,  0,  0, 86,  0,131, 85,132,  0,  /* 7_          */
        0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  /* 8_          */
        0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,109, 64,  0,  0,  /* 9_          */
        0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 44,  0,  0,  0,  0,  0,  /* A_          */
        0,  0,  0,  0,  0,  0, 56,131, 62,  0,  0,  0,  0,  0,  0,  0,  /* B_          */
        0,  0,  0,  0,  0,  0,132, 80, 83, 85,  0, 79,  0, 89,  0, 81,  /* C_          */
        84, 86, 75, 76,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  /* D_          */
        0,  0,  0,  0,  0,  0,  0,  0,  0, 81,  0, 79, 80,  0,  0,  0,  /* E_          */
        75, 76, 84,  0, 89, 83,  0,  0,  0,  0, 86,  0,131, 85,132,  0},  /* F_        */

    {  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  /* 0_ (NANPOS) */
        0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,109, 64,  0,  0,  /* 1_          */
        0,  0,  0,  0,  0,  0, 56,  0,  0,  0, 44,  0,  0,  0,  0,  0,  /* 2_          */
        0,  0,  0,  0,  0,  0,  0,136, 62,  0,  0,  0,  0,  0,  0,  0,  /* 3_          */
        0,  0,  0,  0,  0,  0,138, 80, 83, 85,  0, 79,  0, 89,  0, 81,  /* 4_          */
        84, 86, 75, 76,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  /* 5_          */
        0,  0,  0,  0,  0,  0,  0,  0,  0, 81,  0, 79, 80,  0,  0,  0,  /* 6_          */
        75, 76, 84,  0, 89, 83,  0,  0,  0,  0, 86,  0,136, 85,138,  0,  /* 7_          */
        0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  /* 8_          */
        0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,109, 64,  0,  0,  /* 9_          */
        0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 44,  0,  0,  0,  0,  0,  /* A_          */
        0,  0,  0,  0,  0,  0, 56,136, 62,  0,  0,  0,  0,  0,  0,  0,  /* B_          */
        0,  0,  0,  0,  0,  0,138, 80, 83, 85,  0, 79,  0, 89,  0, 81,  /* C_          */
        84, 86, 75, 76,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  /* D_          */
        0,  0,  0,  0,  0,  0,  0,  0,  0, 81,  0, 79, 80,  0,  0,  0,  /* E_          */
        75, 76, 84,  0, 89, 83,  0,  0,  0,  0, 86,  0,136, 85,138,  0} /* F_          */

};

/* Lookup table for scan set 1  */
static  unsigned char  ScanSet1Table[ 256 ] = {
/*     x0  x1  x2  x3  x4  x5  x6  x7  x8  x9  xA  xB  xC  xD  xE  xF */
    0,110,  2,  3,  4,  5,  6,  7,  8,  9, 10, 11, 12, 13, 15, 16,  /* 0_ (NANPOS)  */
    17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 43, 58, 31, 32,  /* 1_           */
    33, 34, 35, 36, 37, 38, 39, 40, 41,  1, 44, 42, 46, 47, 48, 49,  /* 2_           */
    50, 51, 52, 53, 54, 55, 57,136, 60, 61, 30,112,113,114,115,116,  /* 3_           */
    117,118,119,120,121,139,137, 91, 96,101,  0, 92, 97,102,  0, 93,  /* 4_           */
    98,103, 94,104,136,  0, 45,122,123, 77, 78, 82, 87, 88, 90,107,  /* 5_           */
    0,  0,  0,108,135,124,125,126,127, 99, 95,100,105,106,128,  0,  /* 6_           */
    133,  0,  0, 56,  0,  0,  0,  0,124,132,  0,131,135, 14,  0,  0,  /* 7_           */
    0,110,  2,  3,  4,  5,  6,  7,  8,  9, 10, 11, 12, 13, 15, 16,  /* 8_           */
    17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 43, 58, 31, 32,  /* 9_           */
    33, 34, 35, 36, 37, 38, 39, 40, 41, 01, 44, 42, 46, 47, 48, 49,  /* A_           */
    50, 51, 52, 53, 54, 55, 57,136, 60, 61, 30,112,113,114,115,116,  /* B_           */
    117,118,119,120,121,139,137, 91, 96,101,  0, 92, 97,102,  0, 93,  /* C_           */
    98,103, 94,104,136,  0, 45,122,123, 77, 78, 82, 87, 88, 90,107,  /* D_           */
    0,  0,  0,108,135,124,125,126,127, 99, 95,100,105,106,128,  0,  /* E_           */
    133,  0,  0, 56,  0,  0,  0,  0,124,132,  0,131,135, 14,  0,  0   /* F_           */
};

/* **********************************************************************
 * The following table is used to determine what scancodes get sent when
 * we know that there is a certain key pressed.  This is used if the
 * call to get a remapped value fails.  This table is indexed by ANPOS/
 * NANPOS, controller type.  We will use the remap logic to do the
 * standard Intrepid scancode remapping.
 *
 *  Change for Key switch 108: (@h)
 *    - removed 0xE0 from Nanpos Scanset 1 table
 *
 * **********************************************************************
 */
static unsigned char  ScancodesToGo[ 140 ][ 4 ] = {
    /* ANPOS                               */
    /* ScanSet2 (Controller Type 1)        */
    /* ScanSet 1 Make (Controller Type 2)  */
    {0x00,0x00,0x00,0x00},       /* Key 000 (placeholder)   */
    {0x29,0x00,0x00,0x00},       /* Key 001                 */
    {0x02,0x00,0x00,0x00},       /* Key 002                 */
    {0x03,0x00,0x00,0x00},       /* Key 003                 */
    {0x04,0x00,0x00,0x00},       /* Key 004                 */
    {0x05,0x00,0x00,0x00},       /* Key 005                 */
    {0x06,0x00,0x00,0x00},       /* Key 006                 */
    {0x07,0x00,0x00,0x00},       /* Key 007                 */
    {0x08,0x00,0x00,0x00},       /* Key 008                 */
    {0x09,0x00,0x00,0x00},       /* Key 009                 */
    {0x0A,0x00,0x00,0x00},       /* Key 010                 */
    {0x0B,0x00,0x00,0x00},       /* Key 011                 */
    {0x0C,0x00,0x00,0x00},       /* Key 012                 */
    {0x0D,0x00,0x00,0x00},       /* Key 013                 */
    {0x7D,0x00,0x00,0x00},       /* Key 014                 */
    {0x0E,0x00,0x00,0x00},       /* Key 015                 */
    {0x0F,0x00,0x00,0x00},       /* Key 016                 */
    {0x10,0x00,0x00,0x00},       /* Key 017                 */
    {0x11,0x00,0x00,0x00},       /* Key 018                 */
    {0x12,0x00,0x00,0x00},       /* Key 019                 */
    {0x13,0x00,0x00,0x00},       /* Key 020                 */
    {0x14,0x00,0x00,0x00},       /* Key 021                 */
    {0x15,0x00,0x00,0x00},       /* Key 022                 */
    {0x16,0x00,0x00,0x00},       /* Key 023                 */
    {0x17,0x00,0x00,0x00},       /* Key 024                 */
    {0x18,0x00,0x00,0x00},       /* Key 025                 */
    {0x19,0x00,0x00,0x00},       /* Key 026                 */
    {0x1A,0x00,0x00,0x00},       /* Key 027                 */
    {0x1B,0x00,0x00,0x00},       /* Key 028                 */
    {0x1C,0x00,0x00,0x00},       /* Key 029                 */
    {0x3A,0x00,0x00,0x00},       /* Key 030                 */
    {0x1E,0x00,0x00,0x00},       /* Key 031                 */
    {0x1F,0x00,0x00,0x00},       /* Key 032                 */
    {0x20,0x00,0x00,0x00},       /* Key 033                 */
    {0x21,0x00,0x00,0x00},       /* Key 034                 */
    {0x22,0x00,0x00,0x00},       /* Key 035                 */
    {0x23,0x00,0x00,0x00},       /* Key 036                 */
    {0x24,0x00,0x00,0x00},       /* Key 037                 */
    {0x25,0x00,0x00,0x00},       /* Key 038                 */
    {0x26,0x00,0x00,0x00},       /* Key 039                 */
    {0x27,0x00,0x00,0x00},       /* Key 040                 */
    {0x28,0x00,0x00,0x00},       /* Key 041                 */
    {0x2B,0x00,0x00,0x00},       /* Key 042                 */
    {0x1C,0x00,0x00,0x00},       /* Key 043                 */
    {0x2A,0x00,0x00,0x00},       /* Key 044                 */
    {0x56,0x00,0x00,0x00},       /* Key 045                 */
    {0x2C,0x00,0x00,0x00},       /* Key 046                 */
    {0x2D,0x00,0x00,0x00},       /* Key 047                 */
    {0x2E,0x00,0x00,0x00},       /* Key 048                 */
    {0x2F,0x00,0x00,0x00},       /* Key 049                 */
    {0x30,0x00,0x00,0x00},       /* Key 050                 */
    {0x31,0x00,0x00,0x00},       /* Key 051                 */
    {0x32,0x00,0x00,0x00},       /* Key 052                 */
    {0x33,0x00,0x00,0x00},       /* Key 053                 */
    {0x34,0x00,0x00,0x00},       /* Key 054                 */
    {0x35,0x00,0x00,0x00},       /* Key 055                 */
    {0x73,0x00,0x00,0x00},       /* Key 056                 */
    {0x36,0x00,0x00,0x00},       /* Key 057                 */
    {0x1D,0x00,0x00,0x00},       /* Key 058                 */
    {0x00,0x00,0x00,0x00},       /* Key 059                 */
    {0x38,0x00,0x00,0x00},       /* Key 060                 */
    {0x39,0x00,0x00,0x00},       /* Key 061                 */
    {0xE0,0x38,0x00,0x00},       /* Key 062                 */
    {0x00,0x00,0x00,0x00},       /* Key 063                 */
    {0xE0,0x1D,0x00,0x00},       /* Key 064                 */
    {0x00,0x00,0x00,0x00},       /* Key 065                 */
    {0x00,0x00,0x00,0x00},       /* Key 066                 */
    {0x00,0x00,0x00,0x00},       /* Key 067                 */
    {0x00,0x00,0x00,0x00},       /* Key 068                 */
    {0x00,0x00,0x00,0x00},       /* Key 069                 */
    {0x00,0x00,0x00,0x00},       /* Key 070                 */
    {0x00,0x00,0x00,0x00},       /* Key 071                 */
    {0x00,0x00,0x00,0x00},       /* Key 072                 */
    {0x00,0x00,0x00,0x00},       /* Key 073                 */
    {0x00,0x00,0x00,0x00},       /* Key 074                 */
    {0xE0,0x52,0x00,0x00},       /* Key 075                 */
    {0xE0,0x53,0x00,0x00},       /* Key 076                 */
    {0x59,0x00,0x00,0x00},       /* Key 077                 */
    {0x5A,0x00,0x00,0x00},       /* Key 078                 */
    {0xE0,0x4B,0x00,0x00},       /* Key 079                 */
    {0xE0,0x47,0x00,0x00},       /* Key 080                 */
    {0xE0,0x4F,0x00,0x00},       /* Key 081                 */
    {0x5B,0x00,0x00,0x00},       /* Key 082                 */
    {0xE0,0x48,0x00,0x00},       /* Key 083                 */
    {0xE0,0x50,0x00,0x00},       /* Key 084                 */
    {0xE0,0x49,0x00,0x00},       /* Key 085                 */
    {0xE0,0x51,0x00,0x00},       /* Key 086                 */
    {0x5C,0x00,0x00,0x00},       /* Key 087                 */
    {0x5D,0x00,0x00,0x00},       /* Key 088                 */
    {0xE0,0x4D,0x00,0x00},       /* Key 089                 */
    {0x5E,0x00,0x00,0x00},       /* Key 090                 */
    {0x47,0x00,0x00,0x00},       /* Key 091                 */
    {0x4B,0x00,0x00,0x00},       /* Key 092                 */
    {0x4F,0x00,0x00,0x00},       /* Key 093                 */
    {0x52,0x00,0x00,0x00},       /* Key 094                 */
    {0x6A,0x00,0x00,0x00},       /* Key 095                 */
    {0x48,0x00,0x00,0x00},       /* Key 096                 */
    {0x4C,0x00,0x00,0x00},       /* Key 097                 */
    {0x50,0x00,0x00,0x00},       /* Key 098                 */
    {0x69,0x00,0x00,0x00},       /* Key 099                 */
    {0x6B,0x00,0x00,0x00},       /* Key 100                 */
    {0x49,0x00,0x00,0x00},       /* Key 101                 */
    {0x4D,0x00,0x00,0x00},       /* Key 102                 */
    {0x51,0x00,0x00,0x00},       /* Key 103                 */
    {0x53,0x00,0x00,0x00},       /* Key 104                 */
    {0x6C,0x00,0x00,0x00},       /* Key 105                 */
    {0x6D,0x00,0x00,0x00},       /* Key 106                 */
    {0x5F,0x00,0x00,0x00},       /* Key 107                 */
    {0x63,0x00,0x00,0x00},       /* Key 108                 */
    {0x1C,0x00,0x00,0x00},       /* Key 109  @h             */
    {0x01,0x00,0x00,0x00},       /* Key 110                 */
    {0x00,0x00,0x00,0x00},       /* Key 111                 */
    {0x3B,0x00,0x00,0x00},       /* Key 112                 */
    {0x3C,0x00,0x00,0x00},       /* Key 113                 */
    {0x3D,0x00,0x00,0x00},       /* Key 114                 */
    {0x3E,0x00,0x00,0x00},       /* Key 115                 */
    {0x3F,0x00,0x00,0x00},       /* Key 116                 */
    {0x40,0x00,0x00,0x00},       /* Key 117                 */
    {0x41,0x00,0x00,0x00},       /* Key 118                 */
    {0x42,0x00,0x00,0x00},       /* Key 119                 */
    {0x43,0x00,0x00,0x00},       /* Key 120                 */
    {0x44,0x00,0x00,0x00},       /* Key 121                 */
    {0x57,0x00,0x00,0x00},       /* Key 122                 */
    {0x58,0x00,0x00,0x00},       /* Key 123                 */
    {0x65,0x00,0x00,0x00},       /* Key 124                 */
    {0x66,0x00,0x00,0x00},       /* Key 125                 */
    {0x67,0x00,0x00,0x00},       /* Key 126                 */
    {0x68,0x00,0x00,0x00},       /* Key 127                 */
    {0x6E,0x00,0x00,0x00},       /* Key 128                 */
    {0x00,0x00,0x00,0x00},       /* Key 129                 */
    {0x00,0x00,0x00,0x00},       /* Key 130                 */
    {0x7B,0x00,0x00,0x00},       /* Key 131                 */
    {0x79,0x00,0x00,0x00},       /* Key 132                 */
    {0x70,0x00,0x00,0x00},       /* Key 133                 */
    {0x00,0x00,0x00,0x00},       /* Key 134                 */
    {0x64,0x00,0x00,0x00},       /* Key 135                 */
    {0x37,0x00,0x00,0x00},       /* Key 136                 */
    {0x46,0x00,0x00,0x00},       /* Key 137                 */
    {0xE1,0x1D,0x45,0x00},       /* Key 138                 */
    {0x45,0x00,0x00,0x00}        /* Key 139                 */
};

/* Holds scancodes for caps lock, num lock, scroll lock. */

#endif
