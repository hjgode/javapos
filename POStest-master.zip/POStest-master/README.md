POStest
=======

Open Source project designed to give developers a GUI based utility for exercising POS devices using JavaPOS. http://postest.sourceforge.net/